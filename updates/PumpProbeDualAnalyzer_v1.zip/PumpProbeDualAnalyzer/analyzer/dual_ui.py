"""Standalone dual-channel analysis UI; all I/O and optimization run in a worker."""
from pathlib import Path
from threading import Event
import numpy as np
from PyQt5.QtCore import Qt, QTimer, QThreadPool
from PyQt5.QtWidgets import (QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QFormLayout,
    QGroupBox,QTabWidget,QScrollArea,QSplitter,QLabel,QLineEdit,QDoubleSpinBox,
    QSpinBox,QComboBox,QCheckBox,QPushButton,QPlainTextEdit,QFileDialog,QTableWidget,
    QTableWidgetItem,QHeaderView,QAbstractItemView)
from . import core
from .dual_core import load_dual_pair,prepare_dual,compare_fits
from .io import associated_notes
from .dual_figure import DualFigure
from .dialogs import ExportFolderDialog
from .tasks import Job
from .presentation import angle_unit

STYLE='''
QMainWindow {background:#edf2f7;}
QGroupBox {background:white;border:1px solid #d8e2ec;border-radius:7px;margin-top:12px;padding:10px;}
QGroupBox::title {subcontrol-origin:margin;left:10px;color:#25435d;padding:0 4px;}
QLineEdit,QComboBox,QSpinBox,QDoubleSpinBox {min-height:25px;}
QPushButton {padding:7px 10px;background:#f5f8fc;color:#194764;border:1px solid #bfcedb;border-radius:4px;}
QPushButton#primary {background:#126e96;color:white;}
QPushButton:disabled {color:#93a2ae;}
QTabBar::tab {padding:9px 15px;min-height:22px;}
QTableWidget {background:white;gridline-color:#e1e8f0;}
'''


def spin(value=0,low=-1e12,high=1e12,decimals=6):
    w=QDoubleSpinBox();w.setDecimals(decimals);w.setRange(low,high);w.setValue(value)
    w.setKeyboardTracking(False);w.setSingleStep(.01);return w


def numerical(field):
    value=field.value() if hasattr(field,'value') else float(field.text().strip().replace(',','.'))
    if not np.isfinite(value):raise ValueError('Числа должны быть конечными.')
    return value


class ChannelControls(QWidget):
    """Editable, SI-backed initial parameters for a single independent fit."""
    def __init__(self,owner,index):
        super().__init__();self.owner,self.index=owner,index;self.scales=[]
        layout=QVBoxLayout(self)
        group=QGroupBox('Модель и полоса FFT');form=QFormLayout(group)
        self.model=QComboBox();self.model.addItems(['Один затухающий синус + C','Сумма затухающих синусов + C'])
        self.count=QSpinBox();self.count.setRange(2,6);self.count.setValue(2)
        form.addRow('Модель',self.model);form.addRow('Число синусов',self.count)
        self.auto_band=QCheckBox('Автоматическая полоса FFT');self.auto_band.setChecked(True);form.addRow(self.auto_band)
        self.low,self.high=spin(.3,0,1e6),spin(2,0,1e6)
        row=QHBoxLayout();row.addWidget(self.low);row.addWidget(self.high);form.addRow('Полоса, GHz',row)
        self.peak=QLabel('Нет данных');self.peak.setWordWrap(True);form.addRow(self.peak)
        layout.addWidget(group)
        group=QGroupBox('Стартовые параметры и результат');inner=QVBoxLayout(group)
        note=QLabel('A ≥ 0; τ > 0. A и φ относятся к общему началу окна фита.\nЧисло подтверждается Enter или выходом из поля.')
        note.setWordWrap(True);inner.addWidget(note)
        self.table=QTableWidget(0,3);self.table.setHorizontalHeaderLabels(['Параметр','Старт','Фит ± σ'])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch)
        self.table.setMinimumHeight(350);self.table.setWordWrap(False);inner.addWidget(self.table)
        self.seed=QPushButton('Обновить старт по FFT');inner.addWidget(self.seed)
        layout.addWidget(group);layout.addStretch()
        self.model.currentIndexChanged.connect(self.model_changed);self.count.valueChanged.connect(self.model_changed)
        self.auto_band.toggled.connect(self.band_changed)
        self.low.editingFinished.connect(self.manual_band);self.high.editingFinished.connect(self.manual_band)
        self.seed.clicked.connect(self.reset_seed);self.count.setEnabled(False)

    def components(self):return 1 if self.model.currentIndex()==0 else self.count.value()
    def model_changed(self,*_):
        self.count.setEnabled(self.model.currentIndex()==1);self.owner.manual_initials[self.index]=None
        self.owner.invalidate()
    def reset_seed(self):
        self.owner.manual_initials[self.index]=None;self.owner.invalidate()
    def band_changed(self,*_):
        self.low.setEnabled(not self.auto_band.isChecked());self.high.setEnabled(not self.auto_band.isChecked())
        self.reset_seed()
    def manual_band(self):
        self.auto_band.blockSignals(True);self.auto_band.setChecked(False);self.auto_band.blockSignals(False)
        self.reset_seed()
    def band(self):return numerical(self.low)*1e9,numerical(self.high)*1e9
    def set_band(self,band):
        self.low.setValue(band[0]/1e9);self.high.setValue(band[1]/1e9)
    def read_parameters(self):
        return np.asarray([self.table.cellWidget(i,1).value()*self.scales[i] for i in range(self.table.rowCount())])
    def changed_parameter(self,*_):
        self.owner.manual_initials[self.index]=self.read_parameters().copy();self.owner.invalidate()
    def populate(self,parameters,result,prepared,unit):
        if parameters is None:
            self.table.setRowCount(0);return
        values=prepared.y[prepared.fit_mask] if prepared.fit_mask.any() else prepared.y
        afactor,aunit=angle_unit([np.std(values)])
        factor=self.owner.time_factor;count=(len(parameters)-1)//4
        self.scales=[];row_units=[]
        for i,value in enumerate(parameters):
            if i==len(parameters)-1 or i%4==0:
                scale,selected_unit=angle_unit([value]) if value else (afactor,aunit)
                self.scales.append(scale);row_units.append(selected_unit.replace('rad','V') if unit=='V' else selected_unit)
            else:
                self.scales.append({1:1e9,2:1.,3:factor}[i%4]);row_units.append({1:'GHz',2:'rad',3:self.owner.time_unit.currentText()}[i%4])
        self.table.setRowCount(len(parameters))
        for i,(parameter,scale) in enumerate(zip(parameters,self.scales)):
            name=core.names(count)[i][0];u=row_units[i]
            label=QTableWidgetItem(f'{name} [{u}]');label.setFlags(label.flags()&~Qt.ItemIsEditable);self.table.setItem(i,0,label)
            field=spin(parameter/scale)
            if i<len(parameters)-1 and i%4 in (0,1):field.setMinimum(0)
            if i<len(parameters)-1 and i%4==3:field.setMinimum(.000001)
            self.table.setCellWidget(i,1,field);field.valueChanged.connect(self.changed_parameter)
            text=''
            if result is not None:
                err=result.errors[i]/scale;unc=f'{err:.3g}' if np.isfinite(err) else '—'
                text=f'{result.parameters[i]/scale:.6g} ± {unc}'
            item=QTableWidgetItem(text);item.setFlags(item.flags()&~Qt.ItemIsEditable);self.table.setItem(i,2,item)


class DualAnalysisWindow(QMainWindow):
    def __init__(self):
        super().__init__();self.setWindowTitle('Pump–Probe Dual Analyzer · X1 / R2 / phase comparison')
        self.resize(1620,1080);self.setStyleSheet(STYLE)
        self.measurement=self.prepared=None;self.results=(None,None);self.initials=(None,None)
        self.bands=((.3e9,2e9),(.3e9,2e9));self.manual_initials=[None,None]
        self.revision=0;self.job_revision=0;self.job=None;self.pending=False;self.pending_load=None;self.dirty=True;self.closing=False
        self.title_valid=True;self.comparison=None;self.time_factor=1e-9;self._rendering=False
        self.pool=QThreadPool(self);self.pool.setMaxThreadCount(1)
        self.timer=QTimer(self);self.timer.setSingleShot(True);self.timer.setInterval(450);self.timer.timeout.connect(self.dispatch)
        root=QWidget();self.setCentralWidget(root);layout=QVBoxLayout(root)
        header=QHBoxLayout();self.open_button=QPushButton('Открыть .dat + .txt');self.open_button.setObjectName('primary')
        self.notes_button=QPushButton('Выбрать другой .txt');self.save_button=QPushButton('Сохранить картинку…')
        self.export_button=QPushButton('Экспорт рисунка и данных');self.cancel_button=QPushButton('Отмена вычисления')
        for button in (self.open_button,self.notes_button,self.save_button,self.export_button,self.cancel_button):header.addWidget(button)
        layout.addLayout(header);self.file_label=QLabel('Загрузите файл: Position | X1 | Y1 | X2 | Y2. Анализируются X1 и R2 = √(X2² + Y2²).')
        self.file_label.setWordWrap(True);layout.addWidget(self.file_label)
        splitter=QSplitter(Qt.Horizontal);splitter.setChildrenCollapsible(False);layout.addWidget(splitter,1)
        self.tabs=QTabWidget();self.tabs.setMinimumWidth(460);splitter.addWidget(self.tabs)
        common=QWidget();left=QVBoxLayout(common);group=QGroupBox('Время и калибровка');form=QFormLayout(group)
        self.zero_mode=QComboBox();self.zero_mode.addItems(['Максимум исходного X1','Вручную']);form.addRow('Ноль задержки',self.zero_mode)
        self.zero=QLineEdit('106.45');form.addRow('x₀, mm',self.zero)
        self.units=QComboBox();self.units.addItems(['mm','шаги']);form.addRow('Координаты файла',self.units)
        self.step_size=QLineEdit('0');form.addRow('mm на шаг',self.step_size)
        self.light_speed=QLineEdit('3e8');form.addRow('Скорость света, m/s',self.light_speed)
        fixed=QLabel('Оптический путь всегда двойной: t = 2(x − x₀)/c.\nОба канала используют один x₀ и одно окно времени.');fixed.setWordWrap(True);form.addRow(fixed)
        self.bal=QLineEdit();self.sig=QLineEdit();self.bal.setPlaceholderText('Bal < 0');self.sig.setPlaceholderText('Sig > 0')
        form.addRow('X1: Bal, mV (Bal < 0)',self.bal);form.addRow('X1: Sig, mV (Sig > 0)',self.sig)
        self.second_mode=QComboBox();self.second_mode.addItem('R2 в вольтах','volts');self.second_mode.addItem('R2: те же Bal/Sig → rad','same');self.second_mode.addItem('R2: отдельные Bal/Sig → rad','separate');form.addRow('Единицы второго канала',self.second_mode)
        self.second_bal=QLineEdit();self.second_sig=QLineEdit();form.addRow('R2: Bal, mV (Bal < 0)',self.second_bal);form.addRow('R2: Sig, mV (Sig > 0)',self.second_sig)
        cal=QLabel('θ = √2 · V / [4√Sig · √(Sig − Bal)].\nBal/Sig вводятся в mV. Отношение амплитуд сравнивается в исходных вольтах.');cal.setWordWrap(True);form.addRow(cal)
        left.addWidget(group)
        group=QGroupBox('Общее окно анализа');form=QFormLayout(group)
        self.time_unit=QComboBox();self.time_unit.addItem('ns',1e-9);self.time_unit.addItem('ps',1e-12);form.addRow('Единицы времени',self.time_unit)
        self.window_mode=QComboBox();self.window_mode.addItems(['Максимум X1 + шаги → конец','Вручную']);form.addRow('Окно',self.window_mode)
        self.skip_steps=QSpinBox();self.skip_steps.setRange(0,1000000);self.skip_steps.setValue(3);form.addRow('Шагов после максимума',self.skip_steps)
        self.fit_start,self.fit_stop=spin(.01),spin(3.5);form.addRow('Начало окна',self.fit_start);form.addRow('Конец окна',self.fit_stop)
        self.background=QComboBox();self.background.addItems(['Без вычитания','Константа','Линейный','Квадратичный']);form.addRow('Фон (для каждого канала)',self.background)
        self.bg_start,self.bg_stop=spin(.01),spin(3.5);form.addRow('Оценка фона от',self.bg_start);form.addRow('Оценка фона до',self.bg_stop)
        self.window=QComboBox();self.window.addItems(['Hann','Прямоугольное']);form.addRow('Окно FFT',self.window)
        self.padding=QComboBox()
        for n in (1,2,4,8,16,32,64,128):self.padding.addItem('×'+str(n),n)
        self.padding.setCurrentIndex(3);form.addRow('Zero-padding',self.padding);left.addWidget(group);left.addStretch()
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(common);self.tabs.addTab(scroll,'Общие')
        self.channels=[ChannelControls(self,i) for i in range(2)]
        for name,page in zip(('X1','R2'),self.channels):
            scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(page);self.tabs.addTab(scroll,name)
        style=QWidget();form=QFormLayout(style)
        self.normalized=QCheckBox('Показывать нормированное сравнение');self.normalized.setChecked(True);form.addRow(self.normalized)
        note=QLabel('Из каждого сигнала вычитается C его фита.\nМасштаб = max|fit − C| в общем окне.\nТочки могут выходить за ±1 из-за шума; фиты непрозрачны.');note.setWordWrap(True);form.addRow(note)
        self.alpha1,self.alpha2=spin(.55,0,1,2),spin(.55,0,1,2);form.addRow('Непрозрачность точек X1',self.alpha1);form.addRow('Непрозрачность точек R2',self.alpha2)
        self.pair1,self.pair2=QComboBox(),QComboBox();form.addRow('Компонента X1',self.pair1);form.addRow('Компонента R2',self.pair2)
        self.title_size,self.body_size=QSpinBox(),QSpinBox()
        for w,default in ((self.title_size,14),(self.body_size,8)):w.setRange(5,72);w.setValue(default)
        form.addRow('Шрифт Title, pt',self.title_size);form.addRow('Шрифт нижнего блока, pt',self.body_size)
        self.annotation=QPlainTextEdit();self.annotation.setMaximumHeight(100);form.addRow('Примечание внизу',self.annotation)
        self.comparison_label=QLabel('Сравнение появится после обоих фитов.');self.comparison_label.setWordWrap(True);form.addRow(self.comparison_label)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(style);self.tabs.addTab(scroll,'Сравнение / вид')
        self.notes=QPlainTextEdit();self.notes.setReadOnly(True);self.tabs.addTab(self.notes,'Параметры .txt')
        right_widget=QWidget();right=QVBoxLayout(right_widget);splitter.addWidget(right_widget)
        row=QHBoxLayout();row.addWidget(QLabel('Title:'));self.title=QLineEdit('Pump–probe · X1 & R2');self.title.setToolTip(r'Формулы: $\theta(t)$ или $$\theta(t)$$');row.addWidget(self.title,1);right.addLayout(row)
        self.title_error=QLabel();self.title_error.setWordWrap(True);self.title_error.setStyleSheet('color:#a42b2b');self.title_error.hide();right.addWidget(self.title_error)
        self.figure=DualFigure();self.editor=self.figure;right.addWidget(self.figure,1)
        self.messages=QPlainTextEdit();self.messages.setReadOnly(True);self.messages.setMaximumHeight(100);right.addWidget(self.messages)
        splitter.setSizes([495,1125])
        self.open_button.clicked.connect(self.open_files);self.notes_button.clicked.connect(self.change_notes)
        self.save_button.clicked.connect(self.save_picture);self.export_button.clicked.connect(self.export);self.cancel_button.clicked.connect(self.cancel_job)
        self.figure.save_requested.connect(self.save_picture);self.figure.band_changed.connect(self.figure_band_changed)
        self.figure.title_edit_requested.connect(self.edit_title)
        self.figure.title_validation_error.connect(self.title_validation)
        self.title.textChanged.connect(self.figure.set_title);self.figure.set_title(self.title.text())
        for field in (self.zero,self.step_size,self.light_speed,self.bal,self.sig,self.second_bal,self.second_sig):field.textEdited.connect(self.invalidate_physical)
        for field in (self.zero_mode,self.units,self.second_mode,self.window_mode,self.background,self.window,self.padding):field.currentIndexChanged.connect(self.invalidate_physical)
        for field in (self.skip_steps,self.fit_start,self.fit_stop,self.bg_start,self.bg_stop):field.valueChanged.connect(self.invalidate_physical)
        self.time_unit.currentIndexChanged.connect(self.change_time_unit)
        self.normalized.toggled.connect(self.style_changed);self.alpha1.valueChanged.connect(self.style_changed);self.alpha2.valueChanged.connect(self.style_changed)
        self.pair1.currentIndexChanged.connect(self.style_changed);self.pair2.currentIndexChanged.connect(self.style_changed)
        self.title_size.valueChanged.connect(self.fonts_changed);self.body_size.valueChanged.connect(self.fonts_changed);self.annotation.textChanged.connect(self.style_changed)
        self.fonts_changed();self.set_enabled()

    def log(self,text):self.messages.appendPlainText(str(text));self.statusBar().showMessage(str(text).splitlines()[0][:180])
    def components(self):return tuple(channel.components() for channel in self.channels)
    def settings(self):
        if not self.bal.text().strip() or not self.sig.text().strip():
            raise ValueError('Для построения X1 введите Bal < 0 и Sig > 0 в милливольтах во вкладке «Общие».')
        return core.Settings(zero_mm=numerical(self.zero),mm_per_unit=1. if self.units.currentIndex()==0 else numerical(self.step_size),
            c=numerical(self.light_speed),bal_mv=numerical(self.bal),sig_mv=numerical(self.sig),
            zero_mode='peak' if self.zero_mode.currentIndex()==0 else 'manual',
            fit_window_mode='peak_plus_steps' if self.window_mode.currentIndex()==0 else 'manual',skip_steps=self.skip_steps.value(),
            fit_min_s=numerical(self.fit_start)*self.time_factor,fit_max_s=numerical(self.fit_stop)*self.time_factor,
            background_degree=self.background.currentIndex()-1,bg_min_s=numerical(self.bg_start)*self.time_factor,bg_max_s=numerical(self.bg_stop)*self.time_factor,
            window='hann' if self.window.currentIndex()==0 else 'boxcar',padding=self.padding.currentData())
    def invalidate_physical(self,*_):
        self.manual_initials=[None,None];self.invalidate()
    def invalidate(self,*_):
        if self._rendering:return
        self.revision+=1;self.dirty=True;self.results=(None,None);self.comparison=None
        for channel in self.channels:
            for row in range(channel.table.rowCount()):
                if channel.table.item(row,2) is not None:channel.table.item(row,2).setText('')
        if self.job and self.job.kind=='Анализ':self.job.cancel.set()
        self.pending=self.measurement is not None;self.timer.start();self.set_enabled()
        if self.prepared is not None:self.render_data()
        self.statusBar().showMessage('Параметры изменены — автоматический пересчёт…')
    def dispatch(self):
        if self.closing or self.job is not None or not self.pending:return
        self.pending=False
        try:
            cfg=self.settings();mode=self.second_mode.currentData()
            if mode=='separate' and (not self.second_bal.text().strip() or not self.second_sig.text().strip()):
                raise ValueError('Для отдельной калибровки R2 введите его Bal < 0 и Sig > 0 в милливольтах.')
            second_bal=numerical(self.second_bal) if mode=='separate' else None
            second_sig=numerical(self.second_sig) if mode=='separate' else None
            counts=self.components();requested=tuple(c.band() for c in self.channels);automatic=tuple(c.auto_band.isChecked() for c in self.channels)
            manual=tuple(None if p is None else p.copy() for p in self.manual_initials);measurement=self.measurement
        except Exception as exc:self.log(exc);self.set_enabled();return
        def analyze(cancel):
            p=prepare_dual(measurement,cfg,mode,second_bal,second_sig)
            results=[];bands=[];initials=[];errors=[]
            for i,channel in enumerate((p.first,p.second)):
                if cancel.is_set():raise core.Cancelled('Анализ отменён')
                band=requested[i];initial=None;result=None
                try:
                    if not len(channel.spectrum):raise ValueError('Недостаточно точек для FFT/фита.')
                    if automatic[i]:band=core.automatic_band(channel,counts[i])
                    if not 0<=band[0]<band[1]<=channel.nyquist_hz:raise ValueError('Полоса FFT должна находиться между 0 и частотой Найквиста.')
                    initial=manual[i] if manual[i] is not None else core.initial_parameters(channel,counts[i],band)
                    result=core.fit(channel,initial,band,cancel)
                except core.Cancelled:raise
                except Exception as exc:errors.append(('X1' if i==0 else 'R2')+': '+str(exc))
                bands.append(band);initials.append(initial);results.append(result)
            return dict(prepared=p,results=tuple(results),bands=tuple(bands),initials=tuple(initials),errors=errors)
        self.run_job('Анализ',analyze)
    def run_job(self,kind,function):
        if self.job is not None:return
        self.job_revision=self.revision;self.job=Job(kind,function);self.job.signals.completed.connect(self.completed)
        self.pool.start(self.job);self.set_enabled();self.statusBar().showMessage(kind+'…')
    def completed(self,package):
        kind,value,error=package;cancelled=self.job.cancel.is_set();stale=kind=='Анализ' and self.job_revision!=self.revision
        self.job=None
        if self.closing:return
        if cancelled or stale:
            if not self.pending:self.log('Отменённый результат отброшен.')
        elif error:
            self.log(error)
            if kind=='Загрузка':self.file_label.setText(self.file_label.text().replace('загрузка…','ошибка загрузки'))
        elif kind=='Загрузка':
            self.measurement=value;self.prepared=None;self.results=(None,None);self.initials=(None,None);self.manual_initials=[None,None]
            self.notes.setPlainText(value.notes);self.file_label.setText(f'{value.data_path}\nПараметры: {value.notes_path}; исходные единицы: {value.signal_unit}')
            self.pending=True
            for warning in value.warnings:self.log(warning)
        elif kind=='Анализ':
            self.prepared=value['prepared'];self.results=value['results'];self.initials=value['initials'];self.bands=value['bands'];self.dirty=False
            p=self.prepared.first
            self.zero.setText(f'{p.settings.zero_mm:.9g}')
            for field,number in ((self.fit_start,p.settings.fit_min_s),(self.fit_stop,p.settings.fit_max_s)):
                field.blockSignals(True);field.setValue(number/self.time_factor);field.blockSignals(False)
            self.refresh_channels();self.update_pairs();self.render_data()
            self.log(f'Прочитано {len(self.measurement.position)} точек; в общем окне {int(p.fit_mask.sum())}.')
            for i,result in enumerate(self.results):
                if result is not None:
                    self.log(f'{("X1","R2")[i]}: фит R²={result.r_squared:.6g}')
                    for warning in result.warnings:self.log(f'{("X1","R2")[i]}: '+warning)
            for channel in (self.prepared.first,self.prepared.second):
                for warning in channel.warnings:self.log(warning)
            for text in value['errors']:self.log(text)
        elif kind in ('Экспорт','Картинка'):self.log('Сохранено: '+str(value))
        self.set_enabled()
        if self.pending_load is not None:
            paths=self.pending_load;self.pending_load=None;self.pending=False
            self.load_paths(*paths)
        elif self.pending:QTimer.singleShot(0,self.dispatch)
    def refresh_channels(self):
        for i,(ui,p,unit) in enumerate(zip(self.channels,(self.prepared.first,self.prepared.second),(self.prepared.first_unit,self.prepared.second_unit))):
            ui.set_band(self.bands[i]);ui.populate(self.manual_initials[i] if self.manual_initials[i] is not None else self.initials[i],self.results[i],p,unit)
            try:
                idx=core.peak_indices(p,*self.bands[i])[0]
                ui.peak.setText(f'Максимум FFT: {p.frequencies[idx]/1e9:.6g} GHz; Δf ≈ {p.resolution_hz/1e9:.4g} GHz')
            except ValueError:ui.peak.setText('FFT недоступно в выбранной полосе.')
    def update_pairs(self):
        for box,result in zip((self.pair1,self.pair2),self.results):
            old=box.currentIndex();box.blockSignals(True);box.clear()
            if result is not None:
                for i in range((len(result.parameters)-1)//4):box.addItem(f'{i+1}: {result.parameters[4*i+1]/1e9:.6g} GHz',i)
                box.setCurrentIndex(max(0,min(old,box.count()-1)))
            box.blockSignals(False)
    def comparison_summary(self):
        self.comparison=None
        if self.prepared is not None and all(result is not None for result in self.results):
            try:self.comparison=compare_fits(*self.results,self.prepared.first_factor,self.prepared.second_factor,max(0,self.pair1.currentIndex()),max(0,self.pair2.currentIndex()))
            except Exception as exc:self.log(exc)
        from .dual_export import comparison_text
        unit1=self.prepared.first_unit if self.prepared is not None else 'rad'
        unit2=self.prepared.second_unit if self.prepared is not None else 'V'
        summary=comparison_text(self.comparison,unit1,unit2)
        self.comparison_label.setText(summary)
        note=self.annotation.toPlainText().strip()
        return summary+('\n'+note if note else '')
    def render_data(self):
        if self.prepared is None:return
        self._rendering=True
        try:
            summary=self.comparison_summary()
            self.figure.set_data(self.prepared,self.results,self.bands,self.comparison,self.components(),self.time_unit.currentText(),'',self.normalized.isChecked(),(max(0,self.pair1.currentIndex()),max(0,self.pair2.currentIndex())))
            self.figure.set_summary_text(summary)
            self.figure.set_alphas(self.alpha1.value(),self.alpha2.value());self.figure.set_normalized_visible(self.normalized.isChecked())
        finally:self._rendering=False
    def style_changed(self,*_):
        if self._rendering or self.prepared is None:return
        self.figure.set_summary_text(self.comparison_summary())
        self.figure.set_alphas(self.alpha1.value(),self.alpha2.value())
        self.figure.set_normalized_visible(self.normalized.isChecked())
    def fonts_changed(self,*_):self.figure.set_fonts(self.title_size.value(),self.body_size.value())
    def change_time_unit(self,*_):
        new=self.time_unit.currentData()
        for field in (self.fit_start,self.fit_stop,self.bg_start,self.bg_stop):
            field.blockSignals(True);field.setValue(field.value()*self.time_factor/new);field.blockSignals(False)
        self.time_factor=new
        if self.prepared is not None:self.refresh_channels();self.render_data()
    def figure_band_changed(self,index,band):
        if self._rendering:return
        channel=self.channels[index];channel.auto_band.blockSignals(True);channel.auto_band.setChecked(False);channel.auto_band.blockSignals(False)
        channel.set_band(band);self.manual_initials[index]=None;self.invalidate()
    def edit_title(self):
        self.title.setFocus(Qt.OtherFocusReason);self.title.selectAll()
    def title_validation(self,message):
        self.title_valid=not bool(message);self.title_error.setText(str(message)[:250]);self.title_error.setVisible(bool(message));self.set_enabled()
    def set_enabled(self):
        busy=self.job is not None
        self.open_button.setEnabled(not self.closing);self.notes_button.setEnabled(self.measurement is not None and not self.closing)
        ready=self.prepared is not None and not self.dirty and not busy and self.title_valid
        self.save_button.setEnabled(ready);self.export_button.setEnabled(ready);self.cancel_button.setEnabled(busy or self.pending)
        self.zero.setEnabled(self.zero_mode.currentIndex()==1);self.step_size.setEnabled(self.units.currentIndex()==1)
        separate=self.second_mode.currentData()=='separate';self.second_bal.setEnabled(separate);self.second_sig.setEnabled(separate)
        manual=self.window_mode.currentIndex()==1;self.fit_start.setEnabled(manual);self.fit_stop.setEnabled(manual);self.skip_steps.setEnabled(not manual)
        both=all(result is not None for result in self.results);self.normalized.setEnabled(both)
        self.pair1.setEnabled(both);self.pair2.setEnabled(both)
        for channel in self.channels:
            channel.low.setEnabled(not channel.auto_band.isChecked());channel.high.setEnabled(not channel.auto_band.isChecked())
    def open_files(self):
        path,_=QFileDialog.getOpenFileName(self,'Массив измерений','','Data (*.dat *.txt);;All files (*)')
        if not path:return
        notes=associated_notes(path)
        if notes is None:notes,_=QFileDialog.getOpenFileName(self,'Параметры измерения','','Text (*.txt)')
        if notes:self.load_paths(path,notes)
    def change_notes(self):
        notes,_=QFileDialog.getOpenFileName(self,'Параметры измерения',str(Path(self.measurement.notes_path).parent),'Text (*.txt)')
        if notes:self.load_paths(self.measurement.data_path,notes)
    def load_paths(self,path,notes):
        self.timer.stop();self.pending=False;self.revision+=1;self.results=(None,None);self.comparison=None;self.dirty=True
        self.measurement=self.prepared=None;self.initials=(None,None);self.manual_initials=[None,None]
        self.figure.clear_data();self.notes.clear();self.update_pairs()
        self.comparison_label.setText('Сравнение доступно после успешных фитов обоих сигналов.')
        self.file_label.setText(f'Файл: {path}\nПараметры: {notes} · загрузка…')
        for channel in self.channels:channel.table.setRowCount(0);channel.peak.setText('Нет данных')
        if self.job:
            self.pending_load=(path,notes)
            if self.job.kind in ('Анализ','Загрузка'):self.job.cancel.set()
            self.set_enabled();return
        self.pending_load=None
        self.run_job('Загрузка',lambda cancel:load_dual_pair(path,notes))
    def cancel_job(self):
        self.timer.stop();self.pending=False;self.pending_load=None
        if self.job:self.job.cancel.set()
        self.set_enabled()
    def snapshot(self):
        if self.prepared is None or self.dirty:raise ValueError('Дождитесь завершения анализа.')
        return dict(measurement=self.measurement,prepared=self.prepared,results=self.results,bands=self.bands,
            initials=tuple(None if p is None else p.copy() for p in self.initials),components=self.components(),pair=(max(0,self.pair1.currentIndex()),max(0,self.pair2.currentIndex())),
            comparison=self.comparison,title=self.title.text(),time_unit=self.time_unit.currentText(),normalization=self.normalized.isChecked(),
            alphas=(self.alpha1.value(),self.alpha2.value()),annotation=self.annotation.toPlainText())
    def export(self):
        if not self.title_valid or self.job:return
        try:snapshot=self.snapshot()
        except Exception as exc:self.log(exc);return
        source=Path(self.measurement.data_path);base=ExportFolderDialog.choose(self,source.parent,source.stem+'_dual_analysis')
        if base is None:return
        try:payloads=self.figure.capture_images(('png','pdf'))
        except Exception as exc:self.log(exc);return
        from .dual_export import export_dual
        self.run_job('Экспорт',lambda cancel:export_dual(base,snapshot,payloads))
    def save_picture(self):
        if not self.title_valid or self.job or self.prepared is None or self.dirty:return
        path,selected=QFileDialog.getSaveFileName(self,'Сохранить текущую фигуру',str(Path(self.measurement.data_path).with_suffix('.png')),'PNG (*.png);;PDF (*.pdf);;SVG (*.svg)')
        if not path:return
        if not Path(path).suffix:path+='.pdf' if selected.startswith('PDF') else '.svg' if selected.startswith('SVG') else '.png'
        extension=Path(path).suffix.lower().lstrip('.')
        try:payload=self.figure.capture_images((extension,))[extension]
        except Exception as exc:self.log(exc);return
        from .export import write_picture
        self.run_job('Картинка',lambda cancel:write_picture(path,payload))
    def closeEvent(self,event):
        self.closing=True;self.cancel_job()
        if self.pool.activeThreadCount():event.ignore();QTimer.singleShot(100,self.close)
        else:event.accept()
