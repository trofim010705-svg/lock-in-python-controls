"""Independent pump–probe analysis; no instrument drivers or USB access."""
