"""Diagnostic quadratures and unwrapped phase on the existing shared delay grid.

Prepared's legacy *_rad fields contain V for X2/Y2 and rad for phase2. These
diagnostics do not change the fitted X1/R2 signals or their comparison.
"""
from dataclasses import replace
import numpy as np
from . import core
from .io import Measurement


DIAGNOSTIC_UNITS = {'x2': 'V', 'y2': 'V', 'phase2': 'rad'}


def diagnostics_metadata():
    return {
        'x2': 'Signed X2 in source volts; duplicate positions are averaged before the common polynomial background is subtracted.',
        'y2': 'Signed Y2 in source volts; duplicate positions are averaged before the common polynomial background is subtracted.',
        'phase2': 'unwrap(atan2(mean(Y2), mean(X2))) in radians on increasing common time. Each contiguous finite segment is unwrapped independently; phase is undefined at zero averaged complex magnitude. No polynomial background is subtracted from phase.',
        'phase_fft': 'FFT of the unwrapped quadrature phase on the shared selected time interval, with its mean removed and the selected Hann/rectangular window and zero-padding. It is unavailable if that interval contains undefined phase points; gaps at zero magnitude are never interpolated across.',
        'distinction': 'Quadrature phase is not the phase parameter of the fitted R2 oscillation. R2 averages per-row magnitudes; quadrature phase uses the averaged complex quadratures at duplicate positions.',
    }


def _common_config(first):
    cfg=replace(first.settings, zero_mode='manual', fit_window_mode='manual')
    preparation_cfg=cfg
    if cfg.fit_min_s >= cfg.fit_max_s:
        preparation_cfg=replace(cfg,
            fit_min_s=float(np.nextafter(cfg.fit_min_s,-np.inf)),
            fit_max_s=float(np.nextafter(cfg.fit_max_s,np.inf)))
    return cfg,preparation_cfg


def _series(dual, values, *, phase=False):
    """Use the established preprocessing/FFT routine, undoing scalar calibration."""
    first=dual.first; m=dual.measurement
    cfg,preparation_cfg=_common_config(first)
    if phase:
        cfg=replace(cfg,background_degree=-1)
        preparation_cfg=replace(preparation_cfg,background_degree=-1)
    measurement=Measurement(np.asarray(m.position),np.asarray(values,dtype=float),
        m.data_path,m.notes_path,m.notes,'V',list(m.warnings))
    p=core.prepare(measurement,preparation_cfg)
    factor=preparation_cfg.rad_per_unit
    p=replace(p,raw_rad=p.raw_rad/factor,y=p.y/factor,
        background=p.background/factor,spectrum=p.spectrum/factor,
        fit_mask=first.fit_mask.copy(),settings=cfg)
    if not np.array_equal(p.time,first.time):
        raise ValueError('Не удалось получить общую сетку диагностических сигналов.')
    if first.fit_mask.sum()<8:
        return replace(p,frequencies=np.array([]),spectrum=np.array([]),resolution_hz=float('nan'))
    interval=p.y[p.fit_mask]
    floor=64*np.finfo(float).eps*float(np.max(abs(p.raw_rad)))
    if np.ptp(interval)<=floor:
        p=replace(p,frequencies=np.array([]),spectrum=np.array([]),resolution_hz=float('nan'),
            warnings=p.warnings+['Сигнал постоянен в пределах машинной точности; осцилляционный спектр не определён.'])
    return p


def _unwrap_segments(phase):
    """Never bridge an undefined phase by choosing a hidden 2π offset."""
    answer=np.asarray(phase,dtype=float).copy()
    valid=np.flatnonzero(np.isfinite(answer))
    if valid.size:
        for segment in np.split(valid,np.flatnonzero(np.diff(valid)>1)+1):
            answer[segment]=np.unwrap(answer[segment])
    return answer


def prepare_diagnostics(dual_prepared):
    """Return X2, Y2 [V] and unwrapped atan2(Y2,X2) [rad], with their FFTs.

    The calibrated R2 mode has no effect on these source quadratures. X1's
    shared zero, time grid and selected interval remain authoritative.
    """
    dual=dual_prepared; m=dual.measurement
    x2=_series(dual,m.x2); y2=_series(dual,m.y2)
    magnitude=np.hypot(x2.raw_rad,y2.raw_rad)
    phase=np.arctan2(y2.raw_rad,x2.raw_rad)
    phase[magnitude==0]=np.nan
    phase=_unwrap_segments(phase)
    cfg=dual.first.settings
    original_time=(np.asarray(m.position)*cfg.mm_per_unit-cfg.zero_mm)*1e-3*cfg.path_factor/cfg.c
    indices=np.searchsorted(dual.first.time,original_time)
    if (indices>=len(phase)).any() or not np.array_equal(dual.first.time[indices],original_time):
        raise ValueError('Не удалось сопоставить фазу исходным координатам.')
    # Placeholder zeros never enter a phase FFT containing undefined samples:
    # the spectrum is explicitly unavailable below. This lets the same core
    # routine handle the valid selected interval even with undefined data outside it.
    mapped=np.where(np.isfinite(phase),phase,0.)[indices]
    prepared_phase=_series(dual,mapped,phase=True)
    prepared_phase=replace(prepared_phase,raw_rad=phase.copy(),y=phase.copy(),
        background=np.where(np.isfinite(phase),0.,np.nan))
    if np.any(~np.isfinite(phase[dual.first.fit_mask])):
        prepared_phase=replace(prepared_phase,frequencies=np.array([]),spectrum=np.array([]),
            resolution_hz=float('nan'),warnings=prepared_phase.warnings+[
                'В окне анализа есть нулевая амплитуда комплексного сигнала; фаза и её FFT в этом месте не определены.'])
    return {'x2':x2,'y2':y2,'phase2':prepared_phase}
