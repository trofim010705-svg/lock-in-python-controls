"""One editable Matplotlib figure for both on-screen display and exact export.

Adapters keep the analysis UI's numeric API: x is ns/ps or GHz, y is radians.
All Matplotlib/Qt access, including capture_images(), belongs to the GUI thread.
"""
from html import unescape
from io import BytesIO
import re
import numpy as np
from PIL import Image
from PyQt5.QtCore import QObject, QEvent, QTimer, Qt, pyqtSignal
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QScrollArea
from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter
from matplotlib.mathtext import MathTextParser
from matplotlib.font_manager import FontProperties
from matplotlib.widgets import SpanSelector
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT
from .presentation import angle_unit


def _plain(text):
    return unescape(re.sub(r'<br\s*/?>', '\n', str(text), flags=re.IGNORECASE))


class _Toolbar(NavigationToolbar2QT):
    toolitems = tuple(item for item in NavigationToolbar2QT.toolitems
                     if item[0] in ('Home','Back','Forward','Pan','Zoom','Save',None))

    def __init__(self, canvas, editor):
        self.editor = editor
        super().__init__(canvas, editor, coordinates=True)

    def save_figure(self, *args):
        self.editor.save_requested.emit()


class Curve:
    def __init__(self, plot, **kwargs):
        self.plot = plot
        self.artist, = plot.axes.plot([], [], **kwargs)
        self.x = np.array([]); self.y = np.array([])
        plot.curves.append(self)

    def setData(self, x, y):
        self.x = np.asarray(x, dtype=float).copy()
        self.y = np.asarray(y, dtype=float).copy()
        if self.x.shape != self.y.shape:
            raise ValueError('Число координат и значений должно совпадать')
        self.artist.set_data(self.x, self.y)
        self.plot._data_changed()

    def getData(self):
        return self.x, self.y


class _AxisCompatibility:
    def enableAutoSIPrefix(self, enabled):
        # X is already explicitly converted by the analysis UI; never double-scale.
        pass


class Plot:
    def __init__(self, editor, axes):
        self.editor, self.axes = editor, axes
        self.curves = []
        self.auto_y = True
        self._programmatic = 0
        self._y_text, self._y_unit, self._y_factor = '', 'rad', 1.
        axes.set_autoscale_on(False)  # adapters own scaling; drawing never resets a user's view
        axes.grid(True, alpha=.18)
        axes.tick_params(labelsize=9, colors='#354b60')
        for spine in axes.spines.values(): spine.set_color('#a8b5c0')
        axes.callbacks.connect('ylim_changed', self._on_y_changed)
        axes.callbacks.connect('xlim_changed', self._on_x_changed)
        axes.yaxis.set_major_formatter(FuncFormatter(self._format_y))

    def _format_y(self, value, position=None):
        scaled = value/self._y_factor
        if scaled == 0: return '0'
        return f'{scaled:.6g}'

    def _update_y_unit(self):
        if self._y_unit == 'rad':
            factor, unit = angle_unit(self.axes.get_ylim())
        else:
            factor, unit = 1., self._y_unit
        self._y_factor = factor
        text = self._y_text+(' ('+unit+')' if unit else '')
        self.axes.set_ylabel(text, fontsize=10, color='#354b60', parse_math=False)

    def _on_y_changed(self, axes):
        if not self._programmatic:
            self.auto_y = False
        self._update_y_unit()

    def _on_x_changed(self, axes):
        if not self._programmatic:
            self.auto_y = False

    def setLabel(self, axis, text, units=None):
        if axis in ('bottom','top'):
            self.axes.set_xlabel(str(text)+(' ('+str(units)+')' if units else ''),
                                 fontsize=10, color='#354b60', parse_math=False)
        else:
            self._y_text, self._y_unit = str(text), units or ''
            self._update_y_unit()
        self.editor.schedule_draw()

    def setTitle(self, text, color=None, **kwargs):
        try:
            normalized = self.editor.validated_mathtext(str(text), self.editor.title_size)
        except (ValueError, TypeError) as exc:
            self.editor.title_validation_error.emit('Ошибка формулы Title: '+str(exc))
            return False
        self.axes.set_title(normalized, fontsize=self.editor.title_size,
                            color=color or '#29465d', parse_math=True)
        self.editor.title_validation_error.emit('')
        self.editor.schedule_draw()
        return True

    def setXRange(self, low, high, padding=0):
        if not np.isfinite([low,high]).all(): return
        if low == high: low, high = low-.01, high+.01
        extra = (high-low)*padding
        self._programmatic += 1
        try: self.axes.set_xlim(low-extra, high+extra)
        finally: self._programmatic -= 1
        if self.auto_y: self._apply_auto_y()
        self.editor.schedule_draw()

    def setYRange(self, low, high, padding=0):
        if not np.isfinite([low,high]).all() or low >= high:
            raise ValueError('Минимум Y должен быть меньше максимума')
        self.auto_y = False
        extra = (high-low)*padding
        self._programmatic += 1
        try: self.axes.set_ylim(low-extra, high+extra)
        finally: self._programmatic -= 1
        self._update_y_unit(); self.editor.schedule_draw()

    def enableAutoRange(self, axis='y', enable=True):
        self.auto_y = bool(enable)
        if self.auto_y: self._apply_auto_y()
        self.editor.schedule_draw()

    def _apply_auto_y(self):
        low,high = sorted(self.axes.get_xlim())
        values = []
        for curve in self.curves:
            finite = np.isfinite(curve.x)&np.isfinite(curve.y)
            selected = finite&(curve.x>=low)&(curve.x<=high)
            if np.any(selected): values.append(curve.y[selected])
        if not values:
            for curve in self.curves:
                finite = np.isfinite(curve.y)
                if np.any(finite): values.append(curve.y[finite])
        if not values: return
        combined = np.concatenate(values)
        bottom,top = float(np.min(combined)),float(np.max(combined))
        width = top-bottom
        margin = width*.07 if width>0 else max(abs(bottom)*.07,1e-12)
        self._programmatic += 1
        try: self.axes.set_ylim(bottom-margin,top+margin)
        finally: self._programmatic -= 1
        self._update_y_unit()

    def _data_changed(self):
        if self.auto_y: self._apply_auto_y()
        self.editor.schedule_draw()

    def viewRange(self):
        return [list(self.axes.get_xlim()),list(self.axes.get_ylim())]

    def getAxis(self, name): return _AxisCompatibility()
    def addLegend(self, **kwargs): return self.editor.legend
    def addItem(self, item): pass
    def showGrid(self, x=True, y=True, alpha=.18): self.axes.grid(x or y, alpha=alpha)


class Legend:
    """Compatibility adapter; numerical information is now in the footer."""
    def __init__(self, editor):
        self.editor=editor; self.entries=[]; self.artist=None; self.visible=False
        self.location='upper right'

    def _rebuild(self):
        # Never put a legend over the measured curves.
        if self.artist is not None:
            self.artist.remove(); self.artist=None
        self.editor.schedule_draw()

    def clear(self): self.entries.clear(); self._rebuild()
    def setVisible(self, visible): self.visible=bool(visible); self._rebuild()
    def addItem(self, curve, text):
        self.entries=[(c,t) for c,t in self.entries if c is not curve]
        self.entries.append((curve,_plain(text))); self._rebuild()
    def removeItem(self, curve):
        self.entries=[(c,t) for c,t in self.entries if c is not curve]; self._rebuild()


class _Selector(SpanSelector):
    def __init__(self, region, **kwargs):
        self.region = region
        super().__init__(**kwargs)

    def ignore(self, event):
        if self.region.editor.toolbar.mode: return True
        return super().ignore(event)


class Region(QObject):
    sigRegionChanged = pyqtSignal()

    def __init__(self, editor, bounds=(.3,2.)):
        super().__init__(editor)
        self.editor = editor
        self.values = tuple(map(float,bounds))
        self.bounds = (0.,1e6)
        self.selector = _Selector(self, ax=editor.fft_plot.axes,
            onselect=self._selected, onmove_callback=self._selected,
            direction='horizontal', useblit=False, interactive=True,
            drag_from_anywhere=True, button=1, grab_range=8,
            props=dict(facecolor='#1aa5a2', alpha=.12),
            handle_props=dict(color='#37a7a5', linewidth=.9))
        self.selector.extents = self.values

    def getRegion(self): return self.values

    def _selected(self, low, high): self.setRegion((low,high))

    def setRegion(self, values):
        low,high = sorted(map(float,values))
        low,high = max(self.bounds[0],low), min(self.bounds[1],high)
        if not np.isfinite([low,high]).all() or low>high: return
        changed = (low,high) != self.values
        self.values = low,high
        self.selector.extents = self.values
        self.selector.set_visible(True)
        self.editor.schedule_draw()
        if changed: self.sigRegionChanged.emit()

    def setBounds(self, bounds):
        self.bounds = tuple(map(float,bounds))

    def setMovable(self, movable): self.selector.set_active(bool(movable))
    def setZValue(self, value): pass


class FigureEditor(QWidget):
    title_edit_requested = pyqtSignal()
    save_requested = pyqtSignal()
    title_validation_error = pyqtSignal(str)
    footer_validation_error = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.title_size, self.legend_size = 13., 8.
        self._math_parser=MathTextParser('path')
        self._footer=('', '', '')
        self._layout_queued=False
        self._layout_running=False
        self.figure = Figure(figsize=(11,9), dpi=100, facecolor='white', layout='constrained')
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.toolbar = _Toolbar(self.canvas,self)
        layout = QVBoxLayout(self); layout.setContentsMargins(0,0,0,0); layout.setSpacing(0)
        layout.addWidget(self.toolbar)
        self.scroll=QScrollArea(); self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll.setFrameShape(QScrollArea.NoFrame)
        self.canvas.setMinimumWidth(300)
        self.scroll.setWidget(self.canvas); layout.addWidget(self.scroll,1)
        self.scroll.viewport().installEventFilter(self)
        self.grid=self.figure.add_gridspec(3,1,height_ratios=[270,240,.001])
        axes=[self.figure.add_subplot(self.grid[0]), self.figure.add_subplot(self.grid[1])]
        self.footer_axes=self.figure.add_subplot(self.grid[2]); self.footer_axes.set_axis_off()
        self.footer_formula=self.footer_axes.text(.01,.98,'',transform=self.footer_axes.transAxes,
            va='top',ha='left',fontsize=self.legend_size+2,parse_math=True,color='#173b57')
        self.footer_fit_text=self.footer_axes.text(.01,.7,'',transform=self.footer_axes.transAxes,
            va='top',ha='left',fontsize=self.legend_size,linespacing=1.35,parse_math=False,color='#243b50')
        self.footer_fft_text=self.footer_axes.text(.52,.7,'',transform=self.footer_axes.transAxes,
            va='top',ha='left',fontsize=self.legend_size,linespacing=1.35,parse_math=False,color='#243b50')
        self.time_plot, self.fft_plot = Plot(self,axes[0]), Plot(self,axes[1])
        self.legend = Legend(self)
        self.points = Curve(self.time_plot, linestyle='none', marker='o', markersize=3,
                            color='#147c9c', markeredgewidth=0)
        self.fit_curve = Curve(self.time_plot, linewidth=1.8, color='#d56e36')
        self.spectrum = Curve(self.fft_plot, linewidth=1.4, color='#6553a7')
        self.markers = Curve(self.fft_plot, linestyle='none', marker='o', markersize=5,
                             color='#d56e36', markeredgecolor='white', markeredgewidth=.5)
        axes[0].axvline(0, color='#7a8e9b', linewidth=.7, linestyle='--')
        self.region = Region(self)
        self.canvas.setToolTip('Двойной щелчок по Title — редактирование. Все параметры находятся под графиками.')
        self.canvas.mpl_connect('button_press_event',self._pressed)
        self.time_plot.setLabel('bottom','Задержка','ns'); self.time_plot.setLabel('left','Rotation','rad')
        self.fft_plot.setLabel('bottom','Частота','GHz'); self.fft_plot.setLabel('left','FFT amplitude','rad')
        self.fft_plot.setTitle('FFT / selected search band')
        self._layout_footer()

    def _pressed(self, event):
        if event.dblclick and self.time_plot.axes.title.contains(event)[0]:
            self.title_edit_requested.emit()

    def schedule_draw(self):
        if hasattr(self,'canvas'): self.canvas.draw_idle()

    def render(self):
        self._layout_footer()
        self.time_plot._update_y_unit(); self.fft_plot._update_y_unit()
        self.canvas.draw()

    def set_fonts(self, title_size, legend_size):
        self.title_size, self.legend_size = float(title_size),float(legend_size)
        self.time_plot.axes.title.set_fontsize(self.title_size)
        self.fft_plot.axes.title.set_fontsize(self.title_size)
        self._layout_footer()
        self.schedule_draw()

    @staticmethod
    def normalize_mathtext(text):
        """Matplotlib supports MathText $...$; accept user-facing $$...$$ too."""
        text=unescape(str(text))
        text=re.sub(r'(?<!\\)\$\$(.+?)(?<!\\)\$\$',lambda match:'$'+match.group(1)+'$',text,flags=re.DOTALL)
        if re.search(r'(?<!\\)\$\$',text):
            raise ValueError('Закройте формулу парой $$…$$')
        for line in text.splitlines() or ['']:
            if len(re.findall(r'(?<!\\)\$',line))%2:
                raise ValueError('Закройте формулу парой $…$ или $$…$$')
        return text

    def validated_mathtext(self,text,size):
        normalized=self.normalize_mathtext(text)
        for line in normalized.splitlines() or ['']:
            self._math_parser.parse(line,dpi=self.figure.dpi,prop=FontProperties(size=size))
        return normalized

    def set_footer(self, formula_mathtext, fit_text, fft_text):
        formula=str(formula_mathtext)
        try:
            normalized=self.validated_mathtext(formula,self.legend_size+2)
        except (ValueError,TypeError) as exc:
            self.footer_validation_error.emit('Ошибка формулы фита: '+str(exc))
            return False
        self._footer=(normalized,str(fit_text),str(fft_text))
        self.footer_validation_error.emit('')
        self._layout_footer(); self.schedule_draw()
        return True

    def set_footer_visible(self,visible):
        self._footer_visible=bool(visible)
        self._layout_footer(); self.schedule_draw()

    def eventFilter(self, watched, event):
        if hasattr(self,'scroll') and watched is self.scroll.viewport() and event.type()==QEvent.Resize:
            if not self._layout_queued:
                self._layout_queued=True
                QTimer.singleShot(0,self._queued_layout)
        return super().eventFilter(watched,event)

    def _queued_layout(self):
        self._layout_queued=False
        self._layout_footer(); self.schedule_draw()

    def _layout_footer(self):
        if self._layout_running or not hasattr(self,'footer_axes'): return
        self._layout_running=True
        try:
            formula,fit,fft=self._footer
            visible=any((formula,fit,fft)) and getattr(self,'_footer_visible',True)
            self.footer_axes.set_visible(visible); self.footer_axes.set_in_layout(visible)
            if not visible:
                self.grid.set_height_ratios([270,240,.001])
                self.canvas.setMinimumHeight(600)
                return
            width=max(self.canvas.minimumWidth(),self.scroll.viewport().width())
            renderer=self.canvas.get_renderer()
            ratio=max(1.,float(self.canvas.devicePixelRatioF()))
            available=max(1.,width-105.)
            body_font=FontProperties(size=self.legend_size)
            def measure(text,prop,math=False):
                return renderer.get_text_width_height_descent(text,prop,ismath=math)[0]/ratio if text else 0.
            # A glyph may be wider than a narrow column at a large requested font.
            # Use a full-width stacked block in that case; never force 16 characters.
            column_width=available*.47
            stacked=column_width<measure('WWWW',body_font)
            if stacked: column_width=available*.97
            def wrap_line(line):
                if not line: return ''
                result=[]; rest=line
                while rest:
                    if measure(rest,body_font)<=column_width:
                        result.append(rest); break
                    low,high=1,len(rest)
                    while low<high:
                        mid=(low+high+1)//2
                        if measure(rest[:mid],body_font)<=column_width: low=mid
                        else: high=mid-1
                    length=low
                    # Prefer a word boundary but still split overly long numeric tokens.
                    space=rest.rfind(' ',0,length+1)
                    if space>0: length=space
                    result.append(rest[:length].rstrip())
                    rest=rest[length:].lstrip()
                return '\n'.join(result)
            def wrap(text): return '\n'.join(wrap_line(line) for line in text.split('\n'))
            fit_wrapped,fft_wrapped=wrap(fit),wrap(fft)
            fit_lines=max(1,len(fit_wrapped.splitlines())) if fit else 0
            fft_lines=max(1,len(fft_wrapped.splitlines())) if fft else 0
            body_lines=(fit_lines+fft_lines+(1 if fit and fft else 0)) if stacked else max(fit_lines,fft_lines,1)
            font_px=self.legend_size*self.figure.dpi/(72*ratio)
            line_px=font_px*1.4
            equation_size=self.legend_size+2
            formula_lines=formula.splitlines() if formula else []
            if formula_lines:
                prop=FontProperties(size=equation_size)
                widest=max(measure(line,prop,math=('$' in line)) for line in formula_lines)
                if widest>available*.97:
                    equation_size=max(1.,equation_size*available*.97/widest)
                # Math fractions can have much greater height than ordinary text.
                prop=FontProperties(size=equation_size)
                formula_px=sum(max(renderer.get_text_width_height_descent(line,prop,ismath=('$' in line))[1]/ratio,
                    equation_size*self.figure.dpi/(72*ratio))*1.25 for line in formula_lines)
            else: formula_px=0.
            footer_px=24+formula_px+max(1,body_lines)*line_px
            # All rows remain in the figure; large blocks are viewed by scrolling.
            self.canvas.setMinimumHeight(int(510+footer_px+160))
            self.grid.set_height_ratios([270,240,max(footer_px,1)])
            self.footer_formula.set_text(formula); self.footer_formula.set_fontsize(equation_size)
            self.footer_fit_text.set_text(fit_wrapped); self.footer_fft_text.set_text(fft_wrapped)
            y=1-(formula_px+10)/footer_px
            self.footer_fit_text.set_position((.01,y))
            self.footer_fft_text.set_position((.01,y-(fit_lines+(1 if fit and fft else 0))*line_px/footer_px) if stacked else (.52,y))
            for artist in (self.footer_fit_text,self.footer_fft_text): artist.set_fontsize(self.legend_size)
        finally:
            self._layout_running=False

    def capture_images(self, formats=('png',)):
        """Capture current pixel image; vector formats retain this exact layout/view.

        No reconstruction from data occurs. Call only on the Qt GUI thread.
        """
        self.render()
        output = {}
        if 'png' in formats:
            buffer=BytesIO()
            Image.fromarray(np.asarray(self.canvas.buffer_rgba()).copy()).save(buffer,format='PNG')
            output['png']=buffer.getvalue()
        layout_engine=self.figure.get_layout_engine()
        self.figure.set_layout_engine(None)  # freeze the geometry the user just saw
        try:
            for format_name in formats:
                if format_name == 'png': continue
                if format_name not in ('pdf','svg'):
                    raise ValueError('Доступны PNG, PDF и SVG')
                buffer=BytesIO()
                self.figure.savefig(buffer,format=format_name,dpi=self.figure.dpi,
                                    facecolor=self.figure.get_facecolor())
                output[format_name]=buffer.getvalue()
        finally:
            self.figure.set_layout_engine(layout_engine)
        return output
