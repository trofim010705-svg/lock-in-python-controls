"""Explicit export location and folder name selection."""
from pathlib import Path
from PyQt5.QtWidgets import (QDialog,QFormLayout,QHBoxLayout,QLineEdit,QPushButton,
                             QFileDialog,QDialogButtonBox,QLabel)


class ExportFolderDialog(QDialog):
    def __init__(self, parent, default_parent, default_name):
        super().__init__(parent)
        self.setWindowTitle('Папка экспорта'); self.resize(630,180)
        form=QFormLayout(self)
        self.parent_path=QLineEdit(str(default_parent)); browse=QPushButton('…')
        row=QHBoxLayout();row.addWidget(self.parent_path);row.addWidget(browse)
        form.addRow('Расположение',row)
        self.folder_name=QLineEdit(default_name);form.addRow('Имя папки',self.folder_name)
        self.error=QLabel('При совпадении имени добавится _001, _002 и т. д.');self.error.setWordWrap(True)
        form.addRow(self.error)
        buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);form.addRow(buttons)
        buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject)
        browse.clicked.connect(self.browse)

    def browse(self):
        path=QFileDialog.getExistingDirectory(self,'Расположение экспорта',self.parent_path.text())
        if path:self.parent_path.setText(path)

    def target(self):
        name=self.folder_name.text()
        forbidden='<>:"/\\|?*'
        stem=name.split('.')[0].rstrip(' .').upper()
        reserved={'CON','PRN','AUX','NUL',*[f'COM{i}' for i in range(1,10)],*[f'LPT{i}' for i in range(1,10)]}
        if not name.strip() or name in ('.','..') or name.endswith((' ','.')) or stem in reserved or any(c in forbidden or ord(c)<32 for c in name):
            raise ValueError('Введите допустимое имя папки без / \\ : * ? " < > |')
        if not self.parent_path.text().strip():raise ValueError('Укажите расположение папки экспорта')
        path=Path(self.parent_path.text()).expanduser()
        if not path.is_dir():raise ValueError('Выберите существующую родительскую папку')
        return path/name

    def accept(self):
        try:self.target()
        except ValueError as exc:self.error.setText(str(exc));return
        super().accept()

    @classmethod
    def choose(cls,parent,default_parent,default_name):
        dialog=cls(parent,default_parent,default_name)
        return dialog.target() if dialog.exec_()==QDialog.Accepted else None
