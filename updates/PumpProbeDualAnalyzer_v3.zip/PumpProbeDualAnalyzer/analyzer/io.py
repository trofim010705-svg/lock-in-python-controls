"""Read only position and X1; other demodulator columns are deliberately ignored."""
from dataclasses import dataclass
from pathlib import Path
import re
import numpy as np


@dataclass
class Measurement:
    position: np.ndarray
    x1: np.ndarray
    data_path: str
    notes_path: str
    notes: str
    signal_unit: str
    warnings: list


def read_text(path):
    raw = Path(path).read_bytes()
    # Trying UTF-16 without its BOM can silently decode even-length CP1251 text
    # as unrelated characters. Windows Notepad UTF-16 files carry this marker.
    if raw.startswith((b'\xff\xfe', b'\xfe\xff')):
        return raw.decode('utf-16')
    for encoding in ('utf-8-sig', 'cp1251'):
        try:
            return raw.decode(encoding)
        except UnicodeError:
            continue
    raise ValueError('Не удалось определить кодировку: '+str(path))


def associated_notes(path):
    path = Path(path)
    for candidate in (path.with_name(path.stem+'.comments.txt'), path.with_suffix('.txt')):
        if candidate != path and candidate.is_file():
            return candidate
    return None


def load_pair(data_path, notes_path):
    text, notes = read_text(data_path), read_text(notes_path)
    rows, warnings, started = [], [], False
    for line_number, line in enumerate(text.splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue
        # Tabs/semicolon support decimal commas; whitespace supports legacy files.
        # Do not collapse empty tab-separated cells: a missing X1 must not be
        # replaced by Y1 from the third column.
        parts = re.split(r'[\t;]', line.strip(' \r\n')) if '\t' in line or ';' in line else stripped.split()
        try:
            pair = [float(x.strip().replace(',', '.')) for x in parts[:2]]
            if len(pair) != 2:
                raise ValueError()
        except ValueError:
            numeric = []
            for part in parts[:2]:
                try:
                    float(part.strip().replace(',', '.')); numeric.append(True)
                except ValueError:
                    numeric.append(False)
            if started or any(numeric):
                raise ValueError(f'Строка {line_number}: повреждена координата или X1')
            if len(rows) == 0 and line_number > 100:
                raise ValueError('Численные данные не найдены в первых 100 строках')
            continue  # Origin Long Names/Units or other initial text headers.
        started = True
        rows.append(pair)
        if len(rows) > 1000000:
            raise ValueError('Поддерживается не более 1 000 000 точек')
    if not rows:
        raise ValueError('Файл данных пуст: численные точки отсутствуют. Выберите другое измерение.')
    declared = re.findall(r'^Points saved:\s*(\d+)\s*$', notes, flags=re.MULTILINE)
    if declared and int(declared[-1]) != len(rows):
        warnings.append(f'В параметрах указано Points saved={declared[-1]}, '
                        f'а в .dat прочитано {len(rows)} численных строк. Проверьте соответствие пары файлов.')
    outcomes = re.findall(r'^RESULT:\s*(\w+)', notes, flags=re.MULTILINE)
    if outcomes and outcomes[-1].lower() != 'complete':
        warnings.append(f'Измерение завершено со статусом RESULT={outcomes[-1]}; '
                        f'в файле записано {len(rows)} точек. Доступные точки сохраняются для анализа.')
    data = np.asarray(rows)
    finite = np.isfinite(data).all(axis=1)
    if not finite.all():
        warnings.append(f'Исключено нечисловых/бесконечных строк: {np.count_nonzero(~finite)}. Координаты не угадывались.')
        data = data[finite]
    if not len(data):
        raise ValueError('В файле нет конечных координат и X1: все численные строки содержат NaN/Inf')
    unit = 'неизвестна'
    match = re.search(r'(?:Signal unit:\s*|"unit"\s*:\s*")([VA])', text+'\n'+notes)
    if match:
        unit = match.group(1)
    else:
        lines = text.splitlines()
        for i, line in enumerate(lines[:-1]):
            if 'Position' in line and 'X1' in line:
                units = lines[i+1].split()
                if len(units) >= 2 and units[1] in ('V', 'A'):
                    unit = units[1]
    return Measurement(data[:, 0], data[:, 1], str(data_path), str(notes_path), notes, unit, warnings)
