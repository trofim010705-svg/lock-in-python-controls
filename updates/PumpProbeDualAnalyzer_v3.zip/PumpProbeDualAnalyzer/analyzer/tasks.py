"""Single background job with cooperative cancellation during optimization."""
from threading import Event
from PyQt5.QtCore import QObject, QRunnable, pyqtSignal


class Signals(QObject):
    completed = pyqtSignal(object)


class Job(QRunnable):
    def __init__(self, kind, function):
        super().__init__()
        self.kind, self.function = kind, function
        self.cancel = Event()
        self.signals = Signals()

    def run(self):
        try:
            value = self.function(self.cancel)
            result = (self.kind, value, None)
        except Exception as exc:
            result = (self.kind, None, str(exc))
        self.signals.completed.emit(result)
