#!/usr/bin/env python3
"""Run the five-signal Pump-Probe analyzer: python app.py [--demo]."""
import argparse
import sys
from pathlib import Path
from PyQt5.QtCore import Qt,QTimer
from PyQt5.QtWidgets import QApplication
from analyzer.dual_ui import DualAnalysisWindow


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--demo',action='store_true');args=parser.parse_args()
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling,True);QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps,True)
    app=QApplication(sys.argv[:1]);app.setStyle('Fusion');window=DualAnalysisWindow();window.show()
    if args.demo:
        window.bal.setText('-100');window.sig.setText('100');base=Path(__file__).resolve().parent/'examples'
        QTimer.singleShot(0,lambda:window.load_paths(base/'dual_demo.dat',base/'dual_demo.comments.txt'))
    return app.exec_()


if __name__=='__main__':sys.exit(main())
