"""Dual-channel conventions and shared timing use synthetic data only."""
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
import numpy as np
from analyzer import core
from analyzer.dual_core import (DualMeasurement, load_dual_pair, prepare_dual,
                               compare_fits, normalize_signals)


def measurement(position, x1, x2, y2):
    return DualMeasurement(np.asarray(position), np.asarray(x1), np.asarray(x2), np.asarray(y2),
                           'synthetic.dat', 'synthetic.comments.txt', '', 'V', [])


def result(a=1e-6, f=2e9, phi=.2, tau=2e-9, offset=0, reference=0):
    return SimpleNamespace(parameters=np.array([a, f, phi, tau, offset]), reference_s=reference)


class DualInputTests(unittest.TestCase):
    def paths(self, folder, rows, header='Position\tX1\tY1\tX2\tY2\nmm\tV\tV\tV\tV\n'):
        dat, notes = Path(folder)/'scan.dat', Path(folder)/'scan.comments.txt'
        dat.write_text(header+rows, encoding='utf-8')
        notes.write_text('RESULT: complete\n', encoding='utf-8')
        return dat, notes

    def test_fixed_columns_decimal_commas_and_unused_y1(self):
        with tempfile.TemporaryDirectory() as directory:
            m = load_dual_pair(*self.paths(directory, '1,25\t2,5\tignored\t3,5\t4,5\n'))
            np.testing.assert_array_equal(m.position, [1.25])
            np.testing.assert_array_equal(m.x1, [2.5])
            np.testing.assert_array_equal(m.x2, [3.5])
            np.testing.assert_array_equal(m.y2, [4.5])
            self.assertEqual(m.signal_unit, 'V')

    def test_missing_columns_and_blanks_are_not_shifted(self):
        with tempfile.TemporaryDirectory() as directory:
            for row in ('1\t2\t3\n', '1\t2\t3\t\t99\n',
                        '1\t2\t3\t4\t\t99\n', '\t1\t2\t3\t4\n',
                        '1\t\t2\t3\t4\n'):
                with self.subTest(row=row), self.assertRaisesRegex(ValueError, 'X2'):
                    load_dual_pair(*self.paths(directory, row))

    def test_nonfinite_rows_are_removed_jointly(self):
        with tempfile.TemporaryDirectory() as directory:
            m = load_dual_pair(*self.paths(directory, '1\t2\t0\t3\t4\n2\t5\t0\tnan\t6\n'))
            self.assertEqual(len(m.position), 1)
            self.assertTrue(any('NaN/Inf' in text for text in m.warnings))


class DualPreparationTests(unittest.TestCase):
    def setUp(self):
        self.cfg = core.Settings(bal_mv=-100, sig_mv=100)
        positions = np.linspace(100, 200, 101)
        x1 = np.exp(-((positions-120)/1.5)**2)*1e-5 + np.sin(positions)*1e-7
        x2 = 2e-6 + 5e-7*np.sin(positions/3)
        self.m = measurement(positions, x1, x2, np.zeros_like(x2))

    def test_x1_sets_common_zero_window_and_phase_reference(self):
        prepared = prepare_dual(self.m, self.cfg)
        peak = np.argmax(self.m.x1)
        self.assertEqual(prepared.first.settings.zero_mm, self.m.position[peak])
        self.assertEqual(prepared.second.settings.zero_mm, self.m.position[peak])
        np.testing.assert_array_equal(prepared.first.time, prepared.second.time)
        np.testing.assert_array_equal(prepared.first.fit_mask, prepared.second.fit_mask)
        self.assertEqual(prepared.first.settings.fit_min_s, prepared.first.time[peak+3])
        np.testing.assert_allclose(prepared.second.raw_rad, self.m.x2)
        self.assertEqual(prepared.second_unit, 'V')
        self.assertEqual(prepared.second_factor, 1)

    def test_rotating_quadratures_have_constant_r2_and_no_fittable_fft(self):
        phase = np.linspace(0, 100, len(self.m.position))
        self.m.x2 = 2e-6*np.cos(phase)
        self.m.y2 = 2e-6*np.sin(phase)
        p = prepare_dual(self.m, self.cfg)
        np.testing.assert_allclose(p.second.raw_rad, 2e-6, rtol=1e-15)
        self.assertEqual(len(p.second.spectrum), 0)
        self.assertGreater(len(p.first.spectrum), 0)
        self.assertTrue(any('постоянен' in text for text in p.second.warnings))

    def test_modes_and_separate_calibration_have_same_physical_signal(self):
        volts = prepare_dual(self.m, self.cfg)
        same = prepare_dual(self.m, self.cfg, 'same')
        separate = prepare_dual(self.m, self.cfg, 'separate', -200, 200)
        self.assertEqual(same.second_unit, 'rad')
        np.testing.assert_allclose(same.second.y, volts.second.y*2.5)
        np.testing.assert_allclose(separate.second.y, volts.second.y*1.25)
        np.testing.assert_allclose(same.second.spectrum, volts.second.spectrum*2.5)

    def test_modulus_is_computed_before_duplicate_average(self):
        m = measurement([1, 1, 2, 3, 4], [2, 2, 1, 0, 0], [3, -3, 2, 1, 1], [4, -4, 0, 0, 0])
        p = prepare_dual(m, replace(self.cfg, skip_steps=0))
        self.assertEqual(p.second.raw_rad[0], 5)
        self.assertEqual(len(p.first.time), 4)

    def test_short_and_empty_auto_windows_still_display_channels(self):
        for count, skip in ((1, 3), (3, 100), (6, 0)):
            m = measurement(np.arange(count), np.arange(count), np.ones(count), np.zeros(count))
            p = prepare_dual(m, replace(self.cfg, skip_steps=skip))
            self.assertEqual(len(p.second.y), count)
            np.testing.assert_array_equal(p.first.fit_mask, p.second.fit_mask)
            self.assertEqual(len(p.second.spectrum), 0)


class ComparisonTests(unittest.TestCase):
    def test_phase_sign_wrapping_and_voltage_ratio_before_normalization(self):
        # X1 calibrated by 2.5 rad/V, R2 calibrated by 1.25 rad/V.
        values = compare_fits(result(a=5e-6, phi=3), result(a=7.5e-6, phi=-3), 2.5, 1.25)
        self.assertAlmostEqual(values['amplitude_ratio'], 3)
        self.assertAlmostEqual(values['delta_phase_rad'], 2*np.pi-6)
        self.assertAlmostEqual(values['amplitude_x1_v'], 2e-6)

    def test_reference_shift_removes_spurious_phase_and_amplitude_difference(self):
        reference = .1e-9
        initial = result()
        shifted = result(a=1e-6*np.exp(-reference/2e-9),
                         phi=.2+2*np.pi*2e9*reference, reference=reference)
        values = compare_fits(initial, shifted, 1, 1)
        self.assertEqual(values['reference_s'], reference)
        self.assertAlmostEqual(values['delta_phase_rad'], 0, places=12)
        self.assertAlmostEqual(values['amplitude_ratio'], 1)

    def test_different_frequencies_are_reported_at_a_common_instant(self):
        values = compare_fits(result(f=2e9), result(f=2.5e9), 1, 1, reference_s=.2e-9)
        self.assertAlmostEqual(values['delta_frequency_hz'], .5e9)
        self.assertAlmostEqual(values['delta_phase_rad'], .2*np.pi)
        self.assertIn('t-reference_s', values['phase_time_dependence'])

    def test_mode_selection_and_zero_amplitude_are_explicit(self):
        one = result(a=0)
        two = result()
        two.parameters = np.array([1e-6, 2e9, 0, 2e-9, 3e-6, 3e9, 1, 2e-9, 0])
        values = compare_fits(one, two, 1, 1, second_component=1)
        self.assertIsNone(values['amplitude_ratio'])
        self.assertIsNone(values['delta_phase_rad'])
        self.assertEqual(values['frequency_r2_hz'], 3e9)

    def test_normalization_removes_offset_and_preserves_physical_ratio(self):
        t = np.linspace(0, 2e-9, 1000)
        r = result(a=2e-6, offset=1e-5)
        y = core.evaluate(t, r.parameters, r.reference_s)
        p = SimpleNamespace(time=t, y=y, fit_mask=(t >= .1e-9))
        points, fitted, scale = normalize_signals(p, r)
        self.assertAlmostEqual(np.max(np.abs(fitted[p.fit_mask])), 1)
        np.testing.assert_allclose(points[p.fit_mask], fitted[p.fit_mask])
        self.assertTrue(np.isnan(fitted[~p.fit_mask]).all())
        self.assertLess(scale, 2e-6)
        zero = result(a=0)
        with self.assertRaisesRegex(ValueError, 'Нулевая'):
            normalize_signals(p, zero)


if __name__ == '__main__':
    unittest.main()
