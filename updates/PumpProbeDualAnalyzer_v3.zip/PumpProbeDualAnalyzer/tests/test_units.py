import os
os.environ['QT_QPA_PLATFORM']='offscreen'
os.environ['MPLCONFIGDIR']='/tmp/analyzer-test-mpl'
from pathlib import Path
import tempfile
import time
import unittest
import numpy as np
from PyQt5.QtWidgets import QApplication
from analyzer.ui import AnalysisWindow
from analyzer.export import make_figure


class FriendlyUnitTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.app=QApplication.instance() or QApplication([])

    def wait(self,w):
        deadline=time.monotonic()+25
        while (w.job or w.pending_prepare or w.pending_fit or w.auto_timer.isActive() or w.peak_timer.isActive()) and time.monotonic()<deadline:
            self.app.processEvents();time.sleep(.005)
        self.assertIsNone(w.job,w.messages.toPlainText())
        self.assertFalse(w.pending_prepare or w.pending_fit or w.auto_timer.isActive(),w.messages.toPlainText())

    def window(self):
        w=AnalysisWindow();w.show();self.addCleanup(w.close)
        w.bal.setText('-100');w.sig.setText('100')
        root=Path(__file__).resolve().parents[1]/'examples'
        w.load_paths(root/'demo.dat',root/'demo.comments.txt');self.wait(w)
        self.assertIsNotNone(w.result,w.messages.toPlainText())
        return w

    def test_time_units_convert_values_axes_table_and_legend_without_refit(self):
        w=self.window()
        self.assertFalse(hasattr(w,'path_factor'))
        result=w.result;before=w.read_parameters();before_x=w.points.getData()[0].copy()
        ns_start=w.fit_start.value()
        self.assertEqual(w.table.item(1,0).text(),'f1 [GHz]')
        self.assertEqual(w.table.item(3,0).text(),'tau1 [ns]')
        self.assertTrue(.5<w.table.cellWidget(1,1).value()<2)
        w.time_unit.setCurrentIndex(1)
        self.assertAlmostEqual(w.fit_start.value(),ns_start*1000,places=5)
        np.testing.assert_allclose(w.read_parameters(),before,rtol=2e-6,atol=1e-15)
        np.testing.assert_allclose(w.points.getData()[0],before_x*1000)
        self.assertIs(w.result,result)
        self.assertFalse(w.pending_prepare or w.pending_fit)
        self.assertEqual(w.table.item(3,0).text(),'tau1 [ps]')
        self.assertIn('GHz',w.fit_legend_text());self.assertIn('ps',w.fit_legend_text())

    def test_manual_time_window_and_frequency_band_use_friendly_units(self):
        w=self.window()
        w.window_mode.setCurrentIndex(1)
        w.fit_start.setValue(.2);w.fit_stop.setValue(1.8);self.wait(w)
        self.assertAlmostEqual(w.prepared.settings.fit_min_s,.2e-9)
        self.assertAlmostEqual(w.prepared.settings.fit_max_s,1.8e-9)
        w.low.setValue(1);w.high.setValue(1.6);w.apply_band();self.wait(w)
        self.assertFalse(w.band_auto.isChecked())
        np.testing.assert_allclose(w.band(),[1e9,1.6e9])
        w.sig.setText('200');w.sig.textEdited.emit('200');self.wait(w)
        np.testing.assert_allclose(w.band(),[1e9,1.6e9])
        w.low.setValue(2);w.high.setValue(1);w.apply_band()
        self.assertEqual(w.low.value(),1);self.assertEqual(w.high.value(),1.6)

    def test_y_units_and_export_axes_preserve_si_arrays(self):
        w=self.window()
        w.time_y_min.setValue(-2);w.time_y_max.setValue(4);w.time_y_auto.setChecked(False)
        np.testing.assert_allclose(w.applied_time_ylim,[-2e-6,4e-6])
        w.y_unit.setCurrentIndex(1)  # mrad
        self.assertAlmostEqual(w.time_y_min.value(),-.002)
        w.apply_y_limits()
        np.testing.assert_allclose(w.applied_time_ylim,[-2e-6,4e-6])
        w.time_unit.setCurrentIndex(1)
        fig=make_figure(w.prepared,w.result,'units',w.band(),w.presentation())
        self.assertEqual(fig.axes[0].get_xlabel(),'Delay (ps)')
        self.assertEqual(fig.axes[1].get_xlabel(),'Frequency (GHz)')
        np.testing.assert_allclose(fig.axes[0].lines[0].get_xdata(),w.prepared.time[w.prepared.fit_mask]/1e-12)
        np.testing.assert_allclose(fig.axes[1].lines[0].get_xdata(),w.prepared.frequencies/1e9)
        fig.clear()

    def test_one_point_file_still_plots_without_fft_or_fit(self):
        w=AnalysisWindow();w.show();self.addCleanup(w.close)
        w.bal.setText('-100');w.sig.setText('100')
        with tempfile.TemporaryDirectory() as folder:
            data=Path(folder)/'one.dat';notes=data.with_suffix('.txt')
            data.write_text('Position\tX1\nmm\tV\n92.17\t0.00001\n')
            notes.write_text('Points saved: 1\nRESULT: error')
            w.load_paths(data,notes);self.wait(w)
            self.assertEqual(len(w.points.getData()[0]),1)
            self.assertIsNone(w.result)
            self.assertTrue(w.picture_button.isEnabled())


if __name__=='__main__':unittest.main()
