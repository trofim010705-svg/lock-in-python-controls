"""Amplitude half-height widths; synthetic spectra only."""
from types import SimpleNamespace
from math import sqrt,log
import unittest
import numpy as np
from analyzer.export import spectral_peaks,build_report,report_text,make_figure
from analyzer import core
from analyzer.io import Measurement
from analyzer.presentation import PlotStyle


def spectrum(values, frequencies=None):
    frequencies=np.linspace(0,6e9,len(values)) if frequencies is None else frequencies
    return SimpleNamespace(frequencies=frequencies,spectrum=values)


def gaussian(frequency, centre, sigma, amplitude=1):
    return amplitude*np.exp(-.5*((frequency-centre)/sigma)**2)


class FwhmTests(unittest.TestCase):
    def test_offline_picture_uses_footer_not_an_on_plot_legend(self):
        t=np.linspace(0,4e-9,601)
        y=np.sin(2*np.pi*1.4e9*t)*np.exp(-t/3e-9)*1e-6
        m=Measurement(100+t*3e8/2e-3,y/2.5,'generated','generated','test','V',[])
        cfg=core.Settings(zero_mode='manual',zero_mm=100,bal_mv=-100,sig_mv=100,
                          fit_window_mode='manual',fit_min_s=0,fit_max_s=4e-9)
        p=core.prepare(m,cfg)
        fig=make_figure(p,None,r'H=$$\frac{1}{2}$$',(.8e9,2e9),PlotStyle(fit_label='My note'))
        self.assertEqual(len(fig.axes),3)
        self.assertIsNone(fig.axes[0].get_legend())
        self.assertEqual(fig.axes[0].get_title(),r'H=$\frac{1}{2}$')
        self.assertTrue(fig.axes[0].title.get_parse_math())
        footer='\n'.join(artist.get_text() for artist in fig.axes[2].texts)
        self.assertIn('\\theta',footer)
        self.assertIn('My note',footer)
        self.assertIn('FWHM',footer)
        fig.canvas.draw()
        fig.clear()

    def test_report_contains_widths_method_and_null_reasons(self):
        t=np.linspace(0,4e-9,601)
        y=np.sin(2*np.pi*1.4e9*t)*np.exp(-t/3e-9)*1e-6
        m=Measurement(100+t*3e8/2e-3,y/2.5,'generated','generated','test','V',[])
        cfg=core.Settings(zero_mode='manual',zero_mm=100,bal_mv=-100,sig_mv=100,
                          fit_window_mode='manual',fit_min_s=0,fit_max_s=4e-9)
        p=core.prepare(m,cfg)
        report=build_report(m,p,None,'test',(.8e9,2e9),[],PlotStyle())
        self.assertTrue(report['fft_peaks'])
        for field in ('fwhm_hz','fwhm_ghz','half_height_left_hz','half_height_right_hz','fwhm_status','fwhm_note'):
            self.assertIn(field,report['fft_peaks'][0])
        self.assertIn('Not half-prominence or half-power',report['fwhm_definition'])
        text=report_text(report)
        self.assertIn('FWHM [GHz]',text)
        self.assertIn('not intrinsic linewidths',text)

    def test_gaussian_amplitude_width_is_not_half_power_width(self):
        f=np.linspace(0,6e9,6001);sigma=.2e9
        p=spectrum(gaussian(f,3e9,sigma,5e-6),f)
        peak=spectral_peaks(p,(2e9,4e9))[0]
        expected=2*sqrt(2*log(2))*sigma
        self.assertEqual(peak['fwhm_status'],'resolved')
        self.assertAlmostEqual(peak['fwhm_hz']/expected,1,places=5)
        self.assertAlmostEqual(peak['fwhm_ghz'],expected/1e9,places=5)
        self.assertAlmostEqual(peak['half_height_rad'],2.5e-6)
        self.assertGreater(peak['fwhm_hz'],2*sqrt(log(2))*sigma*1.3)

    def test_crossings_can_be_outside_search_band(self):
        f=np.linspace(0,6e9,6001);p=spectrum(gaussian(f,3e9,.2e9),f)
        peak=spectral_peaks(p,(2.99e9,3.01e9))[0]
        self.assertEqual(peak['fwhm_status'],'resolved')
        self.assertLess(peak['half_height_left_hz'],2.99e9)
        self.assertGreater(peak['half_height_right_hz'],3.01e9)

    def test_nonzero_floor_uses_absolute_half_height_not_prominence(self):
        f=np.linspace(0,6e9,6001);sigma=.2e9
        p=spectrum(.1+gaussian(f,3e9,sigma),f)
        peak=spectral_peaks(p,(2e9,4e9))[0]
        # Peak=1.1, half-height=.55 -> Gaussian part=.45.
        expected=2*sigma*sqrt(-2*log(.45))
        self.assertAlmostEqual(peak['half_height_rad'],.55)
        self.assertAlmostEqual(peak['fwhm_hz']/expected,1,places=5)

    def test_boundary_maximum_without_local_peak_has_no_width(self):
        f=np.linspace(0,6e9,6001);p=spectrum(gaussian(f,3e9,.3e9),f)
        peak=spectral_peaks(p,(2e9,2.5e9))[0]
        self.assertFalse(peak['is_local_maximum'])
        self.assertEqual(peak['fwhm_status'],'not_local_peak')
        self.assertIsNone(peak['fwhm_hz'])

    def test_missing_crossings_are_not_zero_widths(self):
        f=np.linspace(0,6e9,6001)
        for centre,status in ((.2e9,'missing_left_crossing'),(5.8e9,'missing_right_crossing')):
            with self.subTest(centre=centre):
                peak=spectral_peaks(spectrum(gaussian(f,centre,.5e9),f),(0,6e9))[0]
                self.assertEqual(peak['fwhm_status'],status)
                self.assertIsNone(peak['fwhm_hz'])
        peak=spectral_peaks(spectrum(.8+gaussian(f,3e9,.2e9,.2),f),(2e9,4e9))[0]
        self.assertEqual(peak['fwhm_status'],'missing_half_height_crossings')
        self.assertIsNone(peak['fwhm_hz'])

    def test_overlapping_half_height_lobes_do_not_get_individual_widths(self):
        f=np.linspace(0,6e9,6001)
        y=gaussian(f,2.7e9,.2e9)+gaussian(f,3.3e9,.2e9)
        peaks=spectral_peaks(spectrum(y,f),(2e9,4e9))
        self.assertEqual(len(peaks),2)
        for peak in peaks:
            self.assertEqual(peak['fwhm_status'],'merged_half_height_lobe')
            self.assertIsNone(peak['fwhm_hz'])
            self.assertIsNotNone(peak['half_height_left_hz'])
            self.assertIsNotNone(peak['half_height_right_hz'])

    def test_separated_peaks_have_independent_amplitude_widths(self):
        f=np.linspace(0,6e9,6001);sigma=.1e9
        y=gaussian(f,2e9,sigma)+gaussian(f,4e9,sigma,.6)
        peaks=spectral_peaks(spectrum(y,f),(1e9,5e9))
        self.assertEqual(len(peaks),2)
        for peak in peaks:
            self.assertEqual(peak['fwhm_status'],'resolved')
            self.assertAlmostEqual(peak['fwhm_hz']/(2*sqrt(2*log(2))*sigma),1,places=4)


if __name__=='__main__':unittest.main()
