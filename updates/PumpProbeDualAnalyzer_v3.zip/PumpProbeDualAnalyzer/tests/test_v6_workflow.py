"""End-to-end checks for editing the exact figure that gets exported."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
os.environ.setdefault('MPLCONFIGDIR','/tmp/analyzer-v6-mpl')
from pathlib import Path
import json
import tempfile
import time
import unittest
from unittest.mock import patch
import numpy as np
from PIL import Image
from PyQt5.QtWidgets import QApplication
from analyzer.ui import AnalysisWindow


class VisibleFigureWorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])

    def wait(self,w):
        deadline=time.monotonic()+30
        while (w.job or w.pending_prepare or w.pending_fit or w.auto_timer.isActive() or w.peak_timer.isActive()) and time.monotonic()<deadline:
            self.app.processEvents();time.sleep(.005)
        self.assertIsNone(w.job,w.messages.toPlainText())
        self.assertFalse(w.pending_prepare or w.pending_fit or w.auto_timer.isActive())

    def window(self):
        w=AnalysisWindow();w.show();self.addCleanup(w.close)
        root=Path(__file__).resolve().parents[1]/'examples'
        w.bal.setText('-100');w.sig.setText('100')
        w.load_paths(root/'demo.dat',root/'demo.comments.txt');self.wait(w)
        self.assertIsNotNone(w.result,w.messages.toPlainText())
        return w

    def test_title_fonts_formula_and_exact_visible_png(self):
        w=self.window();original=w.result
        with patch('analyzer.ui.QInputDialog.getText',return_value=('Мой Title <A>',True)):
            w.editor.title_edit_requested.emit()
        self.assertEqual(w.title.text(),'Мой Title <A>')
        w.title_font_size.setValue(18);w.legend_font_size.setValue(10)
        w.editor.time_plot.axes.set_xlim(.2,1.7)
        w.editor.time_plot.axes.set_ylim(-2e-6,4e-6)
        w.editor.render()
        visible=np.asarray(w.editor.canvas.buffer_rgba()).copy()
        formula,fit_text,fft_text=w.footer_content()
        self.assertIn(r'\theta',formula);self.assertIn('A1 =',fit_text)
        self.assertIn('FWHM',fft_text)
        self.assertEqual(w.editor.time_plot.axes.get_title(),'Мой Title <A>')
        self.assertEqual(w.editor.time_plot.axes.title.get_fontsize(),18)
        self.assertEqual(w.editor.footer_fit_text.get_fontsize(),10)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'visible.png'
            with patch('analyzer.ui.QFileDialog.getSaveFileName',return_value=(str(path),'PNG (*.png)')):
                w.save_picture();self.wait(w)
            np.testing.assert_array_equal(np.asarray(Image.open(path).convert('RGBA')),visible)
        self.assertIs(w.result,original)

    def test_custom_folder_report_and_exact_image_use_p0_of_completed_fit(self):
        w=self.window();used=w.fit_initial_used.copy()
        w.time_unit.setCurrentIndex(1)
        w.title.setText('Экспорт с моим именем')
        w.editor.render();visible=np.asarray(w.editor.canvas.buffer_rgba()).copy()
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'Мой эксперимент'
            with patch('analyzer.ui.ExportFolderDialog.choose',return_value=target),patch('analyzer.export.make_figure',side_effect=AssertionError('Must not recreate visible figure')):
                w.export();self.wait(w)
            self.assertTrue(target.is_dir())
            report=json.loads((target/'analysis.json').read_text(encoding='utf-8'))
            np.testing.assert_array_equal(report['initial_parameters_si'],used)
            self.assertTrue(report['fft_peaks'])
            notes=(target/'measurement_parameters.txt').read_text(encoding='utf-8')
            for text in ('SIMULATED','FFT / SPECTRAL PEAKS','FIT MODEL','INITIAL PARAMETERS','FIT RESULT'):
                self.assertIn(text,notes)
            self.assertTrue((target/'analysis.txt').is_file())
            np.testing.assert_array_equal(np.asarray(Image.open(target/'analysis.png').convert('RGBA')),visible)


if __name__=='__main__':unittest.main()
