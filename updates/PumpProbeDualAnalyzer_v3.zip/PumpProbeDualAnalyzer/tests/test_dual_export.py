import tempfile
import unittest
from pathlib import Path
import json
import numpy as np
from analyzer import core
from analyzer.dual_core import load_dual_pair, prepare_dual, compare_fits
from analyzer.dual_export import build_dual_report, dual_report_text, export_dual
from analyzer.dual_signals import prepare_diagnostics


class DualExportTests(unittest.TestCase):
    def snapshot(self):
        base=Path(__file__).resolve().parents[1]/'examples'
        m=load_dual_pair(base/'dual_demo.dat',base/'dual_demo.comments.txt')
        p=prepare_dual(m,core.Settings(bal_mv=-100,sig_mv=100))
        results=[];initials=[];bands=[]
        for prepared in (p.first,p.second):
            band=core.automatic_band(prepared)
            initial=core.initial_parameters(prepared,1,band)
            results.append(core.fit(prepared,initial,band));initials.append(initial);bands.append(band)
        comparison=compare_fits(*results,p.first_factor,p.second_factor)
        return dict(measurement=m,prepared=p,results=results,bands=bands,initials=initials,
            components=(1,1),pair=(0,0),comparison=comparison,title=r'$$\theta(t)$$',
            time_unit='ns',normalization=True,alphas=(.2,.7),annotation='Sample note')

    def test_end_to_end_known_phase_ratio_and_native_units(self):
        s=self.snapshot();c=s['comparison'];ref=c['reference_s']
        self.assertAlmostEqual(c['delta_phase_rad'],.6,delta=.025)
        expected=.6*np.exp(-ref/2.2e-9+ref/1.8e-9)
        self.assertAlmostEqual(c['amplitude_ratio'],expected,delta=.01)
        report=build_dual_report(s)
        self.assertEqual(report['channels'][0]['fit']['parameters'][0]['unit'],'rad')
        self.assertEqual(report['channels'][1]['fit']['parameters'][0]['unit'],'V')
        text=dual_report_text(report)
        for value in ('Δφ','A_R2 / A_X1','FFT PEAKS','Initial p0','Sample note','not atan2'):
            self.assertIn(value,text)
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(export_dual(Path(tmp)/'My sample',s,{'png':b'exact captured bytes'}))
            self.assertEqual((folder/'analysis.png').read_bytes(),b'exact captured bytes')
            loaded=json.loads((folder/'analysis.json').read_text())
            self.assertEqual(loaded['comparison']['amplitude_ratio'],c['amplitude_ratio'])
            self.assertEqual(loaded['channels'][1]['initial_parameters'],s['initials'][1].tolist())
            a=np.loadtxt(folder/'normalized.tsv',skiprows=1)
            self.assertEqual(a.shape,(len(s['prepared'].first.time),5))
            mask=s['prepared'].first.fit_mask
            self.assertAlmostEqual(np.nanmax(abs(a[mask,2])),1)
            self.assertAlmostEqual(np.nanmax(abs(a[mask,4])),1)
            self.assertIn('Raw_V',(folder/'R2_time.tsv').read_text().splitlines()[0])
            self.assertIn('Raw_rad',(folder/'X1_time.tsv').read_text().splitlines()[0])
            other=Path(export_dual(Path(tmp)/'My sample',s,{}))
            self.assertEqual(other.name,'My sample_001')

    def test_missing_second_fit_exports_first_and_reports_unavailable_comparison(self):
        s=self.snapshot();s['results'][1]=None;s['comparison']=None
        report=build_dual_report(s)
        self.assertIsNotNone(report['channels'][0]['fit'])
        self.assertIsNone(report['channels'][1]['fit'])
        self.assertIn('not available',dual_report_text(report))

    def test_short_record_without_any_fit_exports_without_fake_parameters(self):
        base=Path(__file__).resolve().parents[1]/'examples'
        m=load_dual_pair(base/'dual_demo.dat',base/'dual_demo.comments.txt')
        p=prepare_dual(m,core.Settings(bal_mv=-100,sig_mv=100,skip_steps=100000))
        s=dict(measurement=m,prepared=p,results=(None,None),bands=((0,1e9),(0,1e9)),
            initials=(None,None),components=(1,1),pair=(0,0),comparison=None)
        report=build_dual_report(s)
        for channel in report['channels']:
            self.assertEqual(channel['initial_parameters'],[])
            self.assertIsNone(channel['fit'])
            self.assertEqual(channel['fft_peaks'],[])
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(export_dual(Path(tmp)/'partial',s,{}))
            self.assertTrue((folder/'analysis.txt').is_file())

    def test_diagnostics_and_hidden_fit_presentation_export_all_numerical_results(self):
        s=self.snapshot();s['diagnostics']=prepare_diagnostics(s['prepared'])
        s['labels']={'x2.title':r'$$X_2(t)$$','normalized.ylabel':'a.u.'}
        s['fit_visible']=(False,True);s['footer_visible']=False
        report=build_dual_report(s)
        self.assertEqual(report['fit_lines_visible'],[False,True])
        self.assertFalse(report['footer_visible'])
        self.assertIsNotNone(report['channels'][0]['fit'])
        self.assertEqual(report['plot_labels'],s['labels'])
        self.assertEqual([d['unit'] for d in report['diagnostics']],['V','V','rad'])
        self.assertIn('DIAGNOSTIC phase2',dual_report_text(report))
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(export_dual(Path(tmp)/'extended',s,{}))
            for key,unit in (('x2','V'),('y2','V'),('phase2','rad')):
                data=np.loadtxt(folder/(key+'_time.tsv'),skiprows=1)
                np.testing.assert_allclose(data[:,1],s['diagnostics'][key].raw_rad)
                self.assertIn('Raw_'+unit,(folder/(key+'_time.tsv')).read_text().splitlines()[0])
                self.assertTrue((folder/(key+'_spectrum.tsv')).is_file())
            loaded=json.loads((folder/'analysis.json').read_text())
            self.assertEqual(loaded['plot_labels'],s['labels'])


if __name__=='__main__': unittest.main()
