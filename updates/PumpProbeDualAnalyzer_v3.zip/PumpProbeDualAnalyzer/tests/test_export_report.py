"""Reports and capture export use generated data, never private measurements."""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/analyzer-report-mpl')
from dataclasses import replace
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from analyzer import core
from analyzer.io import Measurement
from analyzer.export import export_analysis,write_picture,spectral_peaks


def generated():
    t=np.linspace(0,4e-9,501)
    parameters=np.array([3e-6,1.4e9,.2,2.3e-9,.2e-6])
    y=core.evaluate(t,parameters,0)
    measurement=Measurement(100+t*3e8/2e-3,y/1.25,'generated.dat','generated.txt',
                            'ORIGINAL USER NOTES\nSample synthetic', 'V',[])
    settings=core.Settings(zero_mode='manual',zero_mm=100,bal_mv=-200,sig_mv=200,
                          fit_window_mode='manual',fit_min_s=0,fit_max_s=4e-9)
    prepared=core.prepare(measurement,settings)
    initial=core.initial_parameters(prepared,1,(.8e9,2e9))
    result=core.fit(prepared,initial,(.8e9,2e9))
    return measurement,prepared,initial,result


class ReportTests(unittest.TestCase):
    def test_captured_bytes_are_written_exactly_and_text_contains_analysis(self):
        measurement,p,initial,result=generated()
        payloads={'png':b'\x89PNG\r\n\x1a\nexact captured pixels',
                  'pdf':b'%PDF-1.4\nexact captured vectors'}
        with tempfile.TemporaryDirectory() as folder,patch('analyzer.export.make_figure',side_effect=AssertionError('must not render another image')):
            output=Path(export_analysis(Path(folder)/'custom folder',measurement,p,result,'My title',(.8e9,2e9),initial,image_payloads=payloads))
            self.assertEqual((output/'analysis.png').read_bytes(),payloads['png'])
            self.assertEqual((output/'analysis.pdf').read_bytes(),payloads['pdf'])
            report=json.loads((output/'analysis.json').read_text(encoding='utf-8'))
            self.assertEqual(report['component_count'],1)
            self.assertEqual(report['initial_parameters_si'],initial.tolist())
            self.assertEqual(report['initial_parameters'][1]['unit'],'Hz')
            self.assertAlmostEqual(report['initial_parameters'][1]['value'],initial[1])
            self.assertGreater(len(report['fft_peaks']),0)
            self.assertTrue(report['fft_peaks'][0]['strongest'])
            self.assertAlmostEqual(report['fft_peaks'][0]['frequency_ghz'],report['fft_peaks'][0]['frequency_hz']/1e9)
            self.assertEqual(len(report['fit']['parameters']),5)
            text=(output/'analysis.txt').read_text(encoding='utf-8')
            notes=(output/'measurement_parameters.txt').read_text(encoding='utf-8')
            for fragment in ('SPECTRAL PEAKS','INITIAL PARAMETERS','FIT RESULT','sqrt(2)','f1','tau1','R2=', 'GHz','rad/V','My title'):
                self.assertIn(fragment,text)
            self.assertTrue(notes.startswith(measurement.notes))
            self.assertIn(text,notes)
            other=Path(export_analysis(Path(folder)/'custom folder',measurement,p,result,'Other',(.8e9,2e9),initial,image_payloads=payloads))
            self.assertNotEqual(output,other)
            self.assertEqual((output/'analysis.png').read_bytes(),payloads['png'])

    def test_incomplete_payload_rejected_without_creating_export_folder(self):
        m,p,initial,result=generated()
        with tempfile.TemporaryDirectory() as folder:
            output=Path(folder)/'not-created'
            with self.assertRaises(ValueError):export_analysis(output,m,p,result,'title',(.8e9,2e9),initial,image_payloads={'png':b'only png'})
            self.assertFalse(output.exists())

    def test_report_without_fit_and_boundary_maximum(self):
        m,p,initial,result=generated()
        lo,hi=.89e9,.97e9
        peaks=spectral_peaks(p,(lo,hi))
        self.assertTrue(peaks)
        self.assertTrue(peaks[0]['strongest'])
        self.assertFalse(peaks[0]['is_local_maximum'])
        self.assertTrue(peaks[0]['is_band_edge'])
        with tempfile.TemporaryDirectory() as folder:
            output=Path(export_analysis(Path(folder)/'unfitted',m,p,None,'No fit',(lo,hi),[],image_payloads={'png':b'pixels','pdf':b'vectors'}))
            text=(output/'analysis.txt').read_text(encoding='utf-8')
            self.assertIn('Фит не рассчитан',text)
            self.assertIn('band_maximum_not_local_peak',text)
            self.assertNotIn('NaN', (output/'analysis.json').read_text())

    def test_atomic_picture_write_preserves_original_on_replace_error(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'image.png';path.write_bytes(b'original')
            with patch('analyzer.export.os.replace',side_effect=OSError('disk failure')):
                with self.assertRaises(OSError):write_picture(path,b'new pixels')
            self.assertEqual(path.read_bytes(),b'original')
            self.assertEqual(list(Path(folder).iterdir()),[path])
            with self.assertRaises(ValueError):write_picture(path,b'')
            with self.assertRaises(ValueError):write_picture(path.with_suffix('.dat'),b'not image')


if __name__=='__main__':unittest.main()
