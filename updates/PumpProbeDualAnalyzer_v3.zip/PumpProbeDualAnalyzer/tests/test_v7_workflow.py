"""Footer replaces legends; math Title errors are handled as form validation."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
os.environ.setdefault('MPLCONFIGDIR','/tmp/analyzer-v7-mpl')
from pathlib import Path
import time
import unittest
from types import SimpleNamespace
import numpy as np
from PyQt5.QtWidgets import QApplication
from analyzer.ui import AnalysisWindow
from analyzer.presentation import footer_sections


class FooterWorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])

    def test_math_title_validation_and_footer_values_in_main_window(self):
        w=AnalysisWindow();w.show();self.addCleanup(w.close)
        base=Path(__file__).resolve().parents[1]/'examples'
        w.bal.setText('-100');w.sig.setText('100');w.load_paths(base/'demo.dat',base/'demo.comments.txt')
        end=time.monotonic()+30
        while (w.job or w.pending_prepare or w.pending_fit or w.auto_timer.isActive() or w.peak_timer.isActive()) and time.monotonic()<end:
            self.app.processEvents();time.sleep(.005)
        self.assertIsNotNone(w.result,w.messages.toPlainText());result=w.result
        valid=r'$$H=61.3\,\mathrm{mT},\quad\theta(t)$$'
        w.title.setText(valid)
        self.assertTrue(w.title_is_valid);self.assertEqual(w.applied_title,valid)
        shown=w.editor.time_plot.axes.get_title()
        self.assertIsNone(w.editor.time_plot.axes.get_legend())
        formula,fit_text,fft_text=w.footer_content()
        for name in ('A1 =','f1 =','τ1 =','φ1 =','C =','RMSE','R²'):self.assertIn(name,fit_text)
        self.assertIn('FWHM =',fft_text);self.assertIn(r'\frac',formula)
        w.title.setText(r'$$\unknowncommand{x}$$')
        self.assertFalse(w.title_is_valid);self.assertFalse(w.picture_button.isEnabled())
        self.assertEqual(w.editor.time_plot.axes.get_title(),shown)
        self.assertEqual(w.applied_title,valid)
        w.title.setText(r'$\Delta\theta(t)$')
        self.assertTrue(w.title_is_valid);self.assertTrue(w.picture_button.isEnabled())
        self.assertIs(w.result,result)

    def test_all_six_modes_and_all_peak_records_are_formatted_without_limit(self):
        parameters=np.array([v for i in range(6) for v in (1e-6*(i+1),1e9*(i+1),.3,2e-9)]+[1e-7])
        result=SimpleNamespace(parameters=parameters,errors=np.abs(parameters)*.01,reference_s=1e-11,
                               rmse_rad=1e-8,r_squared=.99,warnings=[])
        peaks=[dict(rank=i,frequency_hz=i*1e8,amplitude_rad=1e-6,fwhm_hz=.1e9,fwhm_status='resolved') for i in range(1,101)]
        formula,fit_text,fft_text=footer_sections(result,peaks)
        self.assertIn('^{6}',formula)
        for i in range(1,7):
            for name in ('A','f','τ','φ'):self.assertIn(f'{name}{i} =',fit_text)
        self.assertEqual(fft_text.count('FWHM ='),100)
        self.assertIn('100: f =',fft_text)


if __name__=='__main__':unittest.main()
