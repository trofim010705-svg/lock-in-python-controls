from dataclasses import replace
import unittest
import numpy as np
from analyzer import core
from analyzer.dual_fit_support import diagnostic_fit_input, overlay_values


class DiagnosticFitSupportTests(unittest.TestCase):
    def prepared(self, n=601):
        time=np.linspace(0,3e-9,n)
        params=np.array([.7,1.5e9,.4,2.1e-9,3.])
        values=core.evaluate(time,params,0)
        cfg=core.Settings(bal_mv=-100,sig_mv=100,zero_mode='manual',zero_mm=0,
            fit_window_mode='manual',fit_min_s=0,fit_max_s=3e-9)
        return core.Prepared(time,values.copy(),values.copy(),np.ones(n,bool),
            np.array([]),np.array([]),float('nan'),1e11,[],cfg,np.zeros(n)),params

    def test_quadrature_prepared_values_and_units_are_not_changed(self):
        p,_=self.prepared()
        self.assertIs(diagnostic_fit_input(p,'x2'),p)
        self.assertIs(diagnostic_fit_input(p,'y2'),p)
        with self.assertRaises(ValueError):diagnostic_fit_input(p,'other')

    def test_phase_fit_uses_longest_finite_run_and_recovers_known_frequency(self):
        p,truth=self.prepared()
        p.y[200]=p.raw_rad[200]=np.nan
        fitted_input=diagnostic_fit_input(p,'phase2')
        self.assertIs(fitted_input.y,p.y)
        self.assertEqual(np.flatnonzero(fitted_input.fit_mask)[0],201)
        self.assertEqual(np.flatnonzero(fitted_input.fit_mask)[-1],600)
        self.assertEqual(fitted_input.settings.fit_min_s,p.time[201])
        self.assertEqual(fitted_input.settings.background_degree,-1)
        self.assertAlmostEqual(fitted_input.frequencies[np.argmax(fitted_input.spectrum)]/1e9,1.5,delta=.04)
        band=core.automatic_band(fitted_input)
        p0=core.initial_parameters(fitted_input,1,band)
        result=core.fit(fitted_input,p0,band)
        self.assertAlmostEqual(result.parameters[1]/1e9,1.5,delta=.002)
        self.assertEqual(result.reference_s,p.time[201])
        self.assertGreater(result.r_squared,.99999)
        self.assertTrue(np.isnan(p.y[200]))

    def test_tied_phase_runs_choose_earliest_and_no_cross_gap_interpolation(self):
        p,_=self.prepared(17);p.y[8]=np.nan
        result=diagnostic_fit_input(p,'phase2')
        np.testing.assert_array_equal(np.flatnonzero(result.fit_mask),np.arange(8))
        self.assertGreater(len(result.spectrum),0)
        p.fit_mask[:4]=False
        result=diagnostic_fit_input(p,'phase2')
        np.testing.assert_array_equal(np.flatnonzero(result.fit_mask),np.arange(9,17))

    def test_short_empty_and_constant_phase_do_not_invent_fft(self):
        p,_=self.prepared(9);p.y[4]=np.nan
        result=diagnostic_fit_input(p,'phase2')
        self.assertEqual(result.fit_mask.sum(),4)
        self.assertEqual(len(result.spectrum),0)
        self.assertTrue(any('минимум 8' in message for message in result.warnings))
        p.y[:]=np.nan;result=diagnostic_fit_input(p,'phase2')
        self.assertFalse(result.fit_mask.any());self.assertEqual(len(result.spectrum),0)
        p.y[:]=3.;result=diagnostic_fit_input(p,'phase2')
        self.assertEqual(result.fit_mask.sum(),9);self.assertEqual(len(result.spectrum),0)

    def test_fft_recomputation_ignores_calibration_and_preserves_window(self):
        p,_=self.prepared();p.fit_mask[:100]=False;p.fit_mask[500:]=False
        a=diagnostic_fit_input(p,'phase2')
        other=replace(p,settings=replace(p.settings,bal_mv=-400,sig_mv=25))
        b=diagnostic_fit_input(other,'phase2')
        np.testing.assert_array_equal(a.fit_mask,p.fit_mask)
        np.testing.assert_array_equal(a.spectrum,b.spectrum)
        self.assertEqual(a.settings.window,'hann')
        self.assertEqual(a.settings.padding,8)


class OverlayNormalizationTests(unittest.TestCase):
    def prepared(self):return DiagnosticFitSupportTests().prepared()

    def test_fit_offset_and_scale_match_existing_normalization(self):
        p,truth=self.prepared()
        result=core.FitResult(truth,np.zeros(5),np.eye(5),0,0.,1.,[],1,1.)
        p.fit_mask[:100]=False
        overlay=overlay_values(p,result)
        self.assertEqual(overlay['method'],'fit')
        self.assertEqual(overlay['offset'],3.)
        self.assertAlmostEqual(np.max(abs(overlay['fitted'][overlay['mask']])),1)
        self.assertTrue(np.isnan(overlay['fitted'][:100]).all())
        np.testing.assert_allclose(overlay['points'],(p.y-3.)/overlay['scale'])

    def test_data_only_centering_scale_and_invalid_points(self):
        p,_=self.prepared();p.y[20]=np.nan
        a=overlay_values(p)
        self.assertEqual(a['method'],'data')
        self.assertAlmostEqual(np.mean(a['points'][a['mask']]),0,delta=1e-14)
        self.assertAlmostEqual(np.max(abs(a['points'][a['mask']])),1)
        self.assertTrue(np.isnan(a['points'][20]));self.assertFalse(a['mask'][20])
        self.assertTrue(np.isnan(a['fitted']).all())
        native=replace(p,y=p.y*1e-6)
        b=overlay_values(native)
        np.testing.assert_allclose(a['points'],b['points'],atol=1e-14,equal_nan=True)

    def test_constant_and_empty_data_can_be_displayed_without_division_by_zero(self):
        p,_=self.prepared();p.y[:]=5.
        a=overlay_values(p)
        self.assertEqual(a['method'],'constant');self.assertEqual(a['scale'],1.)
        np.testing.assert_array_equal(a['points'],np.zeros(len(p.time)))
        p.y[:]=np.nan;a=overlay_values(p)
        self.assertEqual(a['method'],'empty');self.assertFalse(a['mask'].any())
        self.assertTrue(np.isnan(a['points']).all())
        p.y[:]=np.arange(len(p.time));p.fit_mask[:]=False
        a=overlay_values(p)
        self.assertEqual(a['method'],'data');self.assertTrue(a['mask'].all())


if __name__=='__main__':unittest.main()
