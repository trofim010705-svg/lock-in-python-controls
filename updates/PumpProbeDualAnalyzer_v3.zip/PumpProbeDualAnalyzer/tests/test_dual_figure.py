"""The dual overview is the same full figure that is exported."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
from io import BytesIO
from types import SimpleNamespace
import unittest
import numpy as np
from PIL import Image
from PyQt5.QtWidgets import QApplication
from analyzer.dual_figure import DualFigure
from analyzer.core import Prepared,Settings,FitResult,evaluate


class DualFigureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])

    def data(self):
        time=np.linspace(0,3e-9,300)
        settings=Settings(bal_mv=-100,sig_mv=100,fit_window_mode='manual',fit_min_s=0,fit_max_s=3e-9)
        prepared=[];results=[]
        for i in range(2):
            params=np.array([2e-6*(i+1),1.2e9,.3+i*.4,2e-9,1e-7])
            y=evaluate(time,params,0)
            f=np.linspace(0,5e9,400);s=1e-6*np.exp(-((f-1.2e9)/.2e9)**2)
            prepared.append(Prepared(time,y,y,np.ones(len(time),bool),f,s,1/3e-9,50e9,[],settings,np.zeros_like(time)))
            results.append(FitResult(params,np.abs(params)*.01,np.diag((params*.01)**2),0,1e-9,.999,[],10,2.))
        dual=SimpleNamespace(first=prepared[0],second=prepared[1],first_unit='rad',second_unit='V',first_factor=2.5,second_factor=1)
        return dual,tuple(results),((.5e9,2e9),(.5e9,2e9))

    def test_footers_units_normalization_transparency_and_exact_png(self):
        e=DualFigure();e.resize(1150,850);e.show();self.addCleanup(e.close);self.app.processEvents()
        dual,results,bands=self.data()
        e.set_data(dual,results,bands)
        e.set_summary_text('Δφ(R2 − X1) = 0.4 rad; A_R2/A_X1 = 5')
        e.set_alphas(.2,.7)
        self.app.processEvents();e.render()
        self.assertIn('µV',e.column_artists[1].get_text())
        self.assertIn('FWHM',e.column_artists[0].get_text())
        self.assertIn('A1 =',e.column_artists[1].get_text())
        self.assertIsNone(e.time_axes[0].get_legend())
        self.assertAlmostEqual(e.normalized_points[0].get_alpha(),.2)
        self.assertAlmostEqual(e.normalized_points[1].get_alpha(),.7)
        self.assertEqual(e.normalized_fits[0].get_alpha(),1)
        self.assertGreater(len(e.normalized_points[0].get_ydata()),250)
        self.assertLessEqual(np.max(np.abs(e.normalized_fits[0].get_ydata())),1.002)
        before=np.asarray(e.canvas.buffer_rgba()).copy()
        images=e.capture_images(('png','pdf','svg'))
        np.testing.assert_array_equal(np.asarray(Image.open(BytesIO(images['png']))),before)
        self.assertTrue(images['pdf'].startswith(b'%PDF'));self.assertIn(b'<svg',images['svg'])
        self.assertGreater(e.scroll.verticalScrollBar().maximum(),0)
        e.set_normalized_visible(False);e.render();self.assertFalse(e.normalized_axes.get_visible())

    def test_clear_data_removes_previous_measurement_and_ps_style_keeps_units(self):
        e=DualFigure();e.resize(1050,800);e.show();self.addCleanup(e.close);self.app.processEvents()
        dual,results,bands=self.data();e.set_data(dual,results,bands,time_unit='ps')
        e.set_title(r'$$R_2(t)$$');e.set_alphas(.2,.8);e.set_summary_text('comparison')
        e.set_normalized_visible(False);e.set_normalized_visible(True)
        self.assertEqual(e.normalized_axes.get_xlabel(),'Задержка (ps)')
        title=e.title_artist.get_text();e.clear_data();e.render()
        self.assertIsNone(e._prepared);self.assertEqual(e.title_artist.get_text(),title)
        self.assertEqual(e.normalized_axes.get_xlabel(),'Задержка (ps)')
        self.assertAlmostEqual(e.point_artists[0].get_alpha(),.2)
        for artist in (*e.point_artists,*e.fit_artists,*e.spectrum_artists,*e.peak_artists,*e.normalized_points,*e.normalized_fits):
            self.assertEqual(len(artist.get_ydata()),0)
        for artist in (*e.column_artists,*e.formula_artists,e.summary_artist):self.assertEqual(artist.get_text(),'')
        e.set_data(dual,results,bands,time_unit='ps');e.render()
        self.assertGreater(len(e.point_artists[0].get_ydata()),0)

    def test_title_math_guard_and_styles_preserve_zoom(self):
        e=DualFigure();e.resize(1050,800);e.show();self.addCleanup(e.close);self.app.processEvents()
        dual,results,bands=self.data();e.set_data(dual,results,bands)
        e.time_axes[0].set_xlim(.5,1.);e.normalized_axes.set_ylim(-.8,.8)
        self.assertTrue(e.set_title(r'$$\theta_1(t),\quad R_2(t)$$'))
        valid=e.title_artist.get_text()
        self.assertFalse(e.set_title(r'$$\unknown{x}$$'));self.assertEqual(e.title_artist.get_text(),valid)
        e.set_fonts(18,11);e.set_alphas(.3,.4);e.render()
        self.assertEqual(e.time_axes[0].get_xlim(),(.5,1.))
        self.assertEqual(e.normalized_axes.get_ylim(),(-.8,.8))
        self.assertIn('R_2',e.title_artist.get_text())
        selected=[];e.band_changed.connect(lambda i,b:selected.append((i,b)))
        e._band_selected(1,.6,1.9)
        self.assertEqual(selected,[(1,(.6e9,1.9e9))])


if __name__=='__main__':unittest.main()
