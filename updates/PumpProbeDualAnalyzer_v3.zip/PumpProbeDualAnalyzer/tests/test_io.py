"""Input handling uses synthetic files; real measurements are not redistributed."""
import tempfile
from pathlib import Path
import unittest
import numpy as np
from analyzer.io import load_pair, associated_notes, read_text


class InputTests(unittest.TestCase):
    def pair(self, folder, rows, notes='RESULT: complete\n'):
        data=Path(folder)/'scan.dat'; info=Path(folder)/'scan.comments.txt'
        data.write_text('Position\tX1\tY1\nmm\tV\tV\n'+rows,encoding='utf-8')
        info.write_text(notes,encoding='utf-8')
        return data,info

    def test_short_measurements_are_loaded_and_empty_is_explicit(self):
        with tempfile.TemporaryDirectory() as folder:
            paths=self.pair(folder,'1\t2\t3\n2\t4\t6\n','RESULT: reset\nPoints saved: 2\n')
            measurement=load_pair(*paths)
            np.testing.assert_array_equal(measurement.x1,[2,4])
            self.assertIn('RESULT=reset',measurement.warnings[0])
            paths=self.pair(folder,'','RESULT: reset\nPoints saved: 0\n')
            with self.assertRaisesRegex(ValueError,'пуст'):
                load_pair(*paths)

    def test_missing_first_or_second_cell_never_uses_other_channel(self):
        with tempfile.TemporaryDirectory() as folder:
            for rows in ('1\t\t999\n','\t1\t999\n',
                         '1\t2\t999\n2\t\t999\n', 'bad\t2\t999\n'):
                paths=self.pair(folder,rows)
                with self.assertRaisesRegex(ValueError,'координата или X1'):
                    load_pair(*paths)

    def test_nan_filter_and_declared_count_warning(self):
        with tempfile.TemporaryDirectory() as folder:
            paths=self.pair(folder,'1\t2\tbad\n2\tnan\tunused\n3\t4\tignored\n',
                            'RESULT: complete\nPoints saved: 100\n')
            measurement=load_pair(*paths)
            self.assertEqual(len(measurement.x1),2)
            self.assertTrue(any('Points saved=100' in w for w in measurement.warnings))
            self.assertTrue(any('NaN' in w or 'нечисловых' in w for w in measurement.warnings))

    def test_cp1251_and_utf16_notes(self):
        with tempfile.TemporaryDirectory() as folder:
            for encoding in ('cp1251','utf-16','utf-8-sig'):
                path=Path(folder)/'notes.txt'
                expected='Параметры: образец, Bal = -100 mV'
                path.write_bytes(expected.encode(encoding))
                self.assertEqual(read_text(path),expected)

    def test_pair_selection_stays_in_same_directory(self):
        with tempfile.TemporaryDirectory() as folder:
            first=Path(folder)/'first';second=Path(folder)/'second'
            first.mkdir();second.mkdir()
            data,notes=self.pair(first,'1\t2\t3\n')
            _,other=self.pair(second,'1\t2\t3\n')
            self.assertEqual(associated_notes(data),notes)
            notes.unlink()
            self.assertIsNone(associated_notes(data))
            self.assertTrue(other.exists())


if __name__=='__main__': unittest.main()
