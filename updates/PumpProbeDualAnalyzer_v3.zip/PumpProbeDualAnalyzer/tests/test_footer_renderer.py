import os
os.environ['QT_QPA_PLATFORM']='offscreen'
from io import BytesIO
import unittest
from PIL import Image
from PyQt5.QtWidgets import QApplication
from analyzer.figure_editor import FigureEditor


class FooterLayoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])

    def test_all_rows_are_below_plots_and_canvas_grows_without_truncation(self):
        e=FigureEditor();e.resize(950,720);e.show();self.addCleanup(e.close)
        self.app.processEvents()
        rows='\n'.join(f'Peak {i}: f={i}.123 GHz; A=3.45 µrad; FWHM=.5 GHz' for i in range(80))
        fit='Fit\n'+ '\n'.join(f'A{i}=1.2 µrad; tau{i}=2.3 ns; phi{i}=.4 rad' for i in range(6))
        e.set_footer(r'$\theta(u)=\sum_{i=1}^{6}A_i e^{-u/\tau_i}\sin(2\pi f_i u+\phi_i)+C$',fit,rows)
        self.app.processEvents();e.render()
        self.assertIn('Peak 79:',e.footer_fft_text.get_text())
        self.assertGreater(e.canvas.minimumHeight(),1500)
        self.assertGreater(e.scroll.verticalScrollBar().maximum(),0)
        renderer=e.canvas.get_renderer()
        fft_box=e.footer_fft_text.get_window_extent(renderer)
        fit_box=e.footer_fit_text.get_window_extent(renderer)
        self.assertGreaterEqual(fft_box.y0,0)
        self.assertGreaterEqual(fit_box.y0,0)
        self.assertLess(fft_box.y1,e.fft_plot.axes.get_window_extent(renderer).y0)
        self.assertLessEqual(fit_box.x1,fft_box.x0+5)
        payload=e.capture_images(('png',))['png']
        self.assertEqual(Image.open(BytesIO(payload)).height,e.canvas.get_width_height(physical=True)[1])
        self.assertIsNone(e.time_plot.axes.get_legend())
        e.set_footer('','','');e.render()
        self.assertFalse(e.footer_axes.get_visible())
        self.assertEqual(e.canvas.minimumHeight(),600)

    def test_large_footer_font_on_narrow_canvas_wraps_without_horizontal_clipping(self):
        e=FigureEditor();e.resize(450,650);e.show();self.addCleanup(e.close)
        self.app.processEvents()
        for fontsize in (24,72):
            with self.subTest(fontsize=fontsize):
                e.set_fonts(16,fontsize)
                e.set_footer(r'$\theta(u)=\sum_{i=1}^{6} A_i e^{-u/\tau_i}\sin(2\pi f_i u+\phi_i)+C$',
                    'Fit parameters\nA1=12.345 µrad; f1=3.456789 GHz; tau1=2.345 ns',
                    'FFT peaks\nf=3.456 GHz; A=12.345 µrad; FWHM=0.567 GHz')
                self.app.processEvents();e.render()
                renderer=e.canvas.get_renderer()
                for artist in (e.footer_formula,e.footer_fit_text,e.footer_fft_text):
                    bbox=artist.get_window_extent(renderer)
                    self.assertGreaterEqual(bbox.x0,0)
                    self.assertLessEqual(bbox.x1,e.canvas.get_width_height(physical=True)[0])
                    self.assertGreaterEqual(bbox.y0,0)
                self.assertEqual(e.footer_fit_text.get_fontsize(),fontsize)
                self.assertLess(e.footer_formula.get_fontsize(),fontsize+2)



if __name__=='__main__':unittest.main()
