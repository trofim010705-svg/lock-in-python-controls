"""Regression tests use generated data, not the user's private measurements."""
from dataclasses import asdict
from threading import Event
import unittest
import numpy as np
from analyzer.core import (Settings,prepare,evaluate,automatic_band,initial_parameters,fit,Cancelled)
from analyzer.io import Measurement


def generated(two=False):
    t=np.linspace(0,2.65e-9,801)
    params=np.array([3e-5,4.2e9,.6,2.4e-9]+([1.5e-5,3.5e9,-.7,3.8e-9] if two else [])+[2e-6])
    rng=np.random.default_rng(12)
    y=evaluate(t,params,0)+rng.normal(0,2e-7,len(t))
    m=Measurement(t*3e8/2e-3+92.171,y/1.25,'generated','generated','generated','V',[])
    cfg=Settings(bal_mv=-200,sig_mv=200,zero_mode='manual',zero_mm=92.171,
                 fit_window_mode='manual',fit_min_s=0,fit_max_s=2.65e-9)
    return prepare(m,cfg),params


class RobustFitTests(unittest.TestCase):
    def test_geometry_is_fixed_and_not_a_configurable_field(self):
        self.assertEqual(Settings().path_factor,2)
        self.assertNotIn('path_factor',asdict(Settings()))
        with self.assertRaises(TypeError):Settings(path_factor=1)

    def test_auto_band_includes_signal_above_old_two_GHz_ceiling(self):
        p,_=generated();lo,hi=automatic_band(p)
        self.assertLess(lo,4.2e9);self.assertGreater(hi,4.2e9)
        self.assertGreater(lo,2e9)

    def test_multistart_recovers_a_high_frequency_from_bad_manual_seed(self):
        p,truth=generated()
        bad=np.array([1e-6,2.1e9,2.7,1e-10,0])
        r=fit(p,bad,(2e9,6e9))
        self.assertGreater(r.r_squared,.999)
        self.assertAlmostEqual(r.parameters[1]/truth[1],1,places=3)
        self.assertAlmostEqual(r.parameters[3]/truth[3],1,places=2)

    def test_two_modes_recover_beats_and_lifetimes(self):
        p,truth=generated(two=True);band=automatic_band(p,2)
        r=fit(p,initial_parameters(p,2,band),band)
        actual=r.parameters[:-1].reshape(2,4)
        actual=actual[np.argsort(actual[:,1])]
        expected=truth[:-1].reshape(2,4)
        expected=expected[np.argsort(expected[:,1])]
        np.testing.assert_allclose(actual[:,1],expected[:,1],rtol=.003)
        np.testing.assert_allclose(actual[:,3],expected[:,3],rtol=.03)
        self.assertGreater(r.r_squared,.999)

    def test_manually_restricted_band_is_respected_and_warns_about_main_peak(self):
        p,_=generated();band=(.3e9,2e9)
        r=fit(p,initial_parameters(p,1,band),band)
        self.assertTrue(band[0]<=r.parameters[1]<=band[1])
        self.assertTrue(any('вне выбранной полосы' in warning for warning in r.warnings))
        self.assertLess(r.r_squared,.5)

    def test_cancellation_and_short_curves(self):
        p,_=generated();cancel=Event();cancel.set()
        with self.assertRaises(Cancelled):fit(p,initial_parameters(p,1,automatic_band(p)),automatic_band(p),cancel)
        for n in (1,4,7):
            m=Measurement(np.arange(n,dtype=float),np.arange(n,dtype=float),'g','g','g','V',[])
            short=prepare(m,Settings(bal_mv=-200,sig_mv=200))
            self.assertEqual(len(short.time),n);self.assertEqual(len(short.spectrum),0)
            self.assertTrue(np.isfinite(short.nyquist_hz))


if __name__=='__main__':unittest.main()
