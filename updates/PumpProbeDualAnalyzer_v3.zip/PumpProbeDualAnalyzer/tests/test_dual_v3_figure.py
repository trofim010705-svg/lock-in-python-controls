"""Five-signal comparison, independent fits and optional FFT text."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
from dataclasses import replace
from io import BytesIO
from types import SimpleNamespace
import unittest
import numpy as np
from PIL import Image
from PyQt5.QtWidgets import QApplication
from analyzer.core import Prepared, Settings, FitResult, evaluate
from analyzer.dual_figure import DualFigure


class FiveSignalFigureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])

    def build(self):
        e=DualFigure();e.resize(1100,800);e.show();self.addCleanup(e.close);self.app.processEvents()
        t=np.linspace(0,3e-9,260);frequency=np.linspace(0,8e9,600)
        cfg=Settings(bal_mv=-100,sig_mv=100,fit_window_mode='manual',fit_min_s=0,fit_max_s=3e-9)
        contexts={};results={}
        for i,key in enumerate(('x1','r2','x2','y2','phase2')):
            amplitude=.2 if key=='phase2' else (i+1)*1e-6
            params=np.array([amplitude,1.2e9,.2+i*.1,2e-9,.6 if key=='phase2' else 5e-6])
            y=evaluate(t,params,0);spectrum=amplitude*np.exp(-((frequency-1.2e9)/.2e9)**2)
            contexts[key]=Prepared(t,y,y,np.ones(len(t),bool),frequency,spectrum,1/3e-9,8e9,[],cfg,np.zeros_like(t))
            results[key]=FitResult(params,abs(params)*.01,np.eye(5),0,amplitude*.01,.999,[],10,2.)
        phase_mask=(t>=.5e-9)&(t<=2e-9)
        fit_prepared={key:contexts[key] for key in ('x2','y2','phase2')}
        fit_prepared['phase2']=replace(contexts['phase2'],fit_mask=phase_mask)
        dual=SimpleNamespace(first=contexts['x1'],second=contexts['r2'],first_unit='rad',second_unit='V')
        bands=((.5e9,2e9),)*2
        e.set_data(dual,(results['x1'],results['r2']),bands,
            diagnostics={key:contexts[key] for key in ('x2','y2','phase2')},
            diagnostic_results={key:results[key] for key in ('x2','y2','phase2')},
            diagnostic_fit_prepared=fit_prepared,diagnostic_bands={key:bands[0] for key in fit_prepared},
            diagnostic_components={key:1 for key in fit_prepared})
        return e,contexts,results,fit_prepared

    def test_any_subset_has_own_fit_visibility_alpha_and_custom_legend(self):
        e,p,results,fit_p=self.build()
        original={key:r.parameters.copy() for key,r in results.items()}
        e.time_axes[0].set_xlim(.3,1.1);e.normalized_axes.set_ylim(-.8,.8)
        e.set_labels({'legend.x2_points':'Quadrature X','legend.phase2_fit':r'$\varphi$ fit'})
        e.set_overlay_signals(('x2','phase2'))
        e.set_signal_alphas({'x2':.15,'phase2':.8})
        e.set_fit_visibility({'x2':False,'phase2':True,'r2':False})
        self.assertFalse(e.normalized_points[0].get_visible())
        self.assertFalse(e.normalized_points[1].get_visible())
        self.assertTrue(e.normalized_diagnostic_points['x2'].get_visible())
        self.assertTrue(e.normalized_diagnostic_points['phase2'].get_visible())
        self.assertFalse(e.normalized_diagnostic_points['y2'].get_visible())
        self.assertFalse(e.diagnostic_fit_artists['x2'].get_visible())
        self.assertFalse(e.normalized_diagnostic_fits['x2'].get_visible())
        self.assertTrue(e.diagnostic_fit_artists['phase2'].get_visible())
        self.assertEqual(e.normalized_diagnostic_points['x2'].get_alpha(),.15)
        self.assertEqual(e.normalized_diagnostic_fits['phase2'].get_alpha(),1)
        self.assertEqual(e.time_axes[0].get_xlim(),(.3,1.1))
        self.assertEqual(e.normalized_axes.get_ylim(),(-.8,.8))
        labels=[text.get_text() for text in e.normalized_axes.get_legend().get_texts()]
        self.assertIn('Quadrature X',labels);self.assertIn(r'$\varphi$ fit',labels)
        self.assertNotIn('X2 fit',labels)
        for key in original:np.testing.assert_array_equal(results[key].parameters,original[key])
        e.set_overlay_signals(())
        self.assertIsNone(e.normalized_axes.get_legend())
        for key in ('x2','y2','phase2'):self.assertFalse(e.normalized_diagnostic_points[key].get_visible())

    def test_peak_flags_only_remove_footer_fft_text_not_fits_or_spectra(self):
        e,p,results,fit_p=self.build()
        before=np.asarray(e.diagnostic_spectra['x2'].get_ydata()).copy()
        e.set_peak_annotations({key:False for key in ('x1','x2','y2','r2','phase2')})
        text='\n'.join(e._columns)
        self.assertNotIn('FFT:',text);self.assertIn('A1 =',text);self.assertIn('φ₂',text)
        e.set_peak_annotations({'x2':True})
        text='\n'.join(e._columns)
        self.assertEqual(text.count('FFT:'),1)
        self.assertIn('FWHM =',text)
        np.testing.assert_array_equal(e.diagnostic_spectra['x2'].get_ydata(),before)
        self.assertEqual(len(e.diagnostic_peaks['x2'].get_xdata()),1)
        emitted=[];e.diagnostic_band_changed.connect(lambda key,band:emitted.append((key,band)))
        e._diagnostic_band_selected('x2',.6,1.9)
        self.assertEqual(emitted,[('x2',(.6e9,1.9e9))])

    def test_phase_fit_stays_in_its_interval_and_new_lines_are_exactly_exported(self):
        e,p,results,fit_p=self.build();e.set_overlay_signals(('x1','x2','y2','r2','phase2'))
        selected=p['phase2'].time[fit_p['phase2'].fit_mask]/1e-9
        x=e.diagnostic_fit_artists['phase2'].get_xdata()
        self.assertAlmostEqual(x[0],selected[0]);self.assertAlmostEqual(x[-1],selected[-1])
        nx=e.normalized_diagnostic_fits['phase2'].get_xdata()
        self.assertAlmostEqual(nx[0],selected[0]);self.assertAlmostEqual(nx[-1],selected[-1])
        e.render();self.app.processEvents();before=np.asarray(e.canvas.buffer_rgba()).copy()
        payload=e.capture_images(('png',))['png']
        np.testing.assert_array_equal(before,np.asarray(Image.open(BytesIO(payload))))
        e.clear_data()
        for artists in (e.diagnostic_fit_artists,e.normalized_diagnostic_points,e.normalized_diagnostic_fits):
            for artist in artists.values():self.assertEqual(len(artist.get_ydata()),0)


if __name__=='__main__':unittest.main()
