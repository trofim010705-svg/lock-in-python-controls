import os
os.environ['QT_QPA_PLATFORM']='offscreen'
os.environ['MPLCONFIGDIR']='/tmp/analyzer-test-mpl'
from dataclasses import replace
from pathlib import Path
from threading import Event
import tempfile
import time
import unittest
from unittest.mock import patch
import numpy as np
from PyQt5.QtWidgets import QApplication
from analyzer.io import Measurement, load_pair
from analyzer import core
from analyzer.export import export_analysis, make_figure, save_picture
from analyzer.presentation import PlotStyle, angle_unit, angle_text
from analyzer.ui import AnalysisWindow


def synthetic(count=1, irregular=False):
    rng=np.random.default_rng(123)
    t=np.linspace(0,8e-9,1601)
    if irregular: t[1:-1]+=rng.uniform(-.1,.1,len(t)-2)*5e-12
    params=np.array([2e-6,1.2e9,.3,3e-9, .3e-6] if count==1 else
                    [2e-6,1.2e9,.3,3e-9, 1.2e-6,2.1e9,-.8,5e-9, .3e-6])
    y=core.evaluate(t,params,0)+rng.normal(0,5e-9,len(t))
    m=Measurement(t*3e8/2e-3+106.45,y/2.5,'test.dat','test.txt','test','V',[])
    cfg=core.Settings(bal_mv=-100,sig_mv=100,fit_min_s=0,fit_max_s=8e-9,zero_mode="manual",fit_window_mode="manual")
    return m,cfg,params


def coherence_measurement():
    """Synthetic coherence spike and a slightly jittered mechanical grid."""
    positions=90.171+np.arange(316)*.5
    positions[5:8]=[92.669,93.170,93.669]
    t=(positions-positions[4])*2e-3/3e8
    y=2e-5*np.sin(2*np.pi*1.5e9*t)*np.exp(-np.maximum(t,0)/2e-9)
    y[4]=3e-4
    return Measurement(positions,y,'synthetic.dat','synthetic.txt','synthetic','V',[])


class NumericTests(unittest.TestCase):
    def test_automatic_window_starts_at_third_measured_step_and_ends_at_data_end(self):
        m=coherence_measurement();cfg=core.Settings(bal_mv=-200,sig_mv=200)
        p=core.prepare(m,cfg)
        self.assertEqual(p.settings.zero_mm,92.171)
        self.assertAlmostEqual(m.position[p.fit_mask][0],93.669)
        self.assertEqual(np.flatnonzero(p.fit_mask)[0],7)
        self.assertEqual(p.fit_mask.sum(),309)
        self.assertAlmostEqual(p.settings.fit_min_s,9.9866666666666e-12,places=23)
        self.assertEqual(p.settings.fit_max_s,p.time[-1])
        reverse=replace(m,position=m.position[::-1],x1=m.x1[::-1])
        r=core.prepare(reverse,cfg)
        np.testing.assert_allclose(p.time,r.time)
        np.testing.assert_array_equal(p.fit_mask,r.fit_mask)
        fig=make_figure(p,None,'window',(.3e9,2e9))
        self.assertEqual(fig.axes[0].lines[0].get_xdata()[0],p.settings.fit_min_s/1e-9)
        fig.clear()

    def test_peak_at_scan_end_keeps_curve_without_fft_instead_of_raising(self):
        m=coherence_measurement();m.x1[-1]=1
        p=core.prepare(m,core.Settings(bal_mv=-200,sig_mv=200))
        self.assertEqual(len(p.time),316)
        self.assertFalse(p.fit_mask.any());self.assertEqual(len(p.spectrum),0)
        self.assertTrue(any('Исходная кривая' in warning for warning in p.warnings))
    def test_calibration_units_signs_and_current_input_rejection(self):
        self.assertAlmostEqual(core.calibration_coefficient(-100,100),2.5)
        self.assertAlmostEqual(core.calibration_coefficient(-20,80)*2e-6,7.9056941504e-6,places=14)
        for bal,sig in ((None,None),(0,100),(10,100),(-10,0),(-10,-5),
                        (np.nan,100),(-10,np.inf)):
            with self.assertRaises(ValueError): core.calibration_coefficient(bal,sig)
        m,cfg,_=synthetic()
        with self.assertRaisesRegex(ValueError,'амперы'):
            core.prepare(replace(m,signal_unit='A'),cfg)

    def test_display_prefixes_do_not_change_stored_radians(self):
        for value,factor,unit in ((2.5e-3,1e-3,'mrad'),(2.5e-6,1e-6,'µrad'),
                                 (2.5e-9,1e-9,'nrad'),(2.5e-12,1e-12,'prad')):
            self.assertEqual(angle_unit([-value,value]),(factor,unit))
            self.assertEqual(angle_text(value),'2.5 '+unit)

    def test_peak_zero_is_raw_signed_maximum_including_steps_and_reverse_order(self):
        m,cfg,_=synthetic()
        m.x1[200]=100
        m.x1[400]=-1000  # abs maximum must NOT become zero.
        cfg=replace(cfg,zero_mode='peak',background_degree=1,
                    bg_min_s=-1e-9,bg_max_s=8e-9)
        p=core.prepare(m,cfg)
        self.assertEqual(p.settings.zero_mm,m.position[200])
        self.assertEqual(p.time[200],0)
        mm_peak=m.position[200]
        m.position=m.position[::-1]/.002;m.x1=m.x1[::-1]
        reversed_p=core.prepare(m,replace(cfg,mm_per_unit=.002))
        self.assertAlmostEqual(reversed_p.settings.zero_mm,mm_peak)
        np.testing.assert_allclose(reversed_p.time,p.time,atol=1e-23)

    def test_delay_seconds_and_bal_sig_calibration(self):
        m,cfg,_=synthetic()
        p=core.prepare(m,cfg)
        old_ns=(m.position-106.45)/.3*2/1000
        np.testing.assert_allclose(p.time,old_ns*1e-9,atol=1e-23)
        np.testing.assert_allclose(p.raw_rad,m.x1*2.5)
        steps=replace(m,position=m.position/.002)
        np.testing.assert_allclose(core.prepare(steps,replace(cfg,mm_per_unit=.002)).time,
                                   core.prepare(m,cfg).time,atol=1e-23)

    def test_single_fit_recovers_frequency_lifetime_amplitude_and_offset(self):
        m,cfg,truth=synthetic();p=core.prepare(m,cfg)
        initial=core.initial_parameters(p,1,(.8e9,1.6e9))
        result=core.fit(p,initial,(.8e9,1.6e9))
        np.testing.assert_allclose(result.parameters,truth,rtol=.015,atol=5e-10)
        self.assertGreater(result.r_squared,.999)
        self.assertTrue(np.isfinite(result.errors).all())

    def test_two_sines_irregular_grid_descending_and_duplicate_coordinates(self):
        m,cfg,truth=synthetic(2,True)
        m.position=np.r_[m.position,m.position[100]][::-1]
        m.x1=np.r_[m.x1,m.x1[100]][::-1]
        p=core.prepare(m,cfg)
        self.assertTrue(any('усреднены' in s for s in p.warnings))
        self.assertTrue(any('интерполяция' in s for s in p.warnings))
        seed=core.initial_parameters(p,2,(.7e9,2.7e9))
        result=core.fit(p,seed,(.7e9,2.7e9))
        actual=result.parameters[:-1].reshape(-1,4)
        actual=actual[np.argsort(actual[:,1])]
        target=truth[:-1].reshape(-1,4)
        np.testing.assert_allclose(actual[:,1],target[:,1],rtol=.003)
        np.testing.assert_allclose(actual[:,3],target[:,3],rtol=.03)
        self.assertGreater(result.r_squared,.999)

    def test_fft_peak_tracks_selected_band(self):
        m,cfg,_=synthetic(2);p=core.prepare(m,cfg)
        for band,target in [((.8e9,1.5e9),1.2e9),((1.8e9,2.4e9),2.1e9)]:
            index=core.peak_indices(p,*band)[0]
            self.assertLess(abs(p.frequencies[index]-target),p.resolution_hz)
        with self.assertRaises(ValueError): core.peak_indices(p,3e12,4e12)

    def test_background_and_invalid_settings(self):
        m,cfg,_=synthetic()
        p=core.prepare(m,replace(cfg,background_degree=1,bg_min_s=0,bg_max_s=8e-9))
        np.testing.assert_allclose(p.raw_rad-p.background,p.y)
        for invalid in (replace(cfg,mm_per_unit=0),replace(cfg,fit_min_s=1),replace(cfg,padding=3)):
            with self.assertRaises(ValueError):core.prepare(m,invalid)
        cancel=Event();cancel.set()
        with self.assertRaises(core.Cancelled):core.fit(p,core.initial_parameters(p,1,(.8e9,1.6e9)),(.8e9,1.6e9),cancel)


class FileTests(unittest.TestCase):
    def test_selected_picture_path_custom_legend_and_limits(self):
        m,cfg,_=synthetic();p=core.prepare(m,cfg)
        style=PlotStyle(experiment_label='Sample A',fit_label='Custom fit',
                        time_ylim=(-1e-6,2e-6),fft_ylim=(0,1e-6))
        fig=make_figure(p,None,'Custom title',(.8e9,1.6e9),style)
        self.assertEqual(fig.axes[0].get_title(),'Custom title')
        np.testing.assert_allclose(fig.axes[0].get_ylim(),np.asarray(style.time_ylim)/1e-6)
        self.assertEqual(fig.axes[0].get_ylabel(),'Rotation (µrad)')
        np.testing.assert_allclose(fig.axes[1].get_ylim(),np.asarray(style.fft_ylim)/1e-6)
        self.assertIsNone(fig.axes[0].get_legend())
        self.assertTrue(any('Sample A' in text.get_text() for text in fig.axes[2].texts))
        fig.clear()
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'Выбранный путь'/'мой график.svg'
            save_picture(path,p,None,'Custom title',(.8e9,1.6e9),style)
            self.assertIn('Sample A',path.read_text())
            self.assertEqual(list(path.parent.iterdir()),[path])
            with self.assertRaises(ValueError):
                save_picture(path.with_suffix('.exe'),p,None,'title',(.8e9,1.6e9),style)
        with self.assertRaises(ValueError):PlotStyle(time_ylim=(2,1)).validate()

    def test_new_old_headers_decimal_comma_and_ignore_other_channels(self):
        with tempfile.TemporaryDirectory() as folder:
            folder=Path(folder); notes=folder/'scan.comments.txt'
            notes.write_text('Образец A\n"unit": "V"',encoding='utf-8')
            data=folder/'scan.dat'
            for header in ('Position\tX1\tY1\tX2\tY2\nmm\tV\tV\tV\tV\n','# Position_mm X1\n# Signal unit: V\n',''):
                data.write_text(header+'\n'.join(f'{i},000\t0,001\tinvalid\tNaN\tunused' for i in range(10)),encoding='utf-8')
                m=load_pair(data,notes)
                self.assertEqual(m.signal_unit,'V');self.assertEqual(len(m.position),10)
                np.testing.assert_allclose(m.x1,.001)
            data.write_text('\n'.join(f'{i}\t1' for i in range(10))+'\nbroken\t1')
            with self.assertRaises(ValueError):load_pair(data,notes)

    def test_export_does_not_overwrite_and_writes_si_tables_and_images(self):
        m,cfg,_=synthetic();p=core.prepare(m,cfg)
        initial=core.initial_parameters(p,1,(.8e9,1.6e9));r=core.fit(p,initial,(.8e9,1.6e9))
        with tempfile.TemporaryDirectory() as folder:
            args=(Path(folder)/'result',m,p,r,'Sample A',(.8e9,1.6e9),initial)
            first=Path(export_analysis(*args)); second=Path(export_analysis(*args))
            self.assertNotEqual(first,second)
            for name in ('analysis.png','analysis.pdf','analysis.json','time_domain.tsv','spectrum.tsv','measurement_parameters.txt'):
                self.assertGreater((first/name).stat().st_size,0)
            self.assertEqual(np.loadtxt(first/'time_domain.tsv',skiprows=1).shape,(1601,6))


class GuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])

    def wait(self,w):
        end=time.monotonic()+20
        while (w.job is not None or w.pending_prepare or w.pending_fit or w.auto_timer.isActive() or w.peak_timer.isActive()) and time.monotonic()<end:
            self.app.processEvents();time.sleep(.005)
        self.assertIsNone(w.job,w.messages.toPlainText())
        self.assertFalse(w.pending_prepare or w.pending_fit or w.auto_timer.isActive(),w.messages.toPlainText())

    def test_load_fit_region_reseed_title_and_invalidate(self):
        w=AnalysisWindow();w.show();self.addCleanup(w.close)
        base=Path(__file__).resolve().parents[1]/'examples'
        w.bal.setText('-100');w.sig.setText('100')
        w.load_paths(base/'demo.dat',base/'demo.comments.txt');self.wait(w)
        self.assertIsNotNone(w.prepared,w.messages.toPlainText())
        self.assertEqual(w.table.rowCount(),5);self.assertIn('SIMULATED',w.notes.toPlainText())
        self.assertIsNotNone(w.result,w.messages.toPlainText())
        self.assertGreater(w.result.r_squared,.98)
        w.title.setText('Sample title')
        self.assertIsNotNone(w.result)
        w.region.setRegion((1,1.6));w.peak_timer.stop();w.update_peaks()
        self.assertIsNone(w.result)
        self.assertTrue(1<=w.table.cellWidget(1,1).value()<=1.6)
        w.model.setCurrentIndex(1);self.wait(w);self.assertEqual(w.table.rowCount(),9)
        w.sig.setText('200');w.invalidate()
        self.assertTrue(w.dirty);self.assertFalse(w.export_button.isEnabled())

    def test_manual_start_parameter_edit_triggers_fit_without_resetting_it(self):
        w=AnalysisWindow();w.show();self.addCleanup(w.close)
        base=Path(__file__).resolve().parents[1]/'examples'
        w.bal.setText('-100');w.sig.setText('100')
        w.load_paths(base/'demo.dat',base/'demo.comments.txt');self.wait(w)
        first=w.result
        w.table.cellWidget(2,1).setValue(.8)
        self.wait(w)
        self.assertIsNotNone(w.result);self.assertIsNot(w.result,first)
        self.assertEqual(w.table.cellWidget(2,1).value(),.8)

    def test_setting_changes_during_fit_discard_old_result_and_automatically_recompute(self):
        w=AnalysisWindow();w.show();self.addCleanup(w.close)
        base=Path(__file__).resolve().parents[1]/'examples'
        w.bal.setText('-100');w.sig.setText('100')
        started=Event();original=core.fit
        def delayed(p,parameters,band,cancel):
            if not started.is_set():
                started.set();time.sleep(.25)
                return original(p,parameters,band)  # Simulate a late, uncancellable result.
            return original(p,parameters,band,cancel)
        with patch('analyzer.core.fit',side_effect=delayed),patch.object(w,'draw_fit',wraps=w.draw_fit) as draw:
            w.load_paths(base/'demo.dat',base/'demo.comments.txt')
            end=time.monotonic()+10
            while not started.is_set() and time.monotonic()<end:
                self.app.processEvents();time.sleep(.002)
            self.assertTrue(started.is_set())
            w.sig.setText('200');w.sig.textEdited.emit('200')
            self.wait(w)
            self.assertEqual(w.prepared.settings.sig_mv,200)
            self.assertIsNotNone(w.result,w.messages.toPlainText())
            self.assertEqual(draw.call_count,1)

    def test_insufficient_window_still_draws_the_full_raw_curve(self):
        w=AnalysisWindow();w.show();self.addCleanup(w.close)
        w.bal.setText('-100');w.sig.setText('100')
        with tempfile.TemporaryDirectory() as folder:
            m=coherence_measurement();m.x1[-1]=1
            data=Path(folder)/'short.dat';notes=data.with_suffix('.txt')
            np.savetxt(data,np.c_[m.position,m.x1],delimiter='\t');notes.write_text('test')
            w.load_paths(data,notes);self.wait(w)
            self.assertIsNone(w.result)
            self.assertEqual(len(w.points.getData()[0]),316)
            self.assertTrue(w.picture_button.isEnabled())

    def test_parameters_can_be_read_before_entering_bal_and_sig(self):
        w=AnalysisWindow();w.show();self.addCleanup(w.close)
        base=Path(__file__).resolve().parents[1]/'examples'
        w.load_paths(base/'demo.dat',base/'demo.comments.txt');self.wait(w)
        self.assertIsNotNone(w.measurement)
        self.assertIn('Bal = -100',w.notes.toPlainText())
        self.assertIsNone(w.prepared);self.assertFalse(w.export_button.isEnabled())
        w.bal.setText('-100');w.sig.setText('100');w.invalidate();self.wait(w)
        self.assertIsNotNone(w.prepared,w.messages.toPlainText())
        np.testing.assert_allclose(w.prepared.raw_rad,
            w.measurement.x1[np.argsort(w.measurement.position)]*2.5)

    def test_automatic_zero_editable_legend_manual_y_and_save_dialog(self):
        w=AnalysisWindow();w.show();self.addCleanup(w.close)
        base=Path(__file__).resolve().parents[1]/'examples'
        w.bal.setText('-100');w.sig.setText('100')
        w.load_paths(base/'demo.dat',base/'demo.comments.txt');self.wait(w)
        expected=w.measurement.position[np.argmax(w.measurement.x1)]
        self.assertEqual(w.prepared.settings.zero_mm,expected)
        self.assertAlmostEqual(float(w.zero.text()),expected,places=8)
        self.assertFalse(w.zero.isEnabled())
        result=w.result;self.assertIsNotNone(result)
        w.experiment_label.setText('My points')
        self.assertIn('f1 =',w.footer_content()[1])
        w.fit_label.setPlainText('My custom fit\nSecond line')
        self.assertTrue(w.footer_content()[0].startswith(r'$\theta'))
        self.assertIn('My custom fit\nSecond line',w.footer_content()[1])
        self.assertIs(w.result,result)
        w.time_y_min.setValue(-2);w.time_y_max.setValue(4)
        w.time_y_auto.setChecked(False)
        np.testing.assert_allclose(w.time_plot.viewRange()[1],[-2e-6,4e-6])
        self.assertIs(w.result,result)
        w.time_y_max.setValue(-3);w.apply_y_limits()
        self.assertEqual(w.applied_time_ylim,(-2e-6,4e-6))
        with tempfile.TemporaryDirectory() as folder:
            path=str(Path(folder)/'chosen.png')
            with patch('analyzer.ui.QFileDialog.getSaveFileName',return_value=(path,'PNG (*.png)')):
                w.save_picture();self.wait(w)
            self.assertGreater(Path(path).stat().st_size,0)
        w.time_y_auto.setChecked(True)
        self.assertIsNone(w.applied_time_ylim)


if __name__=='__main__':unittest.main()
