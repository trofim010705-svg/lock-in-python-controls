"""End-to-end dual GUI checks use the shipped synthetic measurement, not mocks."""
import os
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
os.environ.setdefault('MPLCONFIGDIR', '/tmp/analyzer-dual-workflow-mpl')
from pathlib import Path
import tempfile
import time
import unittest
import numpy as np
from PyQt5.QtWidgets import QApplication
from analyzer.dual_ui import DualAnalysisWindow


class DualWorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.base = Path(__file__).resolve().parents[1]/'examples'

    def settle(self, window, timeout=45):
        end = time.monotonic()+timeout
        idle_since = None
        while time.monotonic() < end:
            self.app.processEvents()
            if window.job is None and not window.pending and not window.timer.isActive() and window.pending_load is None:
                if idle_since is None:idle_since = time.monotonic()
                # A completed job can queue the next load with singleShot(0).
                # Require stable idle across several event-loop iterations.
                if time.monotonic()-idle_since >= .05:return
            else:idle_since = None
            time.sleep(.005)
        self.fail('GUI did not settle:\n'+window.messages.toPlainText())

    def close_window(self, window):
        window.close()
        end = time.monotonic()+15
        while window.pool.activeThreadCount() and time.monotonic() < end:
            self.app.processEvents(); time.sleep(.005)
        self.app.processEvents()
        self.assertEqual(window.pool.activeThreadCount(), 0)
        window.close(); self.app.processEvents()

    def demo(self):
        window = DualAnalysisWindow(); window.show()
        self.addCleanup(self.close_window, window)
        window.bal.setText('-100'); window.sig.setText('100')
        window.load_paths(self.base/'dual_demo.dat', self.base/'dual_demo.comments.txt')
        self.settle(window)
        self.assertTrue(all(r is not None for r in window.results), window.messages.toPlainText())
        return window

    def assert_truth(self, window):
        comparison = window.comparison
        self.assertIsNotNone(comparison)
        self.assertAlmostEqual(comparison['delta_phase_rad'], .6, delta=.04)
        expected_ratio = .6*np.exp(-comparison['reference_s']/2.2e-9+comparison['reference_s']/1.8e-9)
        self.assertAlmostEqual(comparison['amplitude_ratio'], expected_ratio, delta=.015)
        for result in window.results:
            self.assertAlmostEqual(result.parameters[1]/1e9, 1.28, delta=.005)
        self.assertEqual(window.results[0].reference_s, window.results[1].reference_s)

    def test_demo_truth_and_style_changes_keep_fits_and_comparison(self):
        window = self.demo(); self.assert_truth(window)
        results = window.results
        parameters = tuple(r.parameters.copy() for r in results)
        comparison = dict(window.comparison)
        window.alpha1.setValue(.2); window.alpha2.setValue(.8)
        window.title.setText(r'$$\theta_1(t),\quad R_2(t)$$')
        window.title_size.setValue(18); window.body_size.setValue(10)
        window.annotation.setPlainText('Synthetic comparison')
        window.normalized.setChecked(False); window.normalized.setChecked(True)
        window.pair1.setCurrentIndex(0); window.pair2.setCurrentIndex(0)
        self.app.processEvents()
        self.assertIsNone(window.job); self.assertFalse(window.pending)
        for i, result in enumerate(window.results):
            self.assertIs(result, results[i])
            np.testing.assert_array_equal(result.parameters, parameters[i])
        self.assertEqual(window.comparison, comparison)
        self.assertTrue(window.title_valid)
        self.assertIn(r'\theta_1', window.figure.title_artist.get_text())
        self.assertAlmostEqual(window.figure.normalized_points[0].get_alpha(), .2)
        self.assertAlmostEqual(window.figure.normalized_points[1].get_alpha(), .8)
        self.assertEqual(window.figure.normalized_fits[0].get_alpha(), 1)
        self.assertEqual(window.figure.normalized_fits[1].get_alpha(), 1)
        self.assertTrue(window.figure.normalized_axes.get_visible())
        self.assertGreater(len(window.figure.normalized_points[0].get_ydata()), 700)
        self.assertIn('Synthetic comparison', window.figure.summary_artist.get_text())

    def test_shared_manual_window_and_calibration_keep_physical_ratio(self):
        window = self.demo()
        initial = window.results
        window.window_mode.setCurrentIndex(1)
        window.fit_start.setValue(.15); window.fit_stop.setValue(1.9)
        self.assertTrue(window.dirty)
        self.assertEqual(window.results, (None, None))
        self.settle(window); self.assert_truth(window)
        self.assertIsNot(window.results[0], initial[0])
        np.testing.assert_array_equal(window.prepared.first.fit_mask, window.prepared.second.fit_mask)
        self.assertGreaterEqual(window.results[0].reference_s, .15e-9)
        self.assertLessEqual(window.prepared.first.time[window.prepared.first.fit_mask][-1], 1.9e-9)
        ratio = window.comparison['amplitude_ratio']
        phase = window.comparison['delta_phase_rad']
        native = window.results[1].parameters[0]
        window.second_mode.setCurrentIndex(window.second_mode.findData('same'))
        self.settle(window)
        self.assertEqual(window.prepared.second_unit, 'rad')
        self.assertAlmostEqual(window.comparison['amplitude_ratio'], ratio, delta=2e-4)
        self.assertAlmostEqual(window.comparison['delta_phase_rad'], phase, delta=2e-4)
        self.assertAlmostEqual(window.results[1].parameters[0]/native, 2.5, delta=.002)

    def test_new_measurement_requested_during_analysis_replaces_stale_work(self):
        window = self.demo()
        # Start real optimization, then immediately select another file. No
        # mocked worker sleeps: dispatch creates a live background analysis job.
        window.skip_steps.setValue(4); window.timer.stop(); window.dispatch()
        self.assertIsNotNone(window.job)
        self.assertEqual(window.job.kind, 'Анализ')
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'second_measurement.dat'
            notes = path.with_suffix('.comments.txt')
            path.write_bytes((self.base/'dual_demo.dat').read_bytes())
            notes.write_text('A newly selected synthetic measurement\nRESULT: complete\n', encoding='utf-8')
            window.load_paths(path, notes)
            self.settle(window)
            self.assertEqual(Path(window.measurement.data_path), path)
            self.assertIn('newly selected', window.notes.toPlainText())
            self.assertTrue(all(r is not None for r in window.results), window.messages.toPlainText())
            self.assertFalse(window.dirty)
            self.assert_truth(window)
            self.assertEqual(window.prepared.first.settings.skip_steps, 4)
            # Closing while a real worker is active must cancel and drain it.
            window.skip_steps.setValue(5);window.timer.stop();window.dispatch()
            self.assertIsNotNone(window.job)
            self.close_window(window)


if __name__ == '__main__':
    unittest.main()
