"""Folder naming and display settings do not require experiment files."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
from pathlib import Path
import tempfile
import unittest
from PyQt5.QtWidgets import QApplication, QDialog
from analyzer.dialogs import ExportFolderDialog
from analyzer.presentation import PlotStyle, model_formula


class V6DialogTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])

    def dialog(self, folder, name):
        dialog=ExportFolderDialog(None,folder,name)
        self.addCleanup(dialog.deleteLater)
        return dialog

    def test_unicode_export_folder_name_is_user_selected(self):
        with tempfile.TemporaryDirectory() as folder:
            dialog=self.dialog(folder,'Моё измерение 61 mT')
            self.assertEqual(dialog.target(),Path(folder)/'Моё измерение 61 mT')
            dialog.folder_name.setText('Другой результат')
            dialog.accept()
            self.assertEqual(dialog.result(),QDialog.Accepted)
            self.assertEqual(dialog.target(),Path(folder)/'Другой результат')
            self.assertFalse(dialog.target().exists())

    def test_invalid_windows_names_are_not_accepted(self):
        with tempfile.TemporaryDirectory() as folder:
            for name in ('','   ','.','..','A/B','A\\B','bad:name','bad*name','name.',
                         'name ','CON','con.txt','PRN','AUX','NUL','COM1','LPT9'):
                with self.subTest(name=name):
                    dialog=self.dialog(folder,name)
                    with self.assertRaises(ValueError):dialog.target()
                    dialog.accept()
                    self.assertEqual(dialog.result(),QDialog.Rejected)
                    self.assertIn('имя',dialog.error.text())

    def test_nonexistent_parent_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            dialog=self.dialog(Path(folder)/'missing','result')
            with self.assertRaises(ValueError):dialog.target()

    def test_formula_matches_number_of_modes_and_has_reference_definition(self):
        one=model_formula(1)
        self.assertIn('A₁',one);self.assertIn('exp',one);self.assertIn('sin',one)
        self.assertNotIn('Σ',one);self.assertIn('u = t − t_ref',one)
        two=model_formula(2)
        self.assertIn('Σ(i=1…2)',two);self.assertIn('u = t − t_ref',two)

    def test_font_sizes_are_explicit_and_validated(self):
        style=PlotStyle(title_font_size=22,legend_font_size=11).validate()
        self.assertEqual(style.title_font_size,22)
        self.assertEqual(style.legend_font_size,11)
        for invalid in (4,73,float('nan'),float('inf')):
            with self.subTest(size=invalid):
                with self.assertRaises(ValueError):PlotStyle(title_font_size=invalid).validate()
                with self.assertRaises(ValueError):PlotStyle(legend_font_size=invalid).validate()


if __name__=='__main__':unittest.main()
