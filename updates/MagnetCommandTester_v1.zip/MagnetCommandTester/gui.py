"""Отдельная диагностическая утилита; не зависит от программы lock-in."""
from datetime import datetime
from pathlib import Path

from PyQt5.QtCore import Qt, QStandardPaths, QThread, pyqtSignal
from PyQt5.QtWidgets import (
    QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout,
    QGridLayout, QGroupBox, QHBoxLayout, QLabel, QMainWindow,
    QPlainTextEdit, QPushButton, QScrollArea, QSpinBox, QSplitter,
    QVBoxLayout, QWidget,
)
from serial.tools import list_ports

from driver import MagnetDriver
from worker import SerialWorker


class MainWindow(QMainWindow):
    requested = pyqtSignal(str, object)
    shutdown_requested = pyqtSignal()

    def __init__(self, demo=False):
        super().__init__()
        self.setWindowTitle('Magnet Command Tester · GEN60-40 / коммутационный блок')
        self.resize(1220, 880)
        self.setMinimumSize(850, 650)
        self.state = {'connected': False, 'identified': False, 'selected': False, 'values': {}}
        self.busy = self.stop_pending = self.closing = self.can_close = False
        self.actions = []
        self.log_file = None
        self._build(demo)
        self._start_log()
        self.worker = SerialWorker()
        self.thread = QThread(self)
        self.worker.moveToThread(self.thread)
        self.requested.connect(self.worker.execute)
        self.shutdown_requested.connect(self.worker.shutdown)
        self.worker.logged.connect(self.log)
        self.worker.completed.connect(self.completed)
        self.worker.closed.connect(self.thread.quit)
        self.worker.closed.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.finish_close)
        self.thread.start()
        self.refresh_ports()
        self.update_enabled()
        self.log('MagnetCommandTester 1.0. Программа запущена. Команды автоматически не отправляются.')

    @staticmethod
    def spin(maximum, decimals=3, initial=0.0):
        field = QDoubleSpinBox()
        field.setDecimals(decimals)
        field.setRange(0, maximum)
        field.setValue(initial)
        field.setKeyboardTracking(False)
        field.setMinimumWidth(120)
        return field

    def button(self, text, operation, params=lambda: {}, identified=False, selected=False):
        button = QPushButton(text)
        button.setMinimumHeight(34)
        button.clicked.connect(lambda: self.submit(operation, params()))
        self.actions.append((button, identified, selected))
        return button

    def _build(self, demo):
        root = QWidget()
        page = QVBoxLayout(root)
        title = QLabel('ПРОВЕРКА СВЯЗИ И КОМАНД МАГНИТА')
        title.setStyleSheet('font-size: 19px; font-weight: 600; color: #17566f;')
        page.addWidget(title)
        note = QLabel('При подключении выход и уставки не меняются. '
                      'Закрытие COM не выключает источник. '
                      'Кнопка обнуления ниже отправляет PC 0 и OUT 0.')
        note.setWordWrap(True)
        page.addWidget(note)

        split = QSplitter(Qt.Horizontal)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        left = QWidget()
        settings = QVBoxLayout(left)
        settings.setContentsMargins(2, 2, 10, 2)
        scroll.setWidget(left)
        split.addWidget(scroll)
        page.addWidget(split, 1)

        connection = QGroupBox('1. Подключение')
        form = QFormLayout(connection)
        self.demo = QCheckBox('Демо: оборудование не подключается')
        self.demo.setChecked(demo)
        form.addRow(self.demo)
        self.source_port = QComboBox()
        self.source_port.setEditable(True)
        self.source_port.setMinimumContentsLength(12)
        ports_row = QWidget()
        ports_layout = QHBoxLayout(ports_row)
        ports_layout.setContentsMargins(0, 0, 0, 0)
        ports_layout.addWidget(self.source_port, 1)
        self.refresh = QPushButton('Обновить')
        self.refresh.clicked.connect(self.refresh_ports)
        ports_layout.addWidget(self.refresh)
        form.addRow('COM блока / источника', ports_row)
        self.same_port = QCheckBox('Реле и источник через этот же COM')
        self.same_port.setChecked(True)
        self.same_port.toggled.connect(self.update_enabled)
        form.addRow(self.same_port)
        self.relay_port = QComboBox()
        self.relay_port.setEditable(True)
        form.addRow('Отдельный COM реле', self.relay_port)
        self.baud = QComboBox()
        self.baud.addItems(['9600', '19200', '38400', '57600', '115200'])
        form.addRow('Скорость, бод · 8N1', self.baud)
        self.address = QSpinBox()
        self.address.setRange(0, 30)
        self.address.setValue(6)
        form.addRow('Адрес Genesys', self.address)
        self.timeout = self.spin(10, 1, 1.0)
        self.timeout.setMinimum(0.1)
        form.addRow('Тайм-аут ответа, s', self.timeout)
        self.connect_button = QPushButton('Подключить COM')
        self.connect_button.setMinimumHeight(36)
        self.connect_button.clicked.connect(self.toggle_connection)
        form.addRow(self.connect_button)
        settings.addWidget(connection)

        queries = QGroupBox('2. Проверка источника · только чтение')
        grid = QGridLayout(queries)
        grid.addWidget(self.button('Выбрать адрес · ADR', 'select'), 0, 0)
        grid.addWidget(self.button('Проверить источник', 'probe'), 0, 1)
        grid.addWidget(self.button('Прочитать I, U и уставки', 'readings', selected=True), 1, 0, 1, 2)
        self.query_box = QComboBox()
        self.query_box.addItems(MagnetDriver.READ_COMMANDS)
        grid.addWidget(self.query_box, 2, 0)
        grid.addWidget(self.button('Отправить запрос', 'query',
                                   lambda: {'command': self.query_box.currentText()}, selected=True), 2, 1)
        settings.addWidget(queries)

        control = QGroupBox('3. Ток, напряжение и выход')
        form = QFormLayout(control)
        self.armed = QCheckBox('Разрешить команды изменения уставок и OUT ON')
        self.armed.toggled.connect(self.update_enabled)
        form.addRow(self.armed)
        self.limit_i = self.spin(40)
        self.limit_u = self.spin(60)
        self.limit_i.setSuffix(' A')
        self.limit_u.setSuffix(' V')
        form.addRow('Допустимый ток магнита', self.limit_i)
        form.addRow('Допустимое напряжение', self.limit_u)
        info = QLabel('Введите пределы именно вашего магнита. Нули блокируют включение. '
                      'Эти пределы проверяются программой перед командами; '
                      'они не заменяют защиты источника.')
        info.setWordWrap(True)
        form.addRow(info)
        self.current = self.spin(40)
        self.voltage = self.spin(60)
        form.addRow('Новая уставка I, A', self.current)
        form.addRow(self.button('Передать PC · уставку тока', 'set',
                               lambda: {'kind': 'PC', 'value': self.current.value(), 'limits': self.limits()}, True))
        form.addRow('Новая уставка U, V', self.voltage)
        form.addRow(self.button('Передать PV · уставку напряжения', 'set',
                               lambda: {'kind': 'PV', 'value': self.voltage.value(), 'limits': self.limits()}, True))
        form.addRow(self.button('Включить выход · OUT 1', 'enable', lambda: {'limits': self.limits()}, True))
        settings.addWidget(control)

        relay = QGroupBox('4. Коммутация полярности')
        layout = QVBoxLayout(relay)
        text = QLabel('Перед H/X: OUT OFF, PC 0 и три свежих MC? ≤ 0,01 A по модулю. '
                      'При отсутствии связи с источником переключение блокируется.')
        text.setWordWrap(True)
        layout.addWidget(text)
        buttons = QHBoxLayout()
        self.relay_armed = QCheckBox('Разрешить проверку H/X')
        self.relay_armed.toggled.connect(self.update_enabled)
        layout.addWidget(self.relay_armed)
        self.positive = self.button('Positive · H + CR', 'relay', lambda: {'command': 'H'})
        self.negative = self.button('Negative · X + CR', 'relay', lambda: {'command': 'X'})
        buttons.addWidget(self.positive)
        buttons.addWidget(self.negative)
        layout.addLayout(buttons)
        settings.addWidget(relay)
        settings.addStretch()

        right = QWidget()
        visual = QVBoxLayout(right)
        visual.setContentsMargins(8, 2, 2, 2)
        readouts = QGroupBox('Последние ответы прибора')
        cards = QGridLayout(readouts)
        self.readouts = {}
        for row, (command, title, unit) in enumerate([
            ('MC?', 'Фактический ток', 'A'), ('MV?', 'Фактическое напряжение', 'V'),
            ('PC?', 'Уставка тока', 'A'), ('PV?', 'Уставка напряжения', 'V'), ('OUT?', 'Выход', ''),
        ]):
            cards.addWidget(QLabel(title), row, 0)
            label = QLabel('—')
            label.setStyleSheet('font-size: 21px; font-weight: 600; color: #17566f;')
            cards.addWidget(label, row, 1)
            self.readouts[command] = (label, unit)
        self.identity = QLabel('GEN60-40 ещё не подтверждён')
        self.identity.setWordWrap(True)
        cards.addWidget(self.identity, 5, 0, 1, 2)
        visual.addWidget(readouts)

        self.stop_button = QPushButton('Обнулить ток и выключить выход · PC 0 / OUT 0')
        self.stop_button.setMinimumHeight(44)
        self.stop_button.setStyleSheet('background: #a52a3a; color: white; font-weight: 600;')
        self.stop_button.clicked.connect(self.stop)
        visual.addWidget(self.stop_button)
        note = QLabel('Это программная команда по COM. При потере связи используйте '
                      'кнопку выключения на самом источнике.')
        note.setWordWrap(True)
        visual.addWidget(note)
        self.message = QLabel('Выберите порт. По умолчанию: COM11, 9600 бод, адрес 6.')
        self.message.setWordWrap(True)
        self.message.setMinimumHeight(64)
        visual.addWidget(self.message)
        visual.addWidget(QLabel('Журнал · время, направление, ASCII и HEX'))
        self.journal = QPlainTextEdit()
        self.journal.setReadOnly(True)
        self.journal.setMaximumBlockCount(5000)
        self.journal.setStyleSheet('font-family: Consolas, monospace; font-size: 12px;')
        visual.addWidget(self.journal, 1)
        self.log_path = QLabel()
        self.log_path.setWordWrap(True)
        self.log_path.setTextInteractionFlags(Qt.TextSelectableByMouse)
        visual.addWidget(self.log_path)
        save = QPushButton('Сохранить копию журнала…')
        save.clicked.connect(self.save_log)
        visual.addWidget(save)
        split.addWidget(right)
        split.setSizes([510, 690])
        self.setCentralWidget(root)
        self.setStyleSheet('QMainWindow {background: #f1f5f8;} '
                           'QGroupBox {font-weight: 600; border: 1px solid #cbd8e2; '
                           'border-radius: 7px; margin-top: 12px; padding-top: 12px;} '
                           'QGroupBox::title {subcontrol-origin: margin; left: 10px;} '
                           'QPushButton {padding: 6px;} QComboBox, QSpinBox, QDoubleSpinBox {min-height: 27px;}')

    def limits(self):
        return {'current': self.limit_i.value(), 'voltage': self.limit_u.value()}

    @staticmethod
    def port_value(combo):
        return combo.currentData() if combo.currentText() == combo.itemText(combo.currentIndex()) else combo.currentText().strip()

    def refresh_ports(self):
        ports = list(list_ports.comports())
        for combo in (self.source_port, self.relay_port):
            previous = self.port_value(combo) or 'COM11'
            combo.clear()
            for port in ports:
                combo.addItem(f'{port.device} — {port.description}', port.device)
            index = combo.findData(previous)
            if index >= 0:
                combo.setCurrentIndex(index)
            else:
                combo.setEditText(previous)

    def _start_log(self):
        try:
            path = Path(QStandardPaths.writableLocation(QStandardPaths.AppLocalDataLocation)) / 'logs'
            path.mkdir(parents=True, exist_ok=True)
            self.log_name = path / f'magnet_{datetime.now():%Y%m%d_%H%M%S_%f}.log'
            self.log_file = self.log_name.open('a', encoding='utf-8', newline='\n')
            self.log_path.setText(f'Автожурнал: {self.log_name}')
        except OSError as exc:
            self.log_name = None
            self.log_path.setText(f'Автожурнал не открыт: {exc}. Сохраните журнал кнопкой.')

    def log(self, message):
        line = f'{datetime.now().astimezone().isoformat(timespec="milliseconds")}  {message}'
        self.journal.appendPlainText(line)
        if self.log_file:
            try:
                self.log_file.write(line + '\n')
                self.log_file.flush()
            except OSError as exc:
                self.log_file.close()
                self.log_file = None
                self.log_path.setText(f'Ошибка записи автожурнала: {exc}. Сохраните копию вручную.')

    def save_log(self):
        filename, _ = QFileDialog.getSaveFileName(self, 'Сохранить журнал', 'magnet_test.log', 'Журнал (*.log *.txt)')
        if not filename:
            return
        try:
            # Копируем полный журнал с диска, а не только 5000 строк на экране.
            text = self.log_name.read_text(encoding='utf-8') if self.log_name and self.log_name.exists() else self.journal.toPlainText()
            Path(filename).write_text(text, encoding='utf-8')
            self.message.setText(f'Журнал сохранён: {filename}')
        except OSError as exc:
            self.message.setText(f'Не удалось сохранить: {exc}')

    def toggle_connection(self):
        if self.state['connected']:
            self.submit('close')
            return
        params = {'demo': self.demo.isChecked(), 'connection': {
            'source_port': self.port_value(self.source_port) or '',
            'relay_port': '' if self.same_port.isChecked() else (self.port_value(self.relay_port) or ''),
            'baudrate': int(self.baud.currentText()), 'address': self.address.value(),
            'timeout': self.timeout.value(),
        }}
        self.armed.setChecked(False)
        self.relay_armed.setChecked(False)
        self.log(f"CONNECT: demo={params['demo']}; {params['connection']}")
        self.submit('open', params)

    def submit(self, operation, params=None):
        if self.busy or self.closing:
            return
        self.busy = True
        self.message.setText('Выполняется…')
        if operation in ('set', 'enable'):
            self.log(f'USER {operation}: {params}')
        self.update_enabled()
        self.requested.emit(operation, params or {})

    def stop(self):
        if self.stop_pending or not self.state['connected']:
            return
        self.stop_pending = True
        self.busy = True
        self.worker.cancel.set()  # threading.Event; COM здесь не трогаем.
        self.log('USER STOP: прерывание текущей операции; затем PC 0 и OUT 0.')
        self.message.setText('Ожидание остановки текущей операции и выключения выхода…')
        self.update_enabled()
        self.requested.emit('stop', {})

    def completed(self, operation, success, message, state):
        self.state = state
        if operation == 'stop':
            self.stop_pending = False
        if not self.stop_pending:
            self.busy = False
        self.log(('DONE: ' if success else 'FAILED: ') + message)
        if not self.stop_pending:
            self.message.setText(message)
            self.message.setStyleSheet('color: #17566f;' if success else 'color: #a52a3a;')
        for command, (label, unit) in self.readouts.items():
            value = state['values'].get(command)
            if value is None:
                label.setText('—')
            elif command == 'OUT?':
                label.setText('ON' if value else 'OFF')
            else:
                label.setText(f'{value:.4f} {unit}')
        identity = state['values'].get('IDN?', 'GEN60-40 ещё не подтверждён')
        suffix = ' · управление доступно' if state['identified'] else ' · требуется проверка связи'
        self.identity.setText(str(identity) + suffix)
        self.update_enabled()

    def update_enabled(self):
        connected = self.state['connected']
        free = not self.busy and not self.closing
        for field in (self.source_port, self.baud, self.address, self.timeout,
                      self.same_port, self.refresh, self.demo):
            field.setEnabled(free and not connected)
        self.relay_port.setEnabled(free and not connected and not self.same_port.isChecked())
        self.connect_button.setEnabled(free)
        self.connect_button.setText('Отключить COM' if connected else 'Подключить COM')
        for button, identified, selected in self.actions:
            button.setEnabled(free and connected and (not identified or self.state['identified'] and self.armed.isChecked())
                              and (not selected or self.state['selected']))
        for button in (self.positive, self.negative):
            button.setEnabled(free and connected and self.state['identified'] and self.relay_armed.isChecked())
        for field in (self.limit_i, self.limit_u, self.current, self.voltage):
            field.setEnabled(free)
        self.stop_button.setEnabled(connected and not self.stop_pending and not self.closing)

    def closeEvent(self, event):
        if self.can_close:
            if self.log_file:
                self.log_file.close()
            event.accept()
        else:
            event.ignore()
            if not self.closing:
                self.closing = True
                self.worker.cancel.set()
                self.update_enabled()
                self.shutdown_requested.emit()

    def finish_close(self):
        self.can_close = True
        self.close()
