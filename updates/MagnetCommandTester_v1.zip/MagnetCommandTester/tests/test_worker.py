import unittest

import serial

from demo import DemoSerial
from driver import Connection
from worker import SerialWorker


class WorkerTests(unittest.TestCase):
    def setUp(self):
        self.worker = SerialWorker()
        self.results = []
        self.worker.completed.connect(lambda *args: self.results.append(args))
        self.worker.driver.factory = DemoSerial
        self.worker.driver.open(Connection(timeout=0.1))

    def tearDown(self):
        self.worker.driver.close()

    def test_usb_error_closes_connection_and_invalidates_identity(self):
        self.worker.execute('probe', {})
        self.assertTrue(self.results[-1][1])
        link = self.worker.driver.source
        def fail(*args):
            raise serial.SerialException('USB disconnected')
        link.read = fail
        self.worker.execute('readings', {})
        operation, success, message, state = self.results[-1]
        self.assertFalse(success)
        self.assertIn('Состояние выхода неизвестно', message)
        self.assertFalse(state['connected'])
        self.assertFalse(state['identified'])
        self.assertFalse(link.is_open)

    def test_stop_resets_cancellation_and_turns_output_off(self):
        self.worker.execute('probe', {})
        link = self.worker.driver.source
        link.on = True
        link.current = 0.1
        self.worker.cancel.set()
        self.worker.execute('readings', {})
        self.assertFalse(self.results[-1][1])
        self.worker.execute('stop', {})
        self.assertTrue(self.results[-1][1])
        self.assertFalse(link.on)
        self.assertEqual(link.current, 0)
        self.assertFalse(self.worker.cancel.is_set())


if __name__ == '__main__':
    unittest.main()
