import math
import threading
import unittest

from demo import DemoSerial
from driver import Cancelled, Connection, Limits, MagnetDriver, ProtocolError, number, output_state


class DriverTests(unittest.TestCase):
    def setUp(self):
        self.links = []
        self.logs = []
        self.overrides = {}
        owner = self

        class ScriptSerial(DemoSerial):
            def write(self, data):
                command = data.decode('ascii').rstrip('\r')
                if command in owner.overrides:
                    self.writes.append(data)
                    answer = owner.overrides[command]
                    if callable(answer):
                        answer = answer()
                    if isinstance(answer, BaseException):
                        raise answer
                    if answer is not None:
                        self.buffer.extend(answer)
                    return len(data)
                return super().write(data)

        def factory(port, baud):
            link = ScriptSerial(port, baud)
            self.links.append(link)
            return link
        self.driver = MagnetDriver(log=self.logs.append, factory=factory)
        self.driver.open(Connection(timeout=0.1))
        self.link = self.links[0]

    def tearDown(self):
        self.driver.close()

    def commands(self):
        return [x.decode('ascii').rstrip('\r') for x in self.link.writes]

    def ready(self):
        self.driver.probe()

    def test_open_and_close_do_not_write_commands(self):
        self.assertEqual(self.link.writes, [])
        self.driver.close()
        self.assertEqual(self.link.writes, [])

    def test_probe_only_selects_address_and_queries(self):
        self.ready()
        self.assertTrue(self.driver.identified)
        self.assertEqual(self.commands(), ['ADR 06', 'IDN?', 'MC?', 'MV?', 'PC?', 'PV?', 'OUT?'])
        self.assertTrue(all(x.endswith(b'\r') and not x.endswith(b'\r\n') for x in self.link.writes))

    def test_wrong_address_stops_before_other_queries(self):
        self.driver.close()
        self.driver.open(Connection(address=7, timeout=0.1))
        self.link = self.links[-1]
        with self.assertRaises(ProtocolError):
            self.ready()
        self.assertEqual(self.commands(), ['ADR 07'])
        self.assertFalse(self.driver.identified)

    def test_wrong_identity_cannot_enable_output(self):
        self.overrides['IDN?'] = b'OTHER_DEVICE\r'
        with self.assertRaises(ProtocolError): self.ready()
        with self.assertRaises(ProtocolError): self.driver.enable_output(Limits(1, 2))
        self.assertNotIn('OUT 1', self.commands())

    def test_incomplete_probe_cannot_unlock_control(self):
        self.overrides['MC?'] = b'OK\r'
        with self.assertRaises(ProtocolError): self.ready()
        self.assertFalse(self.driver.identified)

    def test_zero_limits_block_enable(self):
        self.ready()
        with self.assertRaises(ProtocolError): self.driver.enable_output(Limits())
        self.assertNotIn('OUT 1', self.commands())

    def test_current_limit_is_enforced_in_driver(self):
        self.ready()
        for value in [2, -1, math.nan, math.inf]:
            with self.assertRaises(ProtocolError): self.driver.set_value('PC', value, Limits(1, 2))
        self.assertFalse(any(x.startswith('PC ') for x in self.commands()))

    def test_setpoint_readback_and_enable(self):
        self.ready()
        self.driver.set_value('PV', 1.5, Limits(0.1, 2))
        self.driver.set_value('PC', 0.02, Limits(0.1, 2))
        self.driver.enable_output(Limits(0.1, 2))
        self.assertTrue(self.driver.last['OUT?'])
        self.assertEqual(self.driver.last['MC?'], 0.02)
        self.assertEqual(self.link.current, 0.02)

    def test_out_uses_current_device_setpoints(self):
        self.ready()
        self.link.voltage = 60
        with self.assertRaises(ProtocolError): self.driver.enable_output(Limits(1, 2))
        self.assertNotIn('OUT 1', self.commands())

    def test_mismatched_readback_reported(self):
        self.ready()
        self.overrides['PC?'] = b'0.5\r'
        with self.assertRaises(ProtocolError): self.driver.set_value('PC', 0.02, Limits(1, 2))

    def test_stop_attempts_out_off_even_if_pc_ack_fails(self):
        self.ready()
        self.link.on = True
        self.overrides['PC 0'] = b'C01\r'
        with self.assertRaises(ProtocolError): self.driver.zero_and_off()
        self.assertIn('OUT 0', self.commands())
        self.assertFalse(self.link.on)

    def test_successful_stop_does_not_send_relay_commands(self):
        self.ready()
        self.link.current = 1
        self.link.on = True
        self.driver.zero_and_off()
        self.assertFalse(self.link.on)
        self.assertEqual(self.link.current, 0)
        self.assertEqual(self.driver.last['PC?'], 0)
        self.assertNotIn('H', self.commands())
        self.assertNotIn('X', self.commands())

    def test_relay_refuses_output_on(self):
        self.ready()
        self.link.on = True
        with self.assertRaises(ProtocolError): self.driver.switch_polarity('H')
        self.assertNotIn('H', self.commands())

    def test_relay_refuses_nonzero_setpoint_even_output_off(self):
        self.ready()
        self.link.current = 0.2
        with self.assertRaises(ProtocolError): self.driver.switch_polarity('X')
        self.assertNotIn('X', self.commands())

    def test_relay_refuses_residual_current(self):
        self.ready()
        self.overrides['MC?'] = b'0.02\r'
        with self.assertRaises(ProtocolError): self.driver.switch_polarity('H')
        self.assertNotIn('H', self.commands())

    def test_relay_checks_all_three_samples(self):
        self.ready()
        responses = iter([b'0\r', b'0.02\r', b'0\r'])
        self.overrides['MC?'] = lambda: next(responses)
        with self.assertRaises(ProtocolError): self.driver.switch_polarity('H')
        self.assertNotIn('H', self.commands())

    def test_relay_send_does_not_claim_contacts_confirmed(self):
        self.ready()
        msg = self.driver.switch_polarity('H')
        self.assertEqual(self.link.writes[-1], b'H\r')
        self.assertIn('Контакты не подтверждены', msg)
        self.assertFalse(self.driver.identified)
        self.assertFalse(self.driver.address_selected)

    def test_separate_relay_port_receives_only_relay_bytes(self):
        self.driver.close()
        self.driver.open(Connection(source_port='COM11', relay_port='COM12', timeout=0.1))
        self.link = self.links[-2]
        relay = self.links[-1]
        self.ready()
        self.driver.switch_polarity('X')
        self.assertEqual(relay.writes, [b'X\r'])
        self.assertNotIn('X', self.commands())

    def test_cancel_during_current_check_never_sends_h(self):
        self.ready()
        def answer():
            self.driver.cancel.set()
            return b'0\r'
        self.overrides['MC?'] = answer
        with self.assertRaises(Cancelled): self.driver.switch_polarity('H')
        self.assertNotIn('H', self.commands())

    def test_echo_and_crlf_are_handled(self):
        self.ready()
        self.overrides['MC?'] = b'MC?\r\n0.002\r\n'
        self.assertEqual(self.driver.query('MC?'), 0.002)

    def test_partial_reply_does_not_become_measurement(self):
        self.ready()
        self.overrides['MC?'] = b'0.00'
        with self.assertRaises(ProtocolError): self.driver.query('MC?')
        self.assertTrue(any('без окончания' in x for x in self.logs))

    def test_stale_answer_is_logged_and_not_used(self):
        self.ready()
        self.link.buffer.extend(b'123\r')
        self.assertEqual(self.driver.query('MC?'), 0)
        self.assertTrue(any('до запроса' in x for x in self.logs))

    def test_no_arbitrary_command_injection(self):
        self.ready()
        for cmd in ['RST', 'MC?\rOUT 1', 'H', 'PC 1']:
            with self.assertRaises(ProtocolError): self.driver.query(cmd)
        self.assertNotIn('RST', self.commands())

    def test_parser_rejects_nonfinite_and_errors(self):
        for value in ['NaN', 'inf', 'OK', 'C01', '1,2', '1 A', '', '1e999']:
            with self.assertRaises(ProtocolError): number(value)
        self.assertEqual(number(' -0.003 '), -0.003)
        self.assertEqual(number('1e-3'), 0.001)
        self.assertTrue(output_state('ON'))
        self.assertFalse(output_state('OFF'))


if __name__ == '__main__':
    unittest.main()
