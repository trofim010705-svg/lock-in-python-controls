"""Run NI native code in a spawned process, on that process's main thread.

The GUI never calls task methods, nor terminates a thread inside a native DLL.
Messages carry raw sample blocks; plotting and storage remain in the parent.
"""
import multiprocessing as mp
import time
import traceback

import numpy as np

from backend import NIInput, DemoInput, explain_error


class RemoteDAQError(RuntimeError):
    pass


def daq_child(connection, stop_event, config):
    source = None
    try:
        source = DemoInput() if config.demo else NIInput(progress=lambda text: connection.send(('log', text)))
        info = source.open(config)
        connection.send(('configured', info))
        while not stop_event.is_set():
            values = source.read(stop_event)
            if len(values):
                connection.send(('samples', values))
    except Exception as exc:
        connection.send(('failure', {'message': explain_error(exc),
            'stage': getattr(exc, 'ni_stage', getattr(source, 'stage', 'initialization')),
            'traceback': traceback.format_exc()}))
    finally:
        try:
            if source is not None:
                source.close()
        except Exception as exc:
            connection.send(('failure', {'message': 'Закрытие AI: ' + explain_error(exc),
                'stage': getattr(source, 'stage', 'close'), 'traceback': traceback.format_exc()}))
        try:
            connection.send(('done', None))
        finally:
            connection.close()


class NIProcessInput:
    def __init__(self, progress=None, cancel=None, target=daq_child,
                 startup_timeout=30, read_timeout=10, shutdown_timeout=2):
        self.progress = progress or (lambda text: None)
        self.cancel = cancel
        self.target = target
        self.startup_timeout, self.read_timeout = startup_timeout, read_timeout
        self.shutdown_timeout = shutdown_timeout
        self.process = self.connection = self.stop_event = None
        self.last_stage = 'starting child process'
        self.done = False

    def open(self, config):
        context = mp.get_context('spawn')
        self.connection, sender = context.Pipe(duplex=False)
        self.stop_event = context.Event()
        self.process = context.Process(target=self.target, args=(sender, self.stop_event, config), daemon=True)
        try:
            self.process.start()
        finally:
            sender.close()
        self.progress(f'NI-процесс PID={self.process.pid}; драйвер работает отдельно от Qt.')
        kind, info = self.receive(self.startup_timeout)
        if kind != 'configured':
            raise RemoteDAQError('NI-процесс не подтвердил настройку канала.')
        return info

    def handle_message(self, message):
        kind, payload = message
        if kind == 'log':
            self.last_stage = payload
            self.progress(payload)
            return None
        if kind == 'failure':
            detail = f"Этап: {payload['stage']}\n{payload['traceback']}"
            self.progress(detail)
            raise RemoteDAQError(payload['message'] + '\nЭтап: ' + payload['stage'])
        if kind == 'done':
            self.done = True
        return message

    def receive(self, timeout):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self.cancel is not None and self.cancel.is_set():
                raise InterruptedError('Остановлено пользователем.')
            if self.connection.poll(0.03):
                try:
                    message = self.connection.recv()
                except EOFError:
                    message = None
                if message is not None:
                    handled = self.handle_message(message)
                    if handled is not None:
                        return handled
                    continue
            if not self.process.is_alive():
                self.process.join(timeout=0.1)
                raise RemoteDAQError(f'Процесс NI завершился без данных. Код: {self.process.exitcode}; '
                                     f'последний этап: {self.last_stage}. См. журнал.')
        raise RemoteDAQError(f'NI не завершил операцию за {timeout:g} s. '
                             f'Последний этап: {self.last_stage}. Процесс чтения будет остановлен.')

    def read(self, stop_event):
        if stop_event.is_set():
            return np.empty(0)
        kind, values = self.receive(self.read_timeout)
        if kind == 'done':
            raise RemoteDAQError('NI-процесс закончил работу до команды Stop. См. журнал.')
        if kind != 'samples':
            raise RemoteDAQError('Неожиданный ответ процесса NI: ' + kind)
        return values

    def close(self):
        if self.process is None:
            return
        process, self.process = self.process, None
        errors = []
        try:
            if process.pid is None:
                return
            self.stop_event.set()
            deadline = time.monotonic() + self.shutdown_timeout
            # Drain pending blocks so a child sending a block can observe Stop.
            while process.is_alive() and time.monotonic() < deadline:
                if self.connection.poll(0.03):
                    try:
                        kind, payload = self.connection.recv()
                    except EOFError:
                        process.join(timeout=max(0, deadline - time.monotonic()))
                        break
                    if kind == 'log':
                        self.last_stage = payload
                        self.progress(payload)
                    elif kind == 'failure':
                        self.progress(payload['traceback'])
                        errors.append(payload['message'])
                    elif kind == 'done':
                        process.join(timeout=max(0, deadline - time.monotonic()))
                        break
                else:
                    process.join(timeout=0.01)
            if process.is_alive():
                self.progress('NI-процесс не завершился после Stop; завершаю только процесс чтения. '
                              'Последний этап: ' + self.last_stage)
                process.terminate()
                process.join(timeout=1)
                if process.is_alive():
                    process.kill()
                    process.join(timeout=1)
            else:
                process.join(timeout=0.1)
        finally:
            self.connection.close()
        if errors:
            raise RemoteDAQError('\n'.join(errors))
