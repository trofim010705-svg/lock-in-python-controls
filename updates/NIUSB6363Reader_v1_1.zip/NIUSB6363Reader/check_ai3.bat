@echo off
setlocal
cd /d "%~dp0"
if not exist "venv\Scripts\python.exe" goto missing
"venv\Scripts\python.exe" check_ai3.py %*
pause
exit /b
:missing
echo First run start.bat to create the venv, or run check_ai3.py with your PyCharm interpreter.
pause
exit /b 1
