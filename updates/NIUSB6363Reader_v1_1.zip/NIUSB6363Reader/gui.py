"""Интерфейс одноканального вольтметра/осциллографа NI USB-6363."""
from datetime import datetime
from pathlib import Path
import os
import tempfile

import numpy as np
import pyqtgraph as pg
from PyQt5.QtCore import Qt, QTimer, QUrl
from PyQt5.QtGui import QDesktopServices
from PyQt5.QtWidgets import (
    QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout,
    QGroupBox, QHBoxLayout, QLabel, QMainWindow, QPlainTextEdit,
    QPushButton, QSplitter, QVBoxLayout, QWidget,
)

from backend import DRIVER_URL, runtime_info
from core import Config, RANGES, SampleStore, peak_view, voltage_text
from worker import Acquisition, Discovery, Export


class MainWindow(QMainWindow):
    def __init__(self, demo=False, acquisition_factory=None):
        super().__init__()
        self.setWindowTitle('NI USB-6363 · AI3 Differential Reader 1.1')
        self.resize(1250, 800)
        self.setMinimumSize(900, 650)
        self.store = SampleStore()
        self.reader = self.discovery = self.exporter = None
        self.closing = self.can_close = False
        self.last_version = -1
        self.acquisition_error = ''
        self.acquisition_factory = acquisition_factory
        self.log_path = None
        try:
            folder = Path(os.getenv('LOCALAPPDATA') or os.getenv('XDG_DATA_HOME') or tempfile.gettempdir()) / 'LabTools' / 'NIUSB6363Reader' / 'logs'
            folder.mkdir(parents=True, exist_ok=True)
            self.log_path = folder / f'AI3_{datetime.now():%Y%m%d_%H%M%S_%f}.log'
        except OSError:
            pass
        self._build(demo)
        self.log('Окружение: ' + str(runtime_info()))
        if self.log_path:
            self.log('Автожурнал: ' + str(self.log_path))
        self.timer = QTimer(self)
        self.timer.setInterval(100)
        self.timer.timeout.connect(self.refresh_plot)
        self.timer.start()
        self.update_enabled()
        if not demo:
            QTimer.singleShot(0, self.discover)
        else:
            self.set_message('ДЕМО · реальное оборудование не открывается.')

    @staticmethod
    def spin(minimum, maximum, value, decimals=0):
        field = QDoubleSpinBox()
        field.setDecimals(decimals)
        field.setRange(minimum, maximum)
        field.setValue(value)
        field.setKeyboardTracking(False)
        field.setMinimumHeight(30)
        return field

    def _build(self, demo):
        root = QWidget()
        outer = QVBoxLayout(root)
        title = QLabel('NI USB-6363  /  ДИФФЕРЕНЦИАЛЬНЫЙ AI3')
        title.setStyleSheet('color: #17566f; font-size: 21px; font-weight: 600;')
        outer.addWidget(title)
        split = QSplitter(Qt.Horizontal)
        outer.addWidget(split, 1)
        left = QWidget()
        settings = QVBoxLayout(left)
        settings.setContentsMargins(0, 0, 10, 0)
        group = QGroupBox('Настройки входа')
        form = QFormLayout(group)
        self.demo = QCheckBox('Демо · без платы и драйвера NI')
        self.demo.setChecked(demo)
        self.demo.toggled.connect(self.update_enabled)
        form.addRow(self.demo)
        self.device = QComboBox()
        self.device.setEditable(True)
        self.device.setEditText('Dev1')
        form.addRow('Устройство из NI MAX', self.device)
        self.refresh_button = QPushButton('Найти платы NI')
        self.refresh_button.clicked.connect(self.discover)
        form.addRow(self.refresh_button)
        self.channel = QLabel('ai3 · DIFFERENTIAL')
        self.channel.setStyleSheet('font-weight: 600; color: #17566f;')
        form.addRow('Канал', self.channel)
        pair = QLabel('U = AI3+ − AI3−\nВ программе задаётся один канал ai3.\n'
                      'Контакты сверяйте по маркировке платы/клеммника.')
        pair.setWordWrap(True)
        form.addRow(pair)
        self.rate = self.spin(1, 2_000_000, 1000)
        self.rate.setSingleStep(100)
        form.addRow('Оцифровка, выборок/с', self.rate)
        self.voltage_range = QComboBox()
        for value in RANGES:
            self.voltage_range.addItem(f'±{value:g} V', value)
        form.addRow('Диапазон входа', self.voltage_range)
        self.window_seconds = self.spin(0.01, 30, 10, 2)
        form.addRow('Последнее окно, s', self.window_seconds)
        self.start_button = QPushButton('▶ Старт чтения')
        self.start_button.clicked.connect(self.start)
        self.start_button.setMinimumHeight(40)
        self.start_button.setStyleSheet('background: #176b89; color: white; font-weight: 600;')
        self.stop_button = QPushButton('■ Стоп')
        self.stop_button.clicked.connect(self.stop)
        self.stop_button.setMinimumHeight(40)
        form.addRow(self.start_button)
        form.addRow(self.stop_button)
        settings.addWidget(group)
        driver_button = QPushButton('Скачать драйвер NI-DAQmx')
        driver_button.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(DRIVER_URL)))
        settings.addWidget(driver_button)
        self.device_info = QLabel('Драйвер: проверка при поиске устройств.')
        self.device_info.setWordWrap(True)
        self.device_info.setTextInteractionFlags(Qt.TextSelectableByMouse)
        settings.addWidget(self.device_info)
        note = QLabel('Дифференциальный вход не является гальванически изолированным. '
                      'Учитывайте допустимое напряжение каждого вывода относительно AI GND.')
        note.setWordWrap(True)
        settings.addWidget(note)
        settings.addStretch()
        split.addWidget(left)

        right = QWidget()
        view = QVBoxLayout(right)
        view.setContentsMargins(6, 0, 0, 0)
        cards = QHBoxLayout()
        self.readouts = {}
        for key, heading in [('mean', 'Среднее блока'), ('last', 'Последний отсчёт'), ('ac_rms', 'Разброс блока · σ')]:
            box = QGroupBox(heading)
            layout = QVBoxLayout(box)
            value = QLabel('—')
            value.setStyleSheet('color: #17566f; font-size: 27px; font-weight: 600;')
            layout.addWidget(value)
            self.readouts[key] = value
            cards.addWidget(box)
        view.addLayout(cards)
        pg.setConfigOptions(antialias=False)
        self.plot = pg.PlotWidget(background='w')
        self.plot.setLabel('left', 'AI3+ − AI3−', units='V')
        self.plot.setLabel('bottom', 'Время от начала сбора', units='s')
        self.plot.showGrid(x=True, y=True, alpha=0.2)
        for side in ('left', 'bottom'):
            self.plot.getAxis(side).setPen('#425466')
            self.plot.getAxis(side).setTextPen('#425466')
        self.plot.setMinimumHeight(300)
        self.curve = self.plot.plot(pen=pg.mkPen('#176b89', width=1.3))
        self.curve.setClipToView(True)
        self.curve.setDownsampling(auto=True, method='peak')
        view.addWidget(self.plot, 1)
        self.counters = QLabel('Всего: 0 отсчётов. Ожидание запуска.')
        self.counters.setWordWrap(True)
        view.addWidget(self.counters)
        self.message = QLabel()
        self.message.setWordWrap(True)
        self.message.setMinimumHeight(48)
        self.message.setTextInteractionFlags(Qt.TextSelectableByMouse)
        view.addWidget(self.message)
        self.save_button = QPushButton('Сохранить последний участок…  (.dat + параметры .json)')
        self.save_button.clicked.connect(self.save)
        view.addWidget(self.save_button)
        help_save = QLabel('Сохраняется последнее окно из исходных отсчётов, а не вся сессия. '
                           'Для графика большие массивы прореживаются с сохранением экстремумов.')
        help_save.setWordWrap(True)
        view.addWidget(help_save)
        self.journal = QPlainTextEdit()
        self.journal.setReadOnly(True)
        self.journal.setMaximumBlockCount(1000)
        self.journal.setMaximumHeight(120)
        view.addWidget(self.journal)
        self.save_log_button = QPushButton('Сохранить журнал диагностики…')
        self.save_log_button.clicked.connect(self.save_log)
        view.addWidget(self.save_log_button)
        split.addWidget(right)
        split.setSizes([355, 895])
        self.setCentralWidget(root)
        self.setStyleSheet('QMainWindow {background: #f1f5f8;} '
                           'QGroupBox {border: 1px solid #cbd8e2; border-radius: 6px; '
                           'margin-top: 12px; padding-top: 12px; font-weight: 600;} '
                           'QGroupBox::title {subcontrol-origin: margin; left: 9px;} '
                           'QPushButton {padding: 7px;} QComboBox {min-height: 29px;}')

    def busy(self, thread):
        return thread is not None and thread.isRunning()

    def update_enabled(self):
        acquiring, finding = self.busy(self.reader), self.busy(self.discovery)
        free = not self.closing and not acquiring and not finding
        for field in (self.demo, self.rate, self.voltage_range, self.window_seconds):
            field.setEnabled(free)
        self.device.setEnabled(free and not self.demo.isChecked())
        self.refresh_button.setEnabled(free and not self.demo.isChecked())
        self.start_button.setEnabled(free)
        self.stop_button.setEnabled(acquiring and not self.closing)
        self.save_button.setEnabled(not self.closing and not self.busy(self.exporter) and self.store.total > 0)

    def set_message(self, text, error=False):
        self.message.setText(text)
        self.message.setStyleSheet('color: #a52a3a;' if error else 'color: #17566f;')
        self.log(text)

    def log(self, text):
        line = f'{datetime.now().astimezone().isoformat(timespec="milliseconds")}  {text}'
        self.journal.appendPlainText(line)
        if self.log_path:
            try:
                with self.log_path.open('a', encoding='utf-8') as stream:
                    stream.write(line + '\n')
            except OSError:
                self.log_path = None

    def save_log(self):
        filename, _ = QFileDialog.getSaveFileName(self, 'Сохранить диагностику AI3',
            f'AI3_diagnostic_{datetime.now():%Y%m%d_%H%M%S}.txt', 'Журнал (*.txt *.log)')
        if filename:
            try:
                text = self.log_path.read_text(encoding='utf-8') if self.log_path else self.journal.toPlainText()
                Path(filename).write_text(text, encoding='utf-8')
                self.set_message('Журнал сохранён: ' + filename)
            except OSError as exc:
                self.set_message('Не удалось сохранить журнал: ' + str(exc), True)

    def discover(self):
        if self.busy(self.discovery) or self.busy(self.reader) or self.closing:
            return
        self.discovery = Discovery(self)
        self.discovery.result.connect(self.discovered)
        self.discovery.finished.connect(self.thread_finished)
        self.discovery.start()
        self.update_enabled()

    def discovered(self, devices, version, error):
        previous = self.device_name()
        self.device.clear()
        for item in devices:
            suffix = ' · NI SIMULATED' if item.get('ni_simulated_device') else ''
            self.device.addItem(f"{item['name']} · {item['product']}{suffix}", item['name'])
        index = self.device.findData(previous)
        if index >= 0:
            self.device.setCurrentIndex(index)
        elif not devices:
            self.device.setEditText(previous or 'Dev1')
        self.device_info.setText(version or 'NI-DAQmx недоступен')
        self.set_message(error or (f'Найдено устройств с ai3: {len(devices)}. Выберите плату и нажмите Старт.'
                                  if devices else 'Устройства с ai3 не найдены. Проверьте плату в NI MAX.'), bool(error))

    def start(self):
        if self.busy(self.reader) or self.busy(self.discovery) or self.closing:
            return
        name = self.device_name()
        config = Config(device='Dev1' if self.demo.isChecked() else name,
                        rate=self.rate.value(), voltage_range=self.voltage_range.currentData(),
                        window_seconds=self.window_seconds.value(), demo=self.demo.isChecked())
        try:
            config.validate()
        except ValueError as exc:
            self.set_message(str(exc), True)
            return
        self.store.clear()
        self.last_version = -1
        self.acquisition_error = ''
        self.reader = Acquisition(config, self.store, factory=self.acquisition_factory, parent=self)
        self.reader.configured.connect(self.configured)
        self.reader.diagnostic.connect(self.log)
        self.reader.result.connect(self.acquisition_result)
        self.reader.finished.connect(self.thread_finished)
        self.reader.start()
        self.set_message('Запуск ДЕМО…' if config.demo else f'Запуск {config.channel} в режиме Differential…')
        self.update_enabled()

    def device_name(self):
        index = self.device.currentIndex()
        if index >= 0 and self.device.currentText() == self.device.itemText(index):
            return self.device.itemData(index)
        return self.device.currentText().strip()

    def configured(self, info):
        prefix = ('ДЕМО' if info['demo'] else
                  'NI SIMULATED · ' + info['product'] if info.get('ni_simulated_device') else info['product'])
        self.device_info.setText(f"{prefix}\n{info['physical_channel']} · Differential\n"
                                 f"Фактическая оцифровка: {info['sample_rate_Hz']:g} выборок/с")
        badge = 'ДЕМО · ' if info['demo'] else 'NI SIMULATED · ' if info.get('ni_simulated_device') else ''
        self.set_message(f"{badge}Сбор идёт. Напряжение в вольтах; временная ось — по частоте оцифровки.")

    def acquisition_result(self, result):
        self.acquisition_error = result['error']
        self.refresh_plot()
        self.set_message(result['error'] or f'Сбор остановлен. Всего считано {self.store.total:,} отсчётов.', bool(result['error']))

    def stop(self):
        if self.busy(self.reader):
            self.reader.request_stop()
            self.stop_button.setEnabled(False)

    def refresh_plot(self):
        if self.store.version == self.last_version:
            return
        frame = self.store.snapshot()
        self.last_version = frame['version']
        t, y = peak_view(frame['times'], frame['values'])
        self.curve.setData(t, y)
        for key, field in self.readouts.items():
            field.setText(voltage_text(frame['stats'].get(key)))
        if len(t) > 1:
            self.plot.setXRange(float(t[0]), float(t[-1]), padding=0.01)
        count = len(frame['values'])
        span = (count - 1) / frame['rate'] if count > 1 else 0
        self.counters.setText(f"Всего: {frame['total']:,} · В окне: {count:,} · Длительность окна: {span:.4g} s\n"
                              f"Среднее и σ — по последнему блоку ({frame['stats'].get('block_samples', 0)} отсчётов). "
                              'Буфер просмотра ограничен 500 000 отсчётов.')
        maximum = frame['metadata'].get('voltage_max_V', 0)
        if maximum and frame['stats'] and max(abs(frame['stats']['minimum']), abs(frame['stats']['maximum'])) >= maximum * 0.995:
            if not self.acquisition_error:
                self.message.setText('Сигнал близок к границе выбранного диапазона. Проверьте амплитуду и диапазон входа.')
                self.message.setStyleSheet('color: #a52a3a;')
        self.update_enabled()

    def save(self):
        if self.busy(self.exporter) or not self.store.total:
            return
        filename, _ = QFileDialog.getSaveFileName(self, 'Сохранить последний участок AI3',
            f'AI3_{datetime.now():%Y%m%d_%H%M%S}.dat', 'Данные (*.dat *.txt *.tsv)')
        if not filename:
            return
        self.exporter = Export(filename, self.store.snapshot(), self)
        self.exporter.result.connect(lambda message, error: self.set_message(error or message, bool(error)))
        self.exporter.finished.connect(self.thread_finished)
        self.exporter.start()
        self.update_enabled()

    def thread_finished(self):
        self.update_enabled()
        if self.closing and not any(self.busy(t) for t in (self.reader, self.discovery, self.exporter)):
            self.can_close = True
            self.close()

    def closeEvent(self, event):
        if self.can_close or not any(self.busy(t) for t in (self.reader, self.discovery, self.exporter)):
            self.timer.stop()
            event.accept()
        else:
            event.ignore()
            self.closing = True
            self.stop()
            self.update_enabled()
