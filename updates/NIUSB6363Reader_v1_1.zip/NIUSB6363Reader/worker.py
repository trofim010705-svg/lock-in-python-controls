"""DAQ, поиск устройств и запись файлов работают вне потока интерфейса."""
import threading
import traceback

from PyQt5.QtCore import QThread, pyqtSignal

from backend import NIInput, DemoInput, discover_devices, explain_error
from core import export_snapshot
from daq_process import NIProcessInput


class Discovery(QThread):
    result = pyqtSignal(object, str, str)

    def run(self):
        try:
            devices, version = discover_devices()
            self.result.emit(devices, version, '')
        except Exception as exc:
            self.result.emit([], '', explain_error(exc))


class Acquisition(QThread):
    configured = pyqtSignal(object)
    result = pyqtSignal(object)
    diagnostic = pyqtSignal(str)

    def __init__(self, config, store, factory=None, parent=None):
        super().__init__(parent)
        self.config = config
        self.store = store
        self.stop_event = threading.Event()
        self.factory = factory or (DemoInput if config.demo else lambda: NIProcessInput(
            progress=self.diagnostic.emit, cancel=self.stop_event))

    def request_stop(self):
        self.stop_event.set()

    def run(self):
        source = None
        error = ''
        try:
            if self.stop_event.is_set():
                return
            source = self.factory()
            metadata = source.open(self.config)
            self.store.configure(metadata['sample_rate_Hz'], self.config.window_seconds, metadata)
            self.configured.emit(metadata)
            while not self.stop_event.is_set():
                values = source.read(self.stop_event)
                if len(values):
                    self.store.append(values)
        except Exception as exc:
            if not (isinstance(exc, InterruptedError) and self.stop_event.is_set()):
                error = explain_error(exc)
                self.diagnostic.emit(traceback.format_exc())
        finally:
            try:
                if source is not None:
                    source.close()
            except Exception as exc:
                error = (error + '\n' if error else '') + 'Закрытие AI: ' + explain_error(exc)
                self.diagnostic.emit(traceback.format_exc())
            self.result.emit({'error': error})


class Export(QThread):
    result = pyqtSignal(str, str)

    def __init__(self, filename, snapshot, parent=None):
        super().__init__(parent)
        self.filename, self.snapshot = filename, snapshot

    def run(self):
        try:
            data, metadata = export_snapshot(self.filename, self.snapshot)
            self.result.emit(f'Сохранено: {data}\nПараметры: {metadata}', '')
        except Exception as exc:
            self.result.emit('', f'Ошибка сохранения: {exc}')
        finally:
            self.snapshot = None
