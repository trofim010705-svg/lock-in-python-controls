"""Запуск: python app.py; симулятор без NI-DAQmx: python app.py --demo."""
import argparse
import sys
import multiprocessing


def main():
    from PyQt5.QtCore import Qt
    from PyQt5.QtWidgets import QApplication
    from gui import MainWindow
    parser = argparse.ArgumentParser(description='NI USB-6363 AI3 Differential Reader')
    parser.add_argument('--demo', action='store_true', help='Симулятор без драйвера NI и оборудования')
    args = parser.parse_args()
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication(sys.argv[:1])
    app.setApplicationName('NIUSB6363Reader')
    app.setOrganizationName('LabTools')
    app.setStyle('Fusion')
    window = MainWindow(demo=args.demo)
    window.show()
    return app.exec_()


if __name__ == '__main__':
    multiprocessing.freeze_support()
    sys.exit(main())
