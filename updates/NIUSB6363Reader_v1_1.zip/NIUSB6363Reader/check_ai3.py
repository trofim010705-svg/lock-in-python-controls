"""Hardware input check without Qt; run check_ai3.bat or python check_ai3.py."""
import argparse
from datetime import datetime
import multiprocessing
from pathlib import Path
import threading
import time
import traceback

from backend import runtime_info
from core import Config
from daq_process import NIProcessInput


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device', default='Dev1')
    parser.add_argument('--rate', type=float, default=1000)
    parser.add_argument('--range', type=float, default=10, dest='voltage_range')
    parser.add_argument('--seconds', type=float, default=3)
    parser.add_argument('--demo', action='store_true')
    args = parser.parse_args()
    path = Path(f'AI3_check_{datetime.now():%Y%m%d_%H%M%S}.txt')
    with path.open('w', encoding='utf-8') as report:
        def log(text):
            line = f'{datetime.now().astimezone().isoformat(timespec="milliseconds")}  {text}'
            print(line, flush=True)
            report.write(line + '\n')
            report.flush()
        log('Проверка AI3 без Qt. Только аналоговый вход. ' + str(runtime_info()))
        log('Отчёт: ' + str(path.resolve()))
        source = NIProcessInput(progress=log)
        status = 0
        try:
            config = Config(device=args.device, rate=args.rate, voltage_range=args.voltage_range, demo=args.demo)
            info = source.open(config)
            log('Настроено: ' + str(info))
            deadline, total = time.monotonic() + args.seconds, 0
            stop = threading.Event()
            while time.monotonic() < deadline:
                values = source.read(stop)
                total += len(values)
                if len(values):
                    log(f'N={total}; mean={values.mean():.8g} V; last={values[-1]:.8g} V')
            log(f'Чтение завершено: {total} отсчётов.')
        except KeyboardInterrupt:
            log('Прервано пользователем.')
        except Exception:
            log(traceback.format_exc())
            status = 1
        finally:
            try:
                source.close()
            except Exception:
                log(traceback.format_exc())
                status = 1
        return status


if __name__ == '__main__':
    multiprocessing.freeze_support()
    raise SystemExit(main())
