"""Explicit transport failures, distinct from invalid settings and disk errors."""


class ConnectionLost(RuntimeError):
    def __init__(self, device, detail):
        self.device = device
        self.detail = str(detail)
        super().__init__(f'{device}: {self.detail}')


def lockin_fingerprint(snapshot):
    selected = {}
    for name in ('Input', 'Demodulator', 'Output filters / Noise',
                 'Reference / Output 1', 'Oscillator output'):
        values = snapshot.get('sections', {}).get(name, {}).get('values', {})
        selected[name] = {key: value for key, value in values.items() if key != 'frq1'}
    return {'signal_unit': snapshot.get('signal_unit'),
            'reference_mode': snapshot.get('reference_mode'), 'sections': selected}
