"""Последовательный обмен и проверки перед изменением состояния магнита."""
from dataclasses import dataclass
import math
import re
import threading
import time

import serial


class ProtocolError(RuntimeError):
    pass


class ValidationError(ProtocolError):
    """Локальный отказ по параметрам; связь с прибором при этом не потеряна."""
    pass


class Cancelled(RuntimeError):
    pass


@dataclass(frozen=True)
class Connection:
    source_port: str = "COM11"
    relay_port: str = ""  # Отдельный порт реле, если он имеется.
    baudrate: int = 9600
    address: int = 6
    timeout: float = 1.0
    shared_relay: bool = False  # Явно выбранный общий порт блока и GEN.


@dataclass(frozen=True)
class Limits:
    current: float = 0.0
    voltage: float = 0.0

    def validate(self):
        if not (math.isfinite(self.current) and 0 < self.current <= 40):
            raise ValidationError("Укажите допустимый ток вашего магнита: больше 0, не более 40 A.")
        if not (math.isfinite(self.voltage) and 0 < self.voltage <= 60):
            raise ValidationError("Укажите допустимое напряжение: больше 0, не более 60 V.")


def number(reply):
    # Ни OK, ни текст ошибки, ни NaN не должны стать показанием тока.
    if not re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", reply.strip()):
        raise ProtocolError(f"Ожидалось число, получено {reply!r}.")
    value = float(reply)
    if not math.isfinite(value):
        raise ProtocolError("Прибор вернул не конечное число.")
    return value


def output_state(reply):
    value = reply.strip().upper()
    if value in ("ON", "1"):
        return True
    if value in ("OFF", "0"):
        return False
    raise ProtocolError(f"Неизвестный ответ OUT?: {reply!r}.")


class MagnetDriver:
    READ_COMMANDS = ("IDN?", "REV?", "SN?", "MC?", "MV?", "PC?", "PV?", "OUT?")

    def __init__(self, log=lambda message: None, factory=None, cancel=None):
        self.log = log
        self.factory = factory or self._serial_factory
        self.cancel = cancel or threading.Event()
        self.config = None
        self.source = self.relay = None
        self.address_selected = False
        self.identified = False
        self.last = {}
        self.rejected_relay_ports = {}

    @staticmethod
    def _serial_factory(port, baudrate):
        # Задаём DTR/RTS до открытия, без аппаратного управления потоком.
        link = serial.Serial(port=None, baudrate=baudrate, bytesize=8,
                             parity=serial.PARITY_NONE, stopbits=1,
                             timeout=0.025, write_timeout=0.5,
                             xonxoff=False, rtscts=False, dsrdtr=False)
        link.dtr = False
        link.rts = False
        link.port = port
        link.open()
        return link

    @property
    def connected(self):
        return self.source is not None

    @property
    def relay_key(self):
        if not self.config:
            return ""
        port = self.config.source_port if self.config.shared_relay else self.config.relay_port
        return port.strip().casefold()

    @property
    def relay_available(self):
        return (self.relay is not None and self.config is not None
                and (self.relay is not self.source or self.config.shared_relay)
                and self.relay_key not in self.rejected_relay_ports)

    def _check_cancel(self):
        if self.cancel.is_set():
            raise Cancelled("Операция прервана пользователем.")

    def open(self, config):
        if not config.source_port.strip():
            raise ValidationError("Введите COM-порт источника/коммутационного блока.")
        if not 0 <= config.address <= 30 or not 0.1 <= config.timeout <= 10:
            raise ValidationError("Адрес должен быть 0…30, тайм-аут — 0.1…10 s.")
        if (config.shared_relay and config.relay_port.strip()
                and config.relay_port.strip().casefold() != config.source_port.strip().casefold()):
            raise ValidationError("Выберите общий COM или отдельный порт реле, не оба режима сразу.")
        self.close()
        self.config = config
        try:
            self.source = self.factory(config.source_port.strip(), config.baudrate)
            relay_port = config.relay_port.strip()
            if relay_port and relay_port.casefold() != config.source_port.strip().casefold():
                self.relay = self.factory(relay_port, config.baudrate)
            else:
                self.relay = self.source
        except Exception:
            self.close()
            raise
        self.log(f"OPEN {config.source_port}, {config.baudrate} baud, 8N1; команды не отправлялись.")
        if self.relay is not self.source:
            self.log(f"OPEN реле: {config.relay_port}, {config.baudrate} baud, 8N1.")
        return "Порт открыт. Нажмите «Проверить источник» для ADR и запросов."

    def close(self):
        links = {id(x): x for x in (self.source, self.relay) if x is not None}
        self.source = self.relay = None
        self.address_selected = self.identified = False
        self.last = {}
        for link in links.values():
            try:
                link.close()
            except Exception as exc:
                self.log(f"CLOSE ERROR: {exc}")
        if links:
            self.log("CLOSE: COM закрыт; команда выключения выхода не отправлялась.")

    def _wire(self, command, relay=False, expect_reply=True, write_only=False):
        self._check_cancel()
        link = self.relay if relay else self.source
        if link is None:
            raise ProtocolError("Сначала подключитесь к COM-порту.")
        payload = command.encode("ascii") + b"\r"
        name = "RELAY" if relay else "SOURCE"
        # Не принимаем оставшийся ответ от предыдущего запроса за новый ответ.
        pending = link.in_waiting
        if pending:
            old = link.read(min(pending, 16384))
            self.log(f"{name} RX до запроса: {old!r} | HEX {old.hex(' ').upper()}")
            if link.in_waiting:
                raise ProtocolError("Входной буфер переполнен. Остановите посторонний обмен.")
        self.log(f"{name} TX {payload!r} | HEX {payload.hex(' ').upper()}")
        if link.write(payload) != len(payload):
            raise ProtocolError("Записана только часть команды; результат неизвестен.")
        if write_only:
            # Relay_2 в исходном EXE передаёт H/X без чтения ответа реле.
            # В общем тракте последующий C01 от GEN не доказывает отказ реле.
            self.log("RELAY: команда записана без ожидания ответа; положение контактов неизвестно.")
            return None
        deadline = time.monotonic() + (self.config.timeout if expect_reply else 0.25)
        buffer = bytearray()
        echo_count = 0
        received = 0
        while time.monotonic() < deadline:
            self._check_cancel()
            chunk = link.read(1)
            if not chunk:
                continue
            received += len(chunk)
            buffer.extend(chunk)
            if len(buffer) > 4096:
                raise ProtocolError("Ответ длиннее 4096 байт: неверный протокол или настройки порта.")
            if chunk not in (b"\r", b"\n"):
                continue
            raw = bytes(buffer)
            buffer.clear()
            if not raw.strip(b"\r\n"):
                continue
            self.log(f"{name} RX {raw!r} | HEX {raw.hex(' ').upper()}")
            if not expect_reply:
                reply = raw.decode('ascii', errors='replace').strip().upper()
                if re.fullmatch(r'[CE]\d{2}', reply):
                    self.rejected_relay_ports[self.relay_key] = reply
                    raise ProtocolError(f"На {command!r} получен код ошибки {reply}. "
                                        "Для GENESYS C01 означает недопустимую команду. "
                                        "Переключение не подтверждено; проверьте порт реле. "
                                        "Повторная отправка H/X через этот порт заблокирована.")
                continue  # Протокол положительного подтверждения реле неизвестен.
            try:
                reply = raw.decode("ascii").strip()
            except UnicodeDecodeError as exc:
                raise ProtocolError("Ответ не ASCII. Проверьте скорость и назначение COM.") from exc
            if reply == command:
                echo_count += 1
                if echo_count > 5:
                    raise ProtocolError("Получено только повторяющееся эхо команды.")
                continue
            return reply
        if buffer:
            self.log(f"{name} RX без окончания: {bytes(buffer)!r} | HEX {buffer.hex(' ').upper()}")
        if expect_reply:
            detail = ("Не получено ни одного байта" if not received else
                      f"Получено {received} байт, но нет полного ответа")
            raise ProtocolError(f"{detail} на {command!r} за {self.config.timeout:g} s. "
                                "Проверьте адрес, скорость и маршрут внутри блока.")
        self.log("RELAY: байты переданы; положение контактов программой не подтверждено.")
        return None

    def _ack(self, command):
        reply = self._wire(command)
        if reply.upper() != "OK":
            raise ProtocolError(f"Команда {command!r}: ожидалось OK, получено {reply!r}.")

    def select_address(self):
        self.address_selected = self.identified = False
        self._ack(f"ADR {self.config.address:02d}")
        self.address_selected = True
        return f"Адрес {self.config.address} подтверждён ответом OK."

    def query(self, command):
        if command not in self.READ_COMMANDS:
            raise ValidationError("Разрешены только запросы из списка.")
        if not self.address_selected:
            raise ValidationError("Сначала выполните ADR: кнопка «Выбрать адрес».")
        reply = self._wire(command)
        if command in ("MC?", "MV?", "PC?", "PV?"):
            value = number(reply)
            maximum = 40 if command in ("MC?", "PC?") else 60
            if abs(value) > maximum * 1.1:
                raise ProtocolError(f"Ответ {command}={value:g} вне диапазона GEN60-40.")
            if command in ("PC?", "PV?") and value < 0:
                raise ProtocolError(f"Отрицательная уставка {command}: {value:g}.")
        elif command == "OUT?":
            value = output_state(reply)
        else:
            value = reply
        self.last[command] = value
        return value

    def probe(self):
        self.select_address()
        identity = self.query("IDN?")
        if not re.search(r"\bGEN\s*60\s*[-/]\s*40\b", identity, re.I):
            raise ProtocolError(f"Ответ IDN?={identity!r} не подтверждает GEN60-40. "
                                "Изменение уставок заблокировано; журнал можно сохранить.")
        self.readings()
        self.identified = True
        return f"Источник определён: {identity}. Уставки и выход не изменялись."

    def readings(self):
        for command in ("MC?", "MV?", "PC?", "PV?", "OUT?"):
            self.query(command)
        return "Показания прочитаны."

    def _require_identity(self):
        if not self.identified:
            raise ValidationError("Сначала успешно выполните «Проверить источник».")

    def set_value(self, kind, value, limits):
        self._require_identity()
        limits.validate()
        if kind not in ("PC", "PV"):
            raise ValidationError("Неизвестная уставка.")
        try:
            value = float(value)
        except (ValueError, TypeError) as exc:
            raise ValidationError("Введите числовую уставку.") from exc
        maximum = limits.current if kind == "PC" else limits.voltage
        if not math.isfinite(value) or not 0 <= value <= maximum:
            raise ValidationError(f"Уставка должна быть от 0 до {maximum:g}.")
        # При OUT OFF можно привести сохранённые уставки в допустимый диапазон
        # по одной. Перед OUT ON обе уставки всё равно проверяются заново.
        other = self.query("PV?" if kind == "PC" else "PC?")
        enabled = self.query("OUT?")
        other_limit = limits.voltage if kind == "PC" else limits.current
        if enabled and other > other_limit and value != 0:
            raise ValidationError(f"Выход включён, вторая уставка {other:g} превышает предел "
                                  f"{other_limit:g}. Обнулите ток и выключите выход, "
                                  "затем исправьте сохранённые уставки.")
        sent = f"{value:.6f}".rstrip("0").rstrip(".") or "0"
        self._ack(f"{kind} {sent}")
        readback = self.query(f"{kind}?")
        if abs(readback - value) > max(0.001, abs(value)*0.001):
            raise ProtocolError(f"Прибор вернул уставку {readback:g} вместо {value:g}.")
        for command in ("MC?", "MV?", "OUT?"):
            self.query(command)
        return f"{kind}: прибор подтвердил {readback:g}."

    def enable_output(self, limits):
        self._require_identity()
        limits.validate()
        self.readings()
        if self.last["PC?"] > limits.current or self.last["PV?"] > limits.voltage:
            raise ValidationError("Уставки прибора превышают введённые пределы; OUT 1 не отправлен. "
                                  "При выключенном выходе приведите обе уставки в допустимый диапазон.")
        if abs(self.last["MC?"]) > limits.current:
            raise ValidationError("Фактический ток превышает введённый предел.")
        self._ack("OUT 1")
        if not self.query("OUT?"):
            raise ProtocolError("OUT 1 принят, но OUT? сообщает OFF. Проверьте защиты источника.")
        self.query("MC?")
        self.query("MV?")
        return "Источник подтвердил OUT ON."

    def zero_and_off(self):
        # Пытаемся выключить выход даже при отсутствии OK на PC 0.
        if not self.connected:
            raise ValidationError("COM не подключён. Используйте управление на самом источнике.")
        if not self.address_selected:
            self.select_address()
        errors = []
        for command in ("PC 0", "OUT 0"):
            try:
                self._ack(command)
            except ProtocolError as exc:
                errors.append(str(exc))
        for command in ("OUT?", "MC?", "PC?"):
            try:
                self.query(command)
            except ProtocolError as exc:
                errors.append(str(exc))
        if (errors or self.last.get("OUT?", True)
                or abs(self.last.get("PC?", float('inf'))) > 1e-9):
            raise ProtocolError("Выключение не полностью подтверждено. " + " | ".join(errors))
        return f"Выход OFF; измеренный ток {self.last['MC?']:g} A. Полярность не изменялась."

    def switch_polarity(self, command):
        self._require_identity()
        if command not in ("H", "X"):
            raise ValidationError("Неизвестная команда реле.")
        if self.relay is None or (self.relay is self.source and not self.config.shared_relay):
            raise ValidationError("H/X не отправлены: выбран порт GEN60-40. "
                                  "Явно выберите режим общего COM коммутационного блока "
                                  "либо отдельный порт реле.")
        if self.relay_key in self.rejected_relay_ports:
            code = self.rejected_relay_ports[self.relay_key]
            raise ValidationError(f"H/X не отправлены: этот порт ранее вернул {code}. "
                                  "Нужно проверить подключение и выбрать порт контроллера реле.")
        # Не переключаем реле на основании одного старого показания.
        if self.query("OUT?") or abs(self.query("PC?")) > 1e-9:
            raise ValidationError("Перед H/X обнулите уставку тока и выключите выход кнопкой ниже.")
        currents = []
        for _ in range(3):
            self._check_cancel()
            currents.append(self.query("MC?"))
            if abs(currents[-1]) > 0.01:
                raise ValidationError("Ток ещё превышает 0.01 A. H/X не отправлена; дождитесь спада тока.")
            if self.cancel.wait(0.1):
                self._check_cancel()
        # Повторная проверка непосредственно перед записью команды реле.
        if self.query("OUT?") or abs(self.query("PC?")) > 1e-9:
            raise ValidationError("Состояние источника изменилось; H/X не отправлена.")
        self.log(f"RELAY CHECK: OUT OFF, PC 0; MC = {currents} A.")
        try:
            self._wire(command, relay=True, expect_reply=False,
                       write_only=self.config.shared_relay)
            if self.config.shared_relay and self.cancel.wait(0.05):
                self._check_cancel()
        finally:
            # Даже при прерывании неизвестно, дошла ли команда и изменился ли маршрут.
            self.address_selected = self.identified = False
        return (f"{command} + CR передано. Контакты не подтверждены. "
                "Перед дальнейшим управлением снова нажмите «Проверить источник».")
