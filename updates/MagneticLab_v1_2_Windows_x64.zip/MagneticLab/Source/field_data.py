"""Bounded live averaging and sample-weighted capture of field in a time window."""
from collections import deque
import math
import threading
import time

import numpy as np
from reconnection import ConnectionLost


class FieldData:
    def __init__(self):
        self.condition = threading.Condition()
        self.blocks = deque()
        self.capture = None
        self.metadata = {}
        self.error = ''
        self.ready = False
        self.watermark = -math.inf
        self.last_received = -math.inf
        self.generation = 0

    def configure(self, metadata):
        with self.condition:
            self.blocks.clear()
            self.generation += 1
            if self.capture is not None:
                self.capture['error'] = self.capture.get('error') or 'NI переподключена во время точки.'
            self.metadata = dict(metadata)
            self.error = ''
            self.ready = True
            self.watermark = self.last_received = -math.inf
            self.condition.notify_all()

    def fail(self, error):
        with self.condition:
            self.ready = False
            self.error = error or 'Сбор NI остановлен.'
            if self.capture is not None:
                self.capture['error'] = self.error
                self.capture['end'] = min(self.capture['end'], time.perf_counter())
            self.condition.notify_all()

    def append(self, start_index, rate, origin, values):
        values = np.asarray(values, dtype=np.float64)
        if values.ndim != 1 or not np.isfinite(values).all():
            raise ValueError('NI вернул неверный массив напряжения.')
        if not len(values):
            return
        first = origin + start_index / rate
        last = first + (len(values) - 1) / rate
        with self.condition:
            self.blocks.append((first, rate, values.copy()))
            # At most 60 s for the live indicator, and at most 200000 samples.
            count = sum(len(block[2]) for block in self.blocks)
            while len(self.blocks) > 1 and (last - self.blocks[0][0] > 60 or count > 200000):
                count -= len(self.blocks.popleft()[2])
            self.watermark = max(self.watermark, last)
            self.last_received = time.perf_counter()
            if self.capture is not None and self.capture['generation'] == self.generation and not self.capture.get('error'):
                cap = self.capture
                times = first + np.arange(len(values)) / rate
                selected = values[(times >= cap['start']) & (times < cap['end'])]
                if len(selected):
                    cap['n'] += len(selected)
                    cap['sum'] += float(selected.sum())
                    cap['sumsq'] += float(np.dot(selected, selected))
            self.condition.notify_all()

    def live(self, interval_s, calibration):
        with self.condition:
            if not self.ready or not self.blocks or time.perf_counter() - self.last_received > 2.0:
                return None
            end = self.watermark + 1e-12
            total, count = 0.0, 0
            for first, rate, values in reversed(self.blocks):
                index = max(0, math.ceil((end - interval_s - first) * rate - 1e-7))
                if index < len(values):
                    total += float(values[index:].sum())
                    count += len(values) - index
                if first <= end - interval_s:
                    break
            return float(calibration.field(total / count)) if count else None

    def begin(self, start, end):
        with self.condition:
            if not self.ready or not self.blocks or time.perf_counter() - self.last_received > 2:
                raise ConnectionLost('ni', self.error or 'Нет свежих отсчётов NI.')
            if self.capture is not None:
                raise RuntimeError('Предыдущее окно NI ещё не завершено.')
            # begin is called before Lock-in sampling; already received values may
            # touch the boundary due to the uncertainty of the software time anchor.
            self.capture = {'start': start, 'end': end, 'n': 0, 'sum': 0.0, 'sumsq': 0.0,
                            'generation': self.generation, 'ni': dict(self.metadata), 'error': ''}

    def ensure_online(self):
        with self.condition:
            error = self.capture.get('error') if self.capture is not None else ''
            if error or not self.ready or not self.blocks or time.perf_counter() - self.last_received > 2:
                raise ConnectionLost('ni', error or self.error or 'Нет свежих отсчётов NI.')

    def wait_online(self, cancel):
        with self.condition:
            while True:
                if cancel.is_set():
                    raise InterruptedError('Остановлено при ожидании NI.')
                if self.ready and self.blocks and time.perf_counter() - self.last_received <= 2:
                    return dict(self.metadata)
                self.condition.wait(.1)

    def finish(self, end, calibration, timeout=2.0):
        deadline = time.perf_counter() + timeout
        with self.condition:
            if self.capture is None:
                raise RuntimeError('Окно NI не было открыто.')
            cap = self.capture
            if end is None:
                end = time.perf_counter()
            cap['end'] = min(cap['end'], end)
            while self.ready and not cap.get('error') and self.watermark < cap['end'] and time.perf_counter() < deadline:
                self.condition.wait(min(0.1, max(0.001, deadline - time.perf_counter())))
            cap, self.capture = self.capture, None
            valid = (self.ready and not cap.get('error') and cap['generation'] == self.generation
                     and self.watermark >= cap['end'] and cap['n'] > 0)
            mean = cap['sum'] / cap['n'] if cap['n'] else None
            variance = max(0, cap['sumsq'] / cap['n'] - mean ** 2) if mean is not None else None
            return {'valid': bool(valid), 'samples': cap['n'], 'mean_voltage_V': mean,
                    'mean_voltage_mV': mean * 1000 if mean is not None else None,
                    'field_mean_mT': float(calibration.field(mean)) if mean is not None else None,
                    'voltage_std_V': math.sqrt(variance) if variance is not None else None,
                    'start_monotonic_s': cap['start'], 'end_monotonic_s': cap['end'],
                    'error': '' if valid else cap.get('error') or self.error or 'Нет полного покрытия окна отсчётами NI.',
                    'ni_generation': cap['generation'], 'ni': cap['ni'],
                    'calibration': {'slope_mT_per_mV': calibration.slope, 'offset_mT': calibration.offset}}
