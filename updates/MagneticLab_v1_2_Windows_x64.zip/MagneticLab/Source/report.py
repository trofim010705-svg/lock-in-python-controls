"""Standalone figures rendered after magnet cleanup, without a GUI backend."""
from pathlib import Path

import numpy as np


def save_figures(folder, points, unit):
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.ticker import EngFormatter

    folder = Path(folder)
    fig = Figure(figsize=(9, 8), layout='constrained')
    FigureCanvasAgg(fig)
    a, b = fig.subplots(2, 1, sharex=True)
    valid = [p for p in points if p['result'] == 'complete' and p['field']['valid']]
    field = [p['field']['field_mean_mT'] for p in valid]
    amplitude = [p['statistics']['amplitude_mean'] for p in valid]
    phase = [p['statistics']['phase_mean_deg'] for p in valid]
    a.plot(field, amplitude, 'o-', color='#14798c', markersize=4)
    b.plot(field, [np.nan if v is None else v for v in phase], 'o', color='#8c549f', markersize=4)
    a.set_ylabel(f'Amplitude ({unit})')
    a.yaxis.set_major_formatter(EngFormatter(unit=unit))
    b.set_ylabel('Phase (deg)')
    b.set_xlabel('Magnetic field (mT)')
    b.set_ylim(0, 360)
    a.set_title('Lock-in channel 1 vs measured magnetic field')
    for ax in (a, b):
        ax.grid(alpha=.2)
    fig.savefig(folder / 'field_dependence.png', dpi=180)
    fig.savefig(folder / 'field_dependence.pdf')
    if points:
        last = points[-1]
        candidates = sorted(folder.glob(f"point_{last['index']:04d}_*/signal.dat"))
        if candidates:
            data = np.loadtxt(candidates[0], delimiter='\t', skiprows=1, ndmin=2)
            if data.size:
                a.clear()
                b.clear()
                a.plot(data[:, 0], data[:, 4], '.', color='#14798c', markersize=3)
                b.plot(data[:, 0], data[:, 5], '.', color='#8c549f', markersize=3)
                a.set_ylabel(f'Amplitude ({unit})')
                a.yaxis.set_major_formatter(EngFormatter(unit=unit))
                b.set_ylabel('Phase (deg)')
                b.set_xlabel('Time (s)')
                b.set_ylim(0, 360)
                a.set_title(f"Point {last['index']} · B = {last['field'].get('field_mean_mT')} mT")
                for ax in (a, b):
                    ax.grid(alpha=.2)
                fig.savefig(folder / 'last_point_time_signals.png', dpi=180)
