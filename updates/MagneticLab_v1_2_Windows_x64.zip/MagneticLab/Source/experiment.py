"""One experiment owns the devices until data saving and magnet cleanup finish."""
from dataclasses import asdict
import math
from pathlib import Path
import threading
import time
import traceback

from PyQt5.QtCore import QThread, pyqtSignal

from models import signal_statistics
from storage import create_folder, now, save_point, save_summary, metadata
from report import save_figures
from reconnection import ConnectionLost, lockin_fingerprint


class ExperimentRunner(QThread):
    changed = pyqtSignal(str)
    point_started = pyqtSignal(int, int)
    samples = pyqtSignal(object)
    point_ready = pyqtSignal(object)
    prepared = pyqtSignal(object)
    recovering = pyqtSignal(object)
    outcome = pyqtSignal(object)
    log = pyqtSignal(str)

    def __init__(self, parameters, calibration, lockin, magnet, field, magnet_connected,
                 demo=False, parent=None):
        super().__init__(parent)
        self.parameters, self.calibration = parameters, calibration
        self.lockin, self.magnet, self.field = lockin, magnet, field
        self.magnet_connected, self.demo = magnet_connected, demo
        self.stop_event = threading.Event()
        self.abort_error = ''
        self.unsaved = None
        self.folder = None
        self.retry_delay = 2.0
        self.monitor_period = 1.0
        self.info = {}
        self.points = []
        self.reconnected_snapshot = None

    def stop(self):
        self.stop_event.set()

    def abort(self, message):
        self.abort_error = message
        self.stop_event.set()

    def check(self):
        if self.abort_error:
            raise RuntimeError(self.abort_error)
        if self.stop_event.is_set():
            raise InterruptedError('Остановлено пользователем.')
        if hasattr(self.field, 'ensure_online'):
            self.field.ensure_online()
        elif not self.field.ready:
            raise ConnectionLost('ni', self.field.error or 'Нет данных NI.')

    def cancelled(self):
        if self.abort_error:
            raise RuntimeError(self.abort_error)
        if self.stop_event.is_set():
            raise InterruptedError('Остановлено пользователем.')

    def event(self, device, state, detail, attempt=0):
        entry = dict(time=now(), device=device, state=state, detail=str(detail), attempt=attempt)
        self.info.setdefault('recovery_events', []).append(entry)
        self.recovering.emit(entry)
        self.log.emit(f"{device}: {state}: {detail}")
        if self.folder is not None:
            save_summary(self.folder, self.points, dict(self.info, result='reconnecting'))

    def recover_device(self, failure):
        device = failure.device
        self.event(device, 'lost', failure.detail)
        # During a sweep, keep a readable magnet at zero while other devices are
        # unavailable. Single mode explicitly leaves the pre-existing current alone.
        if device != 'magnet' and self.magnet_connected and self.parameters.mode == 'sweep':
            try:
                self.magnet.call('zero')
            except ConnectionLost as secondary:
                self.recover_device(secondary)
                self.magnet.call('zero')
        attempt = 0
        while True:
            self.cancelled()
            attempt += 1
            names = {'magnet': 'магнита', 'lockin': 'Lock-in', 'ni': 'NI'}
            message = f'Ожидание связи {names.get(device, device)} · попытка {attempt}. Stop остаётся доступен.'
            self.changed.emit(message)
            try:
                if device == 'magnet':
                    self.magnet.call('reconnect', cancel=self.stop_event)
                elif device == 'lockin':
                    candidate = self.lockin.call('lab_reconnect', cancel=self.stop_event)
                    previous = self.info.get('lockin')
                    if previous and lockin_fingerprint(candidate) != lockin_fingerprint(previous):
                        raise RuntimeError('Связь есть, но настройки Lock-in изменились. Восстановите исходные настройки или нажмите Stop.')
                    self.reconnected_snapshot = candidate
                elif device == 'ni':
                    if hasattr(self.field, 'wait_online'):
                        ni = self.field.wait_online(self.stop_event)
                        self.info['ni'] = ni
                    elif not self.field.ready:
                        raise RuntimeError(self.field.error or 'NI не готова.')
                else:
                    raise RuntimeError('Неизвестный прибор: ' + device)
            except InterruptedError:
                raise
            except Exception as exc:
                self.event(device, 'retry', exc, attempt)
                self.changed.emit(message + '\n' + str(exc))
                if self.stop_event.wait(self.retry_delay):
                    self.cancelled()
                continue
            self.event(device, 'restored', 'Связь проверена; незавершённая точка будет измерена заново.', attempt)
            return

    def zero_on_finish(self, info):
        self.changed.emit('Обнуление тока и выключение выхода…')
        while True:
            try:
                info['magnet_final'] = self.magnet.call('zero', timeout=90)
                info['magnet_finish_action'] = 'zeroed'
                return ''
            except ConnectionLost as exc:
                if not self.stop_event.is_set():
                    try:
                        self.recover_device(exc)
                        continue
                    except Exception as recovery_error:
                        exc = recovery_error
                info['magnet_finish_action'] = 'zero_failed'
                self.log.emit('Не удалось подтвердить обнуление магнита: ' + str(exc))
                return str(exc)
            except Exception as exc:
                info['magnet_finish_action'] = 'zero_failed'
                self.log.emit('Не удалось подтвердить обнуление магнита: ' + str(exc))
                return str(exc)

    def hold_on_finish(self):
        while True:
            self.cancelled()
            try:
                return self.magnet.call('read', cancel=self.stop_event)
            except ConnectionLost as exc:
                self.recover_device(exc)
                if self.parameters.mode == 'sweep':
                    target = self.parameters.currents()[-1]
                    try:
                        self.magnet.call('set_current', {'current': target,
                            'voltage': self.parameters.voltage_V}, self.stop_event)
                        self.magnet.call('wait_current', {'current': target}, self.stop_event)
                    except ConnectionLost:
                        continue

    def measure_attempt(self, index, target, attempt, info):
        p = self.parameters
        self.check()
        current_state = {}
        if p.mode == 'sweep':
            self.changed.emit(f'Точка {index}/{len(p.currents())}: установка {target:+.4g} A')
            self.magnet.call('set_current', {'current': target, 'voltage': p.voltage_V}, self.stop_event)
            current_state = self.magnet.call('wait_current', {'current': target}, self.stop_event)
            if self.stop_event.wait(p.settle_s):
                self.cancelled()
        elif self.magnet_connected:
            current_state = self.magnet.call('read', cancel=self.stop_event)
        self.check()
        self.point_started.emit(index, len(p.currents()))
        self.changed.emit(f'Точка {index}/{len(p.currents())}: измерение {p.acquisition_s:g} s · попытка {attempt}')
        start = time.perf_counter()
        deadline = start + p.acquisition_s
        self.field.begin(start, deadline)
        rows, batch, next_tick, last_emit = [], [], start, start
        next_health = start + self.monitor_period
        failure = None
        try:
            while time.perf_counter() < deadline:
                self.check()
                if self.stop_event.wait(max(0, min(next_tick, deadline) - time.perf_counter())):
                    self.cancelled()
                if time.perf_counter() >= deadline:
                    break
                if self.magnet_connected and time.perf_counter() >= next_health:
                    self.magnet.call('health', {'current': target}, self.stop_event)
                    next_health = time.perf_counter() + self.monitor_period
                sample = self.lockin.call('lab_xy', cancel=self.stop_event)
                if sample['end'] <= deadline:
                    row = (sample['start'] - start, sample['end'] - start,
                           sample['x'], sample['y'], sample['amplitude'], sample['phase'],
                           sample['status'], sample['overload'])
                    rows.append(row)
                    batch.append(row)
                if time.perf_counter() - last_emit >= 0.1:
                    self.samples.emit(tuple(batch))
                    batch = []
                    last_emit = time.perf_counter()
                period = p.period_ms / 1000
                next_tick += period
                if next_tick < time.perf_counter():
                    next_tick += math.ceil((time.perf_counter() - next_tick) / period) * period
            self.check()
            if self.magnet_connected:
                self.magnet.call('health', {'current': target}, self.stop_event)
        except Exception as exc:
            failure = exc
        if batch:
            self.samples.emit(tuple(batch))
        field = self.field.finish(None, self.calibration)
        if not field['valid'] and failure is None:
            failure = ConnectionLost('ni', field['error'])
        if not rows and failure is None:
            failure = RuntimeError('В точке нет отсчётов Lock-in.')
        point_reason = ('connection_lost' if isinstance(failure, ConnectionLost) else
                        'stopped' if self.stop_event.is_set() else 'error' if failure else 'complete')
        point = {'index': index, 'attempt': attempt, 'target_current_A': target,
            'measured_current_A': current_state.get('signed_current_A'),
            'magnet': current_state, 'result': point_reason, 'error': str(failure) if failure else '',
            'acquisition_actual_s': field['end_monotonic_s'] - start, 'field': field,
            'statistics': signal_statistics(rows), 'lockin': info['lockin'],
            'parameters': asdict(p), 'started_monotonic_s': start, 'saved': now()}
        sign_name = 'held' if target is None else f'{target:+.5f}'.replace('-', 'm').replace('+', 'p').replace('.', 'p') + 'A'
        name = f'point_{index:04d}_{sign_name}'
        point_folder = self.folder / name
        if isinstance(failure, ConnectionLost):
            point_folder = self.folder / 'incomplete' / f'{name}_attempt_{attempt:04d}'
        self.unsaved = (rows, point, point_folder)
        save_point(point_folder, rows, point)
        self.unsaved = None
        if isinstance(failure, ConnectionLost):
            info.setdefault('incomplete_attempts', []).append({k:v for k,v in point.items() if k not in ('lockin', 'parameters')})
        else:
            self.points.append(point)
            self.point_ready.emit(point)
        save_summary(self.folder, self.points, dict(info, result='running'))
        if failure:
            raise failure

    def run(self):
        p = self.parameters
        points = []
        info = {'application': 'Magnetic Lab 1.2', 'started': now(), 'demo': self.demo,
                'parameters': asdict(p), 'calibration': asdict(self.calibration),
                'signal_formulas': {'amplitude': 'sqrt(X1^2 + Y1^2)',
                    'phase': 'atan2(Y1, X1), degrees in [0,360)',
                    'mean_amplitude': 'arithmetic mean of individual amplitudes',
                    'mean_phase': 'circular mean of unit phasors; undefined for zero resultant',
                    'field': 'B_mT = slope_mT_per_mV * (1000 * U_V) + offset_mT'},
                'timing': 'X1 then Y1 are read sequentially; NI and Lock-in have a software time anchor, not a common hardware trigger.',
                'sig_bal': 'Stored as metadata only; no voltage-to-angle conversion applied.',
                'points_count': len(p.currents())}
        self.info, self.points = info, points
        error, reason, cleanup_error = '', 'complete', ''
        try:
            p.validate()
            self.calibration.validate()
            self.cancelled()
            self.folder = create_folder(p.folder, p.name)
            self.changed.emit('Папка: ' + str(self.folder))
            metadata(self.folder / 'experiment.txt', dict(info, result='preparing'))
            while True:
                try:
                    self.check()
                    info['lockin'] = self.reconnected_snapshot or self.lockin.call('lab_snapshot', cancel=self.stop_event)
                    break
                except ConnectionLost as exc:
                    self.recover_device(exc)
            info['ni'] = dict(self.field.metadata)
            self.prepared.emit(info['lockin'])
            for index, target in enumerate(p.currents(), 1):
                attempt = 1
                while True:
                    try:
                        self.measure_attempt(index, target, attempt, info)
                        break
                    except ConnectionLost as exc:
                        self.recover_device(exc)
                        attempt += 1
        except InterruptedError as exc:
            reason = 'stopped'
            error = str(exc)
        except Exception as exc:
            reason = 'error'
            error = f'{type(exc).__name__}: {exc}'
            self.log.emit(traceback.format_exc())
        finally:
            info['magnet_finish_requested'] = 'zero' if p.zero_after else 'hold'
            info['magnet_finish_action'] = 'not_connected'
            held = False
            if reason == 'complete' and self.stop_event.is_set():
                reason = 'error' if self.abort_error else 'stopped'
                error = self.abort_error or 'Остановлено пользователем.'
            if self.magnet_connected:
                if reason == 'complete' and not p.zero_after:
                    self.changed.emit('Конечная уставка сохраняется. Чтение состояния источника…')
                    try:
                        info['magnet_final'] = self.hold_on_finish()
                        info['magnet_finish_action'] = 'held'
                        held = True
                    except InterruptedError as exc:
                        error, reason = str(exc), 'stopped'
                    except Exception as exc:
                        error = 'Не удалось прочитать конечное состояние магнита: ' + str(exc)
                        reason = 'error'
                if not held:
                    cleanup_error = self.zero_on_finish(info)
                    if cleanup_error:
                        reason = 'error'
            info.update(finished=now(), result=reason, error=error, cleanup_error=cleanup_error)
            if self.folder is not None:
                try:
                    save_summary(self.folder, points, info)
                    if points:
                        suffix = (' Конечная уставка сохраняется.' if held else
                                  ' Ток уже обнулён.' if self.magnet_connected and not cleanup_error else '')
                        self.changed.emit('Сохранение графиков…' + suffix)
                        save_figures(self.folder, points, info.get('lockin', {}).get('signal_unit', 'V'))
                except Exception as exc:
                    error += '\nОшибка сохранения сводки: ' + str(exc)
                    reason = 'error'
                    if held:
                        cleanup_error = self.zero_on_finish(info)
                        held = False
                    info.update(result=reason, error=error, cleanup_error=cleanup_error)
                    try:
                        save_summary(self.folder, points, info)
                    except Exception:
                        pass
            # Stop or an NI fault may arrive while the PNG/PDF files are rendered.
            if reason == 'complete' and self.stop_event.is_set():
                reason = 'error' if self.abort_error else 'stopped'
                error = self.abort_error or 'Остановлено при завершении измерения.'
                if held:
                    cleanup_error = self.zero_on_finish(info)
                    held = False
                if cleanup_error:
                    reason = 'error'
                info.update(result=reason, error=error, cleanup_error=cleanup_error)
                if self.folder is not None:
                    try:
                        save_summary(self.folder, points, info)
                    except Exception as exc:
                        reason = 'error'
                        error += '\nОшибка сохранения: ' + str(exc)
            self.outcome.emit({'reason': reason, 'error': error, 'cleanup_error': cleanup_error,
                'finish_action': info['magnet_finish_action'],
                'folder': str(self.folder) if self.folder else '', 'points': points,
                'metadata': info, 'unsaved': self.unsaved is not None})
