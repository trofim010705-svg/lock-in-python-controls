"""Single-owner instrument workers and thread-safe requests from the experiment."""
import math
import threading
import time
import traceback
import re
from dataclasses import replace

import numpy as np
import serial
from PyQt5.QtCore import QObject, QThread, Qt, pyqtSignal, pyqtSlot

from gui_app import Worker, Instrument, USB7230, DemoTransport, ProtocolError as USBProtocolError, CommandError
from magnet_driver import MagnetDriver, Connection, ProtocolError, ValidationError
from magnet_demo import DemoSerial
from magnet import MagnetController
from models import phase_deg
from ni_input.core import Config
from ni_input.daq_process import NIProcessInput
from reconnection import ConnectionLost


def _visa_link_failure(exc):
    return (isinstance(exc, (OSError, USBProtocolError, ConnectionLost))
            or type(exc).__name__ == 'VisaIOError')


class Ticket:
    def __init__(self, cancel=None):
        self.event = threading.Event()
        self.cancel = cancel
        self.value = None
        self.error = None
        self.started = False

    def finish(self, value=None, error=None):
        self.value, self.error = value, error
        self.event.set()


class Port(QObject):
    request = pyqtSignal(str, object)

    def __init__(self, worker):
        super().__init__()
        self.request.connect(worker.execute, Qt.QueuedConnection)

    def call(self, operation, data=None, cancel=None, timeout=90):
        ticket = Ticket(cancel)
        self.request.emit(operation, {'ticket': ticket, 'data': data or {}})
        deadline = time.perf_counter() + timeout
        while not ticket.event.wait(0.025):
            # An in-flight write must finish before cleanup is queued. Otherwise
            # a delayed PC/OUT command could execute after the cleanup command.
            if time.perf_counter() > deadline:
                raise TimeoutError(f'Нет ответа рабочего потока на {operation}. Состояние операции неизвестно.')
        if ticket.error is not None:
            raise ticket.error
        return ticket.value


def snapshot(instrument, cancel=None):
    original = instrument.transport
    raw = {}

    class Recorder:
        def exchange(self, command, *args, **kwargs):
            if cancel is not None and cancel.is_set():
                raise InterruptedError('Чтение настроек отменено.')
            result = original.exchange(command, *args, **kwargs)
            raw[command] = result[0]
            return result

    instrument.transport = Recorder()
    try:
        firmware = instrument.query('VER')
        mode = int(instrument.values('REFMODE')[0])
        imode = int(instrument.values('IMODE')[0])
        sections = {title: instrument.read_section(title) for title in instrument.sections}
        return {'firmware': firmware, 'reference_mode': mode, 'input_mode': imode,
                'signal_unit': 'V' if imode == 0 else 'A', 'sections': sections,
                'raw_replies': raw, 'usb_resource': getattr(getattr(original, 'module', None), '_USB_RESOURCE', 'DEMO')}
    finally:
        instrument.transport = original


class LabLockinWorker(Worker):
    plant = None
    connection_changed = pyqtSignal(bool, str)

    @pyqtSlot(str, object)
    def execute(self, job, payload):
        if job == 'poll':
            payload = dict(payload, include_xy=True)
        if job not in ('lab_snapshot', 'lab_xy', 'lab_reconnect'):
            return super().execute(job, payload)
        ticket = payload['ticket']
        try:
            if ticket.cancel is not None and ticket.cancel.is_set():
                raise InterruptedError('Измерение отменено.')
            ticket.started = True
            if job == 'lab_reconnect':
                if self.instrument is None:
                    demo, serial_number, timeout, sections, maximum = self.args
                    transport = DemoTransport() if demo else USB7230(serial_number, timeout)
                    self.instrument = Instrument(transport, sections, maximum)
                    transport.open()
                state = snapshot(self.instrument, ticket.cancel)
                self.connection_changed.emit(True, 'Lock-in: связь восстановлена · ' + state['firmware'])
                ticket.finish(state)
                return
            if self.instrument is None:
                raise ConnectionLost('lockin', 'Lock-in не подключён.')
            if job == 'lab_snapshot':
                ticket.finish(snapshot(self.instrument, ticket.cancel))
                return
            inst = self.instrument
            t0 = time.perf_counter()
            if self.args[0] and self.plant is not None:
                current = self.plant.get_current()
                amplitude = 12e-6 * (1 + .35 * math.sin(current * 1.2))
                phase = math.radians(165 + 24 * current)
                x = amplitude * math.cos(phase) + .25e-6 * math.sin(t0 * 71)
                y = amplitude * math.sin(phase) + .25e-6 * math.cos(t0 * 47)
                status, overload = 1, 0
            else:
                x_values = inst.values(inst.channel_command('X', 1) + '.')
                status, overload = inst.status, inst.overload
                y_values = inst.values(inst.channel_command('Y', 1) + '.')
                status |= inst.status
                overload |= inst.overload
                if len(x_values) != 1 or len(y_values) != 1:
                    raise RuntimeError('От Lock-in ожидалась одна пара X1/Y1.')
                x, y = x_values[0], y_values[0]
            if not math.isfinite(x) or not math.isfinite(y):
                raise RuntimeError('Lock-in вернул NaN/Inf.')
            ticket.finish({'start': t0, 'end': time.perf_counter(), 'x': x, 'y': y,
                           'amplitude': math.hypot(x, y), 'phase': phase_deg(x, y),
                           'status': status, 'overload': overload})
        except Exception as exc:
            if not isinstance(exc, InterruptedError) and self.instrument is not None:
                try:
                    self.instrument.transport.close()
                except Exception:
                    pass
                self.instrument = None
                self.failed.emit('lab_usb', str(exc), True)
                self.connection_changed.emit(False, str(exc))
            if _visa_link_failure(exc) and not isinstance(exc, ConnectionLost):
                exc = ConnectionLost('lockin', str(exc))
            ticket.finish(error=exc)


class MagnetWorker(QObject):
    state_changed = pyqtSignal(object)
    completed = pyqtSignal(str, bool, str)
    logged = pyqtSignal(str)
    stopped = pyqtSignal()

    def __init__(self, demo=False, plant=None):
        super().__init__()
        self.demo = demo
        self.demo_state = None
        self.driver = MagnetDriver(log=self.logged.emit, factory=self.demo_factory if demo else None)
        self.controller = MagnetController(self.driver, plant)
        self.saved_connection = None
        self.saved_usb = None
        self.saved_source_serial = None

    def demo_factory(self, port, baud):
        link = DemoSerial(port, baud)
        if self.demo_state:
            link.current, link.voltage, link.on = self.demo_state
        return link

    def remember_demo_state(self):
        if self.demo and self.driver.source is not None:
            link = self.driver.source
            self.demo_state = (link.current, link.voltage, link.on)

    def remember_connection(self):
        self.saved_usb = None
        if not self.demo:
            from serial.tools import list_ports
            for port in list_ports.comports():
                if port.device.casefold() == self.saved_connection.source_port.casefold():
                    self.saved_usb = (port.vid, port.pid, port.serial_number, port.location)
                    break
        self.saved_source_serial = self.source_serial()

    def source_serial(self):
        try:
            value = str(self.driver.query('SN?')).strip()
            return value if value and not re.fullmatch(r'[CE]\d{2}', value) else None
        except ProtocolError:
            return None

    def reconnect(self):
        if self.saved_connection is None:
            raise ValidationError('Нет сохранённых параметров подключения магнита.')
        connection = self.saved_connection
        if self.saved_usb and not self.demo:
            from serial.tools import list_ports
            vid, pid, serial_number, location = self.saved_usb
            matches = [p for p in list_ports.comports() if (p.vid, p.pid) == (vid, pid)
                       and ((serial_number and p.serial_number == serial_number)
                            or (not serial_number and location and p.location == location))]
            if len(matches) == 1:
                connection = replace(connection, source_port=matches[0].device)
            elif serial_number or location:
                raise ConnectionLost('magnet', 'Ожидание того же USB-переходника магнита; найдено подходящих портов: ' + str(len(matches)))
        # Reopening never sends a current, output-enable or relay command.
        self.controller.polarity = None
        self.driver.open(connection)
        self.driver.probe()
        serial_number = self.source_serial()
        if self.saved_source_serial and serial_number != self.saved_source_serial:
            self.driver.close()
            raise ValidationError('Серийный номер источника изменился. Ожидание исходного GEN60-40.')
        self.saved_connection = connection
        return self.controller.state()

    @pyqtSlot(str, object)
    def execute(self, operation, payload):
        ticket = payload.get('ticket')
        data = payload.get('data', payload)
        try:
            if ticket is not None:
                if ticket.cancel is not None and ticket.cancel.is_set():
                    raise InterruptedError('Команда отменена до исполнения.')
                ticket.started = True
            if operation == 'open':
                self.controller.polarity = None
                self.saved_connection = Connection(source_port=data['port'], baudrate=data['baud'],
                    address=data['address'], timeout=1.0, shared_relay=True)
                self.driver.open(self.saved_connection)
                self.driver.probe()
                self.remember_connection()
            elif operation == 'reconnect':
                self.reconnect()
            elif operation == 'close':
                self.driver.close()
                self.controller.polarity = None
            elif operation == 'zero':
                if not self.driver.connected:
                    raise ConnectionLost('magnet', 'COM магнита не подключён.')
                self.controller.zero()
            elif operation == 'flip':
                self.controller.switch(-self.controller.polarity if self.controller.polarity else -1)
            elif operation == 'flip_start':
                sign = -self.controller.polarity if self.controller.polarity else -1
                self.controller.switch(sign)
                if data['current'] > 0:
                    self.controller.set_signed(sign * data['current'], data['voltage'])
            elif operation == 'set_current':
                if not self.driver.connected:
                    raise ConnectionLost('magnet', 'COM магнита не подключён.')
                self.controller.set_signed(data['current'], data['voltage'],
                                           ticket.cancel if ticket is not None else None)
            elif operation == 'wait_current':
                self.controller.wait_current(data['current'], ticket.cancel)
            elif operation == 'read':
                if not self.driver.connected:
                    raise ConnectionLost('magnet', 'COM магнита не подключён.')
                self.driver.readings()
            elif operation == 'health':
                if not self.driver.connected:
                    raise ConnectionLost('magnet', 'COM магнита не подключён.')
                enabled = self.driver.query('OUT?')
                requested = self.driver.query('PC?')
                self.driver.query('MC?')
                target = data.get('current')
                if target is not None and (abs(requested - abs(target)) > .002
                    or bool(enabled) != (abs(target) > 1e-10)):
                    raise ValidationError('Состояние источника изменилось без команды программы. Проверьте GEN60-40.')
            else:
                raise ValueError('Неизвестная команда магнита: ' + operation)
            state = self.controller.state()
            self.remember_demo_state()
            self.state_changed.emit(state)
            if ticket is not None:
                ticket.finish(state)
            else:
                self.completed.emit(operation, True, 'Выполнено: ' + operation)
        except Exception as exc:
            self.remember_demo_state()
            lost = (isinstance(exc, (serial.SerialException, OSError, ConnectionLost))
                    or isinstance(exc, ProtocolError) and not isinstance(exc, ValidationError))
            if operation in ('open', 'reconnect') or lost:
                self.driver.close()
                self.controller.polarity = None
            self.logged.emit(traceback.format_exc())
            self.state_changed.emit(self.controller.state())
            if ticket is not None:
                if lost and not isinstance(exc, ConnectionLost):
                    exc = ConnectionLost('magnet', str(exc))
                ticket.finish(error=exc)
            else:
                self.completed.emit(operation, False, str(exc))

    @pyqtSlot()
    def shutdown(self):
        if self.driver.connected:
            try:
                self.controller.zero()
            except Exception as exc:
                self.logged.emit('Закрытие: обнуление не подтверждено: ' + str(exc))
        self.driver.close()
        self.stopped.emit()


class FieldReader(QThread):
    configured = pyqtSignal(object)
    failed = pyqtSignal(str)
    diagnostic = pyqtSignal(str)

    def __init__(self, config, store, plant=None, parent=None):
        super().__init__(parent)
        self.config, self.store, self.plant = config, store, plant
        self.stop_event = threading.Event()

    def stop(self):
        self.stop_event.set()

    def run(self):
        attempt = 0
        while not self.stop_event.is_set():
            source = None
            try:
                if self.config.demo:
                    info = {'demo': True, 'physical_channel': 'DEMO/ai3',
                            'sample_rate_Hz': self.config.rate, 'terminal_configuration': 'DIFFERENTIAL',
                            'origin_monotonic_s': time.perf_counter(), 'time_anchor_uncertainty_s': 0}
                else:
                    source = NIProcessInput(progress=self.diagnostic.emit, cancel=self.stop_event)
                    info = source.open(self.config)
                rate, origin = info['sample_rate_Hz'], info['origin_monotonic_s']
                self.store.configure(info)
                self.configured.emit(info)
                attempt = 0
                count = 0
                while not self.stop_event.is_set():
                    if self.config.demo:
                        n = self.config.block_samples
                        target = origin + (count + n) / rate
                        if self.stop_event.wait(max(0, target - time.perf_counter())):
                            break
                        t = origin + (count + np.arange(n)) / rate
                        values = self.plant.get_current() * .01 + .000005 * np.sin(t * 73)
                    else:
                        values = source.read(self.stop_event)
                    if len(values):
                        self.store.append(count, rate, origin, values)
                        count += len(values)
            except Exception as exc:
                if not self.stop_event.is_set():
                    attempt += 1
                    self.store.fail(str(exc))
                    self.diagnostic.emit(traceback.format_exc())
                    self.failed.emit(f'{exc} · переподключение NI, попытка {attempt}')
            finally:
                if source is not None:
                    try:
                        source.close()
                    except Exception as exc:
                        self.diagnostic.emit('Закрытие NI: ' + str(exc))
                if self.store.ready:
                    self.store.fail('Сбор NI остановлен.')
            if not self.stop_event.is_set():
                self.stop_event.wait(2.0)
        self.store.fail('Сбор NI остановлен пользователем.')
