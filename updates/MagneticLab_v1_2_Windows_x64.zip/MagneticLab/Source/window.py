"""Full Lock-in controls plus a compact field experiment dashboard."""
from collections import deque
from datetime import datetime
from pathlib import Path
import time
import math

import numpy as np
import pyqtgraph as pg
from PyQt5.QtCore import Qt, QSettings, QStandardPaths, QThread, QTimer, pyqtSignal, pyqtSlot
from PyQt5.QtWidgets import (
    QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout, QGridLayout, QGroupBox,
    QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit, QProgressBar, QPushButton,
    QScrollArea, QSpinBox, QSplitter, QTabWidget, QVBoxLayout, QWidget,
)
from serial.tools import list_ports

from gui_app import LockinWindow, engineering
from gui_widgets import InstrumentTabBar
from models import Calibration, DemoPlant, Experiment
from field_data import FieldData
from services import LabLockinWorker, MagnetWorker, Port, FieldReader
from ni_input.core import Config, peak_view
from experiment import ExperimentRunner
from storage import create_folder, save_point, save_summary


class Recovery(QThread):
    result = pyqtSignal(bool, str)

    def __init__(self, target, unsaved, parent=None):
        super().__init__(parent)
        self.target, self.unsaved = target, unsaved

    def run(self):
        try:
            rows, point, original = self.unsaved
            folder = create_folder(self.target, 'recovered_point')
            save_point(folder / original.name, rows, point)
            save_summary(folder, [point], {'lockin': point['lockin'], 'recovered_from': str(original)})
            self.result.emit(True, str(folder))
        except Exception as exc:
            self.result.emit(False, str(exc))


class LabWindow(LockinWindow):
    worker_class = LabLockinWorker
    mag_request = pyqtSignal(str, object)
    mag_shutdown = pyqtSignal()

    def __init__(self, args):
        self.exclusive = 'idle'
        self.pending_launch = False
        self.runner = self.field_reader = self.recovery = None
        self.mag_busy = False
        self.mag_state = {'connected': False, 'identified': False, 'polarity': None, 'values': {}}
        self.want_close = self.services_shutdown = False
        self.plant = DemoPlant()
        self.field_data = FieldData()
        self.live_rows = deque(maxlen=50000)
        self.points = []
        self.graph_version = self.drawn_version = 0
        self.signal_unit = 'V'
        self.settings = QSettings()
        self.default_fields = {}
        super().__init__(args)
        self.worker.plant = self.plant
        self.setWindowTitle('Magnetic Lab 1.2 · Lock-in / Magnet / NI AI3' + (' · DEMO' if args.demo else ''))
        available = self.screen().availableGeometry()
        self.resize(min(1530, available.width()), min(1000, available.height()))
        self.setMinimumSize(1040, 640)
        self.control_page = self.takeCentralWidget()
        self.pages = QTabWidget()
        self.pages.setTabBar(InstrumentTabBar(self.pages))
        self.dashboard = self.build_dashboard()
        self.pages.addTab(self.dashboard, 'Измерения и магнит')
        self.control_scroll = QScrollArea()
        self.control_scroll.setWidgetResizable(True)
        self.control_scroll.setWidget(self.control_page)
        self.pages.addTab(self.control_scroll, 'Управление Lock-in')
        self.pages.addTab(self.journal_page, 'Журнал')
        self.setCentralWidget(self.pages)
        # Show the first channel on all four readout cards by default.
        for (selector, _, _), index in zip(self.reading_controls, (0, 1, 2, 3)):
            selector.setCurrentIndex(index)
        self.mag_thread = QThread(self)
        self.mag_worker = MagnetWorker(args.demo, self.plant)
        self.mag_worker.moveToThread(self.mag_thread)
        self.mag_request.connect(self.mag_worker.execute, Qt.QueuedConnection)
        self.mag_shutdown.connect(self.mag_worker.shutdown, Qt.QueuedConnection)
        self.mag_worker.state_changed.connect(self.magnet_state)
        self.mag_worker.completed.connect(self.magnet_completed)
        self.mag_worker.logged.connect(self.journal_line)
        self.mag_worker.stopped.connect(self.mag_thread.quit)
        self.mag_thread.finished.connect(self.mag_worker.deleteLater)
        self.mag_thread.start()
        self.mag_port = Port(self.mag_worker)
        self.lockin_port = Port(self.worker)
        self.worker.connection_changed.connect(self.lockin_connection_changed)
        self.live_timer = QTimer(self)
        self.live_timer.setInterval(100)
        self.live_timer.timeout.connect(self.refresh_dashboard)
        self.live_timer.start()
        self.update_enabled()
        self.journal_line('ДЕМО: оборудование не открывается.' if args.demo else 'Ожидание подключения приборов. Выходы не включены.')

    def number(self, key, value, low, high, decimals=3):
        w = QDoubleSpinBox()
        w.setDecimals(decimals)
        w.setRange(low, high)
        try:
            w.setValue(float(self.settings.value('defaults/' + key, value)))
        except (TypeError, ValueError):
            w.setValue(value)
        w.setKeyboardTracking(False)
        w.setMinimumHeight(31)
        w.setContextMenuPolicy(Qt.NoContextMenu)
        w.lineEdit().setContextMenuPolicy(Qt.NoContextMenu)
        self.default_fields[key] = w
        return w

    def save_defaults(self):
        try:
            for field in self.default_fields.values():
                field.interpretText()
            self.calibration().validate()
            for key, field in self.default_fields.items():
                self.settings.setValue('defaults/' + key, field.value())
            self.settings.setValue('defaults/measurement_mode', self.measurement_mode.currentIndex())
            self.settings.setValue('defaults/zero_after', self.after_measurement.currentData())
            self.settings.sync()
            if self.settings.status() != QSettings.NoError:
                raise OSError('Не удалось записать настройки пользователя.')
            self.defaults_status.setText('Значения по умолчанию сохранены.')
            self.journal_line('Сохранены параметры формы по умолчанию. Уставки приборов не менялись.')
        except Exception as exc:
            self.defaults_status.setText('Не удалось сохранить: ' + str(exc))
            self.journal_line(self.defaults_status.text())

    @staticmethod
    def group(parent, title):
        box = QGroupBox(title)
        form = QFormLayout(box)
        form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        form.setSpacing(8)
        parent.addWidget(box)
        return box, form

    def build_dashboard(self):
        page = QWidget()
        outer = QVBoxLayout(page)
        title = QLabel('MAGNETIC FIELD  /  LOCK-IN MEASUREMENTS' + ('  ·  DEMO' if self.args.demo else ''))
        title.setStyleSheet('font-size:20px; font-weight:600; color:#15596c; padding:5px;')
        header = QHBoxLayout()
        header.addWidget(title, 1)
        self.save_defaults_button = QPushButton('Сохранить значения по умолчанию')
        self.save_defaults_button.setToolTip('Сохранить числовые параметры формы, режим измерения и действие после завершения для следующих запусков. Команды приборам не отправляются.')
        self.save_defaults_button.clicked.connect(self.save_defaults)
        header.addWidget(self.save_defaults_button)
        outer.addLayout(header)
        split = QSplitter(Qt.Horizontal)
        outer.addWidget(split, 1)
        side = QWidget()
        side_layout = QVBoxLayout(side)
        side_layout.setContentsMargins(0, 0, 0, 0)
        actions = QGroupBox('Управление измерением')
        action_layout = QVBoxLayout(actions)
        self.run_button = QPushButton('▶ Старт измерения')
        self.run_button.setMinimumHeight(39)
        self.run_button.setStyleSheet('background:#176f89; color:white; font-weight:600;')
        self.stop_run_button = QPushButton('■ Стоп · сохранить и обнулить ток')
        self.stop_run_button.setMinimumHeight(37)
        self.run_button.clicked.connect(self.start_experiment)
        self.stop_run_button.clicked.connect(self.stop_experiment)
        action_layout.addWidget(self.run_button)
        action_layout.addWidget(self.stop_run_button)
        self.progress = QProgressBar()
        self.progress.setRange(0, 1000)
        action_layout.addWidget(self.progress)
        self.run_status = QLabel('Ожидание. Подключите Lock-in, магнит и NI.')
        self.run_status.setWordWrap(True)
        self.run_status.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.run_status.setMaximumHeight(100)
        action_layout.addWidget(self.run_status)
        side_layout.addWidget(actions)
        scroll, left = QScrollArea(), QWidget()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setWidget(left)
        scroll.setMinimumWidth(470)
        controls = QVBoxLayout(left)
        controls.setContentsMargins(5, 2, 12, 5)
        _, form = self.group(controls, 'Приборы')
        self.lockin_shortcut = QPushButton('Подключить Lock-in по USB')
        self.lockin_shortcut.clicked.connect(lambda: self.submit('open'))
        form.addRow(self.lockin_shortcut)
        self.lockin_state_label = QLabel('Lock-in: не подключён')
        self.lockin_state_label.setWordWrap(True)
        form.addRow(self.lockin_state_label)
        row = QHBoxLayout()
        self.com = QComboBox()
        self.com.setEditable(True)
        ports = [p.device for p in list_ports.comports()]
        self.com.addItems(ports or ['COM11'])
        self.com.setCurrentText(str(self.settings.value('magnet/port', 'COM11')))
        self.mag_connect = QPushButton('Подключить магнит')
        self.mag_connect.clicked.connect(self.toggle_magnet)
        row.addWidget(self.com, 1)
        row.addWidget(self.mag_connect)
        form.addRow(row)
        self.mag_label = QLabel('Магнит: не подключён')
        self.mag_label.setWordWrap(True)
        form.addRow(self.mag_label)
        self.device = QLineEdit(str(self.settings.value('ni/device', 'Dev1')))
        self.ni_connect = QPushButton('Читать AI3 · Diff')
        self.ni_connect.clicked.connect(self.toggle_ni)
        form.addRow('Имя устройства NI MAX', self.device)
        form.addRow(self.ni_connect)
        self.ni_label = QLabel('NI: не подключена')
        self.ni_label.setWordWrap(True)
        form.addRow(self.ni_label)
        _, form = self.group(controls, 'Магнит · ручное управление')
        self.manual_current = self.number('manual_current_A', 1, 0, 10, 3)
        form.addRow('Величина тока, A', self.manual_current)
        self.voltage = self.number('voltage_V', 5, .001, 60, 3)
        form.addRow('Предел напряжения, V', self.voltage)
        self.mag_set = QPushButton('Установить ток')
        self.mag_flip = QPushButton('Сменить полярность · оставить I = 0')
        self.mag_flip_start = QPushButton('Сменить полярность и подать ток')
        self.mag_zero = QPushButton('Обнулить ток и выключить выход')
        self.mag_zero.setStyleSheet('color:#a62c40; font-weight:600;')
        self.mag_set.clicked.connect(lambda: self.manual_magnet('set_current'))
        self.mag_flip.clicked.connect(lambda: self.manual_magnet('flip'))
        self.mag_flip_start.clicked.connect(lambda: self.manual_magnet('flip_start'))
        self.mag_zero.clicked.connect(self.zero_magnet)
        for button in (self.mag_set, self.mag_flip, self.mag_flip_start, self.mag_zero):
            form.addRow(button)
        hint = QLabel('Смена знака: PC 0 → OUT OFF → проверка тока → H/X.\n'
                      'После подключения первая уставка задаёт положительную полярность.')
        hint.setWordWrap(True)
        hint.setStyleSheet('color:#64748b; font-size:11px;')
        form.addRow(hint)
        _, form = self.group(controls, 'Магнитное поле с AI3+ / AI3−')
        self.field_value = QLabel('— mT')
        self.field_value.setStyleSheet('font-size:30px; font-weight:600; color:#126879;')
        self.field_value.setTextInteractionFlags(Qt.TextSelectableByMouse)
        form.addRow(self.field_value)
        self.average = self.number('field_average_s', 1, .1, 60, 2)
        self.slope = self.number('calibration_slope', 1, -1e6, 1e6, 6)
        self.offset = self.number('calibration_offset', 0, -1e6, 1e6, 6)
        form.addRow('Усреднение индикатора, s', self.average)
        form.addRow('Наклон k, mT/mV', self.slope)
        form.addRow('Сдвиг b, mT', self.offset)
        label = QLabel('B (mT) = k · U (mV) + b\n'
                       'k=1 и b=0 — начальные значения, задайте калибровку датчика.')
        label.setWordWrap(True)
        label.setStyleSheet('color:#64748b; font-size:11px;')
        form.addRow(label)
        self.defaults_status = QLabel('Кнопка вверху сохраняет числовые параметры всей формы.')
        self.defaults_status.setWordWrap(True)
        self.defaults_status.setStyleSheet('color:#64748b; font-size:11px;')
        form.addRow(self.defaults_status)
        self.scan_box, form = self.group(controls, 'Измерение')
        self.measurement_mode = QComboBox()
        self.measurement_mode.addItems(['Проход по току', 'Одно измерение · ток не менять'])
        self.measurement_mode.setCurrentIndex(int(self.settings.value('defaults/measurement_mode', 0)))
        form.addRow(self.measurement_mode)
        self.current_start = self.number('start_A', -1, -10, 10, 3)
        self.current_stop = self.number('stop_A', 1, -10, 10, 3)
        self.intervals = QSpinBox()
        self.intervals.setRange(1, 10000)
        self.intervals.setValue(int(self.settings.value('defaults/intervals', 10)))
        self.intervals.setContextMenuPolicy(Qt.NoContextMenu)
        self.intervals.lineEdit().setContextMenuPolicy(Qt.NoContextMenu)
        self.default_fields['intervals'] = self.intervals
        form.addRow('Начальный ток, A', self.current_start)
        form.addRow('Конечный ток, A', self.current_stop)
        form.addRow('Шагов между краями', self.intervals)
        self.grid_info = QLabel()
        self.grid_info.setWordWrap(True)
        form.addRow(self.grid_info)
        for w in (self.current_start, self.current_stop, self.intervals):
            w.valueChanged.connect(self.grid_changed)
        self.measurement_mode.currentIndexChanged.connect(self.grid_changed)
        self.duration = self.number('duration_s', 10, .1, 86400, 2)
        self.sample_delay = self.number('sample_period_ms', 100, 10, 60000, 1)
        self.settle = self.number('settle_s', 1, 0, 3600, 2)
        form.addRow('Acquisition time, s', self.duration)
        form.addRow('Delay отсчётов, ms', self.sample_delay)
        form.addRow('Задержка после тока, s', self.settle)
        self.after_measurement = QComboBox()
        self.after_measurement.addItem('Обнулить ток и выключить выход', True)
        self.after_measurement.addItem('Оставить конечную уставку', False)
        self.after_measurement.setCurrentIndex(0 if self.settings.value('defaults/zero_after', True, type=bool) else 1)
        form.addRow(QLabel('После успешного измерения:'))
        form.addRow(self.after_measurement)
        after_hint = QLabel('При Stop, ошибке и закрытии программы ток обнуляется.')
        after_hint.setWordWrap(True)
        after_hint.setStyleSheet('color:#64748b; font-size:11px;')
        form.addRow(after_hint)
        self.after_measurement.currentIndexChanged.connect(self.grid_changed)
        _, form = self.group(controls, 'Данные и комментарии')
        self.sig = self.number('sig_mV', 200, -1e9, 1e9, 3)
        self.bal = self.number('bal_mV', -200, -1e9, 1e9, 3)
        self.e_field = QLineEdit()
        self.additional = QPlainTextEdit()
        self.additional.setMaximumHeight(75)
        self.additional.setPlaceholderText('Образец, температура, параметры опыта…')
        form.addRow('Sig, mV', self.sig)
        form.addRow('Bal, mV', self.bal)
        form.addRow('E field', self.e_field)
        form.addRow('Additional', self.additional)
        self.session_name = QLineEdit('measurement')
        form.addRow('Имя папки опыта', self.session_name)
        default_folder = str(Path(QStandardPaths.writableLocation(QStandardPaths.DocumentsLocation)) / 'MagneticLab' / 'data')
        self.folder = QLineEdit(str(self.settings.value('data/folder', default_folder)))
        browse = QPushButton('…')
        browse.setMaximumWidth(35)
        browse.clicked.connect(self.choose_folder)
        row = QHBoxLayout()
        row.addWidget(self.folder)
        row.addWidget(browse)
        form.addRow('Сохранение', row)
        self.data_box = form.parentWidget()
        controls.addStretch()
        self.point_status = QLabel('Поле точки усредняется по времени измерения.')
        self.point_status.setWordWrap(True)
        controls.insertWidget(0, self.point_status)
        self.recover_button = QPushButton('Сохранить несохранённую точку…')
        self.recover_button.clicked.connect(self.recover_point)
        self.recover_button.hide()
        controls.insertWidget(1, self.recover_button)
        side_layout.addWidget(scroll, 1)
        split.addWidget(side)
        right = QWidget()
        view = QVBoxLayout(right)
        view.setContentsMargins(8, 0, 0, 0)
        cards = QHBoxLayout()
        self.amplitude_value, self.phase_value = QLabel('—'), QLabel('—')
        for title, widget in [('Амплитуда R1', self.amplitude_value), ('Фаза φ1', self.phase_value)]:
            box = QGroupBox(title)
            row = QVBoxLayout(box)
            widget.setStyleSheet('color:#15596c; font-size:28px; font-weight:600;')
            row.addWidget(widget)
            cards.addWidget(box)
        view.addLayout(cards)
        pg.setConfigOptions(antialias=False)
        plots = QGridLayout()
        self.plot_widgets, self.curves = [], []
        for i, (title, x, y, units, color) in enumerate([
            ('Амплитуда · текущая точка', 'Время, s', 'R1', 'V', '#14798c'),
            ('Фаза · текущая точка', 'Время, s', 'φ1', 'deg', '#8c549f'),
            ('Амплитуда от магнитного поля', 'Поле, mT', 'Средняя R1', 'V', '#14798c'),
            ('Фаза от магнитного поля', 'Поле, mT', 'Средняя φ1', 'deg', '#8c549f')]):
            graph = pg.PlotWidget(background='w')
            graph.setTitle(title, color='#31566a', size='12pt')
            graph.setLabel('bottom', x)
            graph.setLabel('left', y, units=units)
            graph.showGrid(x=True, y=True, alpha=.2)
            for side in ('left', 'bottom'):
                graph.getAxis(side).setPen('#52677a')
                graph.getAxis(side).setTextPen('#52677a')
            graph.setMinimumSize(180, 150)
            curve = graph.plot(pen=pg.mkPen(color, width=1.3) if i in (0, 2) else None,
                               symbol='o', symbolSize=4 if i < 2 else 7,
                               symbolBrush=color, symbolPen=None)
            curve.setClipToView(True)
            if i in (1, 3):
                graph.setYRange(0, 360, padding=.025)
                graph.enableAutoRange(axis='y', enable=False)
            self.plot_widgets.append(graph)
            self.curves.append(curve)
            plots.addWidget(graph, i // 2, i % 2)
        view.addLayout(plots, 1)
        self.journal_page = QWidget()
        journal_layout = QVBoxLayout(self.journal_page)
        self.journal = QPlainTextEdit()
        self.journal.setReadOnly(True)
        self.journal.setMaximumBlockCount(1500)
        journal_layout.addWidget(self.journal, 1)
        log_button = QPushButton('Сохранить журнал…')
        log_button.clicked.connect(self.save_journal)
        journal_layout.addWidget(log_button)
        split.addWidget(right)
        split.setSizes([475, 1020])
        self.grid_changed()
        return page

    def grid_changed(self):
        n = self.intervals.value()
        step = (self.current_stop.value() - self.current_start.value()) / n
        sweep = self.measurement_mode.currentIndex() == 0
        self.grid_info.setText(f'{n + 1} точек, ΔI = {step:+.5g} A. Края включены.' if sweep else 'Измерение при текущем токе. Действие после завершения выбирается ниже.')
        for w in (self.current_start, self.current_stop, self.intervals):
            w.setEnabled(sweep and self.exclusive == 'idle')

    def calibration(self):
        result = Calibration(self.slope.value(), self.offset.value())
        result.validate()
        return result

    def journal_line(self, text):
        if not hasattr(self, 'journal'):
            return
        self.journal.appendPlainText(f'{datetime.now().astimezone().isoformat(timespec="milliseconds")}  {text}')

    def choose_folder(self):
        path = QFileDialog.getExistingDirectory(self, 'Папка сохранения', self.folder.text())
        if path:
            self.folder.setText(path)

    def save_journal(self):
        path, _ = QFileDialog.getSaveFileName(self, 'Сохранить журнал', 'MagneticLab_log.txt', 'Текст (*.txt)')
        if path:
            try:
                Path(path).write_text(self.journal.toPlainText() + '\n\nLOCK-IN:\n' + self.log.toPlainText(), encoding='utf-8')
            except OSError as exc:
                self.run_status.setText(str(exc))

    def toggle_magnet(self):
        if self.mag_busy or self.exclusive != 'idle':
            return
        self.mag_busy = True
        if self.mag_state['connected']:
            self.mag_request.emit('close', {})
        else:
            self.mag_request.emit('open', {'port': self.com.currentText(), 'baud': 9600, 'address': 6})
        self.update_enabled()

    def manual_magnet(self, operation):
        if self.mag_busy or self.exclusive != 'idle':
            return
        self.mag_busy = True
        sign = self.mag_state.get('polarity') or 1
        value = self.manual_current.value()
        data = {'current': value * sign if operation == 'set_current' else value, 'voltage': self.voltage.value()}
        self.mag_request.emit(operation, data)
        self.update_enabled()

    def zero_magnet(self):
        if self.runner is not None and self.runner.isRunning():
            self.runner.stop()
        self.mag_request.emit('zero', {})
        self.mag_busy = True
        self.update_enabled()

    def magnet_state(self, state):
        self.mag_state = state
        port = (state.get('connection') or {}).get('source_port')
        if port:
            self.com.setCurrentText(port)
        sign = '+' if state['polarity'] == 1 else '−' if state['polarity'] == -1 else '?'
        values = state['values']
        current = state.get('signed_current_A')
        text = f'{current:+.4f} A' if current is not None else f"{values.get('MC?', 0):.4f} A (знак неизвестен)"
        self.mag_label.setText(f"{text} · OUT {'ON' if values.get('OUT?') else 'OFF'}\nПолярность по команде: {sign}" if state['connected'] else 'Магнит: не подключён')
        self.update_enabled()

    def magnet_completed(self, operation, success, message):
        self.mag_busy = False
        if operation == 'open' and success:
            voltage = self.mag_state['values'].get('PV?', 0)
            if voltage > 0 and not self.settings.contains('defaults/voltage_V'):
                self.voltage.setValue(voltage)
            self.settings.setValue('magnet/port', self.com.currentText())
        self.journal_line(message)
        if not success:
            self.run_status.setText(message)
        self.update_enabled()

    def toggle_ni(self):
        if self.field_reader is not None and self.field_reader.isRunning():
            self.field_reader.stop()
            return
        config = Config(device=self.device.text().strip(), rate=1000, voltage_range=10,
                        window_seconds=10, demo=self.args.demo)
        try:
            config.validate()
        except ValueError as exc:
            self.run_status.setText(str(exc))
            return
        self.ni_label.setText('NI: запуск…')
        self.field_reader = FieldReader(config, self.field_data, self.plant, self)
        self.field_reader.configured.connect(self.ni_configured)
        self.field_reader.failed.connect(self.ni_failed)
        self.field_reader.diagnostic.connect(self.journal_line)
        self.field_reader.finished.connect(self.ni_finished)
        self.field_reader.start()
        self.settings.setValue('ni/device', self.device.text())
        self.update_enabled()

    def ni_configured(self, info):
        self.ni_label.setText(f"{'DEMO' if info.get('demo') else info['physical_channel']} · Diff · {info['sample_rate_Hz']:g} S/s")
        self.journal_line('NI готова: ' + str(info))
        self.update_enabled()

    def ni_failed(self, error):
        self.ni_label.setText('NI: ожидание переподключения · ' + error)
        self.journal_line('NI: ' + error)

    def lockin_connection_changed(self, ready, message):
        self.connected = ready
        self.connection_label.setText(message)
        self.journal_line(message)
        if ready:
            self.refresh()
        self.update_enabled()

    def reconnecting(self, event):
        self.journal_line(f"Переподключение {event['device']}: {event['state']} · {event['detail']}")

    def ni_finished(self):
        self.field_value.setText('— mT')
        self.update_enabled()

    def parameters(self):
        return Experiment(mode='sweep' if self.measurement_mode.currentIndex() == 0 else 'single',
            start_A=self.current_start.value(), stop_A=self.current_stop.value(), intervals=self.intervals.value(),
            acquisition_s=self.duration.value(), period_ms=self.sample_delay.value(), settle_s=self.settle.value(),
            voltage_V=self.voltage.value(), sig_mV=self.sig.value(), bal_mV=self.bal.value(),
            e_field=self.e_field.text(), additional=self.additional.toPlainText(),
            folder=self.folder.text(), name=self.session_name.text(), zero_after=self.after_measurement.currentData())

    def start_experiment(self):
        if self.exclusive != 'idle' or self.want_close:
            return
        try:
            self.frozen_parameters = self.parameters()
            self.frozen_parameters.validate()
            self.frozen_calibration = self.calibration()
            if not self.connected or not self.field_data.ready:
                raise ValueError('Подключите Lock-in и запустите чтение NI.')
            if self.frozen_parameters.mode == 'sweep' and not self.mag_state['identified']:
                raise ValueError('Для прохода подключите магнит.')
            if self.mag_busy:
                raise ValueError('Дождитесь завершения команды магнита.')
        except Exception as exc:
            self.run_status.setText(str(exc))
            return
        self.exclusive = 'draining'
        self.poll_timer.stop()
        self.control_page.setEnabled(False)
        self.run_status.setText('Завершение текущих USB-команд перед измерением…')
        self.update_enabled()
        self.dispatch_next()

    def dispatch_next(self):
        if self.exclusive == 'running':
            return
        super().dispatch_next()
        if (self.exclusive == 'draining' and not self.busy and not self.pending_jobs
                and not self.pending_edits and not self.edit_timer.isActive()):
            self.exclusive = 'running'
            self.pending_launch = True
            QTimer.singleShot(0, self.launch_experiment)

    def launch_experiment(self):
        if not self.pending_launch or self.exclusive != 'running':
            return
        self.pending_launch = False
        if self.want_close or not self.connected:
            self.exclusive = 'idle'
            self.update_enabled()
            return
        self.points = []
        self.live_rows.clear()
        self.graph_version += 1
        self.progress.setValue(0)
        self.recover_button.hide()
        self.runner = ExperimentRunner(self.frozen_parameters, self.frozen_calibration,
            self.lockin_port, self.mag_port, self.field_data, self.mag_state['connected'], self.args.demo, self)
        self.runner.changed.connect(self.run_status.setText)
        self.runner.log.connect(self.journal_line)
        self.runner.point_started.connect(self.point_started)
        self.runner.samples.connect(self.receive_samples)
        self.runner.point_ready.connect(self.receive_point)
        self.runner.prepared.connect(self.lockin_prepared)
        self.runner.recovering.connect(self.reconnecting)
        self.runner.outcome.connect(self.experiment_outcome)
        self.runner.finished.connect(self.experiment_thread_finished)
        self.runner.start()
        self.settings.setValue('data/folder', self.folder.text())
        self.update_enabled()

    def stop_experiment(self):
        if self.exclusive == 'draining' or self.pending_launch:
            self.pending_launch = False
            self.exclusive = 'idle'
            self.run_status.setText('Запуск отменён до изменения тока.')
            self.control_page.setEnabled(True)
            self.update_enabled()
            return
        if self.runner is not None and self.runner.isRunning():
            self.runner.stop()
            self.stop_run_button.setEnabled(False)
            self.run_status.setText('Остановка, сохранение данных и обнуление тока…')

    def point_started(self, index, total):
        self.live_rows.clear()
        self.graph_version += 1
        self.point_start_clock = time.perf_counter()
        self.point_index, self.point_total = index, total

    def lockin_prepared(self, info):
        self.signal_unit = info['signal_unit']
        self.plot_widgets[0].setLabel('left', 'R1', units=self.signal_unit)
        self.plot_widgets[2].setLabel('left', 'Средняя R1', units=self.signal_unit)

    def receive_samples(self, rows):
        self.live_rows.extend(rows)
        self.graph_version += 1
        if rows:
            self.amplitude_value.setText(engineering(rows[-1][4], self.signal_unit))
            self.phase_value.setText(f'{rows[-1][5]:.3f}°')

    def receive_point(self, point):
        self.points.append(point)
        self.signal_unit = point['lockin']['signal_unit']
        self.plot_widgets[0].setLabel('left', 'R1', units=self.signal_unit)
        self.plot_widgets[2].setLabel('left', 'Средняя R1', units=self.signal_unit)
        stats, field = point['statistics'], point['field']
        phase = stats.get('phase_mean_deg')
        field_value = field.get('field_mean_mT')
        self.point_status.setText(f"Точка {point['index']}: B = {field_value:.7g} mT; "
            f"⟨R⟩ = {engineering(stats['amplitude_mean'], self.signal_unit) if stats['amplitude_mean'] is not None else '—'}; "
            f"⟨φ⟩ = {f'{phase:.4g}°' if phase is not None else 'не определена'}; "
            f"Lock-in: {stats['samples']} / NI: {field['samples']} отсчётов" if field_value is not None else 'Поле точки не определено.')
        self.graph_version += 1
        self.progress.setValue(round(1000 * point['index'] / len(self.frozen_parameters.currents())))

    def experiment_outcome(self, result):
        self.last_outcome = result
        message = {'complete': 'Готово. Ток обнулён; режим ожидания.',
                   'stopped': 'Остановлено. Частичные данные сохранены; ток обнулён.',
                   'error': 'Измерение завершилось с ошибкой.'}[result['reason']]
        if result['reason'] == 'complete' and result.get('finish_action') == 'held':
            message = 'Готово. Конечная уставка сохранена; режим ожидания.'
        if not self.runner.magnet_connected:
            message = {'complete': 'Готово. Режим ожидания.',
                       'stopped': 'Остановлено. Частичные данные сохранены.',
                       'error': 'Измерение завершилось с ошибкой.'}[result['reason']]
        if result['cleanup_error']:
            message += '\nОбнуление не подтверждено: ' + result['cleanup_error']
        if result['error']:
            message += '\n' + result['error']
        if result['folder']:
            message += '\nПапка: ' + result['folder']
        self.run_status.setText(message)
        self.journal_line(message)
        self.recover_button.setVisible(result['unsaved'])

    def experiment_thread_finished(self):
        self.exclusive = 'idle'
        self.control_page.setEnabled(True)
        self.update_enabled()
        self.dispatch_next()
        if self.want_close:
            self.close()

    def recover_point(self):
        if not self.runner or not self.runner.unsaved:
            return
        target = QFileDialog.getExistingDirectory(self, 'Папка восстановления данных', self.folder.text())
        if target:
            self.recovery = Recovery(target, self.runner.unsaved, self)
            self.recovery.result.connect(self.recovery_result)
            self.recovery.start()

    def recovery_result(self, success, text):
        self.run_status.setText(('Данные восстановлены: ' if success else 'Ошибка восстановления: ') + text)
        if success:
            self.runner.unsaved = None
            self.recover_button.hide()

    def refresh_dashboard(self):
        try:
            field = self.field_data.live(self.average.value(), self.calibration())
            self.field_value.setText((f'{field:+.6f}'.rstrip('0').rstrip('.') + ' mT') if field is not None else '— mT')
        except ValueError:
            self.field_value.setText('Проверьте k и b')
        if self.graph_version != self.drawn_version:
            if self.live_rows:
                rows = np.asarray(self.live_rows)
                t, r = peak_view(rows[:, 0], rows[:, 4], 5000)
                self.curves[0].setData(t, r)
                self.curves[1].setData(rows[::max(1, len(rows)//5000), 0], rows[::max(1, len(rows)//5000), 5])
            else:
                self.curves[0].setData([], [])
                self.curves[1].setData([], [])
            points = [p for p in self.points if p['result'] == 'complete' and p['field']['valid']]
            field = [p['field']['field_mean_mT'] for p in points]
            self.curves[2].setData(field, [p['statistics']['amplitude_mean'] for p in points])
            self.curves[3].setData(field, [p['statistics']['phase_mean_deg'] if p['statistics']['phase_mean_deg'] is not None else np.nan for p in points])
            self.drawn_version = self.graph_version
        self.update_enabled()

    def update_enabled(self):
        super().update_enabled()
        if not hasattr(self, 'dashboard'):
            return
        idle = self.exclusive == 'idle' and not self.want_close
        self.control_page.setEnabled(idle)
        self.lockin_shortcut.setEnabled(idle and not self.connected and not self.busy)
        self.lockin_state_label.setText('Lock-in: подключён' if self.connected else 'Lock-in: не подключён')
        connected = self.mag_state['connected']
        self.mag_connect.setText('Отключить магнит' if connected else 'Подключить магнит')
        self.mag_connect.setEnabled(idle and not self.mag_busy)
        self.com.setEnabled(idle and not connected and not self.mag_busy)
        for w in (self.mag_set, self.mag_flip_start, self.mag_flip, self.manual_current, self.voltage):
            w.setEnabled(idle and connected and not self.mag_busy)
        if self.mag_state.get('polarity') is None:
            self.mag_flip.setText('Задать полярность − · оставить I = 0')
            self.mag_flip_start.setText('Подать ток с полярностью −')
        else:
            self.mag_flip.setText('Сменить полярность · оставить I = 0')
            self.mag_flip_start.setText('Сменить полярность и подать ток')
        self.mag_zero.setEnabled(connected and not self.want_close)
        ni_running = self.field_reader is not None and self.field_reader.isRunning()
        self.ni_connect.setText('Остановить NI' if ni_running else 'Читать AI3 · Diff')
        self.ni_connect.setEnabled(idle)
        self.device.setEnabled(idle and not ni_running)
        for w in (self.slope, self.offset, self.scan_box, self.data_box, self.save_defaults_button):
            w.setEnabled(idle)
        self.run_button.setEnabled(idle and self.connected and self.field_data.ready and not self.mag_busy
            and (self.measurement_mode.currentIndex() == 1 or self.mag_state['identified']) and not (self.runner and self.runner.unsaved))
        self.stop_run_button.setEnabled(self.exclusive != 'idle' and not self.want_close)

    def schedule_poll(self, *unused):
        if self.exclusive != 'idle' or self.want_close:
            self.poll_timer.stop()
            return
        super().schedule_poll(*unused)

    @pyqtSlot(str, object)
    def on_result(self, job, data):
        if job == 'apply' and self.exclusive == 'draining' and any(v.get('error') for v in data.values()):
            self.exclusive = 'idle'
            self.run_status.setText('Старт отменён: Lock-in отклонил настройку. Проверьте журнал.')
        super().on_result(job, data)
        if job == 'poll' and hasattr(self, 'amplitude_value') and self.exclusive == 'idle':
            xy = data.get('channel1_xy')
            if xy:
                x, y = xy['x'], xy['y']
                if self.args.demo:
                    current, t = self.plant.get_current(), time.perf_counter()
                    amp = 12e-6 * (1 + .35 * math.sin(current * 1.2))
                    phi = math.radians(165 + 24 * current)
                    x, y = amp * math.cos(phi) + .25e-6 * math.sin(t * 71), amp * math.sin(phi) + .25e-6 * math.cos(t * 47)
                self.amplitude_value.setText(engineering(math.hypot(x, y), xy['unit']))
                phase = math.degrees(math.atan2(y, x)) % 360 if x or y else None
                self.phase_value.setText(f'{phase:.3f}°' if phase is not None else '—')

    def closeEvent(self, event):
        self.want_close = True
        if self.runner is not None and self.runner.isRunning():
            event.ignore()
            self.runner.stop()
            return
        if self.recovery is not None and self.recovery.isRunning():
            event.ignore()
            QTimer.singleShot(100, self.close)
            return
        if self.runner and self.runner.unsaved:
            event.ignore()
            self.want_close = False
            self.run_status.setText('Сначала сохраните несохранённую точку кнопкой восстановления.')
            return
        if not self.services_shutdown:
            self.services_shutdown = True
            if self.field_reader is not None:
                self.field_reader.stop()
            self.mag_shutdown.emit()
            self.run_status.setText('Закрытие: обнуление магнита и завершение чтения NI…')
        if self.mag_thread.isRunning() or (self.field_reader is not None and self.field_reader.isRunning()):
            event.ignore()
            QTimer.singleShot(100, self.close)
            return
        if hasattr(self, 'live_timer'):
            self.live_timer.stop()
        super().closeEvent(event)
