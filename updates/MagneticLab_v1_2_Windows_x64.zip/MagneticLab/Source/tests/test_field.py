import threading
import time
import unittest

import numpy as np

from field_data import FieldData
from models import Calibration


class FieldTests(unittest.TestCase):
    def setUp(self):
        self.data = FieldData()
        self.origin = time.perf_counter() - 2
        self.data.configure({'sample_rate_Hz': 10})
        self.data.append(0, 10, self.origin, np.zeros(5))

    def test_capture_clips_boundaries_and_is_sample_weighted(self):
        self.data.begin(self.origin + .5, self.origin + 1.0)
        self.data.append(5, 10, self.origin, np.array([1, 2, 3, 4, 5, 999]))
        result = self.data.finish(self.origin + 1, Calibration(.001, 2), timeout=0)
        self.assertTrue(result['valid'])
        self.assertEqual(result['samples'], 5)
        self.assertAlmostEqual(result['mean_voltage_V'], 3)
        self.assertAlmostEqual(result['field_mean_mT'], 5)

    def test_missing_ni_window_is_not_a_valid_field_point(self):
        self.data.begin(self.origin + .5, self.origin + 1)
        self.data.fail('USB lost')
        result = self.data.finish(self.origin + 1, Calibration(), timeout=0)
        self.assertFalse(result['valid'])
        self.assertIn('USB lost', result['error'])

    def test_live_window_and_capture_window_are_independent(self):
        self.data.begin(self.origin + .5, self.origin + 1)
        self.data.append(5, 10, self.origin, np.arange(1, 12, dtype=float))
        result = self.data.finish(self.origin + 1, Calibration(.001), timeout=0)
        self.assertAlmostEqual(result['field_mean_mT'], 3)
        live = self.data.live(.2, Calibration(.001))
        self.assertGreater(live, 9)


if __name__ == '__main__':
    unittest.main()
