import tempfile
import unittest

from models import Calibration, Experiment, phase_deg, signal_statistics


class ModelsTests(unittest.TestCase):
    def test_millivolts_to_millitesla(self):
        self.assertAlmostEqual(float(Calibration(2.5, -3).field(.004)), 7)

    def test_phase_is_modulo_and_zero_vector_is_undefined(self):
        self.assertAlmostEqual(phase_deg(0, -1), 270)
        self.assertAlmostEqual(phase_deg(1, 0), 0)
        import math
        self.assertTrue(math.isnan(phase_deg(0, 0)))

    def test_phase_averaging_across_zero_and_amplitude_average(self):
        rows = [(0, 0, 1, 0, 2, 359, 0, 0), (1, 1, -1, 0, 4, 1, 0, 0)]
        stats = signal_statistics(rows)
        self.assertAlmostEqual(stats['phase_mean_deg'], 0)
        self.assertEqual(stats['amplitude_mean'], 3)
        self.assertEqual(stats['x1_mean'], 0)

    def test_opposite_phases_have_no_mean(self):
        rows = [(0, 0, 1, 0, 1, 0, 0, 0), (1, 1, -1, 0, 1, 180, 0, 0)]
        self.assertIsNone(signal_statistics(rows)['phase_mean_deg'])

    def test_grid_includes_endpoints_and_zero_and_descends(self):
        e = Experiment(start_A=-5, stop_A=5, intervals=2)
        self.assertEqual(e.currents(), [-5, 0, 5])
        self.assertEqual(Experiment(start_A=5, stop_A=-5, intervals=2).currents(), [5, 0, -5])
        self.assertEqual(len(Experiment(intervals=7).currents()), 8)

    def test_invalid_settings_refused_before_instrument_writes(self):
        with self.assertRaises(ValueError):
            Experiment(start_A=11, folder='/tmp').validate()
        with self.assertRaises(ValueError):
            Calibration(0, 0).validate()


if __name__ == '__main__':
    unittest.main()
