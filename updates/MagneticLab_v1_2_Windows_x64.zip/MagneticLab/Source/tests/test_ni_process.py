import os
import threading
import time
import unittest

from ni_input.core import Config
from ni_input.daq_process import NIProcessInput, RemoteDAQError


def failed_native_call(connection, stop, config):
    connection.send(('log', 'Task.start / DAQmxStartTask'))
    connection.send(('failure', {'stage': 'Task.start / DAQmxStartTask',
        'message': 'OSError: access violation reading 0x0000000000000000',
        'traceback': 'Traceback: simulated native failure'}))
    connection.close()


def stalled_native_call(connection, stop, config):
    connection.send(('log', 'Task.start / DAQmxStartTask'))
    time.sleep(60)  # Simulate a native call that cannot observe the Stop event.


def crashed_native_call(connection, stop, config):
    connection.send(('log', 'Task() / DAQmxCreateTask'))
    os._exit(23)


class ProcessTests(unittest.TestCase):
    def test_spawn_reads_demo_blocks_without_qt_and_joins(self):
        source = NIProcessInput()
        try:
            info = source.open(Config(demo=True))
            self.assertTrue(info['demo'])
            values = source.read(threading.Event())
            self.assertEqual(len(values), 100)
        finally:
            process = source.process
            source.close()
        self.assertFalse(process.is_alive())

    def test_native_exception_keeps_traceback_and_stage(self):
        journal = []
        source = NIProcessInput(target=failed_native_call, progress=journal.append)
        try:
            with self.assertRaisesRegex(RemoteDAQError, 'DAQmxStartTask'):
                source.open(Config())
            self.assertTrue(any('simulated native failure' in text for text in journal))
        finally:
            source.close()

    def test_native_hang_has_bounded_wait_and_stop(self):
        source = NIProcessInput(target=stalled_native_call, startup_timeout=2, shutdown_timeout=0.2)
        before = time.monotonic()
        try:
            with self.assertRaisesRegex(RemoteDAQError, 'DAQmxStartTask'):
                source.open(Config())
        finally:
            process = source.process
            source.close()
        self.assertFalse(process.is_alive())
        self.assertLess(time.monotonic() - before, 6)

    def test_child_crash_reports_exit_code_instead_of_hanging(self):
        source = NIProcessInput(target=crashed_native_call)
        try:
            with self.assertRaisesRegex(RemoteDAQError, '23'):
                source.open(Config())
        finally:
            source.close()

    def test_cancel_during_start_is_observed(self):
        stop = threading.Event()
        stop.set()
        source = NIProcessInput(target=stalled_native_call, cancel=stop)
        try:
            with self.assertRaises(InterruptedError):
                source.open(Config())
        finally:
            source.close()


if __name__ == '__main__':
    unittest.main()
