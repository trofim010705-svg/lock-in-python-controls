"""Симулятор последовательного интерфейса, реальное оборудование не открывается."""
import time


class DemoSerial:
    def __init__(self, port, baudrate):
        self.port = port
        self.baudrate = baudrate
        self.current = self.voltage = 0.0
        self.on = False
        self.selected = False
        self.buffer = bytearray()
        self.writes = []
        self.is_open = True

    @property
    def in_waiting(self):
        return len(self.buffer)

    def close(self):
        self.is_open = False

    def read(self, count=1):
        if not self.buffer:
            time.sleep(0.002)
        result = bytes(self.buffer[:count])
        del self.buffer[:count]
        return result

    def write(self, data):
        self.writes.append(data)
        command = data.decode('ascii').rstrip('\r')
        answer = None
        if command.startswith('ADR '):
            self.selected = int(command[4:]) == 6
            if self.selected:
                answer = 'OK'
        elif command in ('H', 'X'):
            pass  # У реле намеренно нет фиктивного подтверждения положения.
        elif self.selected:
            replies = {'IDN?': 'LAMBDA, GEN60-40', 'REV?': 'DEMO 1.0', 'SN?': 'DEMO',
                       'MC?': f'{self.current if self.on else 0:.6f}',
                       'MV?': f'{self.voltage if self.on else 0:.6f}',
                       'PC?': f'{self.current:.6f}', 'PV?': f'{self.voltage:.6f}',
                       'OUT?': 'ON' if self.on else 'OFF'}
            if command in replies:
                answer = replies[command]
            elif command.startswith('PC '):
                self.current = float(command[3:]); answer = 'OK'
            elif command.startswith('PV '):
                self.voltage = float(command[3:]); answer = 'OK'
            elif command in ('OUT 1', 'OUT 0'):
                self.on = command == 'OUT 1'; answer = 'OK'
            else:
                answer = 'C01'
        if answer is not None:
            self.buffer.extend(answer.encode('ascii') + b'\r\n')
        return len(data)
