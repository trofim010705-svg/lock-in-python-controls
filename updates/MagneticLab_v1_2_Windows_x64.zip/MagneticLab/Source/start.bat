@echo off
setlocal
cd /d "%~dp0"
if exist "venv\Scripts\python.exe" goto dependencies
py -3.11 --version >nul 2>&1
if errorlevel 1 goto default_python
py -3.11 -m venv venv
goto check_venv
:default_python
python -m venv venv
:check_venv
if not exist "venv\Scripts\python.exe" goto failed
:dependencies
"venv\Scripts\python.exe" -c "import PyQt5.QtWidgets, pyvisa, serial, numpy, pyqtgraph, nidaqmx, matplotlib" >nul 2>&1
if not errorlevel 1 goto run
"venv\Scripts\python.exe" -m pip install --only-binary=:all: -r requirements.txt
if errorlevel 1 goto failed
:run
"venv\Scripts\python.exe" app.py %*
if errorlevel 1 goto failed
exit /b 0
:failed
echo.
echo See the error above and README_RU.md. Python 3.11 x64 is recommended.
pause
exit /b 1
