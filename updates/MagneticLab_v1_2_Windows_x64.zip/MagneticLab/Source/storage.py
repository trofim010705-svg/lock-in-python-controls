"""Origin-compatible tabular files, readable metadata, recoverable partial runs."""
from datetime import datetime
import json
import math
import os
from pathlib import Path
import re
import tempfile

import numpy as np


def now():
    return datetime.now().astimezone().isoformat(timespec='milliseconds')


def clean_json(value):
    if isinstance(value, dict):
        return {str(k): clean_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean_json(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def atomic_text(path, text):
    path = Path(path)
    handle, temporary = tempfile.mkstemp(prefix='.' + path.name, dir=path.parent)
    try:
        with os.fdopen(handle, 'w', encoding='utf-8', newline='\n') as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def metadata(path, values):
    atomic_text(path, json.dumps(clean_json(values), ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def create_folder(parent, name):
    safe = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name).strip(' .')[:80] or 'measurement'
    folder = Path(parent).expanduser().resolve() / f'{safe}_{datetime.now():%Y%m%d_%H%M%S_%f}'
    folder.mkdir(parents=True, exist_ok=False)
    return folder


def save_point(folder, rows, point):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    unit = point['lockin']['signal_unit']
    field = point['field'].get('field_mean_mT')
    lines = [f'Time_start_s\tTime_end_s\tX1_{unit}\tY1_{unit}\tAmplitude_{unit}\tPhase_deg\tStatus\tOverload\tField_mean_mT']
    for row in rows:
        lines.append('\t'.join(f'{v:.12g}' for v in (*row, field if field is not None else float('nan'))))
    atomic_text(folder / 'signal.dat', '\n'.join(lines) + '\n')
    metadata(folder / 'parameters.txt', point)


def save_summary(folder, points, info):
    unit = info.get('lockin', {}).get('signal_unit', 'V')
    headers = ['Point', 'Current_set_A', 'Current_measured_A', 'Field_mean_mT',
               f'Amplitude_mean_{unit}', 'Phase_mean_deg', f'Amplitude_std_{unit}',
               'Phase_circular_std_deg', 'Lockin_samples', 'NI_samples', 'Complete']
    lines = ['\t'.join(headers)]
    for point in points:
        stats, field = point['statistics'], point['field']
        values = [point['index'], point.get('target_current_A'), point.get('measured_current_A'),
            field.get('field_mean_mT'), stats.get('amplitude_mean'), stats.get('phase_mean_deg'),
            stats.get('amplitude_std'), stats.get('phase_circular_std_deg'), stats['samples'],
            field.get('samples', 0), int(point['result'] == 'complete' and field.get('valid', False))]
        lines.append('\t'.join('nan' if v is None else f'{v:.12g}' for v in values))
    atomic_text(Path(folder) / 'summary.dat', '\n'.join(lines) + '\n')
    compact = [{k: v for k, v in p.items() if k not in ('lockin', 'parameters')} for p in points]
    metadata(Path(folder) / 'experiment.txt', dict(info, points=compact))
