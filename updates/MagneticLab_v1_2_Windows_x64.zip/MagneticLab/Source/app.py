"""Signal Recovery 7230 + GEN60-40 magnet + NI USB-6363 AI3 differential."""
import argparse
import multiprocessing
import sys


def main():
    if sys.version_info < (3, 10):
        raise RuntimeError('Требуется Python 3.10 или новее; рекомендуется Python 3.11 x64.')
    from PyQt5.QtCore import Qt
    from PyQt5.QtWidgets import QApplication
    from window import LabWindow

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--demo', action='store_true', help='Симулятор всех трёх приборов')
    parser.add_argument('--serial', help='Серийный номер Lock-in')
    parser.add_argument('--timeout', type=int, default=2000)
    parser.add_argument('--max-frequency', type=int, choices=(120000, 250000), default=120000)
    args = parser.parse_args()
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication(sys.argv[:1])
    app.setOrganizationName('LabTools')
    app.setApplicationName('MagneticLab')
    app.setStyle('Fusion')
    window = LabWindow(args)
    window.show()
    return app.exec_()


if __name__ == '__main__':
    multiprocessing.freeze_support()
    sys.exit(main())
