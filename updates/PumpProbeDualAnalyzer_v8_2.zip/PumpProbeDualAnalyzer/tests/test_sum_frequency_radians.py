"""Dimensional and report checks independent of the GUI display format."""
from dataclasses import replace
import unittest
import numpy as np
from matplotlib.mathtext import MathTextParser
from analyzer import core,fit_summary,sum_frequency as sf
from test_sum_frequency import fixture


class SumFrequencyRadiansTests(unittest.TestCase):
    def calibrated(self,p,factor):
        return replace(p,raw_rad=p.raw_rad*factor,y=p.y*factor,
            background=p.background*factor,spectrum=p.spectrum*factor,signal_unit='rad')

    def test_same_calibration_scales_only_amplitude_and_its_covariance(self):
        p,reference,_=fixture(noise=1e-8)
        volts=sf.fit(p,reference,2.5)
        rad=sf.fit(self.calibrated(p,2.5),reference,2.5,response_factor=2.5)
        transform=np.eye(5);transform[1,1]=2.5;transform[4,4]=2.5
        np.testing.assert_allclose(rad.parameters,transform@volts.parameters,rtol=1e-9,atol=1e-18)
        np.testing.assert_allclose(rad.covariance,transform@volts.covariance@transform.T,rtol=1e-8,atol=1e-27)
        np.testing.assert_allclose(core.evaluate_fit(p.time,rad),2.5*core.evaluate_fit(p.time,volts),rtol=1e-10,atol=1e-18)
        self.assertEqual(rad.native_signal_unit,'rad')
        for key in ('delta_Gamma_per_s','delta_A_V','delta_A_rad','delta_f_Hz','delta_phi_deg'):
            self.assertAlmostEqual(sf.report(rad)['modes'][0][key],sf.report(volts)['modes'][0][key],delta=max(abs(sf.report(volts)['modes'][0][key])*1e-8,1e-18))

    def test_separate_calibration_keeps_the_physical_x1_carrier_in_radians(self):
        p,reference,_=fixture()
        r=sf.fit(self.calibrated(p,4.),reference,2.5,response_factor=4.)
        native=sf.native_carrier(r)
        np.testing.assert_array_equal(native,reference.parameters)
        np.testing.assert_allclose(core.evaluate_fit(p.time,r),p.y*4,rtol=1e-10,atol=1e-18)
        mode=sf.report(r)['modes'][0]
        self.assertAlmostEqual(mode['delta_A_rad'],r.parameters[1])
        self.assertAlmostEqual(mode['delta_A_V'],r.parameters[1]/4.)

    def test_constant_still_fits_but_is_absent_from_requested_summary(self):
        p,reference,_=fixture()
        p=replace(p,y=p.y+1.2e-6,raw_rad=p.raw_rad+1.2e-6)
        result=sf.fit(self.calibrated(p,2.5),reference,2.5,include_constant=True)
        self.assertAlmostEqual(result.parameters[-1],3e-6,places=15)
        reference=replace(reference,parameters=np.r_[reference.parameters[:-1],8e-6])
        data=fit_summary.values(reference,{'x2':result,'y2':result})
        text=fit_summary.text(data)
        for removed in ('C =','t_ref','FFT','RMSE','R²','sum','stderr'):
            self.assertNotIn(removed,text)
        for name in ('X1','X2','Y2'):
            self.assertEqual(len(fit_summary.block(name,data[name]).splitlines()),5)
        self.assertEqual(data['X1']['A_0_rad'],reference.parameters[0])
        self.assertAlmostEqual(data['X1']['omega_0_rad_per_s'],2*np.pi*reference.parameters[1])

    def test_single_sine_math_parses_without_sum_constant_or_reference_caption(self):
        parser=MathTextParser('path')
        for formula in (fit_summary.CARRIER_MATH,fit_summary.RESPONSE_MATH):
            for removed in (r'\sum',r'\psi','C','t_ref'):
                self.assertNotIn(removed,formula)
            for line in formula.splitlines():parser.parse(line)
        self.assertIn(r'\omega_0t',fit_summary.CARRIER_MATH)
        self.assertIn(r'2\pi\Delta f',fit_summary.RESPONSE_MATH)


if __name__=='__main__':unittest.main()
