"""Only the requested single-oscillation parameters for print and TXT output."""
import numpy as np
from .presentation import angle_unit
from . import sum_frequency as sf


CARRIER_MATH=(r'$\theta_1^{\mathrm{osc}}(t)=A_0e^{-\Gamma_0t}\sin(\omega_0t+\varphi_0)$')
RESPONSE_MATH=(r'$\theta_2^{\mathrm{osc}}(t)=\frac{1}{2}e^{-\Gamma_0t}'
    r'[(\Delta A-A_0\Delta\Gamma\,t)\sin(\omega_0t+\varphi_0)$' '\n'
    r'$\qquad +A_0(\Delta\varphi+2\pi\Delta f\,t)\cos(\omega_0t+\varphi_0)]$')
CARRIER_TEXT='theta_1^osc(t) = A_0 exp(-Gamma_0 t) sin(omega_0 t + phi_0)'
RESPONSE_TEXT='theta_2^osc(t) = 1/2 exp(-Gamma_0 t) [(Delta_A - A_0 Delta_Gamma t) sin(omega_0 t + phi_0) + A_0 (Delta_phi + 2 pi Delta_f t) cos(omega_0 t + phi_0)]'


def values(first, diagnostics):
    carrier=dict(Gamma_0_per_s=None,omega_0_rad_per_s=None,A_0_rad=None,phi_0_deg=None)
    if first is not None and len(first.parameters)==5:
        a,f,phi,tau,_=first.parameters
        carrier=dict(Gamma_0_per_s=float(1/tau),omega_0_rad_per_s=float(2*np.pi*f),
                     A_0_rad=float(a),phi_0_deg=float(np.rad2deg(phi)%360))
    result={'X1':carrier}
    for key in ('x2','y2'):
        fitted=diagnostics.get(key)
        data={k:None for k in ('delta_Gamma_per_s','delta_A_rad','delta_f_Hz','delta_phi_deg')}
        if sf.is_modulation(fitted):
            mode=sf.report(fitted)['modes'][0]
            data={k:mode[k] for k in data}
        result[key.upper()]=data
    return result


def block(name, data, *, plain=False, label=None):
    def number(value, scale=1., unit=''):
        return '—' if value is None else f'{value/scale:.7g} {unit}'.rstrip()
    def angle(value):
        if value is None:return '—'
        scale,unit=angle_unit([value]);return number(value,scale,unit)
    if name=='X1':
        entries=[('Gamma_0' if plain else 'Γ₀',number(data['Gamma_0_per_s'],1e9,'ns⁻¹')),
            ('omega_0' if plain else 'ω₀',number(data['omega_0_rad_per_s'],1e9,'rad/ns')),
            ('A_0' if plain else 'A₀',angle(data['A_0_rad'])),
            ('phi_0' if plain else 'φ₀',number(data['phi_0_deg'],1.,'deg' if plain else '°'))]
    else:
        entries=[('Delta_Gamma' if plain else 'ΔΓ',number(data['delta_Gamma_per_s'],1e9,'ns⁻¹')),
            ('Delta_A' if plain else 'ΔA',angle(data['delta_A_rad'])),
            ('Delta_f' if plain else 'Δf',number(data['delta_f_Hz'],1e9,'GHz')),
            ('Delta_phi' if plain else 'Δφ',number(data['delta_phi_deg'],1.,'deg' if plain else '°'))]
    return '\n'.join([name if label is None else label,*[f'{key} = {value}' for key,value in entries]])


def text(data):
    return '\n\n'.join([CARRIER_TEXT,RESPONSE_TEXT,*[block(key,data[key],plain=True) for key in ('X1','X2','Y2')]])+'\n'
