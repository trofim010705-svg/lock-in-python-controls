"""First-order electric-field modulation measured at the SUM sideband.

Both models use local t = delay - t_ref; baseline and changes are referenced to t_ref.
X1's carrier is fixed; signed changes are estimated independently for X2/Y2.
"""
from dataclasses import dataclass, field
from threading import Event
import numpy as np
from . import core

MODEL='sum_frequency_linear'
CARRIER_FORMULA='theta1(t) = sum_i A0_i * exp(-Gamma0_i*t) * sin(2*pi*f0_i*t + phi0_i) + C1; Gamma0_i=1/tau_decay_i; t=delay-t_ref'
FORMULA='theta2(t) = 0.5 * sum_i exp(-Gamma0_i*t) * [(delta_A_i - A0_i*delta_Gamma_i*t)*sin(2*pi*f0_i*t+phi0_i) + A0_i*(delta_phi_i + 2*pi*delta_f_i*t)*cos(2*pi*f0_i*t+phi0_i)] + C2; t=delay-t_ref; C2=0 unless explicitly enabled'
CARRIER_MATH_FORMULA=(r'$\theta_1(t)=\sum_i A_{0i}e^{-\Gamma_{0i}t}'
    r'\sin(2\pi f_{0i}t+\varphi_{0i})+C_1,\qquad t=t_{\mathrm{delay}}-t_{\mathrm{ref}}$')
MATH_FORMULA=(r'$\theta_2(t)=\frac{1}{2}\sum_i e^{-\Gamma_{0i}t}'
    r'[(\delta A_i-A_{0i}\delta\Gamma_i t)\sin(2\pi f_{0i}t+\varphi_{0i})$' '\n'
    r'$\qquad +A_{0i}(\delta\varphi_i+2\pi\delta f_i t)\cos(2\pi f_{0i}t+\varphi_{0i})]$')



@dataclass
class ModulationFitResult(core.FitResult):
    model: str = MODEL
    carrier_parameters_v: np.ndarray = field(default_factory=lambda:np.array([]))
    carrier_reference_s: float = 0.
    first_factor_rad_per_v: float = 1.
    fixed_delta_frequencies: dict = field(default_factory=dict)
    include_constant: bool = False
    background_coefficients: np.ndarray = field(default_factory=lambda:np.empty((0,0)))
    background_center_s: float = 0.
    background_scale_s: float = 1.
    identifiable: bool = True
    native_signal_unit: str = 'V'
    response_factor_rad_per_v: float = 1.


def native_carrier(result):
    carrier=result.carrier_parameters_v.copy()
    if result.native_signal_unit=='rad':carrier[::4]*=result.first_factor_rad_per_v
    return carrier


def is_modulation(result):
    return getattr(result,'model',None)==MODEL


def parameter_names(count):
    return [(name+str(i),unit) for i in range(1,count+1)
            for name,unit in [('delta_Gamma','s^-1'),('delta_A','V'),('delta_f','Hz'),('delta_phi','rad')]]+[('C','V')]


def _basis(time_s,carrier,reference_s):
    t=np.asarray(time_s,dtype=float)
    if t.ndim!=1 or not np.isfinite(t).all():raise ValueError('Некорректная сетка времени модуляционного фита.')
    columns=[]
    for i in range((len(carrier)-1)//4):
        amplitude,frequency,phase,tau=carrier[4*i:4*i+4]
        u=t-reference_s
        with np.errstate(over='raise',invalid='raise'):
            envelope=np.exp(-u/tau)
            psi=2*np.pi*frequency*u+phase
            sin,cos=np.sin(psi),np.cos(psi)
            # The complete sideband response, including its 1/2 coefficient.
            columns.extend((-.5*amplitude*envelope*u*sin,
                .5*envelope*sin,
                np.pi*amplitude*envelope*u*cos,
                .5*amplitude*envelope*cos))
    return np.column_stack([*columns,np.ones(len(t))])


def evaluate(time_s,result,parameters=None):
    p=result.parameters if parameters is None else np.asarray(parameters,dtype=float)
    basis=_basis(time_s,native_carrier(result),result.carrier_reference_s)
    if result.background_coefficients.size:
        z=(np.asarray(time_s)-result.background_center_s)/result.background_scale_s
        basis=basis-np.polynomial.polynomial.polyval(z,result.background_coefficients).T
    return basis@p


def carrier_at_reference(result):
    modes=[]
    for i in range((len(result.carrier_parameters_v)-1)//4):
        a,f,phase,tau=result.carrier_parameters_v[4*i:4*i+4]
        a0=float(a)
        modes.append(dict(component=i+1,A0_V=a0,A0_rad=a0*result.first_factor_rad_per_v,
            Gamma0_per_s=float(1/tau),f0_Hz=float(f),phi0_rad=float(phase)))
    return modes


def fit(prepared,reference,first_factor,initial=None,cancel=None,fixed_delta_frequencies=None,include_constant=False,response_factor=None):
    cancel=cancel or Event()
    if cancel.is_set():raise core.Cancelled('Модуляционный фит отменён.')
    if reference is None or is_modulation(reference):raise ValueError('Сначала нужен обычный фит X1 для опорного S0.')
    if not np.isfinite(reference.r_squared):raise ValueError('Колебательный опорный сигнал X1 не определён (например, постоянный X1). δ-параметры не рассчитываются.')
    carrier=np.asarray(reference.parameters,dtype=float).copy()
    count=(len(carrier)-1)//4
    if count<1 or len(carrier)!=4*count+1 or not np.isfinite(carrier).all():raise ValueError('Некорректный опорный фит X1.')
    if not np.isfinite(first_factor) or first_factor<=0:raise ValueError('Нужен положительный коэффициент калибровки X1.')
    carrier[::4]/=first_factor  # A_i and the final C; native X2/Y2 are measured volts.
    unit=prepared.signal_unit
    if unit not in ('V','rad'):raise ValueError('Модуляционный фит требует V или rad.')
    response_factor=first_factor if response_factor is None else float(response_factor)
    if not np.isfinite(response_factor) or response_factor<=0:raise ValueError('Проверьте калибровку X2/Y2.')
    working_carrier=carrier.copy()
    if unit=='rad':working_carrier[::4]*=first_factor
    for i in range(count):
        a,f,phase,tau=carrier[4*i:4*i+4]
        if a<=np.finfo(float).tiny or f<=0 or tau<=0:raise ValueError('Опорная мода X1 имеет нулевую амплитуду/частоту или неверное затухание.')
    length=4*count+1
    initial=np.zeros(length) if initial is None else np.asarray(initial,dtype=float)
    if initial.shape!=(length,) or not np.isfinite(initial).all():raise ValueError('Проверьте набор δ-параметров: 4 на моду X1 и C.')
    fixed=dict(fixed_delta_frequencies or {})
    if any(not isinstance(i,(int,np.integer)) or not 0<=i<count or not np.isfinite(v) for i,v in fixed.items()):
        raise ValueError('Фиксированные δf задаются как {номер моды: знаковый сдвиг Hz}.')
    mask=np.asarray(prepared.fit_mask)&np.isfinite(prepared.time)&np.isfinite(prepared.y)
    matrix=_basis(prepared.time,working_carrier,reference.reference_s)
    coefficients=np.empty((0,length));center=0.;scale=1.
    cfg=prepared.settings
    if cfg.background_degree>=0:
        bg=(prepared.time>=cfg.bg_min_s)&(prepared.time<=cfg.bg_max_s)
        if bg.sum()>cfg.background_degree:
            if include_constant:raise ValueError('C уже удалён полиномиальным фоном. Отключите подбор C или вычитание фона.')
            center=float((prepared.time[bg][0]+prepared.time[bg][-1])/2)
            scale=max(float(np.ptp(prepared.time[bg]))/2,np.finfo(float).tiny)
            z=(prepared.time-center)/scale
            coefficients=np.polynomial.polynomial.polyfit(z[bg],matrix[bg],cfg.background_degree)
            matrix=matrix-np.polynomial.polynomial.polyval(z,coefficients).T
    values=prepared.y[mask];design=matrix[mask]
    pinned={4*i+2:float(v) for i,v in fixed.items()}
    if not include_constant:pinned[length-1]=0.
    free=np.array([i for i in range(length) if i not in pinned],dtype=int)
    if len(values)<max(8,len(free)+2):raise ValueError('Недостаточно точек для δ-параметров выбранных мод X1.')
    parameters=np.zeros(length)
    for i,v in pinned.items():parameters[i]=v
    target=values-design@parameters
    ys=max(float(np.std(values)),float(np.ptp(values))*.1,1e-30)
    norms=np.linalg.norm(design[:,free],axis=0)
    if not np.isfinite(norms).all() or np.any(norms<=np.finfo(float).tiny):
        raise ValueError('Опорная мода исчезла в окне: δ-параметры не определяются.')
    normalized=design[:,free]/norms
    if cancel.is_set():raise core.Cancelled('Модуляционный фит отменён.')
    solution,_,rank,singular=np.linalg.lstsq(normalized,target/ys,rcond=None)
    parameters[free]=solution*ys/norms
    prediction=design@parameters
    residual=prediction-values
    sse=float(np.dot(residual,residual));sst=float(np.sum((values-values.mean())**2))
    condition=float(singular[0]/singular[-1]) if singular[-1]>0 else float('inf')
    identifiable=rank==len(free) and condition<1e12
    covariance=np.zeros((length,length));errors=np.zeros(length)
    warnings=[]
    if identifiable:
        variance=sse/(len(values)-len(free))
        # QR/SVD, without squaring the design's condition number.
        _,s,vh=np.linalg.svd(normalized,full_matrices=False)
        cov=(vh.T*(1/s**2))@vh*variance
        cov=cov/norms[:,None]/norms[None,:]
        covariance[np.ix_(free,free)]=cov
        errors[free]=np.sqrt(np.maximum(0,np.diag(cov)))
        if not np.isfinite(errors[free]).all():identifiable=False
    if not identifiable:
        errors[free]=np.nan;covariance[np.ix_(free,free)]=np.nan
        warnings.append('δ-параметры не разделяются однозначно: недостаточный ранг/плохая обусловленность. Численные коэффициенты — только один из вариантов кривой.')
    if getattr(reference,'r_squared',1.)<.5:warnings.append('Опорный фит X1 имеет низкий R²; интерпретация δ-параметров ограничена.')
    result=ModulationFitResult(parameters,errors,covariance,float(reference.reference_s),float(np.sqrt(sse/len(values))),
        1-sse/sst if sst>0 else float('nan'),warnings,1,condition,
        carrier_parameters_v=carrier,carrier_reference_s=float(reference.reference_s),
        first_factor_rad_per_v=float(first_factor),fixed_delta_frequencies=fixed,include_constant=bool(include_constant),
        background_coefficients=coefficients,background_center_s=center,background_scale_s=scale,identifiable=bool(identifiable),
        native_signal_unit=unit,response_factor_rad_per_v=response_factor)
    for i,base in enumerate(carrier_at_reference(result)):
        gamma,da,df,dphi=parameters[4*i:4*i+4]
        t=prepared.time[mask]-result.reference_s
        if max(abs(da/base['A0_rad' if unit=='rad' else 'A0_V']),float(np.max(abs(gamma*t))),float(np.max(abs(dphi+2*np.pi*df*t))))>.3:
            warnings.append(f'Мода {i+1}: возмущение может быть большим для линейного приближения первого порядка.')
    if cancel.is_set():raise core.Cancelled('Модуляционный фит отменён.')
    return result


def report(result):
    modes=[]
    for i,base in enumerate(carrier_at_reference(result)):
        p=result.parameters[4*i:4*i+4];e=result.errors[4*i:4*i+4]
        mode=dict(component=i+1,reference=base,identifiable=result.identifiable)
        for j,key in enumerate(('delta_Gamma_per_s','delta_A_V','delta_f_Hz','delta_phi_rad')):
            mode[key]=float(p[j]) if result.identifiable else None
            mode[key+'_stderr']=float(e[j]) if np.isfinite(e[j]) else None
        amplitude_rad=p[1] if result.native_signal_unit=='rad' else p[1]*result.response_factor_rad_per_v
        amplitude_v=p[1]/result.response_factor_rad_per_v if result.native_signal_unit=='rad' else p[1]
        mode['delta_A_V']=float(amplitude_v) if result.identifiable else None
        mode['delta_A_V_stderr']=float(e[1]/result.response_factor_rad_per_v if result.native_signal_unit=='rad' else e[1]) if np.isfinite(e[1]) else None
        mode.update(delta_Gamma_per_ns=float(p[0]/1e9) if result.identifiable else None,
            delta_A_rad=float(amplitude_rad) if result.identifiable else None,
            delta_f_GHz=float(p[2]/1e9) if result.identifiable else None,
            delta_phi_deg=float(np.rad2deg(p[3])) if result.identifiable else None,
            delta_phi_deg_stderr=float(np.rad2deg(e[3])) if np.isfinite(e[3]) else None,
            delta_f_fixed=i in result.fixed_delta_frequencies)
        modes.append(mode)
    return dict(model=MODEL,formula=FORMULA,sideband_prefactor=.5,delta_omega_definition='delta_omega = 2*pi*delta_f',
        reference_time_s=result.reference_s,carrier_fit_reference_s=result.carrier_reference_s,parameters_at='t_ref of the X1 carrier fit; local t = delay - t_ref',
        local_time_definition='t = delay - t_ref; all A0, phi0, delta_A and delta_phi refer to the same t_ref',
        native_signal_unit=result.native_signal_unit,first_factor_rad_per_v=result.first_factor_rad_per_v,
        response_factor_rad_per_v=result.response_factor_rad_per_v,
        delta_phi_definition='Signed small modulation in degrees; never reduced modulo 360.',
        uncertainty_definition='Conditional least-squares standard errors with X1 carrier fixed. X1 uncertainty and cross-channel correlations are not propagated.',
        modes=modes,constant_V=float(result.parameters[-1]/result.response_factor_rad_per_v if result.native_signal_unit=='rad' else result.parameters[-1]),constant_fitted=result.include_constant,
        preprocessing='The SAME polynomial-background operator is applied to every model basis column and to measured X2/Y2.',
        background_coefficients=result.background_coefficients.tolist(),background_center_s=result.background_center_s,
        background_scale_s=result.background_scale_s,
        rmse_V=result.rmse_rad/result.response_factor_rad_per_v if result.native_signal_unit=='rad' else result.rmse_rad,
        rmse_rad=result.rmse_rad if result.native_signal_unit=='rad' else result.rmse_rad*result.response_factor_rad_per_v,r_squared=result.r_squared,
        identifiable=result.identifiable,condition=result.condition,warnings=list(result.warnings))


def footer_text(result,time_unit='ns'):
    lines=['½ · модуляционный отклик; опора X1',f't_ref = {result.reference_s/(1e-9 if time_unit=="ns" else 1e-12):.6g} {time_unit}']
    if not result.identifiable:return '\n'.join(lines+['δ-параметры не определены однозначно.'])
    for i in range((len(result.parameters)-1)//4):
        dg,da,df,dp=result.parameters[4*i:4*i+4]
        lines.extend([f'Мода {i+1}: δΓ = {dg/1e9:.6g} ns⁻¹; δA = {da/1e-6:.6g} µV',
                      f'δf = {df/1e9:.6g} GHz; δφ = {np.rad2deg(dp):.6g}°'])
    if result.include_constant:lines.append(f'C = {result.parameters[-1]/1e-6:.6g} µV')
    return '\n'.join(lines)
