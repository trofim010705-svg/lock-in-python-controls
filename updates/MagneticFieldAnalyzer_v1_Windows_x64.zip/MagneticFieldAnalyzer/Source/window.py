"""Desktop editor for independent field sweeps; never opens any instrument."""
from pathlib import Path
import math

from PyQt5.QtCore import QThread, QTimer, Qt, pyqtSignal
from PyQt5.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QColorDialog, QComboBox, QDoubleSpinBox,
    QFileDialog, QFileSystemModel, QFormLayout, QGridLayout, QGroupBox, QHBoxLayout,
    QLabel, QLineEdit, QListView, QMainWindow, QPlainTextEdit, QPushButton,
    QScrollArea, QSlider, QSplitter, QSpinBox, QTabWidget, QTreeView, QTreeWidget,
    QTreeWidgetItem, QVBoxLayout, QWidget,
)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT

from analysis_data import find_measurements, load_measurement
from figure_view import Appearance, Series, PlotFigure, COLORS, MARKERS, PREFIXES, display_unit


class FolderLoader(QThread):
    progress = pyqtSignal(str)
    loaded = pyqtSignal(object, object)

    def __init__(self, folders, existing=(), parent=None):
        super().__init__(parent)
        self.folders, self.existing = folders, set(existing)

    def run(self):
        result, errors, seen = [], [], set(self.existing)
        for selection in self.folders:
            found = False
            try:
                for folder in find_measurements(selection, self.isInterruptionRequested):
                    found = True
                    if self.isInterruptionRequested():
                        break
                    if folder in seen:
                        continue
                    seen.add(folder)
                    if len(seen) > 2000:
                        errors.append('Достигнут предел 2000 папок. Выберите более узкую папку.')
                        break
                    self.progress.emit('Чтение: ' + str(folder))
                    try:
                        result.append(load_measurement(folder))
                    except Exception as exc:
                        errors.append(str(folder) + ': ' + str(exc))
                if not found and not self.isInterruptionRequested():
                    errors.append(str(selection) + ': файлы Magnetic Lab не найдены.')
            except Exception as exc:
                errors.append(str(selection) + ': ' + str(exc))
            if self.isInterruptionRequested():
                break
        self.loaded.emit(result, errors)


class PlotToolbar(NavigationToolbar2QT):
    # Keep one source of truth for labels/styles in the application's controls.
    # Matplotlib's separate curve editor would bypass the phase/export model.
    toolitems = tuple(item for item in NavigationToolbar2QT.toolitems
                     if item[0] in (None, 'Home', 'Back', 'Forward', 'Pan', 'Zoom', 'Save'))

    def home(self, *args):
        super().home(*args)
        self.owner.use_auto_limits()

    def save_figure(self, *args):
        self.owner.save_dialog()


class AnalyzerWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Magnetic Field Analyzer 1.0 · амплитуда и фаза от поля')
        self.setMinimumSize(1050, 650)
        screen = self.screen().availableGeometry()
        self.resize(min(1450, screen.width()), min(930, screen.height()))
        self.series, self.last_import_errors = [], []
        self.worker = None
        self.importing = False
        self.want_close = False
        self.syncing = False
        self.full_pending = True
        self.pending = True
        self.last_error = ''
        self.plot = PlotFigure()
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(65)
        self.timer.timeout.connect(self.render_now)
        self.build_ui()
        self.render_now()

    def build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        header = QHBoxLayout()
        self.add_button = QPushButton('Добавить папки…')
        self.add_button.clicked.connect(self.choose_folders)
        self.remove_button = QPushButton('Удалить серию')
        self.remove_button.clicked.connect(self.remove_series)
        self.save_button = QPushButton('Сохранить рисунок…')
        self.save_button.clicked.connect(self.save_dialog)
        self.export_button = QPushButton('Экспорт данных…')
        self.export_button.clicked.connect(self.export_dialog)
        for button in (self.add_button, self.remove_button, self.save_button, self.export_button):
            button.setMinimumHeight(34)
            header.addWidget(button)
        header.addStretch()
        outer.addLayout(header)
        splitter = QSplitter(Qt.Horizontal)
        outer.addWidget(splitter, 1)
        self.tabs = QTabWidget()
        self.tabs.setMinimumWidth(380)
        self.tabs.setMaximumWidth(580)
        splitter.addWidget(self.tabs)
        self.build_series_page()
        self.build_appearance_page()
        self.info = QPlainTextEdit()
        self.info.setReadOnly(True)
        self.tabs.addTab(self.info, 'Информация')
        charts = QWidget()
        view = QVBoxLayout(charts)
        view.setContentsMargins(5, 0, 0, 0)
        self.canvas = FigureCanvasQTAgg(self.plot.figure)
        self.canvas.setMinimumSize(480, 400)
        self.toolbar = PlotToolbar(self.canvas, self)
        self.toolbar.owner = self
        view.addWidget(self.toolbar)
        view.addWidget(self.canvas, 1)
        splitter.addWidget(charts)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([410, 1000])
        self.canvas.mpl_connect('button_release_event', self.navigation_finished)
        self.status = QLabel('Добавьте папку измерения или родительскую папку с несколькими проходами.')
        self.status.setWordWrap(True)
        self.status.setMaximumHeight(60)
        self.status.setTextInteractionFlags(Qt.TextSelectableByMouse)
        outer.addWidget(self.status)
        self.update_buttons()

    @staticmethod
    def form_group(layout, title):
        group = QGroupBox(title)
        form = QFormLayout(group)
        form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        layout.addWidget(group)
        return form

    @staticmethod
    def real_spin(low, high, value, decimals=1):
        widget = QDoubleSpinBox()
        widget.setRange(low, high)
        widget.setDecimals(decimals)
        widget.setValue(value)
        widget.setKeyboardTracking(False)
        return widget

    def build_series_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        explanation = QLabel('Каждая папка — отдельная серия. Цвет, символ, легенда и сдвиг фазы относятся к выбранной строке.')
        explanation.setWordWrap(True)
        layout.addWidget(explanation)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(['Серия / легенда', 'Точек', 'Δφ, °'])
        self.tree.setColumnWidth(0, 200)
        self.tree.setColumnWidth(1, 55)
        self.tree.setColumnWidth(2, 65)
        self.tree.setMinimumHeight(130)
        self.tree.currentItemChanged.connect(self.selection_changed)
        self.tree.itemChanged.connect(self.tree_changed)
        layout.addWidget(self.tree, 1)
        form = self.form_group(layout, 'Выбранная серия')
        self.legend_text = QLineEdit()
        self.legend_text.textEdited.connect(self.legend_edited)
        form.addRow('Легенда', self.legend_text)
        self.color_button = QPushButton('Выбрать цвет…')
        self.color_button.clicked.connect(self.choose_color)
        self.marker = QComboBox()
        for name, code in MARKERS:
            self.marker.addItem(name, code)
        self.marker.currentIndexChanged.connect(self.series_style_changed)
        row = QHBoxLayout()
        row.addWidget(self.color_button)
        row.addWidget(self.marker)
        form.addRow(row)
        self.opacity = self.real_spin(.05, 1, .85, 2)
        self.opacity.setSingleStep(.05)
        self.opacity.valueChanged.connect(self.series_style_changed)
        form.addRow('Непрозрачность', self.opacity)
        form = self.form_group(layout, 'Сдвиг фазы выбранной серии')
        self.phase_slider = QSlider(Qt.Horizontal)
        self.phase_slider.setRange(-3600, 3600)
        self.phase_slider.setSingleStep(1)
        self.phase_slider.setPageStep(100)
        self.phase_slider.valueChanged.connect(self.slider_changed)
        form.addRow(self.phase_slider)
        self.phase_value = self.real_spin(-360, 360, 0)
        self.phase_value.setSuffix(' °')
        self.phase_value.setSingleStep(.1)
        self.phase_value.valueChanged.connect(self.offset_changed)
        reset = QPushButton('Сбросить сдвиг')
        reset.clicked.connect(lambda: self.phase_value.setValue(0))
        row = QHBoxLayout()
        row.addWidget(self.phase_value)
        row.addWidget(reset)
        form.addRow(row)
        self.phase_mode = QComboBox()
        self.phase_mode.addItem('Фаза 0…360°', 'wrapped')
        self.phase_mode.addItem('Фаза −180…180°', 'signed')
        self.phase_mode.addItem('Непрерывная фаза (unwrap)', 'unwrap')
        self.phase_mode.currentIndexChanged.connect(lambda: self.schedule(True))
        form.addRow(self.phase_mode)
        hint = QLabel('Сдвиг применяется только при отображении и экспорте. Исходные файлы не меняются.')
        hint.setWordWrap(True)
        form.addRow(hint)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(page)
        self.tabs.addTab(scroll, 'Серии')

    def build_appearance_page(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        page = QWidget()
        layout = QVBoxLayout(page)
        form = self.form_group(layout, 'Подписи рисунка')
        self.labels = {}
        defaults = Appearance()
        for key, name in [('title', 'Общий title'), ('amplitude_title', 'Title амплитуды'),
                          ('phase_title', 'Title фазы'), ('x_label', 'Ось поля'),
                          ('amplitude_label', 'Ось амплитуды'), ('phase_label', 'Ось фазы')]:
            edit = QLineEdit(getattr(defaults, key))
            edit.textChanged.connect(lambda: self.schedule(True))
            self.labels[key] = edit
            form.addRow(name, edit)
        self.labels['amplitude_label'].setPlaceholderText('Автоматически по выбранной единице')
        note = QLabel('Формулы: $\\phi(H)$ или $$\\Delta\\phi$$. Установка LaTeX не требуется.')
        note.setWordWrap(True)
        form.addRow(note)
        form = self.form_group(layout, 'Шрифты и точки')
        self.fonts = {}
        for key, name in [('title_size', 'Title'), ('legend_size', 'Легенда'),
                          ('label_size', 'Подписи осей'), ('tick_size', 'Числа на осях')]:
            spin = QSpinBox()
            spin.setRange(6, 40)
            spin.setValue(getattr(defaults, key))
            spin.valueChanged.connect(lambda: self.schedule(True))
            self.fonts[key] = spin
            form.addRow(name, spin)
        self.marker_size = self.real_spin(1, 20, 5)
        self.marker_size.valueChanged.connect(lambda: self.schedule(True))
        form.addRow('Размер точек', self.marker_size)
        self.connected = QCheckBox('Соединять точки в порядке измерения')
        self.connected.toggled.connect(lambda: self.schedule(True))
        form.addRow(self.connected)
        self.show_legend = QCheckBox('Показывать легенду')
        self.show_legend.setChecked(True)
        self.show_legend.toggled.connect(lambda: self.schedule(True))
        form.addRow(self.show_legend)
        self.legend_location = QComboBox()
        for name, code in [('Автоматически', 'best'), ('Справа вверху', 'upper right'),
                           ('Слева вверху', 'upper left'), ('Справа внизу', 'lower right'), ('Слева внизу', 'lower left')]:
            self.legend_location.addItem(name, code)
        self.legend_location.currentIndexChanged.connect(lambda: self.schedule(True))
        form.addRow('Положение легенды', self.legend_location)
        self.grid = QCheckBox('Сетка')
        self.grid.setChecked(True)
        self.grid.toggled.connect(lambda: self.schedule(True))
        form.addRow(self.grid)
        self.amplitude_unit = QComboBox()
        self.fill_units('V')
        self.amplitude_unit.currentIndexChanged.connect(self.unit_changed)
        form.addRow('Единица амплитуды', self.amplitude_unit)
        form = self.form_group(layout, 'Диапазоны осей')
        self.limits = {}
        for key, name in [('x_limits', 'Поле, mT'), ('amplitude_limits', 'Амплитуда'), ('phase_limits', 'Фаза, °')]:
            auto = QCheckBox('Авто')
            auto.setChecked(True)
            low, high = QLineEdit(), QLineEdit()
            low.setPlaceholderText('min')
            high.setPlaceholderText('max')
            low.setMaximumWidth(95)
            high.setMaximumWidth(95)
            low.setEnabled(False)
            high.setEnabled(False)
            low.editingFinished.connect(lambda: self.schedule(True))
            high.editingFinished.connect(lambda: self.schedule(True))
            auto.toggled.connect(lambda checked, k=key: self.auto_limit_changed(k, checked))
            row = QHBoxLayout()
            row.addWidget(auto)
            row.addWidget(low)
            row.addWidget(high)
            form.addRow(name, row)
            self.limits[key] = (auto, low, high)
        reset = QPushButton('Автомасштаб всех осей')
        reset.clicked.connect(self.use_auto_limits)
        form.addRow(reset)
        self.dpi = QSpinBox()
        self.dpi.setRange(72, 1200)
        self.dpi.setValue(200)
        form.addRow('DPI при сохранении', self.dpi)
        layout.addStretch()
        scroll.setWidget(page)
        self.tabs.addTab(scroll, 'Оформление')

    def fill_units(self, unit):
        self.amplitude_unit.blockSignals(True)
        self.amplitude_unit.clear()
        self.amplitude_unit.addItem('Автоматически', None)
        for prefix, factor in reversed(PREFIXES):
            self.amplitude_unit.addItem(prefix + unit, factor)
        self.amplitude_unit.blockSignals(False)

    def current(self):
        item = self.tree.currentItem()
        if item is None:
            return None
        uid = item.data(0, Qt.UserRole)
        return next((s for s in self.series if s.uid == uid), None)

    def update_buttons(self):
        loading = self.importing or (self.worker is not None and self.worker.isRunning())
        self.add_button.setEnabled(not loading)
        self.remove_button.setEnabled(self.current() is not None)
        for widget in (self.legend_text, self.marker, self.color_button, self.opacity, self.phase_slider, self.phase_value):
            widget.setEnabled(self.current() is not None)
        self.save_button.setEnabled(bool(self.series))
        self.export_button.setEnabled(bool(self.series))

    def choose_folders(self):
        dialog = QFileDialog(self, 'Выберите папки (Ctrl — несколько) или общую родительскую папку')
        dialog.setOption(QFileDialog.DontUseNativeDialog, True)
        dialog.setOption(QFileDialog.ShowDirsOnly, True)
        dialog.setFileMode(QFileDialog.Directory)
        dialog.setLabelText(QFileDialog.Accept, 'Добавить')
        for view in dialog.findChildren(QListView) + dialog.findChildren(QTreeView):
            if view.objectName() in ('listView', 'treeView'):
                view.setSelectionMode(QAbstractItemView.ExtendedSelection)
        if dialog.exec_() != QFileDialog.Accepted:
            return
        selected = []
        for view in dialog.findChildren(QListView) + dialog.findChildren(QTreeView):
            if view.objectName() in ('listView', 'treeView') and not view.isHidden():
                for index in view.selectionModel().selectedRows(0):
                    path = index.data(QFileSystemModel.FilePathRole)
                    if path and Path(path).is_dir():
                        selected.append(path)
        self.load_folders(list(dict.fromkeys(selected or dialog.selectedFiles())))

    def load_folders(self, folders):
        if self.worker is not None and self.worker.isRunning():
            return
        self.worker = FolderLoader(folders, [s.data.folder for s in self.series], self)
        self.importing = True
        self.worker.progress.connect(self.status.setText)
        self.worker.loaded.connect(self.loaded)
        self.worker.finished.connect(self.load_finished)
        self.worker.start()
        self.update_buttons()

    def loaded(self, measurements, errors):
        self.last_import_errors = list(errors)
        added = 0
        existing = {s.data.folder for s in self.series}
        for data in measurements:
            if data.folder in existing:
                continue
            if self.series and data.unit != self.series[0].data.unit:
                self.last_import_errors.append(str(data.folder) + ': нельзя смешивать сигналы в V и A на одной оси.')
                continue
            if not self.series:
                self.fill_units(data.unit)
            index = len(self.series)
            label = data.folder.name.replace('$', '\\$')
            if any(s.label == label for s in self.series):
                label += ' (' + data.folder.parent.name.replace('$', '\\$') + ')'
            symbol = MARKERS[(index + index // len(COLORS)) % len(MARKERS)][1]
            s = Series(data, label, COLORS[index % len(COLORS)], symbol)
            self.series.append(s)
            item = QTreeWidgetItem([s.label, str(len(data.field)), '0.0'])
            item.setData(0, Qt.UserRole, s.uid)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(0, Qt.Checked)
            item.setToolTip(0, str(data.folder))
            self.tree.addTopLevelItem(item)
            existing.add(data.folder)
            added += 1
        if self.tree.currentItem() is None and self.tree.topLevelItemCount():
            self.tree.setCurrentItem(self.tree.topLevelItem(0))
        self.full_pending = True
        self.render_now()
        self.refresh_info()
        self.status.setText(f'Добавлено серий: {added}. Всего: {len(self.series)}. Ошибок импорта: {len(self.last_import_errors)}.'
            + (' Подробности — на вкладке «Информация».' if self.last_import_errors else ''))
        self.importing = False
        self.update_buttons()

    def load_finished(self):
        self.update_buttons()
        if self.want_close:
            self.close()

    def selection_changed(self, *unused):
        s = self.current()
        if s is not None:
            self.syncing = True
            self.legend_text.setText(s.label)
            self.marker.setCurrentIndex(self.marker.findData(s.marker))
            self.opacity.setValue(s.alpha)
            self.phase_value.setValue(s.offset)
            self.phase_slider.setValue(round(s.offset * 10))
            self.color_button.setStyleSheet('background:' + s.color + '; color:white;')
            self.syncing = False
        self.refresh_info()
        self.update_buttons()

    def tree_changed(self, item, column):
        if self.syncing or column != 0:
            return
        s = next((s for s in self.series if s.uid == item.data(0, Qt.UserRole)), None)
        if s is not None:
            s.visible = item.checkState(0) == Qt.Checked
            self.schedule(True)

    def legend_edited(self, text):
        s = self.current()
        if s is not None and not self.syncing:
            s.label = text
            self.syncing = True
            self.tree.currentItem().setText(0, text)
            self.syncing = False
            self.schedule(True)

    def choose_color(self):
        s = self.current()
        if s is None:
            return
        color = QColorDialog.getColor(parent=self, title='Цвет серии')
        if color.isValid():
            s.color = color.name()
            self.color_button.setStyleSheet('background:' + s.color + '; color:white;')
            self.schedule(True)

    def series_style_changed(self):
        s = self.current()
        if s is not None and not self.syncing:
            s.marker, s.alpha = self.marker.currentData(), self.opacity.value()
            self.schedule(True)

    def slider_changed(self, value):
        if not self.syncing:
            self.phase_value.setValue(value / 10)

    def offset_changed(self, value):
        s = self.current()
        if s is None or self.syncing:
            return
        s.offset = value
        self.syncing = True
        self.phase_slider.setValue(round(value * 10))
        self.tree.currentItem().setText(2, f'{value:.1f}')
        self.syncing = False
        self.schedule(False)

    def refresh_info(self):
        s = self.current()
        text = 'Ошибки импорта:\n' + '\n'.join(self.last_import_errors) + '\n\n' if self.last_import_errors else ''
        if s is not None:
            text += str(s.data.folder) + f'\nТочек: {len(s.data.field)}; единица SI: {s.data.unit}.\n'
            text += '\n'.join(s.data.warnings) + '\n\n' + s.data.metadata_text
        self.info.setPlainText(text)

    def remove_series(self):
        s = self.current()
        if s is not None:
            self.series.remove(s)
            self.tree.takeTopLevelItem(self.tree.indexOfTopLevelItem(self.tree.currentItem()))
            self.schedule(True)
        self.update_buttons()

    def auto_limit_changed(self, key, checked):
        auto, low, high = self.limits[key]
        low.setEnabled(not checked)
        high.setEnabled(not checked)
        if not checked:
            limits = {'x_limits': self.plot.phase.get_xlim(), 'amplitude_limits': self.plot.amplitude.get_ylim(),
                      'phase_limits': self.plot.phase.get_ylim()}[key]
            low.setText(f'{limits[0]:.10g}')
            high.setText(f'{limits[1]:.10g}')
        self.schedule(True)

    def use_auto_limits(self):
        for auto, _, _ in self.limits.values():
            auto.setChecked(True)
        self.schedule(True)

    def navigation_finished(self, event):
        if not self.toolbar.mode or event.inaxes not in (self.plot.amplitude, self.plot.phase):
            return
        for key, bounds in [('x_limits', self.plot.phase.get_xlim()),
                            ('amplitude_limits', self.plot.amplitude.get_ylim()), ('phase_limits', self.plot.phase.get_ylim())]:
            auto, low, high = self.limits[key]
            auto.blockSignals(True)
            auto.setChecked(False)
            auto.blockSignals(False)
            low.setEnabled(True)
            high.setEnabled(True)
            low.setText(f'{bounds[0]:.10g}')
            high.setText(f'{bounds[1]:.10g}')

    def unit_changed(self):
        auto, low, high = self.limits['amplitude_limits']
        if not auto.isChecked():
            try:
                factor, _ = display_unit(self.series, self.amplitude_unit.currentData())
                low.setText(f'{float(low.text().replace(",", "."))*self.plot.factor/factor:.10g}')
                high.setText(f'{float(high.text().replace(",", "."))*self.plot.factor/factor:.10g}')
            except ValueError:
                pass
        self.schedule(True)

    def appearance(self):
        args = {key: widget.text() for key, widget in self.labels.items()}
        args.update({key: widget.value() for key, widget in self.fonts.items()})
        args.update(phase_mode=self.phase_mode.currentData(), amplitude_factor=self.amplitude_unit.currentData(),
            marker_size=self.marker_size.value(), connected=self.connected.isChecked(), grid=self.grid.isChecked(),
            show_legend=self.show_legend.isChecked(), legend_location=self.legend_location.currentData())
        for key, (auto, low, high) in self.limits.items():
            if not auto.isChecked():
                try:
                    bounds = float(low.text().replace(',', '.')), float(high.text().replace(',', '.'))
                except ValueError:
                    raise ValueError('Пределы осей должны быть числами.')
                if not all(math.isfinite(v) for v in bounds) or bounds[0] >= bounds[1]:
                    raise ValueError('Нижний предел оси должен быть меньше верхнего; значения должны быть конечными.')
                args[key] = bounds
        return Appearance(**args)

    def schedule(self, full=True):
        if self.syncing:
            return
        self.full_pending = self.full_pending or full
        self.pending = True
        if not self.timer.isActive():
            self.timer.start()

    def render_now(self):
        self.timer.stop()
        try:
            style = self.appearance()
            if self.full_pending:
                self.plot.render(self.series, style)
            else:
                self.plot.update_phase(self.series, style)
            self.full_pending = False
            self.pending = False
            self.last_error = ''
            self.canvas.draw_idle()
            self.labels['amplitude_label'].setPlaceholderText('Автоматически: амплитуда, ' + self.plot.unit)
            self.status.setText(f'Серий: {len(self.series)}. Амплитуда: {self.plot.unit}; фаза: градусы. Исходные файлы не изменяются.')
            return True
        except Exception as exc:
            self.last_error = str(exc)
            self.status.setText('Не применено: ' + str(exc))
            return False

    def save_plot(self, path):
        if self.pending and not self.render_now():
            raise ValueError(self.last_error)
        if not any(s.visible for s in self.series):
            raise ValueError('Нет видимых серий для сохранения.')
        self.canvas.draw()
        message = self.plot.save(path, self.series, self.appearance(), self.dpi.value())
        self.status.setText(message or 'Сохранено: ' + str(path))

    def save_dialog(self):
        path, selected = QFileDialog.getSaveFileName(self, 'Сохранить видимый рисунок', 'field_analysis.png',
                                                     'PNG (*.png);;PDF (*.pdf);;SVG (*.svg)')
        if path:
            if Path(path).suffix.lower() not in ('.png', '.pdf', '.svg'):
                path += { 'PDF (*.pdf)': '.pdf', 'SVG (*.svg)': '.svg' }.get(selected, '.png')
            try:
                self.save_plot(path)
            except Exception as exc:
                self.status.setText('Не удалось сохранить: ' + str(exc))

    def export_data(self, path):
        if self.pending and not self.render_now():
            raise ValueError(self.last_error)
        self.plot.export_data(path, self.series, self.appearance())
        self.status.setText('Таблица сохранена: ' + str(path))

    def export_dialog(self):
        path, selected = QFileDialog.getSaveFileName(self, 'Экспорт видимых серий со сдвигами фазы', 'field_analysis.dat',
                                                     'Таблица DAT (*.dat);;CSV (*.csv)')
        if path:
            if Path(path).suffix.lower() not in ('.dat', '.csv'):
                path += '.csv' if 'CSV' in selected else '.dat'
            try:
                self.export_data(path)
            except Exception as exc:
                self.status.setText('Не удалось экспортировать: ' + str(exc))

    def closeEvent(self, event):
        self.want_close = True
        if self.worker is not None and self.worker.isRunning():
            self.worker.requestInterruption()
            event.ignore()
            return
        self.timer.stop()
        event.accept()
