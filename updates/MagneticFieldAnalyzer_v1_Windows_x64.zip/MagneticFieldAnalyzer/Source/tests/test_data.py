import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

from analysis_data import DataError, find_measurements, load_measurement, shifted_phase, phase_curve

HEADER = 'Point\tCurrent_set_A\tCurrent_measured_A\tField_mean_mT\tAmplitude_mean_V\tPhase_mean_deg\tAmplitude_std_V\tPhase_circular_std_deg\tLockin_samples\tNI_samples\tComplete\n'


def make_folder(folder, field=(30, 20, 10), phase=(359, 1, 20), amp=(1e-5, 2e-5, 3e-5)):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    lines = [HEADER.rstrip()]
    for i, (b, p, a) in enumerate(zip(field, phase, amp), 1):
        lines.append(f'{i}\t{i}\t{i}\t{b}\t{a}\t{p}\t1e-7\t2\t300\t30000\t1')
    (folder / 'summary.dat').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    (folder / 'experiment.txt').write_text(json.dumps({'application':'Magnetic Lab 1.3', 'lockin': {'signal_unit':'V'},
        'parameters': {'additional': 'Test; not an instruction.'}}, ensure_ascii=False), encoding='utf-8')
    return folder


class DataTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.folder = make_folder(Path(self.temp.name) / 'измерение')

    def tearDown(self):
        self.temp.cleanup()

    def test_measured_field_and_descending_acquisition_order_preserved(self):
        data = load_measurement(self.folder)
        np.testing.assert_array_equal(data.field, [30,20,10])
        np.testing.assert_allclose(data.amplitude, [1e-5,2e-5,3e-5])
        np.testing.assert_array_equal(data.phase, [359,1,20])
        self.assertEqual(data.unit, 'V')

    def test_incomplete_missing_field_excluded_undefined_phase_keeps_amplitude(self):
        p=self.folder/'summary.dat'
        with p.open('a') as out:
            out.write('4\t4\t4\t40\t4e-5\t80\t0\t0\t10\t100\t0\n')
            out.write('5\t5\t5\tnan\t5e-5\t80\t0\t0\t10\t100\t1\n')
            out.write('6\t6\t6\t60\t6e-5\tnan\t0\t0\t10\t100\t1\n')
        d=load_measurement(self.folder)
        np.testing.assert_array_equal(d.field,[30,20,10,60])
        self.assertTrue(np.isnan(d.phase[-1]))
        self.assertEqual(len(d.warnings),3)

    def test_summary_current_milliamps_converted_to_amperes(self):
        p=self.folder/'summary.dat'
        p.write_text(p.read_text().replace('Amplitude_mean_V','Amplitude_mean_mA'), encoding='utf-8')
        d=load_measurement(self.folder)
        self.assertEqual(d.unit,'A')
        np.testing.assert_allclose(d.amplitude,[1e-8,2e-8,3e-8])

    def test_metadata_fallback_uses_precomputed_circular_mean(self):
        (self.folder/'summary.dat').unlink()
        info={'lockin':{'signal_unit':'V'},'points':[
            {'index':2,'result':'complete','field':{'valid':True,'field_mean_mT':-10},'statistics':{'amplitude_mean':2e-6,'phase_mean_deg':0}},
            {'index':1,'result':'complete','field':{'valid':True,'field_mean_mT':20},'statistics':{'amplitude_mean':1e-6,'phase_mean_deg':359}},
            {'index':3,'result':'stopped','field':{'valid':True,'field_mean_mT':30},'statistics':{'amplitude_mean':3e-6,'phase_mean_deg':90}}]}
        (self.folder/'experiment.txt').write_text(json.dumps(info))
        d=load_measurement(self.folder)
        np.testing.assert_array_equal(d.field,[20,-10])
        np.testing.assert_array_equal(d.phase,[359,0])

    def test_point_folder_fallback_excludes_incomplete_attempts(self):
        (self.folder/'summary.dat').unlink()
        (self.folder/'experiment.txt').unlink()
        for name,result in [('point_0001','complete'),('incomplete/point_0002_attempt_0001','complete')]:
            path=self.folder/name
            path.mkdir(parents=True)
            (path/'parameters.txt').write_text(json.dumps({'index':1,'result':result,
                'field':{'valid':True,'field_mean_mT':10},'statistics':{'amplitude_mean':2e-6,'phase_mean_deg':90},
                'lockin':{'signal_unit':'V'}}))
        d=load_measurement(self.folder)
        self.assertEqual(len(d.field),1)

    def test_parent_discovery_returns_runs_without_raw_point_duplicates(self):
        make_folder(Path(self.temp.name)/'другая')
        make_folder(self.folder/'incomplete'/'bad_attempt')
        paths=list(find_measurements(self.temp.name))
        self.assertEqual(set(paths),{self.folder.resolve(),(Path(self.temp.name)/'другая').resolve()})
        self.assertEqual(list(find_measurements(self.folder/'incomplete')),[])

    def test_bad_header_is_clear_error(self):
        (self.folder/'summary.dat').write_text('a b\n1 2\n')
        with self.assertRaisesRegex(DataError,'колонок'):
            load_measurement(self.folder)

    def test_modulo_shift_and_signed_phase(self):
        np.testing.assert_allclose(shifted_phase([359,1,180],5,'wrapped'),[4,6,185])
        np.testing.assert_allclose(shifted_phase([359,1,180],5,'signed'),[4,6,-175])

    def test_unwrap_preserves_missing_phase_and_resets_after_gap(self):
        actual=shifted_phase([350,10,30,np.nan,10,350],-360,'unwrap')
        np.testing.assert_allclose(actual,[-10,10,30,np.nan,-350,-370],equal_nan=True)

    def test_cyclic_line_break_keeps_both_experimental_markers(self):
        x,y=phase_curve([1,2,3],[350,10,30],'wrapped',True)
        np.testing.assert_allclose(x,[1,np.nan,2,3],equal_nan=True)
        np.testing.assert_allclose(y,[350,np.nan,10,30],equal_nan=True)
        x,y=phase_curve([1,2,3],[350,10,30],'wrapped',False)
        self.assertEqual(len(x),3)


if __name__=='__main__':
    unittest.main()
