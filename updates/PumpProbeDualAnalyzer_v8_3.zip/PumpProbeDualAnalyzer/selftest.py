"""Native GUI checks for the sideband model, independent quadratures and exports."""
import json
from pathlib import Path
import platform
import sys
import time
import traceback


def run(report_path):
    import numpy as np
    from PyQt5.QtCore import QTimer
    from PyQt5.QtWidgets import QApplication
    from analyzer.dual_ui import DualAnalysisWindow
    from analyzer import sum_frequency as sf
    from analyzer.dual_export import export_dual
    from analyzer.theory_demo import write_demo,changes_at_reference
    report_path=Path(report_path).resolve();report_path.parent.mkdir(parents=True,exist_ok=True)
    data,notes,truth=write_demo(report_path.parent/'измерения')
    app=QApplication(sys.argv[:1]);app.setStyle('Fusion')
    w=DualAnalysisWindow();w.resize(1280,900)
    w.channels[1].fit_enabled.setChecked(False)
    w.diagnostic_channels['phase2'].fit_enabled.setChecked(False)
    w.bal.setText('-100');w.sig.setText('100');w.show()
    result=dict(ok=False,frozen=bool(getattr(sys,'frozen',False)),python=platform.python_version(),
                platform=platform.platform(),qt_platform=app.platformName())
    start=time.monotonic();ending=False;stage='initial';idle=0
    def finish(ok,detail):
        nonlocal ending
        if ending:return
        ending=True;result.update(ok=ok,detail=detail,elapsed_s=time.monotonic()-start)
        report_path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        w.close()
    oldhook=sys.excepthook
    sys.excepthook=lambda typ,val,tb:finish(False,''.join(traceback.format_exception(typ,val,tb)))
    def tick():
        nonlocal stage,idle
        if ending:return
        if w.job is not None or w.pending or w.timer.isActive() or w.dirty or w.prepared is None:
            idle=0;return
        idle+=1
        if idle<3:return
        try:
            if stage=='initial':
                assert w.results[0] is not None,w.messages.toPlainText()
                assert w.results[0].reference_s>0
                for key in ('x2','y2'):
                    r=w.diagnostic_results.get(key)
                    assert sf.is_modulation(r),(key,w.messages.toPlainText())
                    d=sf.report(r)['modes'][0]
                    expected_changes=changes_at_reference(truth[key.upper()],{'A0_V':25e-6,'Gamma0_per_s':.5e9},w.results[0].reference_s)
                    assert r.reference_s==w.results[0].reference_s
                    for name,expected in expected_changes.items():
                        np.testing.assert_allclose(d[name],expected,rtol=.001,atol=1e-13,err_msg=key+' '+name)
                result['half_factor_delta_f_and_zero_time_verified']=True
                result['common_t_ref_verified']=True
                result['separate_signed_x2_y2_parameters']=True
                control=w.diagnostic_channels['y2']
                control.table.cellWidget(2,1).setValue(-.03)
                control.fixed_checks[0].setChecked(True)
                stage='fixed';idle=0
            elif stage=='fixed':
                np.testing.assert_allclose(w.diagnostic_results['y2'].parameters[2],-.03e9/(2*np.pi),rtol=1e-14)
                assert 'Δω [rad/ns]' in w.diagnostic_channels['y2'].table.item(2,0).text()
                result['fixed_delta_f_verified']=True
                trace=w.figure._quadrature_trace
                assert trace.has_fit
                result['theory_fit_on_xy_plane']=True
                w.title.setText('$$S_{\\omega_e+\\omega_p}(t)$$ · модель ½')
                for key,check in w.overlay_checks.items():check.setChecked(key in ('x1','x2','y2'))
                w.fit_checks['x2'].setChecked(False)
                assert not w.figure.quadrature_fit.get_visible()
                w.fit_checks['x2'].setChecked(True)
                assert w.figure.quadrature_fit.get_visible()
                assert w.apply_labels()
                payloads=w.figure.capture_images(('png','pdf'))
                folder=Path(export_dual(report_path.parent/'результат',w.snapshot(),payloads))
                for filename in ('analysis.txt','measurement_parameters.txt'):
                    text=(folder/filename).read_text(encoding='utf-8')
                    tail=text[text.index('theta_1^osc(t)'):]
                    assert '\nX2\n' in tail and '\nY2\n' in tail
                    assert 'Delta_phi =' in tail and ' deg' in tail and 'Delta_omega =' in tail
                    assert 'Delta_f' not in tail and '2 pi Delta_omega' not in tail
                    assert all(word not in tail for word in ('FFT','t_ref','C =','RMSE','sum_'))
                report=json.loads((folder/'analysis.json').read_text(encoding='utf-8'))
                assert report['sum_frequency']['x2']['sideband_prefactor']==.5
                assert report['sum_frequency']['x2']['modes'][0]['delta_phi_deg']<0
                assert (folder/'modulation_deltas.tsv').exists()
                assert (folder/'analysis.png').stat().st_size>1000
                assert (folder/'analysis.pdf').stat().st_size>1000
                result['reports_end_with_separate_delta_parameters']=True
                result['visible_theory_figure_png_pdf_export']=True
                footer='\n'.join(w.figure._columns)
                assert all(word not in footer for word in ('R²','RMSE','Окно фита'))
                assert 'Γ₀' in footer and 'ω₀' in footer and 'ΔA' in footer
                assert all(word not in footer for word in ('FFT','t_ref','C =','R2 =','Расчёт'))
                assert w.figure._summary==''
                assert all(r'\sum' not in f for f in w.figure._formulas)
                assert all('psi' not in f and r'\psi' not in f for f in w.figure._formulas)
                assert r'\theta_2' in w.figure._formulas[1]
                result['aligned_formulas_and_clean_footer']=True
                for key in ('x2','y2'):
                    assert w.diagnostics[key].signal_unit=='rad'
                    assert w.diagnostic_results[key].native_signal_unit=='rad'
                    assert report['sum_frequency'][key]['native_signal_unit']=='rad'
                    table=np.genfromtxt(folder/(key+'_time.tsv'),names=True,delimiter='\t')
                    assert 'Fit_rad' in table.dtype.names
                    mask=table['Fit_mask'].astype(bool)
                    from analyzer.core import evaluate_fit
                    np.testing.assert_allclose(table['Fit_rad'][mask],evaluate_fit(table['Time_s'][mask],w.diagnostic_results[key]),rtol=1e-8,atol=1e-15)
                assert w.figure.quadrature_axes._dual_unit=='rad'
                result['second_channel_radians_verified']=True
                result['single_sine_compact_report_verified']=True
                assert all('Δω' in block for block in w.figure._columns[1].split('\n\n'))
                assert 'delta_omega_rad_per_s' in (folder/'modulation_deltas.tsv').read_text(encoding='utf-8').splitlines()[0]
                shift=report['sum_frequency']['y2']['modes'][0]['delta_omega_rad_per_s']
                np.testing.assert_allclose(shift,-.03e9,rtol=1e-14)
                result['angular_frequency_shift_verified']=True
                result['export_folder']=str(folder)
                w.grab().save(str(report_path.parent/'preview.png'))
                finish(True,'Verified calibrated X2/Y2 in radians, single-sine formulas, compact four-parameter X1/X2/Y2 captions and TXT, preserved fitted constants, common time reference, fixed angular shift and exact plot/export curves.')
        except Exception:finish(False,traceback.format_exc())
    timer=QTimer();timer.setInterval(30);timer.timeout.connect(tick);timer.start()
    QTimer.singleShot(0,lambda:w.load_paths(data,notes))
    QTimer.singleShot(90000,lambda:finish(False,'Self-test timed out: '+w.messages.toPlainText()))
    app.exec_();sys.excepthook=oldhook
    result['worker_stopped']=not w.pool.activeThreadCount()
    result['ok']=bool(result['ok'] and result['worker_stopped'])
    report_path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return 0 if result['ok'] else 1


if __name__=='__main__':raise SystemExit(run(sys.argv[1] if len(sys.argv)>1 else 'selftest_report.json'))
