"""Dimensional and report checks independent of the GUI display format."""
from dataclasses import replace
import unittest
import numpy as np
from matplotlib.mathtext import MathTextParser
from analyzer import core,fit_summary,sum_frequency as sf
from test_sum_frequency import fixture


class SumFrequencyRadiansTests(unittest.TestCase):
    def calibrated(self,p,factor):
        return replace(p,raw_rad=p.raw_rad*factor,y=p.y*factor,
            background=p.background*factor,spectrum=p.spectrum*factor,signal_unit='rad')

    def test_same_calibration_scales_only_amplitude_and_its_covariance(self):
        p,reference,_=fixture(noise=1e-8)
        volts=sf.fit(p,reference,2.5)
        rad=sf.fit(self.calibrated(p,2.5),reference,2.5,response_factor=2.5)
        transform=np.eye(5);transform[1,1]=2.5;transform[4,4]=2.5
        np.testing.assert_allclose(rad.parameters,transform@volts.parameters,rtol=1e-9,atol=1e-18)
        np.testing.assert_allclose(rad.covariance,transform@volts.covariance@transform.T,rtol=1e-8,atol=1e-27)
        np.testing.assert_allclose(core.evaluate_fit(p.time,rad),2.5*core.evaluate_fit(p.time,volts),rtol=1e-10,atol=1e-18)
        self.assertEqual(rad.native_signal_unit,'rad')
        for key in ('delta_Gamma_per_s','delta_A_V','delta_A_rad','delta_f_Hz','delta_phi_deg'):
            self.assertAlmostEqual(sf.report(rad)['modes'][0][key],sf.report(volts)['modes'][0][key],delta=max(abs(sf.report(volts)['modes'][0][key])*1e-8,1e-18))

    def test_separate_calibration_keeps_the_physical_x1_carrier_in_radians(self):
        p,reference,_=fixture()
        r=sf.fit(self.calibrated(p,4.),reference,2.5,response_factor=4.)
        native=sf.native_carrier(r)
        np.testing.assert_array_equal(native,reference.parameters)
        np.testing.assert_allclose(core.evaluate_fit(p.time,r),p.y*4,rtol=1e-10,atol=1e-18)
        mode=sf.report(r)['modes'][0]
        self.assertAlmostEqual(mode['delta_A_rad'],r.parameters[1])
        self.assertAlmostEqual(mode['delta_A_V'],r.parameters[1]/4.)

    def test_constant_still_fits_but_is_absent_from_requested_summary(self):
        p,reference,_=fixture()
        p=replace(p,y=p.y+1.2e-6,raw_rad=p.raw_rad+1.2e-6)
        result=sf.fit(self.calibrated(p,2.5),reference,2.5,include_constant=True)
        self.assertAlmostEqual(result.parameters[-1],3e-6,places=15)
        reference=replace(reference,parameters=np.r_[reference.parameters[:-1],8e-6])
        data=fit_summary.values(reference,{'x2':result,'y2':result})
        text=fit_summary.text(data)
        for removed in ('C =','t_ref','FFT','RMSE','R²','sum','stderr'):
            self.assertNotIn(removed,text)
        for name in ('X1','X2','Y2'):
            self.assertEqual(len(fit_summary.block(name,data[name]).splitlines()),5)
        self.assertEqual(data['X1']['A_0_rad'],reference.parameters[0])
        self.assertAlmostEqual(data['X1']['omega_0_rad_per_s'],2*np.pi*reference.parameters[1])

    def test_single_sine_math_parses_without_sum_constant_or_reference_caption(self):
        parser=MathTextParser('path')
        for formula in (fit_summary.CARRIER_MATH,fit_summary.RESPONSE_MATH):
            for removed in (r'\sum',r'\psi','C','t_ref'):
                self.assertNotIn(removed,formula)
            for line in formula.splitlines():parser.parse(line)
        self.assertIn(r'\omega_0t',fit_summary.CARRIER_MATH)
        self.assertIn(r'\Delta\omega',fit_summary.RESPONSE_MATH)
        self.assertNotIn(r'2\pi\Delta\omega',fit_summary.RESPONSE_MATH)

    def test_angular_shift_and_standard_error_are_converted_by_two_pi(self):
        p,reference,_=fixture(noise=1e-8)
        r=sf.fit(p,reference,2.5)
        mode=sf.report(r)['modes'][0]
        self.assertAlmostEqual(mode['delta_omega_rad_per_s'],2*np.pi*r.parameters[2])
        self.assertAlmostEqual(mode['delta_omega_rad_per_s_stderr'],2*np.pi*r.errors[2])
        data=fit_summary.values(reference,{'x2':r,'y2':r})
        self.assertEqual(data['X2']['delta_omega_rad_per_s'],mode['delta_omega_rad_per_s'])
        self.assertNotIn('delta_f_Hz',data['X2'])
        self.assertIn('Delta_omega =',fit_summary.text(data))

    def test_angular_formula_reproduces_curve_without_extra_two_pi(self):
        p,reference,_=fixture()
        r=sf.fit(p,reference,2.5)
        amplitude,frequency,phase,tau,_=sf.native_carrier(r)
        dg,da,df,dp,constant=r.parameters
        t=p.time-r.reference_s
        omega0=2*np.pi*frequency;delta_omega=sf.report(r)['modes'][0]['delta_omega_rad_per_s']
        literal=.5*np.exp(-t/tau)*((da-amplitude*dg*t)*np.sin(omega0*t+phase)
            +amplitude*(dp+delta_omega*t)*np.cos(omega0*t+phase))+constant
        np.testing.assert_allclose(core.evaluate_fit(p.time,r),literal,rtol=1e-11,atol=1e-18)

    def test_comparison_uses_angular_shift_and_keeps_cyclic_phase(self):
        from analyzer.dual_export import comparison_text
        c=dict(first_component=0,second_component=0,frequency_x1_hz=1e9,
               frequency_r2_hz=1.1e9,delta_frequency_hz=.1e9,delta_phase_deg=-30.,amplitude_ratio=.2)
        text=comparison_text(c,angular=True)
        self.assertIn('Δω = 0.628319 rad/ns',text)
        self.assertIn('Δφ = 330°',text)
        self.assertNotIn('Δf',text)


if __name__=='__main__':unittest.main()
