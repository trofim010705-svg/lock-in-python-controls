"""Quadrature controls and exact frequency constraints through the live UI."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
os.environ.setdefault('MPLCONFIGDIR','/tmp/dual-v4-ui-mpl')
from pathlib import Path
import tempfile
import time
import unittest
import numpy as np
from PyQt5.QtWidgets import QApplication
from analyzer.dual_ui import DualAnalysisWindow


class DualV4UITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])

    def settle(self,w):
        end=time.monotonic()+80;idle=0
        while time.monotonic()<end:
            self.app.processEvents();time.sleep(.005)
            if w.job is None and not w.pending and not w.timer.isActive() and w.pending_load is None:
                idle+=1
                if idle>10:return
            else:idle=0
        self.fail(w.messages.toPlainText())

    def window(self):
        w=DualAnalysisWindow();w.modulation_enabled.setChecked(False);w.second_mode.setCurrentIndex(0)  # Regression: legacy absolute-frequency controls.
        w.show();w.bal.setText('-100');w.sig.setText('100')
        self.addCleanup(self.close_window,w);return w

    def close_window(self,w):
        w.close();end=time.monotonic()+15
        while w.pool.activeThreadCount() and time.monotonic()<end:
            self.app.processEvents();time.sleep(.005)
        w.close();self.app.processEvents()

    def test_fixed_frequency_survives_reseed_units_and_manual_rotation(self):
        w=self.window();base=Path(__file__).resolve().parents[1]/'examples'
        w.load_paths(base/'dual_demo.dat',base/'dual_demo.comments.txt');self.settle(w)
        self.assertIsNotNone(w.diagnostic_results.get('x2'),w.messages.toPlainText())
        x_original=w.measurement.x2.copy();y_original=w.measurement.y2.copy()
        x1=w.prepared.first.raw_rad.copy();r2=w.prepared.second.raw_rad.copy()
        frequency=1.280123457e9
        control=w.diagnostic_channels['x2'];control.table.cellWidget(1,1).setValue(frequency/1e9)
        control.fixed_checks[0].setChecked(True);self.settle(w)
        self.assertEqual(w.diagnostic_results['x2'].parameters[1],frequency)
        self.assertEqual(w.snapshot()['fixed_frequencies']['x2'],{0:frequency})
        self.assertIn('фикс.',control.table.item(1,2).text())
        results=w.results;w.time_unit.setCurrentIndex(1)
        self.assertIs(w.results,results);self.assertEqual(control.read_fixed_frequencies(),{0:frequency})
        control.table.cellWidget(3,1).setValue(control.table.cellWidget(3,1).value()*1.01);self.settle(w)
        self.assertEqual(control.read_fixed_frequencies(),{0:frequency})
        control.reset_seed();self.settle(w)
        self.assertEqual(w.diagnostic_results['x2'].parameters[1],frequency)
        w.rotation_angle.setValue(25.);self.settle(w)
        self.assertEqual(w.snapshot()['rotation_deg'],25.)
        self.assertEqual(control.read_fixed_frequencies(),{0:frequency})
        self.assertEqual(w.diagnostic_results['x2'].parameters[1],frequency)
        angle=np.deg2rad(25.)
        np.testing.assert_allclose(w.diagnostics['x2'].raw_rad,x_original*np.cos(angle)+y_original*np.sin(angle))
        np.testing.assert_allclose(w.diagnostics['y2'].raw_rad,-x_original*np.sin(angle)+y_original*np.cos(angle))
        np.testing.assert_array_equal(w.measurement.x2,x_original)
        np.testing.assert_array_equal(w.prepared.first.raw_rad,x1)
        np.testing.assert_array_equal(w.prepared.second.raw_rad,r2)

    def create_measurement(self,folder,constant=False):
        x=np.linspace(90,390,401);t=2*(x-x[0])*1e-3/3e8
        sine=np.exp(-t/2e-9)*np.sin(2*np.pi*1.4e9*t+.3)
        x1=3e-6*sine;x1[0]=1e-3
        theta=np.deg2rad(42.)
        oscillation=np.zeros_like(t) if constant else 2e-6*sine
        x2=7e-6+oscillation*np.cos(theta);y2=-4e-6+oscillation*np.sin(theta)
        path=Path(folder)/('constant.dat' if constant else 'collinear.dat')
        notes=path.with_suffix('.comments.txt')
        np.savetxt(path,np.c_[x,x1,np.zeros_like(x),x2,y2],delimiter='\t',
            header='Position\tX1\tY1\tX2\tY2\nSignal unit: V')
        notes.write_text('Synthetic quadratures\nRESULT: complete\n',encoding='utf-8')
        return path,notes

    def test_auto_rotation_is_absolute_and_manual_steering_beats_stale_auto(self):
        w=self.window()
        with tempfile.TemporaryDirectory() as folder:
            path,notes=self.create_measurement(folder)
            w.load_paths(path,notes);self.settle(w)
            r2=w.prepared.second.raw_rad.copy()
            w.request_auto_rotation();w.timer.stop();w.dispatch()
            revision=w.revision;w.reset_rotation()
            self.assertFalse(w.auto_rotation_requested);self.assertGreater(w.revision,revision)
            self.settle(w);self.assertEqual(w.rotation_degrees_used,0.)
            w.request_auto_rotation();self.settle(w)
            self.assertAlmostEqual(w.rotation_degrees_used,42.,delta=1e-7)
            self.assertLess(w.rotation_info['residual_fraction'],1e-20)
            self.assertLess(np.ptp(w.diagnostics['y2'].y),1e-19)
            np.testing.assert_array_equal(w.prepared.second.raw_rad,r2)
            w.request_auto_rotation();w.timer.stop();w.dispatch()
            self.assertIsNotNone(w.job)
            w.rotation_angle.setValue(10.);self.settle(w)
            self.assertEqual(w.rotation_degrees_used,10.)
            self.assertEqual(w.rotation_angle.value(),10.)
            self.assertFalse(w.auto_rotation_requested)
            path,notes=self.create_measurement(folder,constant=True)
            w.load_paths(path,notes);self.settle(w)
            w.request_auto_rotation();self.settle(w)
            self.assertFalse(w.dirty)
            self.assertEqual(w.rotation_degrees_used,10.)
            self.assertIn('Автонастройка:',w.messages.toPlainText())
            # Without a spectral peak, a manually fixed frequency still permits
            # optimizing C and the other model parameters on this valid grid.
            control=w.diagnostic_channels['y2']
            self.assertGreater(control.table.rowCount(),0)
            control.table.cellWidget(1,1).setValue(1.4);control.fixed_checks[0].setChecked(True)
            self.settle(w)
            self.assertIsNotNone(w.diagnostic_results['y2'],w.messages.toPlainText())
            self.assertEqual(w.diagnostic_results['y2'].parameters[1],1.4e9)
            w.rotation_angle.setValue(360.);self.settle(w)
            self.assertEqual(w.rotation_degrees_used,0.)
            self.assertEqual(w.rotation_angle.value(),0.)
            self.assertEqual(w.snapshot()['rotation_info']['angle_deg'],0.)


if __name__=='__main__':unittest.main()
