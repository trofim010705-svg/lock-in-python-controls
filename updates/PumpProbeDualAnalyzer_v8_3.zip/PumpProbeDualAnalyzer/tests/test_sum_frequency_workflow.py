"""Real worker/UI/export test for separate sum-frequency X2 and Y2 fits."""
from pathlib import Path
import json
import tempfile
import time
import unittest
import numpy as np
from PyQt5.QtWidgets import QApplication
from analyzer import core,sum_frequency as sf
from analyzer.dual_ui import DualAnalysisWindow
from analyzer.dual_export import build_dual_report,dual_report_text,export_dual
from analyzer.theory_demo import write_demo,changes_at_reference


class SumFrequencyWorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])
    def settle(self,w):
        end=time.monotonic()+45;idle=None
        while time.monotonic()<end:
            self.app.processEvents()
            if w.job is None and not w.pending and not w.timer.isActive() and w.pending_load is None:
                if idle is None:idle=time.monotonic()
                if time.monotonic()-idle>.05:return
            else:idle=None
            time.sleep(.005)
        self.fail(w.messages.toPlainText())
    def close_window(self,w):
        w.close();end=time.monotonic()+15
        while w.pool.activeThreadCount() and time.monotonic()<end:
            self.app.processEvents();time.sleep(.005)
        w.close();self.app.processEvents()
    def load(self,folder,x1_offset=0.):
        path,notes,truth=write_demo(folder)
        if x1_offset:
            data=np.loadtxt(path);data[:,1]+=x1_offset
            np.savetxt(path,data,delimiter='\t',fmt='%.15g',header='Position_mm X1_V Y1_V X2_V Y2_V\nSignal unit: V')
        w=DualAnalysisWindow();self.addCleanup(self.close_window,w)
        # These auxiliary fits are not the sum-sideband theory; retain their controls.
        w.channels[1].fit_enabled.setChecked(False)
        w.diagnostic_channels['phase2'].fit_enabled.setChecked(False)
        w.bal.setText('-100');w.sig.setText('100')
        w.load_paths(path,notes);self.settle(w)
        self.assertFalse(w.dirty,w.messages.toPlainText())
        self.assertTrue(all(sf.is_modulation(w.diagnostic_results[k]) for k in ('x2','y2')),w.messages.toPlainText())
        return w,truth
    def test_theory_parameters_tables_xy_and_tail_of_both_reports(self):
        with tempfile.TemporaryDirectory() as tmp:
            w,truth=self.load(tmp)
            self.assertTrue(w.modulation_enabled.isChecked())
            self.assertFalse(w.channels[0].fit_enabled.isEnabled())
            self.assertEqual(w.channels[0].components(),1)
            self.assertFalse(w.channels[0].model.isEnabled())
            for key in ('x2','y2'):
                r=w.diagnostic_results[key];mode=sf.report(r)['modes'][0]
                carrier={'A0_V':25e-6,'Gamma0_per_s':.5e9}
                expected=changes_at_reference(truth[key.upper()],carrier,w.results[0].reference_s)
                self.assertEqual(r.reference_s,w.results[0].reference_s)
                for parameter,value in expected.items():
                    self.assertAlmostEqual(mode[parameter],value,delta=max(abs(value)*.001,1e-14),msg=key+' '+parameter)
                table=w.diagnostic_channels[key].table
                self.assertIn('ΔΓ',table.item(0,0).text())
                self.assertIn('Δφ',table.item(3,0).text())
                self.assertIn('Δω [rad/ns]',table.item(2,0).text())
                self.assertIn('°',table.item(3,0).text())
            trace=w.figure._quadrature_trace
            self.assertTrue(trace.has_fit)
            np.testing.assert_allclose(trace.fit_x_v,core.evaluate_fit(trace.fit_time_s,w.diagnostic_results['x2']))
            snapshot=w.snapshot();report=build_dual_report(snapshot);text=dual_report_text(report)
            self.assertEqual(report['sum_frequency']['x2']['sideband_prefactor'],.5)
            self.assertLess(report['sum_frequency']['x2']['modes'][0]['delta_phi_deg'],0)
            tail=text
            self.assertIn('\nX2\n',tail);self.assertIn('\nY2\n',tail)
            for name in ('Gamma_0','omega_0','A_0','phi_0','Delta_Gamma','Delta_A','Delta_omega','Delta_phi'):
                self.assertIn(name+' =',tail)
            for removed in ('t_ref','FFT','C =','RMSE','SUM-FREQUENCY','Mode'):
                self.assertNotIn(removed,tail)
            folder=Path(export_dual(Path(tmp)/'export',snapshot,{}))
            for name in ('analysis.txt','measurement_parameters.txt'):
                saved=(folder/name).read_text(encoding='utf-8')
                self.assertTrue(saved.endswith(tail))
            self.assertEqual(len((folder/'modulation_deltas.tsv').read_text().splitlines()),3)
            self.assertIn('delta_omega_rad_per_s',(folder/'modulation_deltas.tsv').read_text().splitlines()[0])
            self.assertNotIn('Delta_f',text)
            self.assertNotIn('2 pi Delta_omega',text)
            omega=next(param for param in report['diagnostics'][0]['fit']['parameters'] if param['name']=='delta_omega1')
            self.assertEqual(omega['unit'],'rad/s')
            self.assertAlmostEqual(omega['value'],2*np.pi*w.diagnostic_results['x2'].parameters[2])
            data=np.genfromtxt(folder/'x2_time.tsv',delimiter='\t',names=True)
            mask=data['Fit_mask'].astype(bool)
            np.testing.assert_allclose(data['Fit_rad'][mask],core.evaluate_fit(data['Time_s'][mask],w.diagnostic_results['x2']),rtol=1e-10,atol=1e-15)
            self.assertIn('ΔΓ','\n'.join(w.figure._columns))
            self.assertEqual(w.diagnostics['x2'].signal_unit,'rad')
            self.assertEqual(w.diagnostics['y2'].signal_unit,'rad')
            self.assertEqual(w.figure.quadrature_axes._dual_unit,'rad')
            for key in ('x2','y2'):
                np.testing.assert_allclose(w.diagnostics[key].raw_rad,getattr(w.measurement,key)[np.argsort(w.measurement.position)]*w.prepared.second_factor)
    def test_signed_fixed_delta_f_and_carrier_frequency_do_not_conflict(self):
        with tempfile.TemporaryDirectory() as tmp:
            w,truth=self.load(tmp)
            control=w.diagnostic_channels['y2'];control.table.cellWidget(2,1).setValue(-.03)
            control.fixed_checks[0].setChecked(True);self.settle(w)
            expected=-.03e9/(2*np.pi)
            self.assertAlmostEqual(w.diagnostic_results['y2'].parameters[2],expected,delta=1e-8)
            self.assertAlmostEqual(sf.report(w.diagnostic_results['y2'])['modes'][0]['delta_omega_rad_per_s'],-.03e9,delta=1e-8)
            self.assertEqual(w.diagnostic_results['y2'].carrier_parameters_v[1],w.results[0].parameters[1])
            w.time_unit.setCurrentIndex(1);self.app.processEvents()
            self.assertAlmostEqual(control.read_fixed_frequencies()[0],expected,delta=1e-8)
            self.assertAlmostEqual(control.table.cellWidget(2,1).value(),-.03,places=12)
            w.fit_checks['x2'].setChecked(False);self.app.processEvents()
            self.assertFalse(w.figure.quadrature_fit.get_visible())
            w.modulation_enabled.setChecked(False);self.settle(w)
            self.assertFalse(sf.is_modulation(w.diagnostic_results.get('x2')))

    def test_x1_offset_is_still_fitted_and_only_hidden_in_caption(self):
        with tempfile.TemporaryDirectory() as tmp:
            w,_=self.load(tmp,x1_offset=7e-6)
            self.assertAlmostEqual(w.results[0].parameters[-1],7e-6*w.prepared.first_factor,delta=1e-10)
            footer='\n'.join(w.figure._columns)
            self.assertNotIn('C =',footer)
            self.assertEqual(len(w.figure._columns[0].splitlines()),5)
            report=build_dual_report(w.snapshot())
            saved_offset=next(v for v in report['channels'][0]['fit']['parameters'] if v['name']=='C')
            self.assertAlmostEqual(saved_offset['value'],w.results[0].parameters[-1])
            self.assertNotIn('C =',dual_report_text(report))


if __name__=='__main__':unittest.main()
