"""Diagnostics retain source units, shared timing and meaningful phase gaps."""
from dataclasses import replace
import unittest
import numpy as np
from analyzer import core
from analyzer.dual_core import DualMeasurement,prepare_dual
from analyzer.dual_signals import prepare_diagnostics,diagnostics_metadata,DIAGNOSTIC_UNITS
from analyzer.dual_fit_support import diagnostic_fit_input


class DualDiagnosticTests(unittest.TestCase):
    def source(self,phase=None):
        position=np.linspace(0,450,601)
        time=position*2e-3/3e8
        phase=2*np.pi*2e9*time if phase is None else phase(time)
        x1=1e-6*np.sin(2*np.pi*1.2e9*time+.2)
        return DualMeasurement(position,x1,3e-6*np.cos(phase),3e-6*np.sin(phase),
            'diagnostic.dat','diagnostic.comments.txt','','V',[])

    def cfg(self,**changes):
        base=core.Settings(bal_mv=-100,sig_mv=100,zero_mode='manual',zero_mm=0,
            fit_window_mode='manual',fit_min_s=0,fit_max_s=3e-9)
        return replace(base,**changes)

    def test_signed_quadratures_have_original_units_and_known_frequency(self):
        m=self.source();p=prepare_dual(m,self.cfg());d=prepare_diagnostics(p)
        self.assertEqual(set(d),{'x2','y2','phase2'})
        self.assertEqual(DIAGNOSTIC_UNITS,{'x2':'V','y2':'V','phase2':'rad'})
        for key,raw in (('x2',m.x2),('y2',m.y2)):
            np.testing.assert_allclose(d[key].raw_rad,raw,atol=1e-20)
            np.testing.assert_array_equal(d[key].time,p.first.time)
            np.testing.assert_array_equal(d[key].fit_mask,p.first.fit_mask)
            peak=d[key].frequencies[np.argmax(d[key].spectrum)]
            self.assertAlmostEqual(peak/1e9,2,delta=.03)
        expected=np.mod(2*np.pi*2e9*p.first.time,2*np.pi)
        np.testing.assert_allclose(np.angle(np.exp(1j*(d['phase2'].raw_rad-expected))),0.,atol=1e-13)
        self.assertTrue(np.all((d['phase2'].raw_rad>=0)&(d['phase2'].raw_rad<2*np.pi)))

    def test_unwrap_removes_pi_jumps_and_phase_fft_recovers_modulation(self):
        m=self.source(lambda t:3+.8*np.sin(2*np.pi*2e9*t))
        p=prepare_dual(m,self.cfg(background_degree=1,bg_min_s=0,bg_max_s=3e-9))
        d=prepare_diagnostics(p)
        expected=np.mod(np.arctan2(d['y2'].y,d['x2'].y),2*np.pi)
        np.testing.assert_allclose(d['phase2'].raw_rad,expected,atol=2e-15)
        np.testing.assert_array_equal(d['phase2'].raw_rad,d['phase2'].y)
        self.assertEqual(d['phase2'].settings.background_degree,-1)
        self.assertEqual(d['x2'].settings.background_degree,1)
        self.assertIn('Same background',diagnostics_metadata()['phase2'])

    def test_zero_complex_magnitude_breaks_phase_without_fake_fft(self):
        m=self.source();m.x2[300]=m.y2[300]=0
        p=prepare_dual(m,self.cfg());d=prepare_diagnostics(p)
        self.assertTrue(np.isnan(d['phase2'].raw_rad[300]))
        self.assertTrue(np.isnan(d['phase2'].y[300]))
        self.assertEqual(len(d['phase2'].spectrum),0)
        self.assertTrue(np.isfinite(d['phase2'].y[299]))
        self.assertTrue(np.isfinite(d['phase2'].y[301]))
        self.assertGreater(len(d['x2'].spectrum),0)

    def test_phase_zero_outside_window_does_not_disable_valid_interval(self):
        m=self.source(lambda t:3+.8*np.sin(2*np.pi*2e9*t));m.x2[0]=m.y2[0]=0
        p=prepare_dual(m,self.cfg(fit_min_s=.1e-9));d=prepare_diagnostics(p)
        self.assertTrue(np.isnan(d['phase2'].y[0]))
        self.assertGreater(len(diagnostic_fit_input(d['phase2'],'phase2').spectrum),0)

    def test_complex_average_precedes_phase_at_duplicate_positions(self):
        m=self.source()
        m.position=np.r_[m.position[0],m.position]
        m.x1=np.r_[m.x1[0],m.x1]
        m.x2=np.r_[-m.x2[0],m.x2]
        m.y2=np.r_[-m.y2[0],m.y2]
        p=prepare_dual(m,self.cfg());d=prepare_diagnostics(p)
        self.assertAlmostEqual(p.second.raw_rad[0],3e-6)
        self.assertEqual(d['x2'].raw_rad[0],0)
        self.assertEqual(d['y2'].raw_rad[0],0)
        self.assertTrue(np.isnan(d['phase2'].y[0]))
        self.assertEqual(len(d['phase2'].spectrum),0)

    def test_calibration_scales_quadratures_and_preserves_phase_and_quality(self):
        m=self.source();cfg=self.cfg()
        volts=prepare_diagnostics(prepare_dual(m,cfg,'volts'))
        separate=prepare_diagnostics(prepare_dual(m,cfg,'separate',-200,200))
        factor=core.calibration_coefficient(-200,200)
        for key in ('x2','y2'):
            np.testing.assert_allclose(volts[key].raw_rad*factor,separate[key].raw_rad)
            np.testing.assert_allclose(volts[key].spectrum*factor,separate[key].spectrum)
            self.assertEqual(separate[key].signal_unit,'rad')
        np.testing.assert_array_equal(volts['phase2'].raw_rad,separate['phase2'].raw_rad)
        np.testing.assert_array_equal(volts['phase2'].y,separate['phase2'].y)
        self.assertEqual(volts['phase2'].phase_info,separate['phase2'].phase_info)

    def test_short_record_and_constant_signals_do_not_invent_fft(self):
        m=self.source(lambda t:np.ones_like(t)*.7)
        d=prepare_diagnostics(prepare_dual(m,self.cfg()))
        for p in d.values():self.assertEqual(len(p.spectrum),0)
        for key in ('position','x1','x2','y2'):setattr(m,key,getattr(m,key)[:1])
        p=prepare_dual(m,replace(self.cfg(),fit_window_mode='peak_plus_steps'))
        d=prepare_diagnostics(p)
        for p in d.values():
            self.assertEqual(len(p.y),1)
            self.assertEqual(len(p.spectrum),0)


if __name__=='__main__':unittest.main()
