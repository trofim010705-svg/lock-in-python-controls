"""V2 controls edit the existing figure without changing fitted results."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
os.environ.setdefault('MPLCONFIGDIR','/tmp/dual-v2-ui-mpl')
from pathlib import Path
import time
import unittest
from PyQt5.QtWidgets import QApplication
from analyzer.dual_ui import DualAnalysisWindow


class DualV2UITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])
        cls.base=Path(__file__).resolve().parents[1]/'examples'

    def close_window(self,w):
        w.close();end=time.monotonic()+15
        while w.pool.activeThreadCount() and time.monotonic()<end:
            self.app.processEvents();time.sleep(.005)
        w.close();self.app.processEvents()

    def settle(self,w,timeout=45):
        end=time.monotonic()+timeout;idle=None
        while time.monotonic()<end:
            self.app.processEvents()
            if w.job is None and not w.pending and not w.timer.isActive() and w.pending_load is None:
                if idle is None:idle=time.monotonic()
                if time.monotonic()-idle>.05:return
            else:idle=None
            time.sleep(.005)
        self.fail(w.messages.toPlainText())

    def demo(self):
        w=DualAnalysisWindow();w.modulation_enabled.setChecked(False);w.second_mode.setCurrentIndex(0);w.show();self.addCleanup(self.close_window,w)
        w.bal.setText('-100');w.sig.setText('100')
        w.load_paths(self.base/'dual_demo.dat',self.base/'dual_demo.comments.txt');self.settle(w)
        self.assertTrue(all(r is not None for r in w.results),w.messages.toPlainText())
        return w

    def test_all_diagnostic_signals_and_cosmetic_controls_preserve_fits(self):
        w=self.demo();results=w.results;diagnostics=w.diagnostics;revision=w.revision
        self.assertEqual(set(diagnostics),{'x2','y2','phase2'})
        for name in diagnostics:
            self.assertGreater(len(w.figure.diagnostic_points[name].get_ydata()),700)
        self.assertEqual(w.figure.normalized_axes.get_ylabel(),'a.u.')
        w.fit_visible1.setChecked(False);w.fit_visible2.setChecked(False)
        w.footer_visible.setChecked(False)
        w.label_fields['x2.title'].setText(r'$$X_2(t)$$')
        w.label_fields['phase2.ylabel'].setText(r'$\varphi_2$ ({unit})')
        w.label_fields['normalized.ylabel'].setText('a.u.')
        self.assertTrue(w.apply_labels())
        self.app.processEvents()
        self.assertEqual(w.revision,revision);self.assertIs(w.results,results)
        self.assertIs(w.diagnostics,diagnostics);self.assertIsNone(w.job);self.assertFalse(w.pending)
        for artist in (*w.figure.fit_artists,*w.figure.normalized_fits):self.assertFalse(artist.get_visible())
        self.assertFalse(w.figure.footer_axes.get_visible())
        self.assertEqual(w.figure.diagnostic_time_axes['x2'].get_title(),r'$X_2(t)$')
        snapshot=w.snapshot()
        self.assertEqual(snapshot['fit_visible'],(False,False));self.assertFalse(snapshot['footer_visible'])
        self.assertEqual(snapshot['labels']['x2.title'],r'$$X_2(t)$$')
        self.assertEqual(set(snapshot['diagnostics']),{'x2','y2','phase2'})
        w.fit_visible2.setChecked(True);self.assertTrue(w.figure.fit_artists[1].get_visible())
        self.assertFalse(w.figure.fit_artists[0].get_visible())
        w.footer_visible.setChecked(True);self.assertTrue(w.figure.footer_axes.get_visible())
        w.time_unit.setCurrentIndex(1);w.alpha1.setValue(.3)
        self.assertIn('ps',w.figure.normalized_axes.get_xlabel())
        self.assertIs(w.results,results)

    def test_invalid_label_keeps_valid_figure_and_blocks_export_until_repaired(self):
        w=self.demo();results=w.results
        field=w.label_fields['y2.ylabel'];field.setText(r'$$\unknown{x}$$')
        before=w.figure.diagnostic_time_axes['y2'].get_ylabel()
        self.assertFalse(w.apply_labels());self.assertFalse(w.labels_valid)
        self.assertFalse(w.export_button.isEnabled());self.assertFalse(w.save_button.isEnabled())
        self.assertEqual(w.figure.diagnostic_time_axes['y2'].get_ylabel(),before)
        field.setText(r'$Y_2$ ({unit})');self.assertTrue(w.apply_labels())
        self.assertTrue(w.labels_valid);self.assertTrue(w.export_button.isEnabled())
        self.assertIs(w.results,results)
        w.edit_label('y2.ylabel');self.assertIs(w.tabs.currentWidget(),w.labels_page)
        w.reset_labels();self.assertEqual(field.text(),w.figure.default_labels()['y2.ylabel'])
        self.assertIsNone(w.job)


if __name__=='__main__':unittest.main()
