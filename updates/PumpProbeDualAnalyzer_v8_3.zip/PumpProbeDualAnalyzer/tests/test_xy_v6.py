"""Paired quadrature cloud, cached fits and bounded-cost canvas interaction."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch
import tempfile
import time
import unittest
import numpy as np
from PyQt5.QtWidgets import QApplication
from matplotlib.backend_bases import MouseEvent
from analyzer import core
from analyzer.dual_core import load_dual_pair,prepare_dual
from analyzer.dual_ui import DualAnalysisWindow
from analyzer.dual_figure import DualFigure
from analyzer.dual_export import export_dual,build_dual_report
from analyzer.fit_cache import fit_key
from analyzer.quadrature_rotation import prepare_rotated_diagnostics

BASE=Path(__file__).resolve().parents[1]/'examples'


class XYV6Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])

    def settle(self,w):
        end=time.monotonic()+70;idle=0
        while time.monotonic()<end:
            self.app.processEvents();time.sleep(.005)
            if w.job is None and not w.pending and not w.timer.isActive() and w.pending_load is None:
                idle+=1
                if idle>10:return
            else:idle=0
        self.fail(w.messages.toPlainText())

    def close_window(self,w):
        w.close();end=time.monotonic()+15
        while w.pool.activeThreadCount() and time.monotonic()<end:
            self.app.processEvents();time.sleep(.005)
        w.close();self.app.processEvents()

    def prepared(self):
        m=load_dual_pair(BASE/'dual_demo.dat',BASE/'dual_demo.comments.txt')
        p=prepare_dual(m,core.Settings(bal_mv=-100,sig_mv=100,background_degree=1))
        return m,p,prepare_rotated_diagnostics(p,37.)

    def figure(self):
        m,p,d=self.prepared();e=DualFigure();e.resize(1000,800);e.show()
        self.addCleanup(e.close);self.app.processEvents()
        e.set_data(p,(None,None),((.3e9,2e9),)*2,diagnostics=d)
        e.render();self.app.processEvents()
        return m,p,d,e

    def test_xy_pairs_all_experimental_values_in_common_window_and_exports_them(self):
        m,p,d,e=self.figure();x,y=d['x2'],d['y2']
        mask=x.fit_mask&y.fit_mask&np.isfinite(x.y)&np.isfinite(y.y)
        np.testing.assert_array_equal(e.quadrature_points.get_xdata(),x.y[mask])
        np.testing.assert_array_equal(e.quadrature_points.get_ydata(),y.y[mask])
        self.assertNotIn('phase2_fft',e.axes_by_id)
        self.assertNotIn('phase2',e.diagnostic_spectra)
        self.assertIn('quadrature',e.axes_by_id)
        self.assertEqual(e.quadrature_axes.get_aspect(),1.)
        self.assertIn('V',e.quadrature_axes.get_xlabel());self.assertIn('V',e.quadrature_axes.get_ylabel())
        scale=1e-6;transform=e.quadrature_axes.transData
        xy=transform.transform([(0,0),(scale,0),(0,scale)])
        self.assertAlmostEqual(np.linalg.norm(xy[1]-xy[0]),np.linalg.norm(xy[2]-xy[0]),places=7)
        self.assertTrue(e.set_labels({'quadrature.title':r'$$X_2+iY_2$$','quadrature.xlabel':'Q ({unit})'}))
        self.assertIn('Q (',e.quadrature_axes.get_xlabel())
        s=dict(measurement=m,prepared=p,results=(None,None),initials=(None,None),
            bands=((.3e9,2e9),)*2,components=(1,1),pair=(0,0),comparison=None,
            diagnostics=d,diagnostic_results={},rotation_deg=37.,
            fft_peak_enabled={'phase2':True})
        r=build_dual_report(s)
        phase=next(q for q in r['diagnostics'] if q['name']=='phase2')
        self.assertFalse(phase['fft_peaks_included']);self.assertFalse(phase['fft_peaks'])
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(export_dual(Path(tmp)/'xy',s,{}))
            table=np.loadtxt(folder/'quadrature_xy.tsv',skiprows=1)
            np.testing.assert_allclose(table[:,1],x.y)
            np.testing.assert_allclose(table[:,2],y.y)
            np.testing.assert_array_equal(table[:,3].astype(bool),mask)
        e.clear_data();self.assertEqual(len(e.quadrature_points.get_xdata()),0)

    def test_style_draws_reuse_geometry_and_selector_does_not_redraw_entire_figure(self):
        *_,e=self.figure()
        with patch.object(e._layout_engine,'execute',wraps=e._layout_engine.execute) as execute:
            e.set_signal_alphas({'x2':.2});e.render()
            self.assertEqual(execute.call_count,0)
            e.set_title('New title');e.render()
            self.assertEqual(execute.call_count,1)
        with patch.object(e.canvas,'draw',wraps=e.canvas.draw) as draw:
            e.selectors[0].extents=(.6,1.5)
            e.selectors[0].update()
            self.assertEqual(draw.call_count,0)
            selected=[];e.band_changed.connect(lambda index,band:selected.append((index,band)))
            axis=e.fft_axes[0];middle=np.mean(axis.get_ylim())
            for name,x in (('button_press_event',.6),('motion_notify_event',.8),('button_release_event',.8)):
                px,py=axis.transData.transform((x,middle))
                event=MouseEvent(name,e.canvas,px,py,button=1)
                e.canvas.callbacks.process(name,event)
            self.assertEqual(draw.call_count,0)
            self.assertEqual(len(selected),1)
            self.assertAlmostEqual(selected[0][1][0]/1e9,.8,places=7)

    def test_fit_cache_keys_cover_data_mask_spectrum_initial_band_and_constraints(self):
        _,p,_=self.prepared();q=p.first;band=core.automatic_band(q)
        initial=core.initial_parameters(q,1,band);key=fit_key(q,initial,band,{})
        self.assertEqual(key,fit_key(q,initial.copy(),band,{}))
        for field in ('time','y','fit_mask','frequencies','spectrum'):
            values=getattr(q,field).copy()
            if values.dtype==bool:values[0]=not values[0]
            else:values[0]+=1e-20
            self.assertNotEqual(key,fit_key(replace(q,**{field:values}),initial,band,{}),field)
        self.assertNotEqual(key,fit_key(q,initial,band,{0:1.2e9}))
        self.assertNotEqual(key,fit_key(q,initial,(band[0]+1,band[1]),{}))
        changed=initial.copy();changed[2]+=.1
        self.assertNotEqual(key,fit_key(q,changed,band,{}))

    def test_single_channel_edit_reuses_other_fit_and_disabled_fits_do_no_work(self):
        w=DualAnalysisWindow();w.modulation_enabled.setChecked(False);w.second_mode.setCurrentIndex(0);w.show();self.addCleanup(self.close_window,w)
        w.bal.setText('-100');w.sig.setText('100')
        for channel in w.all_channel_controls()[2:]:channel.fit_enabled.setChecked(False)
        w.load_paths(BASE/'dual_demo.dat',BASE/'dual_demo.comments.txt')
        with patch.object(core,'fit',wraps=core.fit) as fitted:
            self.settle(w);self.assertEqual(fitted.call_count,2)
            second=w.results[1]
            with patch.object(w,'render_data',wraps=w.render_data) as render:
                field=w.channels[0].table.cellWidget(2,1);field.setValue(field.value()+1.)
                self.assertEqual(render.call_count,0)
                self.settle(w)
            self.assertEqual(fitted.call_count,3)
            self.assertIs(w.results[1],second);self.assertGreaterEqual(w.cache_hits,1)
            self.assertTrue(all(result is None for result in w.diagnostic_results.values()))
            w.channels[0].fit_enabled.setChecked(False);self.settle(w)
            self.assertEqual(fitted.call_count,3);self.assertIsNone(w.results[0])
            self.assertGreater(len(w.figure.point_artists[0].get_ydata()),700)
            self.assertFalse(w.snapshot()['fit_enabled']['x1'])
            self.assertIn('Расчёт фита отключён.','\n'.join(w.figure._columns))
            w.channels[0].fit_enabled.setChecked(True);self.settle(w)
            self.assertEqual(fitted.call_count,3)  # same inputs recover the cached fit
            self.assertIsNotNone(w.results[0])


if __name__=='__main__':unittest.main()
