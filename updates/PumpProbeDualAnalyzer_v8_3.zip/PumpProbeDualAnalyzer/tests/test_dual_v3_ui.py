"""Five fit controls and presentation choices use real synthetic data/workers."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
os.environ.setdefault('MPLCONFIGDIR','/tmp/dual-v3-ui-mpl')
from pathlib import Path
import tempfile
import time
import unittest
import numpy as np
from PyQt5.QtWidgets import QApplication
from analyzer.dual_ui import DualAnalysisWindow


class DualV3UITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])
        cls.base=Path(__file__).resolve().parents[1]/'examples'

    def close_window(self,w):
        w.close();end=time.monotonic()+20
        while w.pool.activeThreadCount() and time.monotonic()<end:
            self.app.processEvents();time.sleep(.005)
        w.close();self.app.processEvents()
        self.assertEqual(w.pool.activeThreadCount(),0)

    def settle(self,w,timeout=90):
        end=time.monotonic()+timeout;idle=None
        while time.monotonic()<end:
            self.app.processEvents()
            if w.job is None and not w.pending and not w.timer.isActive() and w.pending_load is None:
                if idle is None:idle=time.monotonic()
                if time.monotonic()-idle>.05:return
            else:idle=None
            time.sleep(.005)
        self.fail(w.messages.toPlainText())

    def demo(self,data=None,notes=None):
        w=DualAnalysisWindow();w.modulation_enabled.setChecked(False);w.second_mode.setCurrentIndex(0);w.show();self.addCleanup(self.close_window,w)
        w.bal.setText('-100');w.sig.setText('100')
        w.load_paths(data or self.base/'dual_demo.dat',notes or self.base/'dual_demo.comments.txt')
        self.settle(w)
        self.assertTrue(all(r is not None for r in w.results),w.messages.toPlainText())
        self.assertTrue(all(r is not None for r in w.diagnostic_results.values()),w.messages.toPlainText())
        return w

    def test_five_fits_overlay_choice_and_peak_flags_do_not_recalculate(self):
        w=self.demo();original=w.results;diagnostic=dict(w.diagnostic_results);revision=w.revision
        self.assertEqual(set(diagnostic),{'x2','y2','phase2'})
        for key,control in w.diagnostic_channels.items():self.assertEqual(control.table.rowCount(),5)
        for key,check in w.overlay_checks.items():check.setChecked(key in ('x2','phase2'))
        w.signal_alpha_fields['x2'].setValue(.2);w.signal_alpha_fields['phase2'].setValue(.75)
        for check in w.fit_checks.values():check.setChecked(False)
        for key,check in w.peak_checks.items():check.setChecked(key=='y2')
        self.app.processEvents()
        self.assertIs(w.results,original)
        self.assertEqual(w.revision,revision);self.assertIsNone(w.job);self.assertFalse(w.pending)
        for key,result in diagnostic.items():self.assertIs(w.diagnostic_results[key],result)
        self.assertFalse(w.figure.normalized_points[0].get_visible())
        self.assertFalse(w.figure.normalized_points[1].get_visible())
        self.assertTrue(w.figure.normalized_diagnostic_points['x2'].get_visible())
        self.assertFalse(w.figure.normalized_diagnostic_points['y2'].get_visible())
        self.assertTrue(w.figure.normalized_diagnostic_points['phase2'].get_visible())
        self.assertAlmostEqual(w.figure.normalized_diagnostic_points['x2'].get_alpha(),.2)
        for line in (*w.figure.fit_artists,*w.figure.normalized_fits,*w.figure.diagnostic_fit_artists.values(),*w.figure.normalized_diagnostic_fits.values()):
            self.assertFalse(line.get_visible())
        snapshot=w.snapshot()
        self.assertEqual(set(snapshot['overlay_signals']),{'x2','phase2'})
        self.assertEqual(snapshot['fft_peak_enabled'],{key:key=='y2' for key in w.peak_checks})
        self.assertTrue(all(value is False for value in snapshot['fit_visibility'].values()))
        self.assertIsNotNone(snapshot['comparison']) # original X1/R2 calculation remains available
        w.fit_checks['x2'].setChecked(True)
        self.assertTrue(w.figure.diagnostic_fit_artists['x2'].get_visible())
        self.assertTrue(w.figure.normalized_diagnostic_fits['x2'].get_visible())

    def test_manual_x2_seed_and_phase_segment_are_in_completed_snapshot(self):
        with tempfile.TemporaryDirectory() as tmp:
            data=np.loadtxt(self.base/'dual_demo.dat')
            data[400,3:5]=0 # actual missing phase splits two independent unwrap segments
            path=Path(tmp)/'gap.dat';notes=Path(tmp)/'gap.comments.txt'
            np.savetxt(path,data,delimiter='\t',header='Position X1 Y1 X2 Y2\nSignal unit: V')
            notes.write_text('Synthetic phase gap\nRESULT: complete\n',encoding='utf-8')
            w=self.demo(path,notes)
            p=w.diagnostic_fit_prepared['phase2']
            self.assertGreater(p.time[p.fit_mask][0],1e-9)
            self.assertTrue(np.isfinite(p.y[p.fit_mask]).all())
            self.assertEqual(w.diagnostic_results['phase2'].reference_s,p.time[p.fit_mask][0])
            control=w.diagnostic_channels['x2'];field=control.table.cellWidget(1,1)
            field.setValue(field.value()+.03);expected=control.read_parameters().copy()
            self.assertTrue(w.dirty);self.assertEqual(w.diagnostic_results,{})
            self.settle(w)
            self.assertIsNotNone(w.diagnostic_results['x2'],w.messages.toPlainText())
            snapshot=w.snapshot()
            np.testing.assert_allclose(snapshot['diagnostic_initials']['x2'],expected)
            self.assertEqual(snapshot['diagnostic_components']['x2'],1)
            self.assertEqual(len(snapshot['initials']),2)
            self.assertEqual(snapshot['diagnostic_results']['phase2'].reference_s,p.time[p.fit_mask][0])


if __name__=='__main__':unittest.main()
