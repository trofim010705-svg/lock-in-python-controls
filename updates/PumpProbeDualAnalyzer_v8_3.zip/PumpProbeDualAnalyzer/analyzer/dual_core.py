"""Shared-grid X1 / |X2+iY2| preparation and explicit cross-channel comparison.

Prepared's legacy *_rad names hold values in the accompanying channel unit.
The source measurement and the former single-channel program are not modified.
"""
from dataclasses import dataclass, replace
import re
import numpy as np
from . import core
from .io import Measurement, read_text


@dataclass
class DualMeasurement:
    position: np.ndarray
    x1: np.ndarray
    x2: np.ndarray
    y2: np.ndarray
    data_path: str
    notes_path: str
    notes: str
    signal_unit: str
    warnings: list


@dataclass
class DualPrepared:
    first: core.Prepared
    second: core.Prepared
    first_unit: str
    second_unit: str
    first_factor: float
    second_factor: float
    measurement: DualMeasurement


def load_dual_pair(data_path, notes_path):
    """Read fixed Position | X1 | Y1 | X2 | Y2 columns without shifting blanks.

    Non-finite rows are removed jointly so both channels keep one measured grid.
    Y1 is deliberately not used and need not contain numeric data.
    """
    text, notes = read_text(data_path), read_text(notes_path)
    rows, warnings, started = [], [], False
    for line_number, line in enumerate(text.splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue
        parts = (re.split(r'[\t;]', line.strip(' \r\n'))
                 if '\t' in line or ';' in line else stripped.split())
        try:
            # Index explicitly: an empty X2/Y2 never borrows an adjacent value.
            values = [float(parts[i].strip().replace(',', '.')) for i in (0, 1, 3, 4)]
        except (ValueError, IndexError):
            numeric = False
            for i in (0, 1, 3, 4):
                if i < len(parts):
                    try:
                        float(parts[i].strip().replace(',', '.')); numeric = True
                    except ValueError:
                        pass
            if started or numeric:
                raise ValueError(f'Строка {line_number}: нужны корректные столбцы Позиция | X1 | Y1 | X2 | Y2; проверьте координату, X1, X2 и Y2.')
            if line_number > 100:
                raise ValueError('Численные данные не найдены в первых 100 строках')
            continue
        started = True
        rows.append(values)
        if len(rows) > 1000000:
            raise ValueError('Поддерживается не более 1 000 000 точек')
    if not rows:
        raise ValueError('Файл данных пуст: нет численных точек с X1, X2 и Y2.')
    declared = re.findall(r'^Points saved:\s*(\d+)\s*$', notes, flags=re.MULTILINE)
    if declared and int(declared[-1]) != len(rows):
        warnings.append(f'В параметрах Points saved={declared[-1]}, в .dat прочитано {len(rows)} численных строк.')
    outcomes = re.findall(r'^RESULT:\s*(\w+)', notes, flags=re.MULTILINE)
    if outcomes and outcomes[-1].lower() != 'complete':
        warnings.append(f'Измерение завершено со статусом RESULT={outcomes[-1]}; сохранено {len(rows)} точек.')
    data = np.asarray(rows, dtype=float)
    finite = np.isfinite(data).all(axis=1)
    if not finite.all():
        warnings.append(f'Для общей сетки обоих каналов исключено строк с NaN/Inf: {np.count_nonzero(~finite)}.')
        data = data[finite]
    if not len(data):
        raise ValueError('В файле нет общих конечных координат и сигналов X1, X2, Y2.')
    unit = 'неизвестна'
    match = re.search(r'(?:Signal unit:\s*|"unit"\s*:\s*")([VA])', text+'\n'+notes)
    if match:
        unit = match.group(1)
    else:
        lines = text.splitlines()
        for i, line in enumerate(lines[:-1]):
            if 'Position' in line and 'X1' in line:
                units = lines[i+1].split()
                if len(units) >= 5:
                    used = [units[j] for j in (1, 3, 4)]
                    if all(u == 'V' for u in used):
                        unit = 'V'
                    elif any(u == 'A' for u in used):
                        unit = 'A'
    return DualMeasurement(data[:, 0], data[:, 1], data[:, 2], data[:, 3],
                           str(data_path), str(notes_path), notes, unit, warnings)


def prepare_dual(measurement, cfg, second_mode='volts', second_bal_mv=None, second_sig_mv=None):
    """Use X1's zero and interval for both fits, including duplicate coordinates.

    R2 is calculated for each raw row BEFORE averaging duplicate positions.
    The phase of X2+iY2 is not the phase of the fitted R2 oscillation.
    """
    if second_mode not in ('volts', 'same', 'separate'):
        raise ValueError('Режим второго канала: volts, same или separate')
    arrays = [np.asarray(getattr(measurement, key), dtype=float)
              for key in ('position', 'x1', 'x2', 'y2')]
    if any(a.ndim != 1 for a in arrays) or not len(arrays[0]) or any(a.shape != arrays[0].shape for a in arrays):
        raise ValueError('Координата, X1, X2 и Y2 должны иметь одинаковую непустую длину')
    if not all(np.isfinite(a).all() for a in arrays):
        raise ValueError('Для общей сетки нужны конечные координаты, X1, X2, Y2')
    if measurement.signal_unit == 'A':
        raise ValueError('Для этой калибровки сигналы X1, X2 и Y2 должны быть в вольтах.')
    first_factor = cfg.rad_per_unit
    first_measurement = Measurement(arrays[0], arrays[1], measurement.data_path,
        measurement.notes_path, measurement.notes, measurement.signal_unit, measurement.warnings)
    first = replace(core.prepare(first_measurement, cfg), signal_unit='rad')
    magnitude = np.hypot(arrays[2], arrays[3])
    if not np.isfinite(magnitude).all():
        raise ValueError('Переполнение при вычислении R2 = hypot(X2, Y2)')
    common_cfg = replace(first.settings, zero_mode='manual', fit_window_mode='manual')
    preparation_cfg = common_cfg
    if common_cfg.fit_min_s >= common_cfg.fit_max_s:
        # core's manual-window validation needs a nonzero interval even for a
        # scan with one available point; restore the real common mask below.
        preparation_cfg = replace(common_cfg, fit_min_s=float(np.nextafter(common_cfg.fit_min_s, -np.inf)),
            fit_max_s=float(np.nextafter(common_cfg.fit_max_s, np.inf)))
    second_measurement = replace(first_measurement, x1=magnitude)
    second = core.prepare(second_measurement, preparation_cfg)
    if second_mode == 'volts':
        second_factor, second_unit = 1., 'V'
    elif second_mode == 'same':
        second_factor, second_unit = first_factor, 'rad'
    else:
        second_factor = core.calibration_coefficient(second_bal_mv, second_sig_mv)
        second_unit = 'rad'
    relative = second_factor / first_factor
    second = replace(second, raw_rad=second.raw_rad*relative, y=second.y*relative, signal_unit=second_unit,
        background=second.background*relative, spectrum=second.spectrum*relative,
        # Preserve the exact X1 mask even when its auto-window lies beyond data.
        fit_mask=first.fit_mask.copy(), settings=replace(common_cfg,
            bal_mv=second_bal_mv if second_mode == 'separate' else common_cfg.bal_mv,
            sig_mv=second_sig_mv if second_mode == 'separate' else common_cfg.sig_mv))
    if not np.array_equal(first.time, second.time):
        raise ValueError('Не удалось получить общую сетку обоих каналов')
    # When X1's skipped interval is empty, core's manual single-point mask must
    # not leave a spectrum produced for a different interval (normally <8 anyway).
    if first.fit_mask.sum() < 8:
        second = replace(second, frequencies=np.array([]), spectrum=np.array([]), resolution_hz=float('nan'))
    else:
        interval = second.y[second.fit_mask]
        numerical_floor = 64*np.finfo(float).eps*float(np.max(np.abs(second.raw_rad)))
        if np.ptp(interval) <= numerical_floor:
            second = replace(second, frequencies=np.array([]), spectrum=np.array([]),
                resolution_hz=float('nan'), warnings=second.warnings+[
                    'R2 в выбранном окне постоянен в пределах машинной точности; осцилляционная частота и фаза не определены.'])
    return DualPrepared(first, second, 'rad', second_unit, first_factor, second_factor, measurement)


def _component_at(result, index, reference_s):
    parameters = np.asarray(result.parameters, dtype=float)
    count = (len(parameters)-1)//4
    if len(parameters) != 4*count+1 or not isinstance(index, (int, np.integer)) or not 0 <= index < count:
        raise ValueError('Выберите существующую компоненту фита')
    amplitude, frequency, phase, tau = parameters[4*index:4*index+4]
    if not np.isfinite([amplitude, frequency, phase, tau, result.reference_s, reference_s]).all() or tau <= 0:
        raise ValueError('Некорректные параметры фита для сравнения')
    shift = reference_s - result.reference_s
    with np.errstate(over='ignore', invalid='ignore'):
        amplitude = float(amplitude*np.exp(-shift/tau))
    if not np.isfinite(amplitude):
        raise ValueError('Переполнение амплитуды при переносе начала отсчёта')
    phase = float(phase + 2*np.pi*frequency*shift)
    if not np.isfinite(phase):
        raise ValueError('Переполнение фазы при переносе начала отсчёта')
    if amplitude < 0:
        amplitude = -amplitude; phase += np.pi
    return amplitude, float(frequency), phase


def compare_fits(first_result, second_result, first_factor, second_factor,
                 first_component=0, second_component=0, reference_s=None):
    """R2 minus X1 phase; voltage-equivalent A_R2/A_X1 before normalization.

    A common reference is mandatory for phase/amplitude comparisons. Default is
    the later fit reference, avoiding backward extrapolation of tiny lifetimes.
    For different frequencies delta_phase is an instantaneous value at t_ref.
    Cross-channel calibration has no phase shift in this scalar conversion.
    """
    if not np.isfinite([first_factor, second_factor]).all() or min(first_factor, second_factor) <= 0:
        raise ValueError('Коэффициенты калибровки должны быть положительными и конечными')
    if reference_s is None:
        reference_s = max(first_result.reference_s, second_result.reference_s)
    reference_s = float(reference_s)
    a1, f1, p1 = _component_at(first_result, first_component, reference_s)
    a2, f2, p2 = _component_at(second_result, second_component, reference_s)
    a1v, a2v = a1/first_factor, a2/second_factor
    variable_signal = all(np.isfinite(getattr(result,'r_squared',1.)) for result in (first_result,second_result))
    resolved = a1 > 0 and a2 > 0 and variable_signal
    delta = float((p2-p1+np.pi) % (2*np.pi)-np.pi) if resolved else None
    with np.errstate(over='ignore', divide='ignore', invalid='ignore'):
        ratio = float(np.divide(a2v, a1v)) if a1v > 0 and variable_signal else None
    if ratio is not None and not np.isfinite(ratio):
        ratio = None
    return dict(reference_s=reference_s, first_component=int(first_component), second_component=int(second_component),
        frequency_x1_hz=f1, frequency_r2_hz=f2, delta_frequency_hz=f2-f1,
        amplitude_x1=a1, amplitude_r2=a2, amplitude_x1_v=float(a1v), amplitude_r2_v=float(a2v),
        amplitude_ratio=ratio, delta_phase_rad=delta,
        delta_phase_deg=float(np.rad2deg(delta)) if delta is not None else None,
        phase_x1_rad=float((p1+np.pi)%(2*np.pi)-np.pi),
        phase_r2_rad=float((p2+np.pi)%(2*np.pi)-np.pi),
        amplitude_ratio_definition='A_R2[V] / A_X1[V], before normalization, at reference_s',
        phase_definition='phi_R2 - phi_X1 wrapped to [-pi, pi), at reference_s; this is the phase of fitted R2, not atan2(Y2,X2)',
        phase_time_dependence='delta_phi(t) = delta_phi(reference_s) + 2*pi*(f_R2-f_X1)*(t-reference_s)',
        uncertainties_note='Cross-channel uncertainties are not propagated; channels from one measurement can be correlated.')


def normalize_signals(prepared, result):
    """Subtract fitted C and scale by max |fit-C| on actual fit-window points.

    Return full-length points, fit-at-points (NaN outside fit window), and scale.
    Normalization is for display only and never changes amplitude comparisons.
    """
    mask = np.asarray(prepared.fit_mask, dtype=bool)
    if mask.shape != prepared.time.shape or not np.any(mask):
        raise ValueError('Нет точек в окне фита для нормировки')
    interval=np.asarray(prepared.y)[mask]
    floor=64*np.finfo(float).eps*float(np.max(np.abs(interval)))
    if np.ptp(interval)<=max(floor,np.finfo(float).tiny):
        raise ValueError('Постоянный сигнал: осцилляционная нормировка по фиту не определена')
    fitted = core.evaluate_fit(prepared.time[mask], result)
    offset = float(result.parameters[-1])
    oscillation = fitted-offset
    scale = float(np.max(np.abs(oscillation)))
    if not np.isfinite(scale) or scale <= np.finfo(float).tiny:
        raise ValueError('Нулевая или некорректная амплитуда: нормировка невозможна')
    points = (prepared.y-offset)/scale
    fit_at_points = np.full_like(prepared.time, np.nan, dtype=float)
    fit_at_points[mask] = oscillation/scale
    return points, fit_at_points, scale
