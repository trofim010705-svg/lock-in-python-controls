"""Standalone dual-channel analysis UI; all I/O and optimization run in a worker."""
from pathlib import Path
from threading import Event
import numpy as np
from PyQt5.QtCore import Qt, QTimer, QThreadPool
from PyQt5.QtWidgets import (QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QFormLayout,
    QGroupBox,QTabWidget,QScrollArea,QSplitter,QLabel,QLineEdit,QDoubleSpinBox,
    QSpinBox,QComboBox,QCheckBox,QPushButton,QPlainTextEdit,QFileDialog,QTableWidget,
    QTableWidgetItem,QHeaderView,QAbstractItemView)
from . import core
from .dual_core import load_dual_pair,prepare_dual,compare_fits
from .quadrature_rotation import prepare_rotated_diagnostics, auto_rotation, rotation_metadata
from .dual_fit_support import diagnostic_fit_input
from .io import associated_notes
from .dual_figure import DualFigure
from .dialogs import ExportFolderDialog
from .tasks import Job
from .presentation import angle_unit
from .fit_cache import fit_key

SIGNAL_NAMES={'x1':'X1','r2':'R2','x2':'X2','y2':'Y2','phase2':'φ₂'}
DIAGNOSTIC_KEYS=('x2','y2','phase2')

STYLE='''
QMainWindow {background:#edf2f7;}
QGroupBox {background:white;border:1px solid #d8e2ec;border-radius:7px;margin-top:12px;padding:10px;}
QGroupBox::title {subcontrol-origin:margin;left:10px;color:#25435d;padding:0 4px;}
QLineEdit,QComboBox,QSpinBox,QDoubleSpinBox {min-height:25px;}
QPushButton {padding:7px 10px;background:#f5f8fc;color:#194764;border:1px solid #bfcedb;border-radius:4px;}
QPushButton#primary {background:#126e96;color:white;}
QPushButton:disabled {color:#93a2ae;}
QTabBar::tab {padding:9px 15px;min-height:22px;}
QTableWidget {background:white;gridline-color:#e1e8f0;}
'''


def spin(value=0,low=-1e12,high=1e12,decimals=6):
    w=QDoubleSpinBox();w.setDecimals(decimals);w.setRange(low,high);w.setValue(value)
    w.setKeyboardTracking(False);w.setSingleStep(.01);return w


def numerical(field):
    value=field.value() if hasattr(field,'value') else float(field.text().strip().replace(',','.'))
    if not np.isfinite(value):raise ValueError('Числа должны быть конечными.')
    return value


class ChannelControls(QWidget):
    """Editable, SI-backed initial parameters for a single independent fit."""
    def __init__(self,owner,index):
        super().__init__();self.owner,self.index=owner,index;self.scales=[];self.fixed_values={};self.fixed_checks={}
        layout=QVBoxLayout(self)
        group=QGroupBox('Модель и полоса FFT');form=QFormLayout(group)
        self.fit_enabled=QCheckBox('Рассчитывать фит этого сигнала');self.fit_enabled.setChecked(True)
        self.fit_enabled.setToolTip('Отключите для шумового канала: данные и FFT останутся, оптимизация не запускается.')
        form.addRow(self.fit_enabled)
        self.model=QComboBox();self.model.addItems(['Один затухающий синус + C','Сумма затухающих синусов + C'])
        self.count=QSpinBox();self.count.setRange(2,6);self.count.setValue(2)
        form.addRow('Модель',self.model);form.addRow('Число синусов',self.count)
        self.auto_band=QCheckBox('Автоматическая полоса FFT');self.auto_band.setChecked(True);form.addRow(self.auto_band)
        self.low,self.high=spin(.3,0,1e6),spin(2,0,1e6)
        row=QHBoxLayout();row.addWidget(self.low);row.addWidget(self.high);form.addRow('Полоса, GHz',row)
        self.peak=QLabel('Нет данных');self.peak.setWordWrap(True);form.addRow(self.peak)
        layout.addWidget(group)
        group=QGroupBox('Стартовые параметры и результат');inner=QVBoxLayout(group)
        note=QLabel('A ≥ 0; τ > 0. A и φ относятся к началу выбранного участка фита.\nФлажок «Фикс. f» удерживает выбранную частоту точно; остальные параметры подбираются.\nЧисло подтверждается Enter или выходом из поля.')
        self.note=note;note.setWordWrap(True);inner.addWidget(note)
        self.table=QTableWidget(0,4);self.table.setHorizontalHeaderLabels(['Параметр','Старт','Фит ± σ','Фикс. f'])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch)
        self.table.setMinimumHeight(350);self.table.setWordWrap(False);inner.addWidget(self.table)
        self.seed=QPushButton('Обновить старт по FFT');inner.addWidget(self.seed)
        layout.addWidget(group);layout.addStretch()
        self.model.currentIndexChanged.connect(self.model_changed);self.count.valueChanged.connect(self.model_changed)
        self.auto_band.toggled.connect(self.band_changed)
        self.low.editingFinished.connect(self.manual_band);self.high.editingFinished.connect(self.manual_band)
        self.seed.clicked.connect(self.reset_seed);self.count.setEnabled(False)
        self.fit_enabled.toggled.connect(self.owner.invalidate)
        if index==4:
            group.setTitle('Фит фазы (спектр используется только для старта)')
            self.auto_band.setText('Автоматическая полоса старта фита')

    def components(self):return 1 if self.model.currentIndex()==0 else self.count.value()
    def model_changed(self,*_):
        self.count.setEnabled(self.model.currentIndex()==1);self.owner.manual_initials[self.index]=None
        self.fixed_values={i:v for i,v in self.fixed_values.items() if i<self.components()}
        self.table.setRowCount(0);self.fixed_checks={}
        self.owner.invalidate()
    def reset_seed(self):
        self.owner.manual_initials[self.index]=None;self.owner.invalidate()
    def band_changed(self,*_):
        self.low.setEnabled(not self.auto_band.isChecked());self.high.setEnabled(not self.auto_band.isChecked())
        self.reset_seed()
    def manual_band(self):
        self.auto_band.blockSignals(True);self.auto_band.setChecked(False);self.auto_band.blockSignals(False)
        self.reset_seed()
    def band(self):return numerical(self.low)*1e9,numerical(self.high)*1e9
    def set_band(self,band):
        self.low.setValue(band[0]/1e9);self.high.setValue(band[1]/1e9)
    def read_parameters(self):
        return np.asarray([self.table.cellWidget(i,1).value()*self.scales[i] for i in range(self.table.rowCount())])
    def read_fixed_frequencies(self):
        return {i:float(value) for i,value in self.fixed_values.items() if i<self.components()}
    def fixed_toggled(self,component,checked):
        if checked:
            self.fixed_values[component]=self.table.cellWidget(4*component+1,1).value()*1e9
        else:self.fixed_values.pop(component,None)
        parameters=self.read_parameters().copy()
        if not checked:
            low,high=self.band()
            if not low<=parameters[4*component+1]<=high:
                parameters[4*component+1]=(low+high)/2
                field=self.table.cellWidget(4*component+1,1)
                field.blockSignals(True);field.setValue(parameters[4*component+1]/1e9);field.blockSignals(False)
        self.owner.manual_initials[self.index]=parameters;self.owner.invalidate()
    def changed_parameter(self,*_):
        parameters=self.read_parameters()
        for component in tuple(self.fixed_values):
            if 4*component+1<len(parameters):self.fixed_values[component]=float(parameters[4*component+1])
        self.owner.manual_initials[self.index]=parameters.copy();self.owner.invalidate()
    def populate(self,parameters,result,prepared,unit):
        if parameters is None:
            self.table.setRowCount(0);return
        parameters=np.asarray(parameters,dtype=float).copy()
        for component,value in self.fixed_values.items():
            if 4*component+1<len(parameters):parameters[4*component+1]=value
        values=prepared.y[prepared.fit_mask] if prepared.fit_mask.any() else prepared.y
        values=values[np.isfinite(values)]
        if not len(values):values=np.array([0.])
        afactor,aunit=angle_unit([np.std(values)])
        factor=self.owner.time_factor;count=(len(parameters)-1)//4
        self.scales=[];row_units=[]
        for i,value in enumerate(parameters):
            if i==len(parameters)-1 or i%4==0:
                scale,selected_unit=(np.pi/180.,'°') if unit=='deg' else (angle_unit([value]) if value else (afactor,aunit))
                self.scales.append(scale);row_units.append(selected_unit.replace('rad','V') if unit=='V' else selected_unit)
            else:
                self.scales.append({1:1e9,2:np.pi/180.,3:factor}[i%4]);row_units.append({1:'GHz',2:'°',3:self.owner.time_unit.currentText()}[i%4])
        self.table.setRowCount(len(parameters));self.fixed_checks={}
        for i,(parameter,scale) in enumerate(zip(parameters,self.scales)):
            name=core.names(count)[i][0];u=row_units[i]
            label=QTableWidgetItem(f'{name} [{u}]');label.setFlags(label.flags()&~Qt.ItemIsEditable);self.table.setItem(i,0,label)
            display=parameter/scale
            cyclic=(i<len(parameters)-1 and i%4==2) or (unit=='deg' and i==len(parameters)-1)
            if cyclic:display=display%360.
            field=spin(display,decimals=9 if i<len(parameters)-1 and i%4==1 else 6)
            if i<len(parameters)-1 and i%4 in (0,1):field.setMinimum(0)
            if i<len(parameters)-1 and i%4==3:field.setMinimum(.000001)
            self.table.setCellWidget(i,1,field);field.valueChanged.connect(self.changed_parameter)
            text=''
            if result is not None:
                err=result.errors[i]/scale;unc=f'{err:.3g}' if np.isfinite(err) else '—'
                shown=result.parameters[i]/scale
                if cyclic:shown=shown%360.
                text=f'{shown:.6g} ± {unc}'
                if i<len(parameters)-1 and i%4==1 and i//4 in getattr(result,'fixed_frequencies',{}):
                    text=f'{result.parameters[i]/scale:.9g} (фикс.)'
            item=QTableWidgetItem(text);item.setFlags(item.flags()&~Qt.ItemIsEditable);self.table.setItem(i,2,item)
            if i<len(parameters)-1 and i%4==1:
                component=i//4;check=QCheckBox();check.setChecked(component in self.fixed_values)
                check.setToolTip('Частота в этой строке не меняется при оптимизации; ввод в GHz.')
                self.table.setCellWidget(i,3,check);self.fixed_checks[component]=check
                check.toggled.connect(lambda checked,c=component:self.fixed_toggled(c,checked))
            else:
                self.table.removeCellWidget(i,3)
                item=QTableWidgetItem('');item.setFlags(item.flags()&~Qt.ItemIsEditable);self.table.setItem(i,3,item)


class DualAnalysisWindow(QMainWindow):
    def __init__(self):
        super().__init__();self.setWindowTitle('Pump–Probe Dual Analyzer v8.3 · X1 / X2 / Y2 в rad')
        self._animation_windows=[]
        self.resize(1620,1080);self.setStyleSheet(STYLE)
        self.measurement=self.prepared=None;self.results=(None,None);self.initials=(None,None);self.diagnostics={}
        self.bands=((.3e9,2e9),(.3e9,2e9));self.manual_initials=[None]*5
        self.diagnostic_results={};self.diagnostic_initials={};self.diagnostic_bands={}
        self.diagnostic_fit_prepared={};self.diagnostic_components={key:1 for key in DIAGNOSTIC_KEYS}
        self.auto_rotation_requested=False;self.rotation_degrees_used=0.;self.rotation_info={}
        self.fixed_frequencies_used={key:{} for key in SIGNAL_NAMES}
        self._fit_cache={};self.cache_hits=0
        self.revision=0;self.job_revision=0;self.job=None;self.pending=False;self.pending_load=None;self.dirty=True;self.closing=False
        self.title_valid=True;self.labels_valid=True;self.applied_labels={};self.comparison=None;self.time_factor=1e-9;self._rendering=False
        self.pool=QThreadPool(self);self.pool.setMaxThreadCount(1)
        self.timer=QTimer(self);self.timer.setSingleShot(True);self.timer.setInterval(450);self.timer.timeout.connect(self.dispatch)
        root=QWidget();self.setCentralWidget(root);layout=QVBoxLayout(root)
        header=QHBoxLayout();self.open_button=QPushButton('Открыть .dat + .txt');self.open_button.setObjectName('primary')
        self.notes_button=QPushButton('Выбрать другой .txt');self.save_button=QPushButton('Сохранить картинку…')
        self.export_button=QPushButton('Экспорт рисунка и данных');self.cancel_button=QPushButton('Отмена вычисления')
        for button in (self.open_button,self.notes_button,self.save_button,self.export_button,self.cancel_button):header.addWidget(button)
        layout.addLayout(header);self.file_label=QLabel('Загрузите файл: Position | X1 | Y1 | X2 | Y2. Графики сигналов, фаза 0–360° и плоскость X₂–Y₂.')
        self.file_label.setWordWrap(True);layout.addWidget(self.file_label)
        splitter=QSplitter(Qt.Horizontal);splitter.setChildrenCollapsible(False);layout.addWidget(splitter,1)
        self.tabs=QTabWidget();self.tabs.setMinimumWidth(460);splitter.addWidget(self.tabs)
        common=QWidget();left=QVBoxLayout(common);group=QGroupBox('Время и калибровка');form=QFormLayout(group)
        self.zero_mode=QComboBox();self.zero_mode.addItems(['Максимум исходного X1','Вручную']);form.addRow('Ноль задержки',self.zero_mode)
        self.zero=QLineEdit('106.45');form.addRow('x₀, mm',self.zero)
        self.units=QComboBox();self.units.addItems(['mm','шаги']);form.addRow('Координаты файла',self.units)
        self.step_size=QLineEdit('0');form.addRow('mm на шаг',self.step_size)
        self.light_speed=QLineEdit('3e8');form.addRow('Скорость света, m/s',self.light_speed)
        fixed=QLabel('Оптический путь всегда двойной: t = 2(x − x₀)/c.\nОба канала используют один x₀ и одно окно времени.');fixed.setWordWrap(True);form.addRow(fixed)
        self.bal=QLineEdit();self.sig=QLineEdit();self.bal.setPlaceholderText('Bal < 0');self.sig.setPlaceholderText('Sig > 0')
        form.addRow('X1: Bal, mV (Bal < 0)',self.bal);form.addRow('X1: Sig, mV (Sig > 0)',self.sig)
        self.second_mode=QComboBox();self.second_mode.addItem('R2 / X2 / Y2 в вольтах','volts');self.second_mode.addItem('X2 / Y2 / R2: те же Bal/Sig → rad','same');self.second_mode.addItem('X2 / Y2 / R2: отдельные Bal/Sig → rad','separate');self.second_mode.setCurrentIndex(1);form.addRow('Единицы второго канала',self.second_mode)
        self.second_bal=QLineEdit();self.second_sig=QLineEdit();form.addRow('R2: Bal, mV (Bal < 0)',self.second_bal);form.addRow('R2: Sig, mV (Sig > 0)',self.second_sig)
        cal=QLabel('θ = √2 · V / [4√Sig · √(Sig − Bal)].\nBal/Sig вводятся в mV. Отношение амплитуд сравнивается в исходных вольтах.');cal.setWordWrap(True);form.addRow(cal)
        left.addWidget(group)
        group=QGroupBox('Фаза квадратур X2/Y2');form=QFormLayout(group)
        self.rotation_angle=spin(0,-360,360,6);self.rotation_angle.setSingleStep(1.)
        form.addRow('Поворот X2/Y2, °',self.rotation_angle)
        self.auto_rotation_button=QPushButton('Авто: осцилляции → X2');form.addRow(self.auto_rotation_button)
        self.auto_phase_band=QComboBox();self.auto_phase_band.addItems(['Полоса FFT X2','Полоса FFT X1','Вся переменная часть'])
        form.addRow('Диапазон автофазы',self.auto_phase_band)
        self.reset_rotation_button=QPushButton('Вернуть угол 0°');form.addRow(self.reset_rotation_button)
        note=QLabel('X′ = X cosθ + Y sinθ; Y′ = −X sinθ + Y cosθ.\nR2 не меняется. Авто минимизирует переменную часть Y2 после удаления фона.\nПолное подавление возможно только при общей фазе колебаний.')
        note.setWordWrap(True);form.addRow(note)
        self.rotation_status=QLabel('Угол задан относительно исходных квадратур.');self.rotation_status.setWordWrap(True);form.addRow(self.rotation_status)
        left.addWidget(group)
        group=QGroupBox('Достоверность фазы φ₂ · 0–360°');form=QFormLayout(group)
        self.phase_sigma=spin(3.,0.,20.,2);self.phase_sigma.setSingleStep(.5)
        self.phase_noise_nv=spin(0.,0.,1e12,6)
        form.addRow('Порог амплитуды R / σ',self.phase_sigma)
        form.addRow('Шум квадратур σ, nV (0 = авто)',self.phase_noise_nv)
        note=QLabel('Фаза по тем же X2/Y2 после вычитания фона.\nСерые точки ниже порога исключены из FFT/фита.\n'
            'Автооценка σ приблизительная; можно задать измеренный шум.\nУглы 0–360°, без глобальной развёртки.')
        note.setWordWrap(True);form.addRow(note);left.addWidget(group)
        group=QGroupBox('Общее окно анализа');form=QFormLayout(group)
        self.time_unit=QComboBox();self.time_unit.addItem('ns',1e-9);self.time_unit.addItem('ps',1e-12);form.addRow('Единицы времени',self.time_unit)
        self.window_mode=QComboBox();self.window_mode.addItems(['Максимум X1 + шаги → конец','Вручную']);form.addRow('Окно',self.window_mode)
        self.skip_steps=QSpinBox();self.skip_steps.setRange(0,1000000);self.skip_steps.setValue(3);form.addRow('Шагов после максимума',self.skip_steps)
        self.fit_start,self.fit_stop=spin(.01),spin(3.5);form.addRow('Начало окна',self.fit_start);form.addRow('Конец окна',self.fit_stop)
        self.background=QComboBox();self.background.addItems(['Без вычитания','Константа','Линейный','Квадратичный']);form.addRow('Фон (для каждого канала)',self.background)
        self.bg_start,self.bg_stop=spin(.01),spin(3.5);form.addRow('Оценка фона от',self.bg_start);form.addRow('Оценка фона до',self.bg_stop)
        self.window=QComboBox();self.window.addItems(['Hann','Прямоугольное']);form.addRow('Окно FFT',self.window)
        self.padding=QComboBox()
        for n in (1,2,4,8,16,32,64,128):self.padding.addItem('×'+str(n),n)
        self.padding.setCurrentIndex(3);form.addRow('Zero-padding',self.padding);left.addWidget(group);left.addStretch()
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(common);self.tabs.addTab(scroll,'Общие')
        self.modulation_enabled=QCheckBox('X2 / Y2: модуляция на суммарной частоте (½), опора из X1')
        self.modulation_enabled.setChecked(True)
        self.modulation_enabled.setToolTip('X1 рассчитывается как опора, даже если его линия скрыта. X2/Y2 получают отдельные знаковые ΔΓ, ΔA, Δω, Δφ. Снимите флажок для прежней модели.')
        layout.insertWidget(1,self.modulation_enabled)
        self.channels=[ChannelControls(self,i) for i in range(2)]
        for name,page in zip(('X1','R2'),self.channels):
            scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(page);self.tabs.addTab(scroll,name)
        from .modulation_controls import ModulationControls
        self.diagnostic_channels={key:(ModulationControls if key in ('x2','y2') else ChannelControls)(self,index) for index,key in enumerate(DIAGNOSTIC_KEYS,2)}
        for key,page in self.diagnostic_channels.items():
            scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(page);self.tabs.addTab(scroll,SIGNAL_NAMES[key])
        style=QWidget();form=QFormLayout(style)
        self.normalized=QCheckBox('Показывать нормированное сравнение');self.normalized.setChecked(True);form.addRow(self.normalized)
        overlay_group=QGroupBox('Сигналы на общем графике');overlay_form=QFormLayout(overlay_group)
        self.overlay_checks={};self.signal_alpha_fields={};self.fit_checks={};self.peak_checks={}
        for key,name in SIGNAL_NAMES.items():
            check=QCheckBox(name);check.setChecked(key in ('x1','r2'));self.overlay_checks[key]=check
            alpha=spin(.55,0,1,2);self.signal_alpha_fields[key]=alpha
            row=QHBoxLayout();row.addWidget(check);row.addWidget(QLabel('Непрозрачность'));row.addWidget(alpha)
            overlay_form.addRow(row)
        form.addRow(overlay_group)
        fit_group=QGroupBox('Видимость линий фита');fit_form=QFormLayout(fit_group)
        peak_group=QGroupBox('FFT-пики в подписи и отчёте');peak_form=QFormLayout(peak_group)
        for key,name in SIGNAL_NAMES.items():
            check=QCheckBox('Показывать фит '+name);check.setChecked(True);self.fit_checks[key]=check;fit_form.addRow(check)
            peak=QCheckBox('Записывать пики '+name);peak.setChecked(key in ('x1','r2'));self.peak_checks[key]=peak;peak_form.addRow(peak)
            if key=='phase2':peak.hide();peak.setEnabled(False)
        form.addRow(fit_group);form.addRow(peak_group)
        self.fit_visible1,self.fit_visible2=self.fit_checks['x1'],self.fit_checks['r2']
        self.alpha1,self.alpha2=self.signal_alpha_fields['x1'],self.signal_alpha_fields['r2']
        self.footer_visible=QCheckBox('Показывать нижний блок параметров');self.footer_visible.setChecked(True);form.addRow(self.footer_visible)
        note=QLabel('С фитом: вычитается C, масштаб max|fit − C|.\nБез фита: вычитается среднее и используется max|signal − mean|.\nНормировка в a.u.; точки могут выходить за ±1 из-за шума.\nРазность фаз и отношение амплитуд ниже относятся к X1/R2.');note.setWordWrap(True);form.addRow(note)
        self.pair1,self.pair2=QComboBox(),QComboBox();form.addRow('Компонента X1',self.pair1);form.addRow('Компонента R2',self.pair2)
        self.title_size,self.body_size=QSpinBox(),QSpinBox()
        for w,default in ((self.title_size,14),(self.body_size,8)):w.setRange(5,72);w.setValue(default)
        form.addRow('Шрифт Title, pt',self.title_size);form.addRow('Шрифт нижнего блока, pt',self.body_size)
        self.annotation=QPlainTextEdit();self.annotation.setMaximumHeight(100);form.addRow('Примечание внизу',self.annotation)
        self.comparison_label=QLabel('Сравнение появится после обоих фитов.');self.comparison_label.setWordWrap(True);form.addRow(self.comparison_label)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(style);self.tabs.addTab(scroll,'Сравнение / вид')
        self.notes=QPlainTextEdit();self.notes.setReadOnly(True);self.tabs.addTab(self.notes,'Параметры .txt')
        right_widget=QWidget();right=QVBoxLayout(right_widget);splitter.addWidget(right_widget)
        row=QHBoxLayout();row.addWidget(QLabel('Title:'));self.title=QLineEdit('Pump–probe · X1 & R2');self.title.setToolTip(r'Формулы: $\theta(t)$ или $$\theta(t)$$');row.addWidget(self.title,1);right.addLayout(row)
        self.title_error=QLabel();self.title_error.setWordWrap(True);self.title_error.setStyleSheet('color:#a42b2b');self.title_error.hide();right.addWidget(self.title_error)
        self.figure=DualFigure();self.editor=self.figure;right.addWidget(self.figure,1)
        self.build_labels_tab()
        self.messages=QPlainTextEdit();self.messages.setReadOnly(True);self.messages.setMaximumHeight(100);right.addWidget(self.messages)
        splitter.setSizes([495,1125])
        self.open_button.clicked.connect(self.open_files);self.notes_button.clicked.connect(self.change_notes)
        self.save_button.clicked.connect(self.save_picture);self.export_button.clicked.connect(self.export);self.cancel_button.clicked.connect(self.cancel_job)
        self.figure.save_requested.connect(self.save_picture);self.figure.band_changed.connect(self.figure_band_changed)
        self.figure.diagnostic_band_changed.connect(self.diagnostic_figure_band_changed)
        self.figure.animation_requested.connect(self.show_xy_animation)
        self.figure.title_edit_requested.connect(self.edit_title)
        self.figure.title_validation_error.connect(self.title_validation)
        self.figure.labels_validation_error.connect(self.labels_validation)
        self.figure.labels_edit_requested.connect(self.edit_label)
        self.title.textChanged.connect(self.figure.set_title);self.figure.set_title(self.title.text())
        for field in (self.zero,self.step_size,self.light_speed,self.bal,self.sig,self.second_bal,self.second_sig):field.textEdited.connect(self.invalidate_physical)
        for field in (self.zero_mode,self.units,self.second_mode,self.window_mode,self.background,self.window,self.padding):field.currentIndexChanged.connect(self.invalidate_physical)
        for field in (self.skip_steps,self.fit_start,self.fit_stop,self.bg_start,self.bg_stop):field.valueChanged.connect(self.invalidate_physical)
        self.rotation_angle.valueChanged.connect(self.rotation_edited)
        self.phase_sigma.valueChanged.connect(self.invalidate_physical)
        self.phase_noise_nv.valueChanged.connect(self.invalidate_physical)
        self.auto_rotation_button.clicked.connect(self.request_auto_rotation)
        self.auto_phase_band.currentIndexChanged.connect(self.auto_phase_band_changed)
        self.reset_rotation_button.clicked.connect(self.reset_rotation)
        self.time_unit.currentIndexChanged.connect(self.change_time_unit)
        self.normalized.toggled.connect(self.style_changed)
        for field in self.signal_alpha_fields.values():field.valueChanged.connect(self.style_changed)
        for check in self.overlay_checks.values():check.toggled.connect(self.style_changed)
        for check in self.fit_checks.values():check.toggled.connect(self.fit_visibility_changed)
        for check in self.peak_checks.values():check.toggled.connect(self.peak_annotations_changed)
        self.footer_visible.toggled.connect(self.figure.set_footer_visible)
        self.pair1.currentIndexChanged.connect(self.style_changed);self.pair2.currentIndexChanged.connect(self.style_changed)
        self.title_size.valueChanged.connect(self.fonts_changed);self.body_size.valueChanged.connect(self.fonts_changed);self.annotation.textChanged.connect(self.style_changed)
        self.fonts_changed();self.peak_annotations_changed();self.fit_visibility_changed()
        self.modulation_enabled.toggled.connect(self.modulation_mode_changed)
        self.sync_reference_dependency();self.apply_overlay_style();self.set_enabled()

    def uses_modulation(self,index):
        return index in (2,3) and self.modulation_enabled.isChecked()

    def sync_reference_dependency(self):
        active=self.modulation_enabled.isChecked()
        self.second_mode.model().item(0).setEnabled(not active)
        if active and self.second_mode.currentData()=='volts':
            self.second_mode.blockSignals(True);self.second_mode.setCurrentIndex(1);self.second_mode.blockSignals(False)
        reference=self.channels[0]
        if active and reference.model.currentIndex()!=0:
            reference.model.blockSignals(True);reference.model.setCurrentIndex(0);reference.model.blockSignals(False)
            self.manual_initials[0]=None
        reference.model.setEnabled(not active)
        reference.count.setEnabled(not active and reference.model.currentIndex()==1)
        if hasattr(self,'annotation'):
            self.annotation.setEnabled(not active)
            self.annotation.setToolTip('В краткой подписи выводятся только параметры X1, X2 и Y2.' if active else '')
        for key,check in self.peak_checks.items():
            check.setText(('Пики '+key.upper()+' в analysis.json') if active else 'Записывать пики '+key.upper())
        required=self.modulation_enabled.isChecked() and any(self.diagnostic_channels[k].fit_enabled.isChecked() for k in ('x2','y2'))
        check=self.channels[0].fit_enabled
        if required:
            check.blockSignals(True);check.setChecked(True);check.blockSignals(False)
        check.setEnabled(not required)
        check.setToolTip('X1 обязателен как опора модуляционного фита. Линию X1 можно скрыть отдельно на вкладке оформления.' if required else 'Расчёт обычного фита X1.')

    def modulation_mode_changed(self,*_):
        for i,key in ((2,'x2'),(3,'y2')):
            self.manual_initials[i]=None
            control=self.diagnostic_channels[key]
            control.table.setRowCount(0);control.sync_mode()
        self.invalidate()

    def build_labels_tab(self):
        self.labels_page=QWidget();layout=QVBoxLayout(self.labels_page)
        note=QLabel('Меняйте заголовки, названия осей и легенду. Пустое поле убирает подпись.\n'
            'Формулы: $…$ или $$…$$. {unit} подставляет единицу оси, {time_unit} — ns/ps.\n'
            'Правки применяются автоматически и не меняют результаты расчёта.')
        note.setWordWrap(True);layout.addWidget(note)
        self.label_fields={};self.label_rows={}
        defaults=self.figure.default_labels();self.applied_labels=dict(defaults)
        self.labels_table=QTableWidget(len(defaults),2)
        self.labels_table.setHorizontalHeaderLabels(['Подпись','Текст'])
        self.labels_table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeToContents)
        self.labels_table.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch)
        names={'x1':'X1(t)','x1_fft':'FFT X1','x2':'X2(t)','x2_fft':'FFT X2',
            'y2':'Y2(t)','y2_fft':'FFT Y2','r2':'R2(t)','r2_fft':'FFT R2',
            'phase2':'Фаза φ₂(t)','quadrature':'Плоскость X₂–Y₂','normalized':'Сравнение a.u.',
            'legend':'Легенда','channel':'Нижний блок'}
        suffixes={'title':'Заголовок','xlabel':'Ось X','ylabel':'Ось Y',
            'x1_points':'Точки X1','r2_points':'Точки R2','x1_fit':'Фит X1','r2_fit':'Фит R2',
            'x1':'X1','r2':'R2','x2':'X2','y2':'Y2','phase2':'φ₂',
            'x2_points':'Точки X2','y2_points':'Точки Y2','phase2_points':'Точки φ₂',
            'x2_fit':'Фит X2','y2_fit':'Фит Y2','phase2_fit':'Фит φ₂'}
        self.labels_timer=QTimer(self);self.labels_timer.setSingleShot(True);self.labels_timer.setInterval(250)
        self.labels_timer.timeout.connect(self.apply_labels)
        for row,(key,value) in enumerate(defaults.items()):
            head,_,tail=key.partition('.')
            item=QTableWidgetItem(names.get(head,head)+' · '+suffixes.get(tail,tail))
            item.setFlags(item.flags()&~Qt.ItemIsEditable);item.setToolTip(key)
            self.labels_table.setItem(row,0,item)
            field=QLineEdit(value);field.setToolTip(key)
            self.labels_table.setCellWidget(row,1,field);self.label_fields[key]=field;self.label_rows[key]=row
            field.textChanged.connect(lambda *_:self.labels_timer.start())
            field.editingFinished.connect(self.apply_labels)
        layout.addWidget(self.labels_table,1)
        self.labels_error=QLabel();self.labels_error.setWordWrap(True);self.labels_error.setStyleSheet('color:#a42b2b');self.labels_error.hide();layout.addWidget(self.labels_error)
        self.reset_labels_button=QPushButton('Вернуть исходные подписи');layout.addWidget(self.reset_labels_button)
        self.reset_labels_button.clicked.connect(self.reset_labels)
        self.tabs.addTab(self.labels_page,'Подписи')

    def apply_labels(self):
        self.labels_timer.stop()
        labels={key:field.text() for key,field in self.label_fields.items()}
        if self.figure.set_labels(labels):
            self.applied_labels=dict(labels);return True
        return False

    def labels_validation(self,message):
        self.labels_valid=not bool(message)
        self.labels_error.setText(str(message)[:350]);self.labels_error.setToolTip(str(message));self.labels_error.setVisible(bool(message))
        self.set_enabled()

    def edit_label(self,key):
        if key not in self.label_fields:return
        self.tabs.setCurrentWidget(self.labels_page)
        self.labels_table.scrollToItem(self.labels_table.item(self.label_rows[key],0))
        self.label_fields[key].setFocus(Qt.OtherFocusReason);self.label_fields[key].selectAll()

    def reset_labels(self):
        for key,value in self.figure.default_labels().items():
            field=self.label_fields[key];field.blockSignals(True);field.setText(value);field.blockSignals(False)
        self.apply_labels()

    def fit_visibility_changed(self,*_):
        self.figure.set_fit_visibility({key:check.isChecked() for key,check in self.fit_checks.items()})
    def peak_annotations_changed(self,*_):
        self.figure.set_peak_annotations({key:check.isChecked() for key,check in self.peak_checks.items()})
    def all_channel_controls(self):return self.channels+list(self.diagnostic_channels.values())

    def log(self,text):self.messages.appendPlainText(str(text));self.statusBar().showMessage(str(text).splitlines()[0][:180])
    def components(self):return tuple(channel.components() for channel in self.channels)
    def settings(self):
        if not self.bal.text().strip() or not self.sig.text().strip():
            raise ValueError('Для построения X1 введите Bal < 0 и Sig > 0 в милливольтах во вкладке «Общие».')
        return core.Settings(zero_mm=numerical(self.zero),mm_per_unit=1. if self.units.currentIndex()==0 else numerical(self.step_size),
            c=numerical(self.light_speed),bal_mv=numerical(self.bal),sig_mv=numerical(self.sig),
            zero_mode='peak' if self.zero_mode.currentIndex()==0 else 'manual',
            fit_window_mode='peak_plus_steps' if self.window_mode.currentIndex()==0 else 'manual',skip_steps=self.skip_steps.value(),
            fit_min_s=numerical(self.fit_start)*self.time_factor,fit_max_s=numerical(self.fit_stop)*self.time_factor,
            background_degree=self.background.currentIndex()-1,bg_min_s=numerical(self.bg_start)*self.time_factor,bg_max_s=numerical(self.bg_stop)*self.time_factor,
            window='hann' if self.window.currentIndex()==0 else 'boxcar',padding=self.padding.currentData())
    def rotation_edited(self,*_):
        self.auto_rotation_requested=False
        self.manual_initials[2:]=[None]*3
        self.invalidate()
    def reset_rotation(self):
        self.rotation_angle.blockSignals(True);self.rotation_angle.setValue(0.);self.rotation_angle.blockSignals(False)
        self.rotation_edited()
    def request_auto_rotation(self):
        if self.measurement is None:return
        self.auto_rotation_requested=True;self.manual_initials[2:]=[None]*3
        self.invalidate()
    def auto_phase_band_changed(self,*_):
        if self.auto_rotation_requested:self.invalidate()
    def invalidate_physical(self,*_):
        self.manual_initials=[None]*5;self.invalidate()
    def invalidate(self,*_):
        if hasattr(self,'diagnostic_channels'):self.sync_reference_dependency()
        for key in ('x2','y2'):
            if hasattr(self,'diagnostic_channels'):self.diagnostic_channels[key].sync_mode()
        if self._rendering:return
        self.revision+=1;self.dirty=True;self.results=(None,None);self.comparison=None
        self.diagnostic_results={}
        for channel in self.all_channel_controls():
            for row in range(channel.table.rowCount()):
                if channel.table.item(row,2) is not None:channel.table.item(row,2).setText('')
        if self.job and self.job.kind=='Анализ':self.job.cancel.set()
        self.pending=self.measurement is not None;self.timer.start();self.set_enabled()
        # Keep the last complete picture while a worker computes. Rebuilding
        # every subplot here used to freeze the UI on each edit/keystroke.
        self.statusBar().showMessage('Параметры изменены — автоматический пересчёт…')
    def dispatch(self):
        if self.closing or self.job is not None or not self.pending:return
        self.pending=False
        try:
            cfg=self.settings();mode=self.second_mode.currentData()
            if mode=='separate' and (not self.second_bal.text().strip() or not self.second_sig.text().strip()):
                raise ValueError('Для отдельной калибровки R2 введите его Bal < 0 и Sig > 0 в милливольтах.')
            second_bal=numerical(self.second_bal) if mode=='separate' else None
            second_sig=numerical(self.second_sig) if mode=='separate' else None
            counts=tuple(c.components() for c in self.all_channel_controls());requested=tuple(c.band() for c in self.all_channel_controls());automatic=tuple(c.auto_band.isChecked() for c in self.all_channel_controls())
            manual=tuple(None if p is None else p.copy() for p in self.manual_initials);measurement=self.measurement
            fixed=tuple(c.read_fixed_frequencies() for c in self.all_channel_controls())
            enabled=tuple(c.fit_enabled.isChecked() for c in self.all_channel_controls())
            modulation=self.modulation_enabled.isChecked()
            include_constants=tuple(self.diagnostic_channels[k].constant.isChecked() for k in ('x2','y2'))
            if modulation and (enabled[2] or enabled[3]):enabled=(True,)+enabled[1:]
            cached=dict(self._fit_cache)
            angle=numerical(self.rotation_angle);request_auto=self.auto_rotation_requested
            phase_sigma=self.phase_sigma.value();noise_sigma=self.phase_noise_nv.value()*1e-9
            rotation_band=None if self.auto_phase_band.currentIndex()==2 else requested[2 if self.auto_phase_band.currentIndex()==0 else 0]
        except Exception as exc:self.log(exc);self.set_enabled();return
        def analyze(cancel):
            p=prepare_dual(measurement,cfg,mode,second_bal,second_sig)
            if cancel.is_set():raise core.Cancelled('Анализ отменён')
            used_angle=angle;rotation_error=None
            if request_auto:
                try:
                    info=auto_rotation(p,rotation_band);used_angle=float(info['angle_deg'])
                except ValueError as exc:
                    rotation_error=str(exc);info=rotation_metadata(p,used_angle)
            else:info=rotation_metadata(p,used_angle)
            used_angle=float(info['angle_deg'])
            if cancel.is_set():raise core.Cancelled('Анализ отменён')
            diagnostics=prepare_rotated_diagnostics(p,used_angle,phase_sigma,noise_sigma)
            fit_diagnostics={key:diagnostic_fit_input(diagnostics[key],key) for key in DIAGNOSTIC_KEYS}
            results=[];bands=[];initials=[];errors=[];cache_hits=0
            fit_inputs=(p.first,p.second)+tuple(fit_diagnostics[key] for key in DIAGNOSTIC_KEYS)
            for i,channel in enumerate(fit_inputs):
                if cancel.is_set():raise core.Cancelled('Анализ отменён')
                band=requested[i];initial=None;result=None
                try:
                    if i==4 and channel.phase_info and not channel.phase_info.get('fit_allowed',False):
                        raise ValueError('Фаза: нет достоверного непрерывного участка для FFT/фита. Проверьте уровень сигнала и окно анализа.')
                    if modulation and i in (2,3):
                        from . import sum_frequency as sf
                        if results[0] is None:raise ValueError('Нет достоверного опорного фита X1; δ-параметры не рассчитаны.')
                        count=(len(results[0].parameters)-1)//4
                        initial=np.zeros(4*count+1) if manual[i] is None or len(manual[i])!=4*count+1 else manual[i].copy()
                        constraints={j:v for j,v in fixed[i].items() if j<count}
                        for j,v in constraints.items():initial[4*j+2]=v
                        if automatic[i] and len(channel.spectrum):band=core.automatic_band(channel,count)
                        constant=include_constants[i-2] and channel.settings.background_degree<0
                        if enabled[i]:
                            key=(fit_key(channel,initial,band,constraints),sf.MODEL,
                                 results[0].parameters.tobytes(),results[0].reference_s,p.first_factor,p.second_factor,constant,
                                 channel.settings.background_degree,channel.settings.bg_min_s,channel.settings.bg_max_s)
                            if i in cached and cached[i][0]==key:result=cached[i][1];cache_hits+=1
                            else:
                                result=sf.fit(channel,results[0],p.first_factor,initial,cancel,
                                    fixed_delta_frequencies=constraints,include_constant=constant,response_factor=p.second_factor)
                                cached[i]=(key,result)
                        bands.append(band);initials.append(initial);results.append(result)
                        continue
                    constraints=fixed[i];all_fixed=len(constraints)==counts[i]
                    if automatic[i] and len(channel.spectrum):band=core.automatic_band(channel,counts[i])
                    if all_fixed and (not 0<=band[0]<band[1]<=channel.nyquist_hz):
                        band=(max(0.,channel.nyquist_hz*.01),channel.nyquist_hz)
                    if not 0<=band[0]<band[1]<=channel.nyquist_hz:raise ValueError('Полоса FFT должна находиться между 0 и частотой Найквиста.')
                    if manual[i] is not None:initial=manual[i].copy()
                    elif len(channel.spectrum):initial=core.initial_parameters(channel,counts[i],band)
                    else:
                        finite=channel.fit_mask&np.isfinite(channel.y)
                        if finite.sum()<8:raise ValueError('Недостаточно точек для FFT/фита.')
                        time=channel.time[finite];duration=float(np.ptp(time))
                        seed_frequency=min(max((band[0]+band[1])/2,1.),channel.nyquist_hz)
                        frequencies=[constraints.get(j,seed_frequency) for j in range(counts[i])]
                        initial,_=core._linear_parameters(time-time[0],channel.y[finite],frequencies,[duration]*counts[i])
                    for component,value in constraints.items():initial[4*component+1]=value
                    if not len(channel.spectrum) and not all_fixed:raise ValueError('FFT недоступно. Можно зафиксировать все частоты вручную для фита без FFT.')
                    if enabled[i]:
                        key=fit_key(channel,initial,band,constraints)
                        if i in cached and cached[i][0]==key:
                            result=cached[i][1];cache_hits+=1
                        else:
                            result=core.fit(channel,initial,band,cancel,fixed_frequencies=constraints)
                            cached[i]=(key,result)
                    if i==4 and result is not None:
                        phase_indices=[j for j in range(len(result.parameters)) if j==len(result.parameters)-1 or j%4 in (0,2)]
                        if np.any(result.parameters[:-1:4]>np.pi) or not np.isfinite(result.errors[phase_indices]).all() or result.r_squared<.5:
                            result=None
                            raise ValueError('Фаза: модель колебаний не определена достоверно; линия фита не показана.')
                except core.Cancelled:raise
                except Exception as exc:errors.append(('X1','R2','X2','Y2','φ₂')[i]+': '+str(exc))
                bands.append(band);initials.append(initial);results.append(result)
            return dict(prepared=p,diagnostics=diagnostics,results=tuple(results[:2]),bands=tuple(bands[:2]),initials=tuple(initials[:2]),errors=errors,
                diagnostic_results=dict(zip(DIAGNOSTIC_KEYS,results[2:])),diagnostic_initials=dict(zip(DIAGNOSTIC_KEYS,initials[2:])),
                diagnostic_bands=dict(zip(DIAGNOSTIC_KEYS,bands[2:])),diagnostic_fit_prepared=fit_diagnostics,
                diagnostic_components=dict(zip(DIAGNOSTIC_KEYS,counts[2:])),
                rotation_deg=used_angle,rotation_info=info,rotation_error=rotation_error,
                fixed_frequencies=dict(zip(SIGNAL_NAMES,fixed)),fit_cache=cached,cache_hits=cache_hits)
        self.run_job('Анализ',analyze)
    def run_job(self,kind,function):
        if self.job is not None:return
        self.job_revision=self.revision;self.job=Job(kind,function);self.job.signals.completed.connect(self.completed)
        self.pool.start(self.job);self.set_enabled();self.statusBar().showMessage(kind+'…')
    def completed(self,package):
        kind,value,error=package;cancelled=self.job.cancel.is_set();stale=kind=='Анализ' and self.job_revision!=self.revision
        self.job=None
        if self.closing:return
        if cancelled or stale:
            if not self.pending:self.log('Отменённый результат отброшен.')
        elif error:
            self.log(error)
            if kind=='Загрузка':self.file_label.setText(self.file_label.text().replace('загрузка…','ошибка загрузки'))
        elif kind=='Загрузка':
            self.measurement=value;self.prepared=None;self.results=(None,None);self.initials=(None,None);self.manual_initials=[None]*5;self.diagnostics={}
            self.notes.setPlainText(value.notes);self.file_label.setText(f'{value.data_path}\nПараметры: {value.notes_path}; исходные единицы: {value.signal_unit}')
            self.pending=True
            for warning in value.warnings:self.log(warning)
        elif kind=='Анализ':
            self._fit_cache=value['fit_cache'];self.cache_hits=value['cache_hits']
            self.prepared=value['prepared'];self.diagnostics=value['diagnostics'];self.results=value['results'];self.initials=value['initials'];self.bands=value['bands'];self.dirty=False
            self.diagnostic_results=value['diagnostic_results'];self.diagnostic_initials=value['diagnostic_initials']
            self.diagnostic_bands=value['diagnostic_bands'];self.diagnostic_fit_prepared=value['diagnostic_fit_prepared']
            self.diagnostic_components=value['diagnostic_components']
            self.fixed_frequencies_used=value['fixed_frequencies']
            self.rotation_degrees_used=value['rotation_deg'];self.rotation_info=value['rotation_info']
            self.auto_rotation_requested=False
            self.rotation_angle.blockSignals(True);self.rotation_angle.setValue(self.rotation_degrees_used);self.rotation_angle.blockSignals(False)
            retained=self.rotation_info.get('retained_fraction');residual=self.rotation_info.get('residual_fraction')
            scope='В выбранной полосе' if self.rotation_info.get('band_hz') is not None else 'Переменная мощность'
            fractions=f'{scope}: X2 {retained:.2%}; Y2 {residual:.2%}.' if retained is not None and residual is not None else 'Переменная мощность не определена.'
            self.rotation_status.setText(f'Поворот {self.rotation_degrees_used:.6g}°. '+fractions)
            if value['rotation_error']:self.log('Автонастройка: '+value['rotation_error'])
            p=self.prepared.first
            self.zero.setText(f'{p.settings.zero_mm:.9g}')
            for field,number in ((self.fit_start,p.settings.fit_min_s),(self.fit_stop,p.settings.fit_max_s)):
                field.blockSignals(True);field.setValue(number/self.time_factor);field.blockSignals(False)
            self.refresh_channels();self.update_pairs();self.render_data()
            self.log(f'Прочитано {len(self.measurement.position)} точек; в общем окне {int(p.fit_mask.sum())}.')
            for i,result in enumerate(self.results):
                if result is not None:
                    self.log(f'{("X1","R2")[i]}: фит R²={result.r_squared:.6g}')
                    for warning in result.warnings:self.log(f'{("X1","R2")[i]}: '+warning)
            for channel in (self.prepared.first,self.prepared.second):
                for warning in channel.warnings:self.log(warning)
            for name,diagnostic in self.diagnostics.items():
                for warning in diagnostic.warnings:self.log(name+': '+warning)
                fitted=self.diagnostic_results.get(name)
                if fitted is not None:
                    self.log(f'{SIGNAL_NAMES[name]}: фит R²={fitted.r_squared:.6g}')
                    for warning in fitted.warnings:self.log(SIGNAL_NAMES[name]+': '+warning)
                for warning in self.diagnostic_fit_prepared[name].warnings:
                    if warning not in diagnostic.warnings:self.log(SIGNAL_NAMES[name]+': '+warning)
            for text in value['errors']:self.log(text)
            if self.cache_hits:self.statusBar().showMessage(f'Готово · фитов из кэша: {self.cache_hits}')
        elif kind in ('Экспорт','Картинка'):self.log('Сохранено: '+str(value))
        self.set_enabled()
        if self.pending_load is not None:
            paths=self.pending_load;self.pending_load=None;self.pending=False
            self.load_paths(*paths)
        elif self.pending:QTimer.singleShot(0,self.dispatch)
    def refresh_channels(self):
        for i,(ui,p,unit) in enumerate(zip(self.channels,(self.prepared.first,self.prepared.second),(self.prepared.first_unit,self.prepared.second_unit))):
            ui.set_band(self.bands[i]);ui.populate(self.manual_initials[i] if self.manual_initials[i] is not None else self.initials[i],self.results[i],p,unit)
            try:
                idx=core.peak_indices(p,*self.bands[i])[0]
                ui.peak.setText(f'Максимум FFT: {p.frequencies[idx]/1e9:.6g} GHz; разрешение ≈ {p.resolution_hz/1e9:.4g} GHz')
            except ValueError:ui.peak.setText('FFT недоступно в выбранной полосе.')
        for i,key in enumerate(DIAGNOSTIC_KEYS,2):
            ui=self.diagnostic_channels[key];p=self.diagnostic_fit_prepared.get(key,self.diagnostics[key])
            initial=self.manual_initials[i] if self.manual_initials[i] is not None else self.diagnostic_initials.get(key)
            if self.uses_modulation(i) and (initial is None or len(initial)!=4*ui.components()+1):initial=self.diagnostic_initials.get(key)
            band=self.diagnostic_bands.get(key,ui.band());ui.set_band(band)
            ui.populate(initial,self.diagnostic_results.get(key),p,'deg' if key=='phase2' else p.signal_unit)
            try:
                idx=core.peak_indices(p,*band)[0]
                ui.peak.setText(f'Максимум FFT: {p.frequencies[idx]/1e9:.6g} GHz; разрешение ≈ {p.resolution_hz/1e9:.4g} GHz')
            except ValueError:ui.peak.setText('FFT недоступно в выбранном участке.')
    def update_pairs(self):
        for box,result in zip((self.pair1,self.pair2),self.results):
            old=box.currentIndex();box.blockSignals(True);box.clear()
            if result is not None:
                for i in range((len(result.parameters)-1)//4):box.addItem(f'{i+1}: {result.parameters[4*i+1]/1e9:.6g} GHz',i)
                box.setCurrentIndex(max(0,min(old,box.count()-1)))
            box.blockSignals(False)
    def comparison_summary(self):
        self.comparison=None
        if self.prepared is not None and all(result is not None for result in self.results):
            try:self.comparison=compare_fits(*self.results,self.prepared.first_factor,self.prepared.second_factor,max(0,self.pair1.currentIndex()),max(0,self.pair2.currentIndex()))
            except Exception as exc:self.log(exc)
        from .dual_export import comparison_text
        unit1=self.prepared.first_unit if self.prepared is not None else 'rad'
        unit2=self.prepared.second_unit if self.prepared is not None else 'V'
        summary=comparison_text(self.comparison,unit1,unit2,angular=self.modulation_enabled.isChecked())
        self.comparison_label.setText(summary)
        note=self.annotation.toPlainText().strip()
        return summary+('\n'+note if note else '')
    def render_data(self):
        if self.prepared is None:return
        self._rendering=True
        try:
            summary=self.comparison_summary()
            self.figure.set_data(self.prepared,self.results,self.bands,self.comparison,self.components(),self.time_unit.currentText(),'',self.normalized.isChecked(),(max(0,self.pair1.currentIndex()),max(0,self.pair2.currentIndex())),diagnostics=self.diagnostics,
                diagnostic_results=self.diagnostic_results,diagnostic_fit_prepared=self.diagnostic_fit_prepared,
                diagnostic_bands=self.diagnostic_bands,diagnostic_components=self.diagnostic_components,compact_report=self.modulation_enabled.isChecked(),
                fit_enabled={key:channel.fit_enabled.isChecked() for key,channel in zip(SIGNAL_NAMES,self.all_channel_controls())})
            self.figure.set_summary_text(summary)
            self.figure.set_alphas(self.alpha1.value(),self.alpha2.value());self.figure.set_normalized_visible(self.normalized.isChecked())
            self.fit_visibility_changed();self.peak_annotations_changed();self.apply_overlay_style()
            self.figure.set_footer_visible(self.footer_visible.isChecked())
        finally:self._rendering=False
    def style_changed(self,*_):
        if self._rendering or self.prepared is None:return
        self.figure.set_summary_text(self.comparison_summary())
        self.apply_overlay_style()
        self.figure.set_normalized_visible(self.normalized.isChecked())
    def apply_overlay_style(self):
        self.figure.set_overlay_signals(tuple(key for key,check in self.overlay_checks.items() if check.isChecked()))
        self.figure.set_signal_alphas({key:field.value() for key,field in self.signal_alpha_fields.items()})
    def fonts_changed(self,*_):self.figure.set_fonts(self.title_size.value(),self.body_size.value())
    def change_time_unit(self,*_):
        new=self.time_unit.currentData()
        for field in (self.fit_start,self.fit_stop,self.bg_start,self.bg_stop):
            field.blockSignals(True);field.setValue(field.value()*self.time_factor/new);field.blockSignals(False)
        self.time_factor=new
        if self.prepared is not None:self.refresh_channels();self.render_data()
    def figure_band_changed(self,index,band):
        if self._rendering:return
        channel=self.channels[index];channel.auto_band.blockSignals(True);channel.auto_band.setChecked(False);channel.auto_band.blockSignals(False)
        channel.set_band(band);self.manual_initials[index]=None;self.invalidate()
    def diagnostic_figure_band_changed(self,key,band):
        if self._rendering or key not in self.diagnostic_channels:return
        channel=self.diagnostic_channels[key];channel.auto_band.blockSignals(True);channel.auto_band.setChecked(False);channel.auto_band.blockSignals(False)
        channel.set_band(band);self.manual_initials[channel.index]=None;self.invalidate()
    def edit_title(self):
        self.title.setFocus(Qt.OtherFocusReason);self.title.selectAll()
    def title_validation(self,message):
        self.title_valid=not bool(message);self.title_error.setText(str(message)[:250]);self.title_error.setVisible(bool(message));self.set_enabled()
    def set_enabled(self):
        busy=self.job is not None
        self.open_button.setEnabled(not self.closing);self.notes_button.setEnabled(self.measurement is not None and not self.closing)
        ready=self.prepared is not None and not self.dirty and not busy and self.title_valid and self.labels_valid
        self.save_button.setEnabled(ready);self.export_button.setEnabled(ready);self.cancel_button.setEnabled(busy or self.pending)
        self.figure.animation_button.setEnabled(ready and len(self.figure._quadrature_trace.time_s)>1)
        self.zero.setEnabled(self.zero_mode.currentIndex()==1);self.step_size.setEnabled(self.units.currentIndex()==1)
        self.auto_rotation_button.setEnabled(self.measurement is not None and not self.closing)
        separate=self.second_mode.currentData()=='separate';self.second_bal.setEnabled(separate);self.second_sig.setEnabled(separate)
        manual=self.window_mode.currentIndex()==1;self.fit_start.setEnabled(manual);self.fit_stop.setEnabled(manual);self.skip_steps.setEnabled(not manual)
        both=all(result is not None for result in self.results);self.normalized.setEnabled(self.prepared is not None)
        self.pair1.setEnabled(both);self.pair2.setEnabled(both)
        for channel in self.all_channel_controls():
            channel.low.setEnabled(not channel.auto_band.isChecked());channel.high.setEnabled(not channel.auto_band.isChecked())
    def open_files(self):
        path,_=QFileDialog.getOpenFileName(self,'Массив измерений','','Data (*.dat *.txt);;All files (*)')
        if not path:return
        notes=associated_notes(path)
        if notes is None:notes,_=QFileDialog.getOpenFileName(self,'Параметры измерения','','Text (*.txt)')
        if notes:self.load_paths(path,notes)
    def change_notes(self):
        notes,_=QFileDialog.getOpenFileName(self,'Параметры измерения',str(Path(self.measurement.notes_path).parent),'Text (*.txt)')
        if notes:self.load_paths(self.measurement.data_path,notes)
    def load_paths(self,path,notes):
        self.timer.stop();self.pending=False;self.revision+=1;self.results=(None,None);self.comparison=None;self.dirty=True
        self.measurement=self.prepared=None;self.initials=(None,None);self.manual_initials=[None]*5;self.diagnostics={}
        self.auto_rotation_requested=False;self.rotation_info={};self.fixed_frequencies_used={key:{} for key in SIGNAL_NAMES}
        self._fit_cache={};self.cache_hits=0
        self.rotation_status.setText('Угол задан относительно исходных квадратур.')
        self.diagnostic_results={};self.diagnostic_initials={};self.diagnostic_bands={};self.diagnostic_fit_prepared={}
        self.figure.clear_data();self.notes.clear();self.update_pairs()
        self.comparison_label.setText('Сравнение доступно после успешных фитов обоих сигналов.')
        self.file_label.setText(f'Файл: {path}\nПараметры: {notes} · загрузка…')
        for channel in self.all_channel_controls():channel.table.setRowCount(0);channel.peak.setText('Нет данных')
        if self.job:
            self.pending_load=(path,notes)
            if self.job.kind in ('Анализ','Загрузка'):self.job.cancel.set()
            self.set_enabled();return
        self.pending_load=None
        self.run_job('Загрузка',lambda cancel:load_dual_pair(path,notes))
    def cancel_job(self):
        self.timer.stop();self.pending=False;self.pending_load=None;self.auto_rotation_requested=False
        if self.job:self.job.cancel.set()
        self.set_enabled()
    def snapshot(self):
        if self.prepared is None or self.dirty:raise ValueError('Дождитесь завершения анализа.')
        return dict(modulation_enabled=self.modulation_enabled.isChecked(),measurement=self.measurement,prepared=self.prepared,results=self.results,bands=self.bands,
            initials=tuple(None if p is None else p.copy() for p in self.initials),components=self.components(),pair=(max(0,self.pair1.currentIndex()),max(0,self.pair2.currentIndex())),
            comparison=self.comparison,title=self.title.text(),time_unit=self.time_unit.currentText(),normalization=self.normalized.isChecked(),
            alphas=(self.alpha1.value(),self.alpha2.value()),annotation=self.annotation.toPlainText(),
            diagnostics=dict(self.diagnostics),labels=dict(self.applied_labels),
            fit_visible=(self.fit_visible1.isChecked(),self.fit_visible2.isChecked()),footer_visible=self.footer_visible.isChecked(),
            title_font_size=self.title_size.value(),body_font_size=self.body_size.value(),
            diagnostic_results=dict(self.diagnostic_results),
            diagnostic_initials={key:None if value is None else value.copy() for key,value in self.diagnostic_initials.items()},
            diagnostic_bands=dict(self.diagnostic_bands),diagnostic_components=dict(self.diagnostic_components),
            diagnostic_fit_prepared=dict(self.diagnostic_fit_prepared),
            overlay_signals=tuple(key for key,check in self.overlay_checks.items() if check.isChecked()),
            signal_alphas={key:field.value() for key,field in self.signal_alpha_fields.items()},
            fit_visibility={key:check.isChecked() for key,check in self.fit_checks.items()},
            fft_peak_enabled={key:check.isChecked() for key,check in self.peak_checks.items()},
            fit_enabled={key:channel.fit_enabled.isChecked() for key,channel in zip(SIGNAL_NAMES,self.all_channel_controls())},
            fixed_frequencies={key:dict(value) for key,value in self.fixed_frequencies_used.items()},
            rotation_deg=self.rotation_degrees_used,rotation_info=dict(self.rotation_info))
    def export(self):
        if not self.title_valid or self.job or not self.apply_labels():return
        try:snapshot=self.snapshot()
        except Exception as exc:self.log(exc);return
        source=Path(self.measurement.data_path);base=ExportFolderDialog.choose(self,source.parent,source.stem+'_dual_analysis')
        if base is None:return
        try:payloads=self.figure.capture_images(('png','pdf'))
        except Exception as exc:self.log(exc);return
        from .dual_export import export_dual
        self.run_job('Экспорт',lambda cancel:export_dual(base,snapshot,payloads))
    def save_picture(self):
        if not self.title_valid or self.job or self.prepared is None or self.dirty or not self.apply_labels():return
        path,selected=QFileDialog.getSaveFileName(self,'Сохранить текущую фигуру',str(Path(self.measurement.data_path).with_suffix('.png')),'PNG (*.png);;PDF (*.pdf);;SVG (*.svg)')
        if not path:return
        if not Path(path).suffix:path+='.pdf' if selected.startswith('PDF') else '.svg' if selected.startswith('SVG') else '.png'
        extension=Path(path).suffix.lower().lstrip('.')
        try:payload=self.figure.capture_images((extension,))[extension]
        except Exception as exc:self.log(exc);return
        from .export import write_picture
        self.run_job('Картинка',lambda cancel:write_picture(path,payload))
    def show_xy_animation(self):
        if self.prepared is None or self.dirty or self.job or not self.apply_labels():return
        from .xy_animation import XYAnimationDialog
        figure=self.figure;scale,unit=figure._xyunit()
        style=dict(title=figure.title_artist.get_text(),plane_title=figure.quadrature_axes.get_title(),
            xlabel=figure._expanded_label(figure._labels['quadrature.xlabel'],unit),
            ylabel=figure._expanded_label(figure._labels['quadrature.ylabel'],unit),
            xlim=figure.quadrature_axes.get_xlim(),ylim=figure.quadrature_axes.get_ylim(),
            scale=scale,alpha=figure.quadrature_points.get_alpha(),time_unit=self.time_unit.currentText(),
            fit_visible=figure.quadrature_fit.get_visible(),
            points_label=figure._expanded_label(figure._labels['legend.quadrature_points']),
            fit_label=figure._expanded_label(figure._labels['legend.quadrature_fit']))
        path=Path(self.measurement.data_path).with_suffix('.xy.gif')
        dialog=XYAnimationDialog(figure._quadrature_trace,style,path,self)
        self._animation_windows.append(dialog)
        dialog.finished.connect(lambda _:self._animation_windows.remove(dialog) if dialog in self._animation_windows else None)
        dialog.show()
    def closeEvent(self,event):
        self.closing=True;self.labels_timer.stop();self.cancel_job()
        for dialog in tuple(self._animation_windows):dialog.close()
        if self.pool.activeThreadCount() or self._animation_windows:event.ignore();QTimer.singleShot(100,self.close)
        else:event.accept()
