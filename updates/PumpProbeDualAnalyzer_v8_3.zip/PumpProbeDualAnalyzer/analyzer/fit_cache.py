"""Exact content keys for reusing independent fits within one loaded file."""
from hashlib import blake2b
import numpy as np


def fit_key(prepared, initial, band, fixed):
    """Include everything the optimizer/its spectral multistart actually uses."""
    digest=blake2b(digest_size=24)
    digest.update(prepared.signal_unit.encode('ascii'))
    for value in (prepared.time,prepared.y,prepared.fit_mask,prepared.frequencies,
                  prepared.spectrum,initial,band,
                  (prepared.resolution_hz,prepared.nyquist_hz)):
        array=np.ascontiguousarray(value)
        digest.update(str((array.shape,array.dtype.str)).encode('ascii'))
        digest.update(array.tobytes())
    digest.update(repr(sorted(fixed.items())).encode('ascii'))
    return digest.digest()
