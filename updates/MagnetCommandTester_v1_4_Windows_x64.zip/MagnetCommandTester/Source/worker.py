"""Все обращения к COM выполняются последовательно в одном QThread."""
import threading

import serial
from PyQt5.QtCore import QObject, pyqtSignal, pyqtSlot

from demo import DemoSerial
from driver import Cancelled, Connection, Limits, MagnetDriver, ProtocolError, ValidationError


class SerialWorker(QObject):
    logged = pyqtSignal(str)
    completed = pyqtSignal(str, bool, str, object)
    closed = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.cancel = threading.Event()
        self.driver = MagnetDriver(log=self.logged.emit, cancel=self.cancel)

    @pyqtSlot(str, object)
    def execute(self, operation, params):
        success = False
        try:
            if operation == 'stop':
                self.cancel.clear()
            else:
                self.driver._check_cancel()
            if operation == 'open':
                self.driver.factory = DemoSerial if params['demo'] else self.driver._serial_factory
                message = self.driver.open(Connection(**params['connection']))
            elif operation == 'close':
                self.driver.close()
                message = 'COM отключён. Состояние выхода источника не менялось.'
            elif operation == 'select':
                message = self.driver.select_address()
            elif operation == 'probe':
                message = self.driver.probe()
            elif operation == 'readings':
                message = self.driver.readings()
            elif operation == 'query':
                value = self.driver.query(params['command'])
                message = f"{params['command']} → {value}"
            elif operation == 'set':
                message = self.driver.set_value(params['kind'], params['value'], Limits(**params['limits']))
            elif operation == 'enable':
                message = self.driver.enable_output(Limits(**params['limits']))
            elif operation == 'stop':
                message = self.driver.zero_and_off()
            elif operation == 'relay':
                message = self.driver.switch_polarity(params['command'])
            else:
                raise ProtocolError(f'Неизвестная операция: {operation}')
            success = True
        except Cancelled as exc:
            message = str(exc)
        except ValidationError as exc:
            # Отказ по пределам не означает, что идентификация прибора потеряна.
            message = str(exc)
        except (serial.SerialException, OSError) as exc:
            message = f'Ошибка COM: {exc}. Состояние выхода неизвестно.'
            self.driver.close()
        except Exception as exc:
            message = f'{type(exc).__name__}: {exc}'
            self.driver.identified = False
        if not success:
            self.logged.emit('ERROR: ' + message)
        self.completed.emit(operation, success, message,
                            {'connected': self.driver.connected,
                             'identified': self.driver.identified,
                             'selected': self.driver.address_selected,
                             'relay_available': self.driver.relay_available,
                             'values': dict(self.driver.last)})

    @pyqtSlot()
    def shutdown(self):
        self.driver.close()
        self.closed.emit()
