import unittest

import serial

from demo import DemoSerial
from driver import Connection
from worker import SerialWorker


class WorkerTests(unittest.TestCase):
    def setUp(self):
        self.worker = SerialWorker()
        self.results = []
        self.worker.completed.connect(lambda *args: self.results.append(args))
        self.worker.driver.factory = DemoSerial
        self.worker.driver.open(Connection(timeout=0.1))

    def tearDown(self):
        self.worker.driver.close()

    def test_usb_error_closes_connection_and_invalidates_identity(self):
        self.worker.execute('probe', {})
        self.assertTrue(self.results[-1][1])
        link = self.worker.driver.source
        def fail(*args):
            raise serial.SerialException('USB disconnected')
        link.read = fail
        self.worker.execute('readings', {})
        operation, success, message, state = self.results[-1]
        self.assertFalse(success)
        self.assertIn('Состояние выхода неизвестно', message)
        self.assertFalse(state['connected'])
        self.assertFalse(state['identified'])
        self.assertFalse(link.is_open)

    def test_stop_resets_cancellation_and_turns_output_off(self):
        self.worker.execute('probe', {})
        link = self.worker.driver.source
        link.on = True
        link.current = 0.1
        self.worker.cancel.set()
        self.worker.execute('readings', {})
        self.assertFalse(self.results[-1][1])
        self.worker.execute('stop', {})
        self.assertTrue(self.results[-1][1])
        self.assertFalse(link.on)
        self.assertEqual(link.current, 0)
        self.assertFalse(self.worker.cancel.is_set())

    def test_local_limit_refusal_preserves_identity_and_allows_correction(self):
        self.worker.execute('probe', {})
        link = self.worker.driver.source
        link.voltage = 28.518
        self.worker.execute('enable', {'limits': {'current': 2, 'voltage': 5}})
        self.assertFalse(self.results[-1][1])
        self.assertTrue(self.results[-1][3]['identified'])
        self.assertFalse(link.on)
        self.worker.execute('set', {'kind': 'PV', 'value': 2,
                                    'limits': {'current': 2, 'voltage': 5}})
        self.assertTrue(self.results[-1][1])
        self.assertTrue(self.results[-1][3]['identified'])
        self.assertEqual(link.voltage, 2)

    def test_malformed_device_reply_still_invalidates_identity(self):
        self.worker.execute('probe', {})
        link = self.worker.driver.source
        original_write = link.write
        def malformed(data):
            if data == b'MC?\r':
                link.writes.append(data)
                link.buffer.extend(b'NaN\r')
                return len(data)
            return original_write(data)
        link.write = malformed
        self.worker.execute('readings', {})
        self.assertFalse(self.results[-1][1])
        self.assertFalse(self.results[-1][3]['identified'])
        self.assertTrue(self.results[-1][3]['connected'])

    def test_shared_usb_loss_does_not_retry_relay_or_enable_output(self):
        self.worker.driver.close()
        self.worker.driver.open(Connection(shared_relay=True, timeout=0.1))
        self.worker.execute('probe', {})
        link = self.worker.driver.source
        original_write, original_read = link.write, link.read
        relay_sent = []
        def write(data):
            result = original_write(data)
            if data == b'X\r': relay_sent.append(data)
            return result
        def read(count=1):
            if relay_sent: raise serial.SerialException('USB disappeared after relay switching')
            return original_read(count)
        link.write, link.read = write, read
        self.worker.execute('relay', {'command': 'X'})
        self.assertTrue(self.results[-1][1])
        self.assertIn('Контакты не подтверждены', self.results[-1][2])
        self.assertFalse(self.results[-1][3]['identified'])
        self.worker.execute('probe', {})
        self.assertFalse(self.results[-1][1])
        self.assertFalse(self.results[-1][3]['connected'])
        self.assertEqual(link.writes.count(b'X\r'), 1)
        self.assertNotIn(b'OUT 1\r', link.writes)


if __name__ == '__main__':
    unittest.main()
