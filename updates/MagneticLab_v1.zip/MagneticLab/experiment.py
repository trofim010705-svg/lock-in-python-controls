"""One experiment owns the devices until data saving and magnet cleanup finish."""
from dataclasses import asdict
import math
from pathlib import Path
import threading
import time
import traceback

from PyQt5.QtCore import QThread, pyqtSignal

from models import signal_statistics
from storage import create_folder, now, save_point, save_summary, metadata
from report import save_figures


class ExperimentRunner(QThread):
    changed = pyqtSignal(str)
    point_started = pyqtSignal(int, int)
    samples = pyqtSignal(object)
    point_ready = pyqtSignal(object)
    prepared = pyqtSignal(object)
    outcome = pyqtSignal(object)
    log = pyqtSignal(str)

    def __init__(self, parameters, calibration, lockin, magnet, field, magnet_connected,
                 demo=False, parent=None):
        super().__init__(parent)
        self.parameters, self.calibration = parameters, calibration
        self.lockin, self.magnet, self.field = lockin, magnet, field
        self.magnet_connected, self.demo = magnet_connected, demo
        self.stop_event = threading.Event()
        self.abort_error = ''
        self.unsaved = None
        self.folder = None

    def stop(self):
        self.stop_event.set()

    def abort(self, message):
        self.abort_error = message
        self.stop_event.set()

    def check(self):
        if self.abort_error:
            raise RuntimeError(self.abort_error)
        if self.stop_event.is_set():
            raise InterruptedError('Остановлено пользователем.')
        if not self.field.ready:
            raise RuntimeError(self.field.error or 'Нет данных NI.')

    def run(self):
        p = self.parameters
        points = []
        info = {'application': 'Magnetic Lab 1.0', 'started': now(), 'demo': self.demo,
                'parameters': asdict(p), 'calibration': asdict(self.calibration),
                'signal_formulas': {'amplitude': 'sqrt(X1^2 + Y1^2)',
                    'phase': 'atan2(Y1, X1), degrees in [0,360)',
                    'mean_amplitude': 'arithmetic mean of individual amplitudes',
                    'mean_phase': 'circular mean of unit phasors; undefined for zero resultant',
                    'field': 'B_mT = slope_mT_per_mV * (1000 * U_V) + offset_mT'},
                'timing': 'X1 then Y1 are read sequentially; NI and Lock-in have a software time anchor, not a common hardware trigger.',
                'sig_bal': 'Stored as metadata only; no voltage-to-angle conversion applied.',
                'points_count': len(p.currents())}
        error, reason, cleanup_error = '', 'complete', ''
        try:
            p.validate()
            self.calibration.validate()
            self.check()
            self.folder = create_folder(p.folder, p.name)
            self.changed.emit('Папка: ' + str(self.folder))
            metadata(self.folder / 'experiment.txt', dict(info, result='preparing'))
            self.changed.emit('Чтение текущих настроек Lock-in…')
            info['lockin'] = self.lockin.call('lab_snapshot', cancel=self.stop_event)
            info['ni'] = dict(self.field.metadata)
            self.prepared.emit(info['lockin'])
            for index, target in enumerate(p.currents(), 1):
                self.check()
                current_state = {}
                if p.mode == 'sweep':
                    self.changed.emit(f'Точка {index}/{len(p.currents())}: установка {target:+.4g} A')
                    self.magnet.call('set_current', {'current': target, 'voltage': p.voltage_V}, self.stop_event)
                    current_state = self.magnet.call('wait_current', {'current': target}, self.stop_event)
                    if self.stop_event.wait(p.settle_s):
                        self.check()
                elif self.magnet_connected:
                    current_state = self.magnet.call('read', cancel=self.stop_event)
                self.check()
                self.point_started.emit(index, len(p.currents()))
                self.changed.emit(f'Точка {index}/{len(p.currents())}: измерение {p.acquisition_s:g} s')
                start = time.perf_counter()
                deadline = start + p.acquisition_s
                self.field.begin(start, deadline)
                rows, batch, next_tick, last_emit = [], [], start, start
                sample_error = ''
                try:
                    while time.perf_counter() < deadline:
                        self.check()
                        if self.stop_event.wait(max(0, min(next_tick, deadline) - time.perf_counter())):
                            self.check()
                        if time.perf_counter() >= deadline:
                            break
                        sample = self.lockin.call('lab_xy', cancel=self.stop_event)
                        if sample['end'] <= deadline:
                            row = (sample['start'] - start, sample['end'] - start,
                                   sample['x'], sample['y'], sample['amplitude'], sample['phase'],
                                   sample['status'], sample['overload'])
                            rows.append(row)
                            batch.append(row)
                        if time.perf_counter() - last_emit >= 0.1:
                            self.samples.emit(tuple(batch))
                            batch = []
                            last_emit = time.perf_counter()
                        period = p.period_ms / 1000
                        next_tick += period
                        if next_tick < time.perf_counter():
                            next_tick += math.ceil((time.perf_counter() - next_tick) / period) * period
                except Exception as exc:
                    sample_error = f'{type(exc).__name__}: {exc}'
                end = min(time.perf_counter(), deadline)
                if batch:
                    self.samples.emit(tuple(batch))
                field = self.field.finish(None, self.calibration)
                end = field['end_monotonic_s']
                point_reason = ('error' if self.abort_error else 'stopped' if self.stop_event.is_set() else
                                'error' if sample_error or not field['valid'] or not rows else 'complete')
                point = {'index': index, 'target_current_A': target,
                    'measured_current_A': current_state.get('signed_current_A'),
                    'magnet': current_state, 'result': point_reason, 'error': sample_error,
                    'acquisition_actual_s': end - start, 'field': field,
                    'statistics': signal_statistics(rows), 'lockin': info['lockin'],
                    'parameters': asdict(p), 'started_monotonic_s': start, 'saved': now()}
                sign_name = 'held' if target is None else f'{target:+.5f}'.replace('-', 'm').replace('+', 'p').replace('.', 'p') + 'A'
                point_folder = self.folder / f'point_{index:04d}_{sign_name}'
                self.unsaved = (rows, point, point_folder)
                save_point(point_folder, rows, point)
                self.unsaved = None
                points.append(point)
                save_summary(self.folder, points, dict(info, result='running'))
                self.point_ready.emit(point)
                if point_reason != 'complete':
                    if self.stop_event.is_set():
                        raise InterruptedError('Остановлено пользователем; частичная точка сохранена.')
                    raise RuntimeError(sample_error or field['error'] or 'В точке нет отсчётов Lock-in.')
        except InterruptedError as exc:
            reason = 'stopped'
            error = str(exc)
        except Exception as exc:
            reason = 'error'
            error = f'{type(exc).__name__}: {exc}'
            self.log.emit(traceback.format_exc())
        finally:
            # No cancellation token here: Stop must not cancel the zero/off command.
            if self.magnet_connected:
                self.changed.emit('Обнуление тока и выключение выхода…')
                try:
                    info['magnet_final'] = self.magnet.call('zero', timeout=90)
                except Exception as exc:
                    cleanup_error = str(exc)
                    reason = 'error'
                    self.log.emit('Не удалось подтвердить обнуление магнита: ' + cleanup_error)
            info.update(finished=now(), result=reason, error=error, cleanup_error=cleanup_error)
            if self.folder is not None:
                try:
                    save_summary(self.folder, points, info)
                    if points:
                        self.changed.emit('Сохранение графиков…' + (' Ток уже обнулён.' if self.magnet_connected and not cleanup_error else ''))
                        save_figures(self.folder, points, info.get('lockin', {}).get('signal_unit', 'V'))
                except Exception as exc:
                    error += '\nОшибка сохранения сводки: ' + str(exc)
                    reason = 'error'
                    info.update(result=reason, error=error)
                    try:
                        save_summary(self.folder, points, info)
                    except Exception:
                        pass
            self.outcome.emit({'reason': reason, 'error': error, 'cleanup_error': cleanup_error,
                'folder': str(self.folder) if self.folder else '', 'points': points,
                'metadata': info, 'unsaved': self.unsaved is not None})
