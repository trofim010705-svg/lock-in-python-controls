"""End-to-end demo: manual polarity/start, signed sweep, files, GUI, shutdown."""
import json
from pathlib import Path
import platform
import sys
import time
import traceback
from types import SimpleNamespace


def run(report_path):
    from PyQt5.QtCore import QTimer, QSettings
    from PyQt5.QtWidgets import QApplication, QScrollArea
    import numpy as np
    from window import LabWindow
    from ni_input.backend import load_daqmx
    import pyvisa

    _, constants, *_ = load_daqmx()
    assert constants.TerminalConfiguration.DIFF.value == 10106

    report = Path(report_path).resolve()
    report.parent.mkdir(parents=True, exist_ok=True)
    app = QApplication(sys.argv[:1])
    app.setStyle('Fusion')
    app.setOrganizationName('LabTools')
    app.setApplicationName('MagneticLabBuildCheck')
    QSettings.setDefaultFormat(QSettings.IniFormat)
    QSettings.setPath(QSettings.IniFormat, QSettings.UserScope, str(report.parent / 'settings'))
    window = LabWindow(SimpleNamespace(demo=True, serial=None, timeout=2000, max_frequency=120000))
    window.folder.setText(str(report.parent / 'измерения'))
    window.current_start.setValue(-1)
    window.current_stop.setValue(1)
    window.intervals.setValue(2)
    window.duration.setValue(.4)
    window.sample_delay.setValue(50)
    window.settle.setValue(.1)
    window.manual_current.setValue(1)
    window.slope.setValue(1)
    window.offset.setValue(0)
    window.show()
    outcome = {'ok': False, 'frozen': bool(getattr(sys, 'frozen', False)),
               'platform': platform.platform(), 'python': platform.python_version(),
               'qt_platform': app.platformName()}
    phase = 'connecting'
    ending = False
    initial_writes = 0
    started_at = time.monotonic()

    def finish(ok, detail):
        nonlocal ending
        if ending:
            return
        ending = True
        outcome.update(ok=ok, detail=detail, elapsed_s=time.monotonic() - started_at,
                       journal=window.journal.toPlainText())
        report.write_text(json.dumps(outcome, ensure_ascii=False, indent=2), encoding='utf-8')
        window.close()

    previous_hook = sys.excepthook
    sys.excepthook = lambda kind, value, tb: finish(False, ''.join(traceback.format_exception(kind, value, tb)))

    def first_point(index, total):
        if index == 1:
            writes = window.mag_worker.driver.source.writes[initial_writes:]
            commands = [x.decode().strip() for x in writes]
            outcome['first_point_no_reset'] = not any(x in commands for x in ('PC 0', 'OUT 0', 'H', 'X'))

    def tick():
        nonlocal phase, initial_writes
        if ending:
            return
        try:
            if phase == 'connecting':
                if window.connected and window.mag_state['identified'] and window.field_data.blocks and not window.mag_busy:
                    phase = 'manual_positive'
                    window.manual_magnet('set_current')
            elif phase == 'manual_positive' and not window.mag_busy:
                assert window.mag_state['polarity'] == 1
                assert window.mag_state['values']['OUT?']
                phase = 'flip_start'
                window.manual_magnet('flip_start')
            elif phase == 'flip_start' and not window.mag_busy:
                assert window.mag_state['polarity'] == -1
                assert window.mag_state['values']['OUT?']
                assert abs(window.mag_state['values']['PC?'] - 1) < .001
                outcome['manual_flip_and_start'] = True
                initial_writes = len(window.mag_worker.driver.source.writes)
                phase = 'sweep'
                window.start_experiment()
            elif phase == 'sweep':
                if window.runner and not outcome.get('point_hook'):
                    window.runner.point_started.connect(first_point)
                    outcome['point_hook'] = True
                if not hasattr(window, 'last_outcome') or window.exclusive != 'idle':
                    return
                result = window.last_outcome
                assert result['reason'] == 'complete', result
                assert len(result['points']) == 3
                assert all(p['field']['valid'] for p in result['points'])
                assert all(p['statistics']['samples'] >= 4 for p in result['points'])
                assert outcome.get('first_point_no_reset')
                assert not window.mag_state['values']['OUT?']
                assert window.mag_state['values']['PC?'] == 0
                folder = Path(result['folder'])
                assert (folder / 'field_dependence.png').stat().st_size > 1000
                assert (folder / 'field_dependence.pdf').stat().st_size > 1000
                assert (folder / 'experiment.txt').exists()
                summary = np.loadtxt(folder / 'summary.dat', delimiter='\t', skiprows=1, ndmin=2)
                assert summary.shape == (3, 11)
                assert np.allclose(summary[:, 3], [-10, 0, 10], atol=.2)
                for file in folder.glob('point_*/signal.dat'):
                    values = np.loadtxt(file, delimiter='\t', skiprows=1, ndmin=2)
                    assert values.shape[1] == 9
                    assert ((values[:, 5] >= 0) & (values[:, 5] < 360)).all()
                    assert np.allclose(values[:, 4], np.hypot(values[:, 2], values[:, 3]))
                window.refresh_dashboard()
                settings_scroll = window.dashboard.findChild(QScrollArea)
                assert settings_scroll.widget().width() <= settings_scroll.viewport().width(), 'Settings pane clipped horizontally'
                window.grab().save(str(report.parent / 'preview.png'))
                outcome['folder'] = str(folder)
                outcome['field_points_mT'] = summary[:, 3].tolist()
                finish(True, 'Manual flip/start, -1/0/+1 A sweep, matching NI average, data, figures and zero/off checked in demo.')
        except Exception:
            finish(False, traceback.format_exc())

    timer = QTimer()
    timer.setInterval(20)
    timer.timeout.connect(tick)
    timer.start()
    QTimer.singleShot(0, lambda: window.submit('open'))
    QTimer.singleShot(0, window.toggle_magnet)
    QTimer.singleShot(0, window.toggle_ni)
    QTimer.singleShot(60000, lambda: finish(False, 'Demo test timed out.'))
    app.exec_()
    sys.excepthook = previous_hook
    outcome['threads_stopped'] = (not window.thread.isRunning() and not window.mag_thread.isRunning()
        and not window.field_reader.isRunning() and (window.runner is None or not window.runner.isRunning()))
    outcome['ok'] = bool(outcome['ok'] and outcome['threads_stopped'])
    report.write_text(json.dumps(outcome, ensure_ascii=False, indent=2), encoding='utf-8')
    return 0 if outcome['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(run(sys.argv[1] if len(sys.argv) > 1 else 'selftest.json'))
