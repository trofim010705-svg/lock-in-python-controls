"""Single-owner instrument workers and thread-safe requests from the experiment."""
import math
import threading
import time
import traceback

import numpy as np
import serial
from PyQt5.QtCore import QObject, QThread, Qt, pyqtSignal, pyqtSlot

from gui_app import Worker
from magnet_driver import MagnetDriver, Connection
from magnet_demo import DemoSerial
from magnet import MagnetController
from models import phase_deg
from ni_input.core import Config
from ni_input.daq_process import NIProcessInput


class Ticket:
    def __init__(self, cancel=None):
        self.event = threading.Event()
        self.cancel = cancel
        self.value = None
        self.error = None
        self.started = False

    def finish(self, value=None, error=None):
        self.value, self.error = value, error
        self.event.set()


class Port(QObject):
    request = pyqtSignal(str, object)

    def __init__(self, worker):
        super().__init__()
        self.request.connect(worker.execute, Qt.QueuedConnection)

    def call(self, operation, data=None, cancel=None, timeout=90):
        ticket = Ticket(cancel)
        self.request.emit(operation, {'ticket': ticket, 'data': data or {}})
        deadline = time.monotonic() + timeout
        while not ticket.event.wait(0.025):
            # An in-flight write must finish before cleanup is queued. Otherwise
            # a delayed PC/OUT command could execute after the cleanup command.
            if time.monotonic() > deadline:
                raise TimeoutError(f'Нет ответа рабочего потока на {operation}. Состояние операции неизвестно.')
        if ticket.error is not None:
            raise ticket.error
        return ticket.value


def snapshot(instrument, cancel=None):
    original = instrument.transport
    raw = {}

    class Recorder:
        def exchange(self, command, *args, **kwargs):
            if cancel is not None and cancel.is_set():
                raise InterruptedError('Чтение настроек отменено.')
            result = original.exchange(command, *args, **kwargs)
            raw[command] = result[0]
            return result

    instrument.transport = Recorder()
    try:
        firmware = instrument.query('VER')
        mode = int(instrument.values('REFMODE')[0])
        imode = int(instrument.values('IMODE')[0])
        sections = {title: instrument.read_section(title) for title in instrument.sections}
        return {'firmware': firmware, 'reference_mode': mode, 'input_mode': imode,
                'signal_unit': 'V' if imode == 0 else 'A', 'sections': sections,
                'raw_replies': raw, 'usb_resource': getattr(getattr(original, 'module', None), '_USB_RESOURCE', 'DEMO')}
    finally:
        instrument.transport = original


class LabLockinWorker(Worker):
    plant = None

    @pyqtSlot(str, object)
    def execute(self, job, payload):
        if job == 'poll':
            payload = dict(payload, include_xy=True)
        if job not in ('lab_snapshot', 'lab_xy'):
            return super().execute(job, payload)
        ticket = payload['ticket']
        try:
            if ticket.cancel is not None and ticket.cancel.is_set():
                raise InterruptedError('Измерение отменено.')
            ticket.started = True
            if self.instrument is None:
                raise RuntimeError('Lock-in не подключён.')
            if job == 'lab_snapshot':
                ticket.finish(snapshot(self.instrument, ticket.cancel))
                return
            inst = self.instrument
            t0 = time.monotonic()
            if self.args[0] and self.plant is not None:
                current = self.plant.get_current()
                amplitude = 12e-6 * (1 + .35 * math.sin(current * 1.2))
                phase = math.radians(165 + 24 * current)
                x = amplitude * math.cos(phase) + .25e-6 * math.sin(t0 * 71)
                y = amplitude * math.sin(phase) + .25e-6 * math.cos(t0 * 47)
                status, overload = 1, 0
            else:
                x_values = inst.values(inst.channel_command('X', 1) + '.')
                status, overload = inst.status, inst.overload
                y_values = inst.values(inst.channel_command('Y', 1) + '.')
                status |= inst.status
                overload |= inst.overload
                if len(x_values) != 1 or len(y_values) != 1:
                    raise RuntimeError('От Lock-in ожидалась одна пара X1/Y1.')
                x, y = x_values[0], y_values[0]
            if not math.isfinite(x) or not math.isfinite(y):
                raise RuntimeError('Lock-in вернул NaN/Inf.')
            ticket.finish({'start': t0, 'end': time.monotonic(), 'x': x, 'y': y,
                           'amplitude': math.hypot(x, y), 'phase': phase_deg(x, y),
                           'status': status, 'overload': overload})
        except Exception as exc:
            if not isinstance(exc, InterruptedError) and self.instrument is not None:
                try:
                    self.instrument.transport.close()
                except Exception:
                    pass
                self.instrument = None
                self.failed.emit('lab_usb', str(exc), True)
            ticket.finish(error=exc)


class MagnetWorker(QObject):
    state_changed = pyqtSignal(object)
    completed = pyqtSignal(str, bool, str)
    logged = pyqtSignal(str)
    stopped = pyqtSignal()

    def __init__(self, demo=False, plant=None):
        super().__init__()
        self.demo = demo
        self.driver = MagnetDriver(log=self.logged.emit, factory=DemoSerial if demo else None)
        self.controller = MagnetController(self.driver, plant)

    @pyqtSlot(str, object)
    def execute(self, operation, payload):
        ticket = payload.get('ticket')
        data = payload.get('data', payload)
        try:
            if ticket is not None:
                if ticket.cancel is not None and ticket.cancel.is_set():
                    raise InterruptedError('Команда отменена до исполнения.')
                ticket.started = True
            if operation == 'open':
                self.controller.polarity = None
                self.driver.open(Connection(source_port=data['port'], baudrate=data['baud'],
                    address=data['address'], timeout=1.0, shared_relay=True))
                self.driver.probe()
            elif operation == 'close':
                self.driver.close()
                self.controller.polarity = None
            elif operation == 'zero':
                self.controller.zero()
            elif operation == 'flip':
                self.controller.switch(-self.controller.polarity if self.controller.polarity else 1)
            elif operation == 'flip_start':
                if self.controller.polarity is None:
                    raise ValueError('Сначала установите ток, чтобы задать исходную полярность.')
                sign = -self.controller.polarity
                self.controller.switch(sign)
                if data['current'] > 0:
                    self.controller.set_signed(sign * data['current'], data['voltage'])
            elif operation == 'set_current':
                self.controller.set_signed(data['current'], data['voltage'],
                                           ticket.cancel if ticket is not None else None)
            elif operation == 'wait_current':
                self.controller.wait_current(data['current'], ticket.cancel)
            elif operation == 'read':
                self.driver.readings()
            else:
                raise ValueError('Неизвестная команда магнита: ' + operation)
            state = self.controller.state()
            self.state_changed.emit(state)
            if ticket is not None:
                ticket.finish(state)
            else:
                self.completed.emit(operation, True, 'Выполнено: ' + operation)
        except Exception as exc:
            if operation == 'open' or isinstance(exc, (serial.SerialException, OSError)):
                self.driver.close()
                self.controller.polarity = None
            self.logged.emit(traceback.format_exc())
            self.state_changed.emit(self.controller.state())
            if ticket is not None:
                ticket.finish(error=exc)
            else:
                self.completed.emit(operation, False, str(exc))

    @pyqtSlot()
    def shutdown(self):
        if self.driver.connected:
            try:
                self.controller.zero()
            except Exception as exc:
                self.logged.emit('Закрытие: обнуление не подтверждено: ' + str(exc))
        self.driver.close()
        self.stopped.emit()


class FieldReader(QThread):
    configured = pyqtSignal(object)
    failed = pyqtSignal(str)
    diagnostic = pyqtSignal(str)

    def __init__(self, config, store, plant=None, parent=None):
        super().__init__(parent)
        self.config, self.store, self.plant = config, store, plant
        self.stop_event = threading.Event()

    def stop(self):
        self.stop_event.set()

    def run(self):
        source = None
        try:
            if self.config.demo:
                info = {'demo': True, 'physical_channel': 'DEMO/ai3',
                        'sample_rate_Hz': self.config.rate, 'terminal_configuration': 'DIFFERENTIAL',
                        'origin_monotonic_s': time.monotonic(), 'time_anchor_uncertainty_s': 0}
            else:
                source = NIProcessInput(progress=self.diagnostic.emit, cancel=self.stop_event)
                info = source.open(self.config)
            rate = info['sample_rate_Hz']
            origin = info['origin_monotonic_s']
            self.store.configure(info)
            self.configured.emit(info)
            count = 0
            while not self.stop_event.is_set():
                if self.config.demo:
                    n = self.config.block_samples
                    target = origin + (count + n) / rate
                    if self.stop_event.wait(max(0, target - time.monotonic())):
                        break
                    t = origin + (count + np.arange(n)) / rate
                    values = self.plant.get_current() * .01 + .000005 * np.sin(t * 73)
                else:
                    values = source.read(self.stop_event)
                if len(values):
                    self.store.append(count, rate, origin, values)
                    count += len(values)
        except Exception as exc:
            if not (isinstance(exc, InterruptedError) and self.stop_event.is_set()):
                self.diagnostic.emit(traceback.format_exc())
                self.store.fail(str(exc))
                self.failed.emit(str(exc))
        finally:
            if source is not None:
                try:
                    source.close()
                except Exception as exc:
                    self.diagnostic.emit(traceback.format_exc())
                    self.failed.emit(str(exc))
            if self.store.ready:
                self.store.fail('Сбор NI остановлен.')
