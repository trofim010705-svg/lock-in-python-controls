from dataclasses import replace
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

from experiment import ExperimentRunner
from models import Calibration, Experiment


class Lockin:
    def __init__(self):
        self.samples = 0
        self.on_sample = None

    def call(self, job, *args, **kwargs):
        if job == 'lab_snapshot':
            return {'signal_unit': 'V', 'firmware': 'DEMO'}
        self.samples += 1
        if self.on_sample:
            self.on_sample()
        t = time.perf_counter()
        return {'start': t, 'end': t, 'x': 3e-6, 'y': 4e-6,
                'amplitude': 5e-6, 'phase': 53.13, 'status': 0, 'overload': 0}


class Magnet:
    def __init__(self):
        self.calls = []
        self.current = 0

    def call(self, job, data=None, *args, **kwargs):
        self.calls.append((job, data))
        if job == 'set_current':
            self.current = data['current']
        if job == 'zero':
            self.current = 0
        return {'signed_current_A': self.current, 'values': {'PC?': abs(self.current), 'OUT?': bool(self.current)}}


class Field:
    ready = True
    error = ''
    metadata = {'sample_rate_Hz': 1000}

    def __init__(self, magnet):
        self.magnet = magnet

    def begin(self, start, end):
        self.start, self.end = start, end

    def finish(self, end, calibration):
        return {'valid': True, 'samples': 100, 'field_mean_mT': self.magnet.current * 10,
                'error': '', 'end_monotonic_s': min(time.perf_counter(), self.end)}


class ExperimentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.lockin, self.magnet = Lockin(), Magnet()
        self.field = Field(self.magnet)
        self.parameters = Experiment(start_A=-1, stop_A=1, intervals=2, acquisition_s=.1,
            period_ms=10, settle_s=0, folder=self.temp.name)
        self.plots = patch('experiment.save_figures')
        self.plots.start()

    def tearDown(self):
        self.plots.stop()
        self.temp.cleanup()

    def runner(self, parameters=None):
        runner = ExperimentRunner(parameters or self.parameters, Calibration(), self.lockin,
            self.magnet, self.field, True, demo=True)
        self.outcome = []
        runner.outcome.connect(self.outcome.append)
        return runner

    def test_signed_grid_data_per_point_and_cleanup(self):
        runner = self.runner()
        runner.run()
        result = self.outcome[-1]
        self.assertEqual(result['reason'], 'complete')
        self.assertEqual([p['target_current_A'] for p in result['points']], [-1, 0, 1])
        self.assertEqual([p['field']['field_mean_mT'] for p in result['points']], [-10, 0, 10])
        self.assertEqual(self.magnet.calls[-1][0], 'zero')
        self.assertEqual(len(list(Path(result['folder']).glob('point_*/signal.dat'))), 3)
        self.assertEqual(len(list(Path(result['folder']).glob('point_*/parameters.txt'))), 3)
        self.assertTrue((Path(result['folder']) / 'summary.dat').exists())

    def test_stop_saves_partial_point_then_zeros(self):
        runner = self.runner()
        self.lockin.on_sample = runner.stop
        runner.run()
        self.assertEqual(self.outcome[-1]['reason'], 'stopped')
        self.assertEqual(self.outcome[-1]['points'][0]['result'], 'stopped')
        self.assertEqual(self.magnet.calls[-1][0], 'zero')

    def test_disk_error_keeps_raw_point_in_memory_and_zeros(self):
        runner = self.runner()
        with patch('experiment.save_point', side_effect=OSError('disk full')):
            runner.run()
        self.assertEqual(self.outcome[-1]['reason'], 'error')
        self.assertIsNotNone(runner.unsaved)
        self.assertTrue(runner.unsaved[0])
        self.assertEqual(self.magnet.calls[-1][0], 'zero')

    def test_single_measurement_does_not_set_or_flip_current(self):
        runner = self.runner(replace(self.parameters, mode='single'))
        runner.run()
        self.assertEqual(self.outcome[-1]['reason'], 'complete')
        self.assertEqual([job for job, _ in self.magnet.calls], ['read', 'zero'])


if __name__ == '__main__':
    unittest.main()
