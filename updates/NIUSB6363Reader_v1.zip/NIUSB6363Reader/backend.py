"""Только аналоговый вход ai3. Никаких AO/DO, сброса устройства или автокалибровки."""
from datetime import datetime
import math
import time

import numpy as np

DRIVER_URL = 'https://www.ni.com/en/support/downloads/drivers/download.ni-daq-mx.html'


def explain_error(exc):
    code = getattr(exc, 'error_code', None)
    if type(exc).__name__ == 'DaqNotFoundError':
        return 'Не найден системный драйвер NI-DAQmx. Установите NI-DAQmx с сайта NI и перезапустите программу.'
    if code == -50103:
        return 'Ресурс NI занят. Закройте Test Panels в NI MAX и другие программы, использующие AI этой платы.'
    if code == -200279:
        return 'Переполнен входной буфер NI-DAQmx. Сбор остановлен: уменьшите частоту оцифровки или нагрузку на USB/компьютер.'
    if code == -200220:
        return 'Устройство с таким именем не найдено. Сверьте Dev1/Dev2 с именем платы в NI MAX.'
    return f'{type(exc).__name__}: {exc}'


def load_daqmx():
    try:
        import nidaqmx
        from nidaqmx import constants
        from nidaqmx.stream_readers import AnalogSingleChannelReader
        from nidaqmx.system import System, Device
    except ImportError as exc:
        raise RuntimeError('Не установлен Python-пакет nidaqmx. Запустите start.bat или pip install -r requirements.txt. '
                           'Также нужен системный драйвер NI-DAQmx.') from exc
    return nidaqmx, constants, AnalogSingleChannelReader, System, Device


def discover_devices():
    _, _, _, system_type, _ = load_daqmx()
    system = system_type.local()
    version = system.driver_version
    found = []
    for device in system.devices:
        channels = list(device.ai_physical_chans.channel_names)
        if f'{device.name}/ai3' in channels:
            found.append({'name': device.name, 'product': device.product_type,
                          'serial': str(device.dev_serial_num), 'channel': f'{device.name}/ai3',
                          'ni_simulated_device': bool(device.dev_is_simulated)})
    return found, f'NI-DAQmx {version.major_version}.{version.minor_version}.{version.update_version}'


class NIInput:
    def __init__(self, loader=load_daqmx):
        self.loader = loader
        self.task = None

    def open(self, config):
        config.validate()
        api, constants, reader_type, _, device_type = self.loader()
        device = device_type(config.device)
        if config.channel not in device.ai_physical_chans.channel_names:
            raise ValueError(f'Канал {config.channel} не найден на выбранном устройстве.')
        maximum = float(device.ai_max_single_chan_rate)
        if config.rate > maximum:
            raise ValueError(f'Для этого устройства максимум одного AI: {maximum:g} выборок/с.')
        self.task = api.Task()
        try:
            channel = self.task.ai_channels.add_ai_voltage_chan(
                config.channel, terminal_config=constants.TerminalConfiguration.DIFF,
                min_val=-config.voltage_range, max_val=config.voltage_range,
                units=constants.VoltageUnits.VOLTS)
            self.task.timing.cfg_samp_clk_timing(config.rate,
                sample_mode=constants.AcquisitionType.CONTINUOUS,
                samps_per_chan=max(10_000, math.ceil(config.rate * 2)))
            self.task.in_stream.over_write = constants.OverwriteMode.DO_NOT_OVERWRITE_UNREAD_SAMPLES
            self.task.control(constants.TaskMode.TASK_COMMIT)
            self.rate = float(self.task.timing.samp_clk_rate)
            if not math.isfinite(self.rate) or self.rate <= 0:
                raise RuntimeError('NI-DAQmx вернул неверную частоту оцифровки.')
            self.reader = reader_type(self.task.in_stream)
            self.array = np.empty(config.block_samples, dtype=np.float64)
            self.task.start()
            return {'device': config.device, 'physical_channel': config.channel,
                    'product': device.product_type, 'serial': str(device.dev_serial_num),
                    'sample_rate_Hz': self.rate, 'requested_sample_rate_Hz': config.rate,
                    'voltage_min_V': float(channel.ai_min), 'voltage_max_V': float(channel.ai_max),
                    'terminal_configuration': 'DIFFERENTIAL', 'demo': False,
                    'ni_simulated_device': bool(getattr(device, 'dev_is_simulated', False)),
                    'started_local': datetime.now().astimezone().isoformat()}
        except Exception:
            self.close()
            raise

    def read(self, stop_event):
        if stop_event.is_set():
            return np.empty(0, dtype=np.float64)
        available = int(self.task.in_stream.avail_samp_per_chan)
        if available == 0:
            stop_event.wait(0.005)
            return np.empty(0, dtype=np.float64)
        wanted = min(available, len(self.array))
        count = self.reader.read_many_sample(self.array,
                     number_of_samples_per_channel=wanted, timeout=0.25)
        return self.array[:count]

    def close(self):
        if self.task is not None:
            task, self.task = self.task, None
            task.close()


class DemoInput:
    def open(self, config):
        config.validate()
        self.config = config
        self.rate = config.rate
        self.index = 0
        self.next_read = time.monotonic()
        self.random = np.random.default_rng(6363)
        return {'device': 'DEMO', 'physical_channel': 'DEMO/ai3', 'product': 'Симулятор USB-6363',
                'sample_rate_Hz': self.rate, 'voltage_min_V': -config.voltage_range,
                'voltage_max_V': config.voltage_range, 'terminal_configuration': 'DIFFERENTIAL',
                'demo': True, 'started_local': datetime.now().astimezone().isoformat()}

    def read(self, stop_event):
        count = self.config.block_samples
        self.next_read += count / self.rate
        if stop_event.wait(max(0, self.next_read - time.monotonic())):
            return np.empty(0, dtype=np.float64)
        t = (self.index + np.arange(count)) / self.rate
        self.index += count
        amplitude = min(0.05, self.config.voltage_range * 0.3)
        offset = min(0.1, self.config.voltage_range * 0.2)
        return offset + amplitude * np.sin(2 * np.pi * min(1, self.rate / 20) * t) + self.random.normal(0, amplitude/30, count)

    def close(self):
        pass
