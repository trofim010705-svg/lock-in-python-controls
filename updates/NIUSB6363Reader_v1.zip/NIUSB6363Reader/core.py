"""Конфигурация, ограниченный буфер и экспорт дифференциального AI3."""
from dataclasses import dataclass
from datetime import datetime
import json
import math
import os
from pathlib import Path
import re
import tempfile
import threading

import numpy as np

RANGES = (10.0, 5.0, 2.0, 1.0, 0.5, 0.2, 0.1)
MAX_POINTS = 500_000


@dataclass(frozen=True)
class Config:
    device: str = 'Dev1'
    rate: float = 1_000.0
    voltage_range: float = 10.0
    window_seconds: float = 10.0
    demo: bool = False

    @property
    def channel(self):
        return f'{self.device}/ai3'

    @property
    def block_samples(self):
        return max(1, min(100_000, round(self.rate * 0.1)))

    def validate(self):
        if (not self.device.strip() or self.device != self.device.strip()
                or not re.fullmatch(r'[A-Za-z0-9_ .-]+', self.device)):
            raise ValueError('Введите имя устройства из NI MAX, например Dev1; канал ai3 задан отдельно.')
        if not math.isfinite(self.rate) or not 1 <= self.rate <= 2_000_000:
            raise ValueError('Частота оцифровки должна быть от 1 до 2 000 000 выборок/с.')
        if self.voltage_range not in RANGES:
            raise ValueError('Выберите диапазон из списка.')
        if not math.isfinite(self.window_seconds) or not 0.01 <= self.window_seconds <= 30:
            raise ValueError('Окно графика: от 0.01 до 30 s.')


def voltage_text(value):
    if value is None or not math.isfinite(value):
        return '—'
    if value == 0:
        return '0 V'
    for scale, unit in ((1.0, 'V'), (1e-3, 'mV'), (1e-6, 'µV'), (1e-9, 'nV'), (1e-12, 'pV')):
        if abs(value) >= scale or scale == 1e-12:
            return f'{value / scale:.6g} {unit}'


def peak_view(times, values, max_points=20_000):
    """Сохраняем минимум и максимум каждого интервала для быстрого рисунка."""
    n = len(values)
    if n <= max_points:
        return times, values
    width = math.ceil(n / max(1, max_points // 2))
    blocks = n // width
    matrix = values[:blocks * width].reshape(blocks, width)
    base = np.arange(blocks) * width
    indices = np.column_stack((base + matrix.argmin(axis=1), base + matrix.argmax(axis=1)))
    indices.sort(axis=1)
    chosen = indices.ravel()
    if blocks * width < n:
        tail = values[blocks * width:]
        chosen = np.concatenate((chosen, np.sort(blocks * width + np.array([tail.argmin(), tail.argmax()]))))
    return times[chosen], values[chosen]


class SampleStore:
    """Хранится только последнее окно, не вся неограниченная сессия."""
    def __init__(self):
        self.lock = threading.Lock()
        self.clear()

    def clear(self):
        with self.lock:
            self.data = np.empty(0, dtype=np.float64)
            self.head = self.retained = self.total = 0
            self.rate = 0.0
            self.metadata = {}
            self.stats = {}
            self.version = 0

    def configure(self, rate, window_seconds, metadata):
        capacity = max(1, min(MAX_POINTS, math.ceil(rate * window_seconds)))
        with self.lock:
            self.data = np.empty(capacity, dtype=np.float64)
            self.head = self.retained = self.total = 0
            self.rate = float(rate)
            self.metadata = dict(metadata)
            self.metadata.update(display_capacity=capacity, requested_window_s=window_seconds,
                                 sample_rate_Hz=self.rate)
            self.stats = {}
            self.version += 1

    def append(self, values):
        values = np.asarray(values, dtype=np.float64)
        if values.ndim != 1 or not np.isfinite(values).all():
            raise ValueError('Получен неверный массив отсчётов: ожидается конечный одномерный сигнал.')
        if len(values) == 0:
            return
        stats = {'last': float(values[-1]), 'mean': float(values.mean()),
                 'ac_rms': float(values.std()), 'minimum': float(values.min()),
                 'maximum': float(values.max()), 'block_samples': len(values)}
        with self.lock:
            capacity = len(self.data)
            if not capacity:
                raise RuntimeError('Буфер ещё не настроен.')
            n = len(values)
            if n >= capacity:
                self.data[:] = values[-capacity:]
                self.head = 0
            else:
                first = min(n, capacity - self.head)
                self.data[self.head:self.head + first] = values[:first]
                if first < n:
                    self.data[:n - first] = values[first:]
                self.head = (self.head + n) % capacity
            self.total += n
            self.retained = min(capacity, self.retained + n)
            self.stats = stats
            self.version += 1

    def snapshot(self):
        with self.lock:
            count = self.retained
            if not count:
                values = np.empty(0, dtype=np.float64)
            elif count < len(self.data):
                values = self.data[:count].copy()
            else:
                values = np.concatenate((self.data[self.head:], self.data[:self.head]))
            first = self.total - count
            rate = self.rate
            result = {'values': values, 'total': self.total, 'first': first, 'rate': rate,
                      'stats': dict(self.stats), 'metadata': dict(self.metadata), 'version': self.version}
        result['times'] = ((first + np.arange(count, dtype=np.float64)) / rate
                           if rate else np.empty(0, dtype=np.float64))
        return result


def export_snapshot(filename, frame):
    """Сохраняются сырые отсчёты окна, без прореживания для графика."""
    if len(frame['values']) == 0:
        raise ValueError('Нет отсчётов для сохранения.')
    target = Path(filename)
    meta_target = target.with_suffix('.json')
    if target.suffix.casefold() == '.json' or target == meta_target:
        raise ValueError('Для данных выберите .dat, .txt или .tsv, не .json.')
    metadata = dict(frame['metadata'])
    metadata.update(saved_local=datetime.now().astimezone().isoformat(),
                    total_session_samples=frame['total'], saved_samples=len(frame['values']),
                    first_sample_index=frame['first'], sample_rate_Hz=frame['rate'],
                    data_scope='last retained window; not the complete acquisition',
                    columns=['Time_s', 'Voltage_V'], terminal_configuration='DIFFERENTIAL')
    temporary = []
    try:
        for destination in (target, meta_target):
            fd, path = tempfile.mkstemp(prefix='.' + destination.name + '.', dir=destination.parent)
            os.close(fd)
            temporary.append(Path(path))
        np.savetxt(temporary[0], np.column_stack((frame['times'], frame['values'])),
                   delimiter='\t', fmt=('%.16g', '%.10g'), header='Time_s\tVoltage_V', comments='')
        temporary[1].write_text(json.dumps(metadata, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
        os.replace(temporary[0], target)
        os.replace(temporary[1], meta_target)
    finally:
        for path in temporary:
            path.unlink(missing_ok=True)
    return str(target), str(meta_target)
