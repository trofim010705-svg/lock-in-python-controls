from types import SimpleNamespace as NS
import threading
import unittest

import numpy as np
from nidaqmx.constants import AcquisitionType, OverwriteMode, TaskMode, TerminalConfiguration, VoltageUnits

from backend import NIInput
from core import Config, SampleStore
from worker import Acquisition


class BackendTests(unittest.TestCase):
    def loader(self, fail_start=False):
        calls = []
        constants = NS(TerminalConfiguration=TerminalConfiguration, VoltageUnits=VoltageUnits,
                       AcquisitionType=AcquisitionType, TaskMode=TaskMode, OverwriteMode=OverwriteMode)
        class Task:
            def __init__(self):
                self.ai_channels = NS(add_ai_voltage_chan=self.add)
                self.timing = NS(cfg_samp_clk_timing=self.clock, samp_clk_rate=800)
                self.in_stream = NS(avail_samp_per_chan=3)
            def add(self, name, **kwargs):
                calls.append(('channel', name, kwargs))
                return NS(ai_min=-10, ai_max=10)
            def clock(self, rate, **kwargs): calls.append(('clock', rate, kwargs))
            def control(self, mode): calls.append(('control', mode))
            def start(self):
                calls.append(('start',))
                if fail_start: raise RuntimeError('USB disconnected')
            def close(self): calls.append(('close',))
        class Reader:
            def __init__(self, stream): pass
            def read_many_sample(self, array, number_of_samples_per_channel, timeout):
                calls.append(('read', number_of_samples_per_channel, timeout))
                array[:number_of_samples_per_channel] = [0.1, 0.2, 0.3][:number_of_samples_per_channel]
                return number_of_samples_per_channel
        device = NS(ai_physical_chans=NS(channel_names=['Dev1/ai3']),
                    ai_max_single_chan_rate=2e6, product_type='USB-6363', dev_serial_num=1234)
        return lambda: (NS(Task=Task), constants, Reader, None, lambda name: device), calls

    def test_task_uses_only_ai3_differential_and_actual_clock(self):
        loader, calls = self.loader()
        source = NIInput(loader)
        info = source.open(Config())
        self.assertEqual(calls[0][0:2], ('channel', 'Dev1/ai3'))
        self.assertEqual(calls[0][2]['terminal_config'], TerminalConfiguration.DIFF)
        self.assertEqual(calls[1][2]['sample_mode'], AcquisitionType.CONTINUOUS)
        self.assertEqual(info['sample_rate_Hz'], 800)
        self.assertEqual(info['terminal_configuration'], 'DIFFERENTIAL')
        values = source.read(threading.Event())
        np.testing.assert_allclose(values, [0.1, 0.2, 0.3])
        source.close()
        self.assertEqual(calls[-1], ('close',))

    def test_failed_start_releases_task(self):
        loader, calls = self.loader(fail_start=True)
        source = NIInput(loader)
        with self.assertRaises(RuntimeError): source.open(Config())
        self.assertIsNone(source.task)
        self.assertEqual(calls[-1], ('close',))

    def test_stop_before_read_does_not_consume_samples(self):
        loader, calls = self.loader()
        source = NIInput(loader);source.open(Config())
        stopped = threading.Event();stopped.set()
        self.assertEqual(len(source.read(stopped)), 0)
        self.assertFalse(any(x[0]=='read' for x in calls))
        source.close()

    def test_partial_session_survives_source_failure(self):
        state = {'closed': False}
        class Source:
            def open(self, cfg): return {'sample_rate_Hz': 1000, 'demo': True}
            def read(self, stop):
                if not state.get('read'):
                    state['read'] = True
                    return np.array([0.1, 0.2])
                raise RuntimeError('USB lost')
            def close(self): state['closed'] = True
        store = SampleStore()
        worker = Acquisition(Config(), store, factory=Source)
        results = []
        worker.result.connect(results.append)
        worker.run()
        self.assertTrue(state['closed'])
        self.assertEqual(store.total, 2)
        self.assertIn('USB lost', results[-1]['error'])

    def test_cancel_before_start_does_not_open_hardware(self):
        calls = []
        worker = Acquisition(Config(), SampleStore(), factory=lambda: calls.append('opened'))
        worker.request_stop();worker.run()
        self.assertEqual(calls, [])


if __name__ == '__main__': unittest.main()
