from pathlib import Path
import json
import tempfile
import unittest

import numpy as np

from core import Config, MAX_POINTS, SampleStore, export_snapshot, peak_view, voltage_text


class BufferTests(unittest.TestCase):
    def buffer(self, rate=10, seconds=1):
        store = SampleStore()
        store.configure(rate, seconds, {'demo': True, 'physical_channel': 'Dev1/ai3'})
        return store

    def test_differential_channel_is_one_channel(self):
        self.assertEqual(Config(device='Dev2').channel, 'Dev2/ai3')
        for name in ('Dev1/ai3', 'Dev1,Dev2', '', 'Dev1:ai3'):
            with self.assertRaises(ValueError): Config(device=name).validate()

    def test_wrap_retains_samples_and_hardware_time_indices(self):
        store = self.buffer()
        for a in (np.arange(4), np.arange(4, 9), np.arange(9, 14)):
            store.append(a)
        frame = store.snapshot()
        np.testing.assert_array_equal(frame['values'], np.arange(4, 14))
        np.testing.assert_allclose(frame['times'], np.arange(4, 14) / 10)
        self.assertEqual(frame['total'], 14)

    def test_large_block_and_followup_keep_order(self):
        store = self.buffer()
        store.append(np.arange(30))
        store.append(np.arange(30, 33))
        np.testing.assert_array_equal(store.snapshot()['values'], np.arange(23, 33))

    def test_memory_is_bounded_at_high_rate(self):
        store = self.buffer(2_000_000, 30)
        self.assertEqual(len(store.data), MAX_POINTS)
        self.assertLessEqual(store.data.nbytes, 4_000_000)

    def test_mean_and_sigma_use_raw_latest_block(self):
        store = self.buffer()
        store.append([1, 2, 3])
        frame = store.snapshot()
        self.assertEqual(frame['stats']['mean'], 2)
        self.assertAlmostEqual(frame['stats']['ac_rms'], np.std([1, 2, 3]))
        self.assertEqual(frame['stats']['last'], 3)

    def test_snapshot_is_independent_of_future_writes(self):
        store = self.buffer()
        store.append([1, 2])
        frame = store.snapshot()
        store.append(np.arange(100))
        np.testing.assert_array_equal(frame['values'], [1, 2])

    def test_invalid_data_does_not_pollute_buffer(self):
        store = self.buffer()
        for values in ([float('nan')], [float('inf')], [[1, 2]]):
            with self.assertRaises(ValueError): store.append(values)
        self.assertEqual(store.total, 0)

    def test_peak_view_preserves_short_spike_and_time_order(self):
        y = np.zeros(100_001)
        y[12345] = 8
        y[54321] = -7
        x, v = peak_view(np.arange(len(y)) / 1000, y, max_points=1000)
        self.assertEqual(v.max(), 8)
        self.assertEqual(v.min(), -7)
        self.assertTrue(np.all(np.diff(x) >= 0))
        self.assertLessEqual(len(v), 1002)

    def test_export_retained_raw_points_not_plot_decimation(self):
        store = self.buffer(10, 1)
        store.append(np.arange(50) / 1000)
        frame = store.snapshot()
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / 'измерение.dat'
            data_name, meta_name = export_snapshot(target, frame)
            loaded = np.loadtxt(data_name, skiprows=1)
            self.assertEqual(loaded.shape, (10, 2))
            np.testing.assert_allclose(loaded[:, 1], np.arange(40, 50) / 1000)
            metadata = json.loads(Path(meta_name).read_text(encoding='utf-8'))
            self.assertEqual(metadata['first_sample_index'], 40)
            self.assertEqual(metadata['total_session_samples'], 50)
            self.assertEqual(metadata['terminal_configuration'], 'DIFFERENTIAL')
            self.assertTrue(metadata['demo'])

    def test_empty_export_and_json_name_refused(self):
        store = self.buffer()
        with self.assertRaises(ValueError): export_snapshot('empty.dat', store.snapshot())
        store.append([1])
        with self.assertRaises(ValueError): export_snapshot('data.JSON', store.snapshot())

    def test_engineering_voltage_units(self):
        self.assertEqual(voltage_text(0), '0 V')
        self.assertEqual(voltage_text(1e-8), '10 nV')
        self.assertEqual(voltage_text(-0.002), '-2 mV')


if __name__ == '__main__': unittest.main()
