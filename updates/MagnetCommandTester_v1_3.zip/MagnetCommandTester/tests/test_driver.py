import math
import threading
import unittest

from demo import DemoSerial
from driver import Cancelled, Connection, Limits, MagnetDriver, ProtocolError, ValidationError, number, output_state


class DriverTests(unittest.TestCase):
    def setUp(self):
        self.links = []
        self.logs = []
        self.overrides = {}
        owner = self

        class ScriptSerial(DemoSerial):
            def write(self, data):
                command = data.decode('ascii').rstrip('\r')
                if command in owner.overrides:
                    self.writes.append(data)
                    answer = owner.overrides[command]
                    if callable(answer):
                        answer = answer()
                    if isinstance(answer, BaseException):
                        raise answer
                    if answer is not None:
                        self.buffer.extend(answer)
                    return len(data)
                return super().write(data)

        def factory(port, baud):
            link = ScriptSerial(port, baud)
            self.links.append(link)
            return link
        self.driver = MagnetDriver(log=self.logs.append, factory=factory)
        self.driver.open(Connection(relay_port='COM12', timeout=0.1))
        self.link = self.links[0]
        self.relay_link = self.links[1]

    def tearDown(self):
        self.driver.close()

    def commands(self):
        return [x.decode('ascii').rstrip('\r') for x in self.link.writes]

    def relay_commands(self):
        return [x.decode('ascii').rstrip('\r') for x in self.relay_link.writes]

    def ready(self):
        self.driver.probe()

    def test_open_and_close_do_not_write_commands(self):
        self.assertEqual(self.link.writes, [])
        self.driver.close()
        self.assertEqual(self.link.writes, [])

    def test_probe_only_selects_address_and_queries(self):
        self.ready()
        self.assertTrue(self.driver.identified)
        self.assertEqual(self.commands(), ['ADR 06', 'IDN?', 'MC?', 'MV?', 'PC?', 'PV?', 'OUT?'])
        self.assertTrue(all(x.endswith(b'\r') and not x.endswith(b'\r\n') for x in self.link.writes))

    def test_wrong_address_stops_before_other_queries(self):
        self.driver.close()
        self.driver.open(Connection(address=7, timeout=0.1))
        self.link = self.links[-1]
        with self.assertRaises(ProtocolError):
            self.ready()
        self.assertEqual(self.commands(), ['ADR 07'])
        self.assertFalse(self.driver.identified)

    def test_wrong_identity_cannot_enable_output(self):
        self.overrides['IDN?'] = b'OTHER_DEVICE\r'
        with self.assertRaises(ProtocolError): self.ready()
        with self.assertRaises(ProtocolError): self.driver.enable_output(Limits(1, 2))
        self.assertNotIn('OUT 1', self.commands())

    def test_incomplete_probe_cannot_unlock_control(self):
        self.overrides['MC?'] = b'OK\r'
        with self.assertRaises(ProtocolError): self.ready()
        self.assertFalse(self.driver.identified)

    def test_zero_limits_block_enable(self):
        self.ready()
        with self.assertRaises(ProtocolError): self.driver.enable_output(Limits())
        self.assertNotIn('OUT 1', self.commands())

    def test_current_limit_is_enforced_in_driver(self):
        self.ready()
        for value in [2, -1, math.nan, math.inf]:
            with self.assertRaises(ProtocolError): self.driver.set_value('PC', value, Limits(1, 2))
        self.assertFalse(any(x.startswith('PC ') for x in self.commands()))

    def test_setpoint_readback_and_enable(self):
        self.ready()
        self.driver.set_value('PV', 1.5, Limits(0.1, 2))
        self.driver.set_value('PC', 0.02, Limits(0.1, 2))
        self.driver.enable_output(Limits(0.1, 2))
        self.assertTrue(self.driver.last['OUT?'])
        self.assertEqual(self.driver.last['MC?'], 0.02)
        self.assertEqual(self.link.current, 0.02)

    def test_out_uses_current_device_setpoints(self):
        self.ready()
        self.link.voltage = 60
        with self.assertRaises(ProtocolError): self.driver.enable_output(Limits(1, 2))
        self.assertNotIn('OUT 1', self.commands())

    def test_screenshot_pc_zero_allowed_with_stored_high_voltage_and_output_off(self):
        self.link.voltage = 28.518
        self.ready()
        self.driver.set_value('PC', 0, Limits(2, 5))
        self.assertIn('PC 0', self.commands())
        self.assertEqual(self.link.voltage, 28.518)
        self.assertFalse(self.link.on)
        self.assertTrue(self.driver.identified)

    def test_off_setpoints_can_be_corrected_in_either_order_without_enabling(self):
        self.link.voltage = 28.518
        self.link.current = 10
        self.ready()
        self.driver.set_value('PC', 0.2, Limits(2, 5))
        with self.assertRaises(ValidationError): self.driver.enable_output(Limits(2, 5))
        self.assertNotIn('OUT 1', self.commands())
        self.driver.set_value('PV', 2, Limits(2, 5))
        self.assertFalse(self.link.on)
        self.driver.enable_output(Limits(2, 5))
        self.assertTrue(self.link.on)

    def test_off_can_lower_voltage_while_stored_current_exceeds_limit(self):
        self.link.voltage = 28.518
        self.link.current = 10
        self.ready()
        self.driver.set_value('PV', 2, Limits(2, 5))
        self.assertEqual(self.link.voltage, 2)
        self.assertFalse(self.link.on)
        with self.assertRaises(ValidationError): self.driver.enable_output(Limits(2, 5))
        self.assertNotIn('OUT 1', self.commands())

    def test_on_still_refuses_nonzero_setpoint_when_other_limit_exceeded(self):
        self.link.voltage = 28.518
        self.link.on = True
        self.ready()
        with self.assertRaises(ValidationError): self.driver.set_value('PC', 0.2, Limits(2, 5))
        self.assertNotIn('PC 0.2', self.commands())

    def test_on_can_zero_current_even_if_stored_voltage_exceeds_limit(self):
        self.link.voltage = 28.518
        self.link.current = 0.2
        self.link.on = True
        self.ready()
        self.driver.set_value('PC', 0, Limits(2, 5))
        self.assertEqual(self.link.current, 0)
        self.assertEqual(self.link.voltage, 28.518)
        self.assertNotIn('H', self.commands())
        self.assertNotIn('X', self.commands())

    def test_mismatched_readback_reported(self):
        self.ready()
        self.overrides['PC?'] = b'0.5\r'
        with self.assertRaises(ProtocolError): self.driver.set_value('PC', 0.02, Limits(1, 2))

    def test_stop_attempts_out_off_even_if_pc_ack_fails(self):
        self.ready()
        self.link.on = True
        self.overrides['PC 0'] = b'C01\r'
        with self.assertRaises(ProtocolError): self.driver.zero_and_off()
        self.assertIn('OUT 0', self.commands())
        self.assertFalse(self.link.on)

    def test_successful_stop_does_not_send_relay_commands(self):
        self.ready()
        self.link.current = 1
        self.link.on = True
        self.driver.zero_and_off()
        self.assertFalse(self.link.on)
        self.assertEqual(self.link.current, 0)
        self.assertEqual(self.driver.last['PC?'], 0)
        self.assertNotIn('H', self.commands())
        self.assertNotIn('X', self.commands())

    def test_relay_refuses_output_on(self):
        self.ready()
        self.link.on = True
        with self.assertRaises(ProtocolError): self.driver.switch_polarity('H')
        self.assertNotIn('H', self.commands())
        self.assertEqual(self.relay_commands(), [])

    def test_relay_refuses_nonzero_setpoint_even_output_off(self):
        self.ready()
        self.link.current = 0.2
        with self.assertRaises(ProtocolError): self.driver.switch_polarity('X')
        self.assertNotIn('X', self.commands())
        self.assertEqual(self.relay_commands(), [])

    def test_relay_refuses_residual_current(self):
        self.ready()
        self.overrides['MC?'] = b'0.02\r'
        with self.assertRaises(ProtocolError): self.driver.switch_polarity('H')
        self.assertNotIn('H', self.commands())
        self.assertEqual(self.relay_commands(), [])

    def test_relay_checks_all_three_samples(self):
        self.ready()
        responses = iter([b'0\r', b'0.02\r', b'0\r'])
        self.overrides['MC?'] = lambda: next(responses)
        with self.assertRaises(ProtocolError): self.driver.switch_polarity('H')
        self.assertNotIn('H', self.commands())
        self.assertEqual(self.relay_commands(), [])

    def test_relay_send_does_not_claim_contacts_confirmed(self):
        self.ready()
        msg = self.driver.switch_polarity('H')
        self.assertEqual(self.relay_link.writes[-1], b'H\r')
        self.assertNotIn('H', self.commands())
        self.assertIn('Контакты не подтверждены', msg)
        self.assertFalse(self.driver.identified)
        self.assertFalse(self.driver.address_selected)

    def test_separate_relay_port_receives_only_relay_bytes(self):
        self.driver.close()
        self.driver.open(Connection(source_port='COM11', relay_port='COM12', timeout=0.1))
        self.link = self.links[-2]
        relay = self.links[-1]
        self.ready()
        self.driver.switch_polarity('X')
        self.assertEqual(relay.writes, [b'X\r'])
        self.assertNotIn('X', self.commands())

    def test_cancel_during_current_check_never_sends_h(self):
        self.ready()
        def answer():
            self.driver.cancel.set()
            return b'0\r'
        self.overrides['MC?'] = answer
        with self.assertRaises(Cancelled): self.driver.switch_polarity('H')
        self.assertNotIn('H', self.commands())
        self.assertEqual(self.relay_commands(), [])

    def test_source_only_mode_never_sends_hx_to_genesys(self):
        self.driver.close()
        self.driver.open(Connection(timeout=0.1))
        self.link = self.links[-1]
        self.ready()
        before = list(self.link.writes)
        for command in ['H', 'X']:
            with self.assertRaisesRegex(ValidationError, 'выбран порт GEN60-40'):
                self.driver.switch_polarity(command)
        self.assertEqual(self.link.writes, before)
        self.assertTrue(self.driver.identified)
        self.assertFalse(self.driver.relay_available)

    def test_same_port_name_cannot_bypass_relay_guard(self):
        self.driver.close()
        self.driver.open(Connection(source_port='COM11', relay_port='com11', timeout=0.1))
        self.link = self.links[-1]
        self.ready()
        with self.assertRaises(ValidationError): self.driver.switch_polarity('X')
        self.assertNotIn('X', self.commands())

    def test_relay_c01_is_failure_and_blocks_retries_after_reprobe(self):
        self.ready()
        self.overrides['X'] = b'C01\r'
        original_read = self.relay_link.read
        def stop_after_error(count=1):
            if not self.relay_link.buffer:
                raise AssertionError('Reading continued after a complete C01 response')
            return original_read(count)
        self.relay_link.read = stop_after_error
        with self.assertRaisesRegex(ProtocolError, 'получен код ошибки C01'):
            self.driver.switch_polarity('X')
        self.assertEqual(self.relay_commands(), ['X'])
        self.assertFalse(self.driver.relay_available)
        self.assertFalse(self.driver.identified)
        self.assertTrue(self.driver.connected)
        self.ready()
        for command in ['H', 'X']:
            with self.assertRaisesRegex(ValidationError, 'ранее вернул C01'):
                self.driver.switch_polarity(command)
        self.assertEqual(self.relay_commands(), ['X'])
        self.assertFalse(any('положение контактов' in line for line in self.logs))

    def test_rejected_relay_port_stays_blocked_after_reconnect(self):
        self.ready()
        self.overrides['X'] = b'C01\r'
        with self.assertRaises(ProtocolError): self.driver.switch_polarity('X')
        self.driver.close()
        self.driver.open(Connection(relay_port='COM12', timeout=0.1))
        self.link, self.relay_link = self.links[-2:]
        self.ready()
        with self.assertRaises(ValidationError): self.driver.switch_polarity('X')
        self.assertEqual(self.relay_commands(), [])

    def test_echo_and_crlf_are_handled(self):
        self.ready()
        self.overrides['MC?'] = b'MC?\r\n0.002\r\n'
        self.assertEqual(self.driver.query('MC?'), 0.002)

    def test_partial_reply_does_not_become_measurement(self):
        self.ready()
        self.overrides['MC?'] = b'0.00'
        with self.assertRaises(ProtocolError): self.driver.query('MC?')
        self.assertTrue(any('без окончания' in x for x in self.logs))

    def test_timeout_distinguishes_no_bytes_from_incomplete_reply(self):
        self.ready()
        self.overrides['MC?'] = None
        with self.assertRaisesRegex(ProtocolError, 'Не получено ни одного байта'):
            self.driver.query('MC?')
        self.overrides['MC?'] = b'0.00'
        with self.assertRaisesRegex(ProtocolError, 'Получено 4 байт'):
            self.driver.query('MC?')

    def test_stale_answer_is_logged_and_not_used(self):
        self.ready()
        self.link.buffer.extend(b'123\r')
        self.assertEqual(self.driver.query('MC?'), 0)
        self.assertTrue(any('до запроса' in x for x in self.logs))

    def test_no_arbitrary_command_injection(self):
        self.ready()
        for cmd in ['RST', 'MC?\rOUT 1', 'H', 'PC 1']:
            with self.assertRaises(ProtocolError): self.driver.query(cmd)
        self.assertNotIn('RST', self.commands())

    def test_parser_rejects_nonfinite_and_errors(self):
        for value in ['NaN', 'inf', 'OK', 'C01', '1,2', '1 A', '', '1e999']:
            with self.assertRaises(ProtocolError): number(value)
        self.assertEqual(number(' -0.003 '), -0.003)
        self.assertEqual(number('1e-3'), 0.001)
        self.assertTrue(output_state('ON'))
        self.assertFalse(output_state('OFF'))


if __name__ == '__main__':
    unittest.main()
