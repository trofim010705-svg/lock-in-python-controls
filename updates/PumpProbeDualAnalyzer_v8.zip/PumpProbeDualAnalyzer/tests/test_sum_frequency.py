"""Independent synthetic reconstruction of the handwritten SUM-sideband model."""
from dataclasses import replace
from threading import Event
import unittest
import numpy as np
from analyzer import core
from analyzer import sum_frequency as sf


def fixture(reference=.4e-9,noise=0.,extra_mode=False,background=-1):
    t=np.linspace(.4e-9,4.2e-9,700)
    modes=[(30e-6,.8e9,.7,2e-9)]
    changes=[(.025e9,.5e-6,.006e9,-4*np.pi/180)]
    if extra_mode:
        modes.append((12e-6,1.6e9,-.3,3.5e-9))
        changes.append((-.01e9,-.3e-6,-.004e9,3*np.pi/180))
    carrier=[];y=np.zeros(len(t))
    for (a,f,phi,tau),(dg,da,df,dp) in zip(modes,changes):
        carrier.extend((a*np.exp(-reference/tau)*2.5,f,phi+2*np.pi*f*reference,tau))
        # Literal formula, independently expanded: delta_omega=2*pi*delta_f.
        psi=2*np.pi*f*t+phi
        y+=.5*a*np.exp(-t/tau)*((da/a)*np.sin(psi)+dp*np.cos(psi)
            +(2*np.pi*df)*t*np.cos(psi)-dg*t*np.sin(psi))
    carrier=np.asarray(carrier+[0.])
    reference_fit=core.FitResult(carrier,np.zeros(len(carrier)),np.zeros((len(carrier),len(carrier))),
        reference,0.,1.,[],1,1.)
    if noise:y+=np.random.default_rng(177).normal(0,noise,len(t))
    raw=y.copy();bg=np.zeros_like(y)
    cfg=core.Settings(bal_mv=-100,sig_mv=100,background_degree=background,bg_min_s=t[0],bg_max_s=t[-1])
    if background>=0:
        raw=y+1e-6+(2e2*t if background>=1 else 0.)
        poly=np.polynomial.Polynomial.fit(t,raw,background)
        bg=poly(t);y=raw-bg
    p=core.Prepared(t,raw,y,np.ones(len(t),bool),np.array([]),np.array([]),1e8,1e11,[],cfg,bg)
    return p,reference_fit,np.r_[np.asarray(changes).ravel(),0.]


class SumFrequencyTests(unittest.TestCase):
    def test_formula_is_half_of_the_actual_carrier_parameter_derivative(self):
        p,ref,true=fixture()
        r=sf.fit(p,ref,2.5)
        a=30e-6;gamma=.5e9;f=.8e9;phi=.7;epsilon=1e-4
        dg,da,df,dp=true[:4];t=p.time
        plus=(a+epsilon*da)*np.exp(-(gamma+epsilon*dg)*t)*np.sin(2*np.pi*(f+epsilon*df)*t+phi+epsilon*dp)
        minus=(a-epsilon*da)*np.exp(-(gamma-epsilon*dg)*t)*np.sin(2*np.pi*(f-epsilon*df)*t+phi-epsilon*dp)
        np.testing.assert_allclose(core.evaluate_fit(t,r),(plus-minus)/(4*epsilon),rtol=2e-7,atol=2e-15)

    def test_half_factor_and_delta_f_recovery_at_physical_zero(self):
        p,reference,true=fixture()
        r=sf.fit(p,reference,2.5)
        np.testing.assert_allclose(r.parameters,true,rtol=2e-10,atol=1e-18)
        np.testing.assert_allclose(core.evaluate_fit(p.time,r),p.y,rtol=1e-10,atol=1e-18)
        self.assertEqual(r.reference_s,0.)
        self.assertAlmostEqual(sf.report(r)['modes'][0]['delta_phi_deg'],-4.,places=9)

    def test_different_fit_window_reference_does_not_change_zero_delay_deltas(self):
        p,first,true=fixture(reference=.4e-9)
        _,later,_=fixture(reference=1.3e-9)
        a=sf.fit(p,first,2.5);b=sf.fit(p,later,2.5)
        np.testing.assert_allclose(a.parameters,b.parameters,rtol=1e-9,atol=1e-18)
        np.testing.assert_allclose(b.parameters,true,rtol=1e-9,atol=1e-18)

    def test_separate_quadratures_can_have_opposite_signed_perturbations(self):
        p,ref,true=fixture()
        x=sf.fit(p,ref,2.5)
        y=sf.fit(replace(p,y=-2*p.y,raw_rad=-2*p.raw_rad),ref,2.5)
        np.testing.assert_allclose(y.parameters,-2*x.parameters,rtol=1e-9,atol=1e-18)
        self.assertGreater(sf.report(y)['modes'][0]['delta_phi_deg'],0)

    def test_multimode_carrier_has_four_changes_per_mode(self):
        p,ref,true=fixture(extra_mode=True)
        r=sf.fit(p,ref,2.5)
        self.assertEqual(len(r.parameters),9)
        np.testing.assert_allclose(r.parameters,true,rtol=1e-8,atol=1e-17)

    def test_identical_background_operator_prevents_bias_from_polynomial_subtraction(self):
        for degree in (0,1,2):
            p,ref,true=fixture(background=degree)
            r=sf.fit(p,ref,2.5)
            np.testing.assert_allclose(r.parameters,true,rtol=1e-8,atol=1e-17)
            np.testing.assert_allclose(core.evaluate_fit(p.time,r),p.y,atol=1e-17)

    def test_fixed_signed_delta_f_is_respected_while_other_changes_fit(self):
        p,ref,true=fixture()
        r=sf.fit(p,ref,2.5,fixed_delta_frequencies={0:true[2]})
        np.testing.assert_allclose(r.parameters,true,rtol=1e-9,atol=1e-18)
        self.assertEqual(r.errors[2],0.)
        self.assertTrue(sf.report(r)['modes'][0]['delta_f_fixed'])

    def test_constant_is_zero_unless_explicitly_enabled(self):
        p,ref,true=fixture()
        p=replace(p,y=p.y+1.2e-6,raw_rad=p.raw_rad+1.2e-6)
        r=sf.fit(p,ref,2.5,include_constant=True)
        np.testing.assert_allclose(r.parameters,np.r_[true[:-1],1.2e-6],rtol=1e-9,atol=1e-17)
        self.assertTrue(r.include_constant)

    def test_rank_deficiency_is_not_reported_as_unique_physical_changes(self):
        p,ref,true=fixture()
        # Two identical X1 modes cannot have independently identifiable changes.
        ref=replace(ref,parameters=np.r_[ref.parameters[:4],ref.parameters])
        r=sf.fit(p,ref,2.5)
        self.assertFalse(r.identifiable)
        self.assertIsNone(sf.report(r)['modes'][0]['delta_Gamma_per_s'])
        self.assertTrue(np.isnan(r.errors[0]))

    def test_noise_produces_finite_conditional_standard_errors(self):
        p,ref,true=fixture(noise=1e-8)
        r=sf.fit(p,ref,2.5)
        self.assertTrue(r.identifiable)
        self.assertTrue(np.all(r.errors[:-1]>0))
        self.assertGreater(r.r_squared,.99)
        self.assertIn('Conditional',sf.report(r)['uncertainty_definition'])

    def test_cancel_and_missing_carrier_do_not_fabricate_fit(self):
        p,ref,_=fixture();cancel=Event();cancel.set()
        with self.assertRaises(core.Cancelled):sf.fit(p,ref,2.5,cancel=cancel)
        with self.assertRaisesRegex(ValueError,'X1'):sf.fit(p,None,2.5)
        with self.assertRaisesRegex(ValueError,'X1'):
            sf.fit(p,replace(ref,r_squared=float('nan')),2.5)


if __name__=='__main__':unittest.main()
