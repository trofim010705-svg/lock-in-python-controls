"""Real worker/UI/export test for separate sum-frequency X2 and Y2 fits."""
from pathlib import Path
import json
import tempfile
import time
import unittest
import numpy as np
from PyQt5.QtWidgets import QApplication
from analyzer import core,sum_frequency as sf
from analyzer.dual_ui import DualAnalysisWindow
from analyzer.dual_export import build_dual_report,dual_report_text,export_dual
from analyzer.theory_demo import write_demo


class SumFrequencyWorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])
    def settle(self,w):
        end=time.monotonic()+45;idle=None
        while time.monotonic()<end:
            self.app.processEvents()
            if w.job is None and not w.pending and not w.timer.isActive() and w.pending_load is None:
                if idle is None:idle=time.monotonic()
                if time.monotonic()-idle>.05:return
            else:idle=None
            time.sleep(.005)
        self.fail(w.messages.toPlainText())
    def close_window(self,w):
        w.close();end=time.monotonic()+15
        while w.pool.activeThreadCount() and time.monotonic()<end:
            self.app.processEvents();time.sleep(.005)
        w.close();self.app.processEvents()
    def load(self,folder):
        path,notes,truth=write_demo(folder)
        w=DualAnalysisWindow();self.addCleanup(self.close_window,w)
        # These auxiliary fits are not the sum-sideband theory; retain their controls.
        w.channels[1].fit_enabled.setChecked(False)
        w.diagnostic_channels['phase2'].fit_enabled.setChecked(False)
        w.bal.setText('-100');w.sig.setText('100')
        w.load_paths(path,notes);self.settle(w)
        self.assertFalse(w.dirty,w.messages.toPlainText())
        self.assertTrue(all(sf.is_modulation(w.diagnostic_results[k]) for k in ('x2','y2')),w.messages.toPlainText())
        return w,truth
    def test_theory_parameters_tables_xy_and_tail_of_both_reports(self):
        with tempfile.TemporaryDirectory() as tmp:
            w,truth=self.load(tmp)
            self.assertTrue(w.modulation_enabled.isChecked())
            self.assertFalse(w.channels[0].fit_enabled.isEnabled())
            for key in ('x2','y2'):
                r=w.diagnostic_results[key];mode=sf.report(r)['modes'][0]
                for parameter,value in truth[key.upper()].items():
                    self.assertAlmostEqual(mode[parameter],value,delta=max(abs(value)*.001,1e-14),msg=key+' '+parameter)
                table=w.diagnostic_channels[key].table
                self.assertIn('δGamma',table.item(0,0).text())
                self.assertIn('δphi',table.item(3,0).text())
                self.assertIn('°',table.item(3,0).text())
            trace=w.figure._quadrature_trace
            self.assertTrue(trace.has_fit)
            np.testing.assert_allclose(trace.fit_x_v,core.evaluate_fit(trace.fit_time_s,w.diagnostic_results['x2']))
            snapshot=w.snapshot();report=build_dual_report(snapshot);text=dual_report_text(report)
            self.assertEqual(report['sum_frequency']['x2']['sideband_prefactor'],.5)
            self.assertLess(report['sum_frequency']['x2']['modes'][0]['delta_phi_deg'],0)
            tail=text[text.rindex('SUM-FREQUENCY MODULATION'):]
            self.assertIn('CHANNEL X2',tail);self.assertIn('CHANNEL Y2',tail)
            self.assertIn('delta_Gamma',tail);self.assertIn('delta_A',tail);self.assertIn('delta_f',tail);self.assertIn('delta_phi',tail)
            folder=Path(export_dual(Path(tmp)/'export',snapshot,{}))
            for name in ('analysis.txt','measurement_parameters.txt'):
                saved=(folder/name).read_text(encoding='utf-8')
                self.assertEqual(saved[saved.rindex('SUM-FREQUENCY MODULATION'):],tail)
                self.assertIn('CHANNEL Y2',saved[saved.rindex('SUM-FREQUENCY MODULATION'):])
            self.assertEqual(len((folder/'modulation_deltas.tsv').read_text().splitlines()),3)
            data=np.genfromtxt(folder/'x2_time.tsv',delimiter='\t',names=True)
            mask=data['Fit_mask'].astype(bool)
            np.testing.assert_allclose(data['Fit_V'][mask],core.evaluate_fit(data['Time_s'][mask],w.diagnostic_results['x2']),rtol=1e-10,atol=1e-15)
            self.assertIn('δΓ','\n'.join(w.figure._columns))
    def test_signed_fixed_delta_f_and_carrier_frequency_do_not_conflict(self):
        with tempfile.TemporaryDirectory() as tmp:
            w,truth=self.load(tmp)
            control=w.diagnostic_channels['y2'];control.table.cellWidget(2,1).setValue(-.005)
            control.fixed_checks[0].setChecked(True);self.settle(w)
            self.assertEqual(w.diagnostic_results['y2'].parameters[2],-.005e9)
            self.assertEqual(w.diagnostic_results['y2'].carrier_parameters_v[1],w.results[0].parameters[1])
            w.time_unit.setCurrentIndex(1);self.app.processEvents()
            self.assertEqual(control.read_fixed_frequencies(),{0:-.005e9})
            w.fit_checks['x2'].setChecked(False);self.app.processEvents()
            self.assertFalse(w.figure.quadrature_fit.get_visible())
            w.modulation_enabled.setChecked(False);self.settle(w)
            self.assertFalse(sf.is_modulation(w.diagnostic_results.get('x2')))


if __name__=='__main__':unittest.main()
