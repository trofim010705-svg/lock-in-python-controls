"""Native GUI checks for the sideband model, independent quadratures and exports."""
import json
from pathlib import Path
import platform
import sys
import time
import traceback


def run(report_path):
    import numpy as np
    from PyQt5.QtCore import QTimer
    from PyQt5.QtWidgets import QApplication
    from analyzer.dual_ui import DualAnalysisWindow
    from analyzer import sum_frequency as sf
    from analyzer.dual_export import export_dual
    from analyzer.theory_demo import write_demo
    report_path=Path(report_path).resolve();report_path.parent.mkdir(parents=True,exist_ok=True)
    data,notes,truth=write_demo(report_path.parent/'измерения')
    app=QApplication(sys.argv[:1]);app.setStyle('Fusion')
    w=DualAnalysisWindow();w.resize(1280,900)
    w.channels[1].fit_enabled.setChecked(False)
    w.diagnostic_channels['phase2'].fit_enabled.setChecked(False)
    w.bal.setText('-100');w.sig.setText('100');w.show()
    result=dict(ok=False,frozen=bool(getattr(sys,'frozen',False)),python=platform.python_version(),
                platform=platform.platform(),qt_platform=app.platformName())
    start=time.monotonic();ending=False;stage='initial';idle=0
    def finish(ok,detail):
        nonlocal ending
        if ending:return
        ending=True;result.update(ok=ok,detail=detail,elapsed_s=time.monotonic()-start)
        report_path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        w.close()
    oldhook=sys.excepthook
    sys.excepthook=lambda typ,val,tb:finish(False,''.join(traceback.format_exception(typ,val,tb)))
    def tick():
        nonlocal stage,idle
        if ending:return
        if w.job is not None or w.pending or w.timer.isActive() or w.dirty or w.prepared is None:
            idle=0;return
        idle+=1
        if idle<3:return
        try:
            if stage=='initial':
                assert w.results[0] is not None,w.messages.toPlainText()
                assert w.results[0].reference_s>0
                for key in ('x2','y2'):
                    r=w.diagnostic_results.get(key)
                    assert sf.is_modulation(r),(key,w.messages.toPlainText())
                    d=sf.report(r)['modes'][0]
                    for name,expected in truth[key.upper()].items():
                        np.testing.assert_allclose(d[name],expected,rtol=.001,atol=1e-13,err_msg=key+' '+name)
                result['half_factor_delta_f_and_zero_time_verified']=True
                result['separate_signed_x2_y2_parameters']=True
                control=w.diagnostic_channels['y2']
                control.table.cellWidget(2,1).setValue(-.005)
                control.fixed_checks[0].setChecked(True)
                stage='fixed';idle=0
            elif stage=='fixed':
                assert w.diagnostic_results['y2'].parameters[2]==-.005e9
                result['fixed_delta_f_verified']=True
                trace=w.figure._quadrature_trace
                assert trace.has_fit
                result['theory_fit_on_xy_plane']=True
                w.title.setText('$$S_{\\omega_e+\\omega_p}(t)$$ · модель ½')
                for key,check in w.overlay_checks.items():check.setChecked(key in ('x1','x2','y2'))
                w.fit_checks['x2'].setChecked(False)
                assert not w.figure.quadrature_fit.get_visible()
                w.fit_checks['x2'].setChecked(True)
                assert w.figure.quadrature_fit.get_visible()
                assert w.apply_labels()
                payloads=w.figure.capture_images(('png','pdf'))
                folder=Path(export_dual(report_path.parent/'результат',w.snapshot(),payloads))
                for filename in ('analysis.txt','measurement_parameters.txt'):
                    text=(folder/filename).read_text(encoding='utf-8')
                    tail=text[text.rindex('SUM-FREQUENCY MODULATION'):]
                    assert 'CHANNEL X2' in tail and 'CHANNEL Y2' in tail
                    assert 'delta_phi' in tail and ' deg ' in tail and 'delta_f' in tail
                report=json.loads((folder/'analysis.json').read_text(encoding='utf-8'))
                assert report['sum_frequency']['x2']['sideband_prefactor']==.5
                assert report['sum_frequency']['x2']['modes'][0]['delta_phi_deg']<0
                assert (folder/'modulation_deltas.tsv').exists()
                assert (folder/'analysis.png').stat().st_size>1000
                assert (folder/'analysis.pdf').stat().st_size>1000
                result['reports_end_with_separate_delta_parameters']=True
                result['visible_theory_figure_png_pdf_export']=True
                result['export_folder']=str(folder)
                w.grab().save(str(report_path.parent/'preview.png'))
                finish(True,'Recovered independent X2/Y2 perturbations from the literal half-sideband formula; zero-delay reference, fixed delta f, XY curve and end-of-file reports verified.')
        except Exception:finish(False,traceback.format_exc())
    timer=QTimer();timer.setInterval(30);timer.timeout.connect(tick);timer.start()
    QTimer.singleShot(0,lambda:w.load_paths(data,notes))
    QTimer.singleShot(90000,lambda:finish(False,'Self-test timed out: '+w.messages.toPlainText()))
    app.exec_();sys.excepthook=oldhook
    result['worker_stopped']=not w.pool.activeThreadCount()
    result['ok']=bool(result['ok'] and result['worker_stopped'])
    report_path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return 0 if result['ok'] else 1


if __name__=='__main__':raise SystemExit(run(sys.argv[1] if len(sys.argv)>1 else 'selftest_report.json'))
