"""Synthetic measurements from the literal 1/2 sum-sideband response."""
from pathlib import Path
import json
import numpy as np


def write_demo(folder):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    time=np.arange(-40,801,dtype=float)*3.5e-12
    a0=25e-6;gamma=.5e9;frequency=1.2e9;phi=.4
    positive=time>=0
    psi=2*np.pi*frequency*time+phi
    envelope=np.exp(-gamma*time)
    x1=np.where(positive,a0*envelope*np.sin(psi),0.)
    x1[40]=150e-6  # Zero-delay pump/probe artifact, excluded by peak+3 steps.
    truth={'X2':{'delta_Gamma_per_s':.035e9,'delta_A_V':.8e-6,'delta_f_Hz':.008e9,'delta_phi_deg':-3.},
           'Y2':{'delta_Gamma_per_s':-.02e9,'delta_A_V':-.45e-6,'delta_f_Hz':-.005e9,'delta_phi_deg':2.}}
    data=[]
    for key in ('X2','Y2'):
        d=truth[key]
        signal=.5*a0*envelope*((d['delta_A_V']/a0)*np.sin(psi)
            +np.deg2rad(d['delta_phi_deg'])*np.cos(psi)
            +2*np.pi*d['delta_f_Hz']*time*np.cos(psi)-d['delta_Gamma_per_s']*time*np.sin(psi))
        data.append(np.where(positive,signal,0.))
    position=106.45+time*3e8/(2e-3)
    path=folder/'sum_frequency_demo.dat';notes=folder/'sum_frequency_demo.comments.txt'
    np.savetxt(path,np.c_[position,x1,np.zeros_like(x1),data[0],data[1]],delimiter='\t',fmt='%.15g',
        header='Position_mm\tX1_V\tY1_V\tX2_V\tY2_V\nSignal unit: V')
    notes.write_text('SYNTHETIC THEORY DEMO; not an experimental measurement.\n'
        'First-order sum-frequency model with factor 1/2; delta_omega=2*pi*delta_f.\n'
        'Signal unit: V\nPoints saved: '+str(len(time))+'\nRESULT: complete\n',encoding='utf-8')
    (folder/'sum_frequency_demo.truth.json').write_text(json.dumps({'carrier':{'A0_V':a0,'Gamma0_per_s':gamma,
        'f0_Hz':frequency,'phi0_rad':phi},'changes':truth},indent=2),encoding='utf-8')
    return path,notes,truth
