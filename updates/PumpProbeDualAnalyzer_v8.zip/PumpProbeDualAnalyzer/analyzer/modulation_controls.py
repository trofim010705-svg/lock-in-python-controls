"""Signed, physically named controls for the sum-sideband fit."""
import numpy as np
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QCheckBox,QTableWidgetItem
from .dual_ui import ChannelControls,spin
from . import core
from .presentation import angle_unit
from . import sum_frequency as sf


class ModulationControls(ChannelControls):
    def __init__(self,owner,index):
        self.delta_fixed={};self.legacy_index=0;self.previous_mode=None
        super().__init__(owner,index)
        self.constant=QCheckBox('Подбирать дополнительный постоянный фон C')
        self.constant.setChecked(False)
        self.model.parentWidget().layout().addRow(self.constant)
        self.constant.toggled.connect(owner.invalidate)
        self.sync_mode()

    def theory(self):return self.owner.uses_modulation(self.index)
    def components(self):return self.owner.channels[0].components() if self.theory() else super().components()
    def read_fixed_frequencies(self):return dict(self.delta_fixed) if self.theory() else super().read_fixed_frequencies()

    def sync_mode(self):
        active=self.theory()
        if self.previous_mode!=active:
            self.model.blockSignals(True)
            if active:
                if self.previous_mode is False:self.legacy_index=self.model.currentIndex()
                self.model.clear();self.model.addItem('½ · модуляционный отклик; опора X1')
            else:
                self.model.clear();self.model.addItems(['Один затухающий синус + C','Сумма затухающих синусов + C'])
                self.model.setCurrentIndex(self.legacy_index)
            self.model.blockSignals(False);self.previous_mode=active
        self.model.setEnabled(not active);self.count.setEnabled(not active and self.model.currentIndex()==1)
        self.count.setVisible(not active)
        self.model.parentWidget().layout().labelForField(self.count).setVisible(not active)
        self.constant.setVisible(active)
        bg=self.owner.background.currentIndex()>0
        self.constant.setEnabled(not bg)
        if bg and self.constant.isChecked():
            self.constant.blockSignals(True);self.constant.setChecked(False);self.constant.blockSignals(False)
        self.seed.setText('Обновить таблицу δ-параметров' if active else 'Обновить старт по FFT')
        self.table.setHorizontalHeaderLabels(['Параметр','Значение для фиксации','Фит ± σ','Фикс. δf'] if active else ['Параметр','Старт','Фит ± σ','Фикс. f'])
        self.note.setText(('Опора A₀, Γ₀, f₀, φ₀ берётся из фита X1. Все δ-параметры относятся к физическому t=0.\n'
            'δ могут быть отрицательными; δφ — в градусах без modulo 360.\n'
            'Модель линейна: стартовые δ не требуются. Число в строке δf используется только при включённой фиксации. '
            'Остальные параметры находятся МНК. C=0, если флажок выше выключен.') if active else
            'A ≥ 0; τ > 0. A и φ относятся к началу участка фита. Флажок удерживает частоту точно.')
        self.delta_fixed={i:v for i,v in self.delta_fixed.items() if i<self.components()}

    def model_changed(self,*args):
        if not self.theory():super().model_changed(*args)
    def fixed_toggled(self,component,checked):
        if not self.theory():return super().fixed_toggled(component,checked)
        if checked:self.delta_fixed[component]=float(self.table.cellWidget(4*component+2,1).value()*1e9)
        else:self.delta_fixed.pop(component,None)
        self.owner.manual_initials[self.index]=self.read_parameters().copy();self.owner.invalidate()
    def changed_parameter(self,*args):
        if not self.theory():return super().changed_parameter(*args)
        parameters=self.read_parameters()
        for i in tuple(self.delta_fixed):self.delta_fixed[i]=float(parameters[4*i+2])
        self.owner.manual_initials[self.index]=parameters.copy();self.owner.invalidate()

    def populate(self,parameters,result,prepared,unit):
        self.sync_mode()
        if not self.theory():return super().populate(parameters,result,prepared,unit)
        if parameters is None:self.table.setRowCount(0);return
        parameters=np.asarray(parameters,dtype=float).copy();count=(len(parameters)-1)//4
        for i,v in self.delta_fixed.items():
            if i<count:parameters[4*i+2]=v
        amplitude_values=parameters[1:-1:4]
        scale,pretty=angle_unit(amplitude_values if np.any(amplitude_values) else prepared.y[prepared.fit_mask])
        amp_unit=pretty.replace('rad','V')
        self.scales=[];self.table.setRowCount(len(parameters));self.fixed_checks={}
        for row,(name,_) in enumerate(sf.parameter_names(count)):
            kind=row%4
            factor=scale if row==len(parameters)-1 or kind==1 else (1e9 if kind in (0,2) else np.pi/180)
            unit=amp_unit if row==len(parameters)-1 or kind==1 else ('ns⁻¹' if kind==0 else 'GHz' if kind==2 else '°')
            self.scales.append(factor)
            label=QTableWidgetItem(f'{name.replace("delta_","δ")} [{unit}]');label.setFlags(label.flags()&~Qt.ItemIsEditable)
            self.table.setItem(row,0,label)
            field=spin(float(parameters[row]/factor),decimals=9)
            self.table.setCellWidget(row,1,field)
            pinned=(row<len(parameters)-1 and kind==2 and row//4 in self.delta_fixed) or (row==len(parameters)-1 and not self.constant.isChecked())
            if row==len(parameters)-1 and not self.constant.isChecked():field.setValue(0);field.setEnabled(False)
            field.valueChanged.connect(self.changed_parameter)
            text=''
            if result is not None:
                if not getattr(result,'identifiable',True) and not pinned:text='не определено'
                else:
                    value=result.parameters[row]/factor;error=result.errors[row]/factor
                    text=f'{value:.9g} (фикс.)' if pinned else f'{value:.6g} ± '+(f'{error:.3g}' if np.isfinite(error) else '—')
            item=QTableWidgetItem(text);item.setFlags(item.flags()&~Qt.ItemIsEditable);self.table.setItem(row,2,item)
            if row<len(parameters)-1 and kind==2:
                i=row//4;check=QCheckBox();check.setChecked(i in self.delta_fixed)
                self.table.setCellWidget(row,3,check);self.fixed_checks[i]=check
                check.toggled.connect(lambda checked,i=i:self.fixed_toggled(i,checked))
            else:self.table.removeCellWidget(row,3)
