"""Diagnostic quadratures and quality-masked circular phase on the shared grid.

Prepared's legacy *_rad fields contain V for X2/Y2 and rad for phase2. These
diagnostics do not change the fitted X1/R2 signals or their comparison.
"""
from dataclasses import replace
import numpy as np
from . import core
from .io import Measurement


DIAGNOSTIC_UNITS = {'x2': 'V', 'y2': 'V', 'phase2': 'rad'}


def diagnostics_metadata():
    return {
        'x2': 'Signed X2 in source volts; duplicate positions are averaged before the common polynomial background is subtracted.',
        'y2': 'Signed Y2 in source volts; duplicate positions are averaged before the common polynomial background is subtracted.',
        'phase2': 'atan2(Y2_processed, X2_processed) modulo 2*pi, displayed/exported in degrees [0,360). Same background as plotted quadratures. Points below the radial noise threshold are excluded from analysis and shown in gray.',
        'phase_fft': 'FFT/fit only on a continuous above-threshold local phase branch, with no >90 degree adjacent circular jumps and total excursion <=180 degrees. No global unwrap of noisy angles. Local branch processing uses radians internally.',
        'distinction': 'Quadrature phase is not the phase parameter of the fitted R2 oscillation. R2 averages per-row magnitudes; quadrature phase uses the averaged complex quadratures at duplicate positions.',
    }


def _common_config(first):
    cfg=replace(first.settings, zero_mode='manual', fit_window_mode='manual')
    preparation_cfg=cfg
    if cfg.fit_min_s >= cfg.fit_max_s:
        preparation_cfg=replace(cfg,
            fit_min_s=float(np.nextafter(cfg.fit_min_s,-np.inf)),
            fit_max_s=float(np.nextafter(cfg.fit_max_s,np.inf)))
    return cfg,preparation_cfg


def _series(dual, values, *, phase=False):
    """Use the established preprocessing/FFT routine, undoing scalar calibration."""
    first=dual.first; m=dual.measurement
    cfg,preparation_cfg=_common_config(first)
    if phase:
        cfg=replace(cfg,background_degree=-1)
        preparation_cfg=replace(preparation_cfg,background_degree=-1)
    measurement=Measurement(np.asarray(m.position),np.asarray(values,dtype=float),
        m.data_path,m.notes_path,m.notes,'V',list(m.warnings))
    p=core.prepare(measurement,preparation_cfg)
    factor=preparation_cfg.rad_per_unit
    p=replace(p,raw_rad=p.raw_rad/factor,y=p.y/factor,
        background=p.background/factor,spectrum=p.spectrum/factor,
        fit_mask=first.fit_mask.copy(),settings=cfg)
    if not np.array_equal(p.time,first.time):
        raise ValueError('Не удалось получить общую сетку диагностических сигналов.')
    if first.fit_mask.sum()<8:
        return replace(p,frequencies=np.array([]),spectrum=np.array([]),resolution_hz=float('nan'))
    interval=p.y[p.fit_mask]
    floor=64*np.finfo(float).eps*float(np.max(abs(p.raw_rad)))
    if np.ptp(interval)<=floor:
        p=replace(p,frequencies=np.array([]),spectrum=np.array([]),resolution_hz=float('nan'),
            warnings=p.warnings+['Сигнал постоянен в пределах машинной точности; осцилляционный спектр не определён.'])
    return p


def prepare_diagnostics(dual_prepared, phase_sigma=3., noise_sigma_v=None):
    """X2/Y2 [V] and masked atan2(Y2_processed,X2_processed) modulo 2π.

    The calibrated R2 mode has no effect on these source quadratures. X1's
    shared zero, time grid and selected interval remain authoritative.
    """
    dual=dual_prepared; m=dual.measurement
    x2=_series(dual,m.x2); y2=_series(dual,m.y2)
    magnitude=np.hypot(x2.y,y2.y)
    phase=np.mod(np.arctan2(y2.y,x2.y),2*np.pi)
    phase[magnitude==0]=np.nan
    if not np.isfinite(phase_sigma) or phase_sigma<0:raise ValueError('Порог фазы σ должен быть неотрицательным.')
    mask=dual.first.fit_mask
    if noise_sigma_v is None or noise_sigma_v==0:
        estimates=[]
        for values in (x2.y[mask],y2.y[mask]):
            differences=np.diff(values,n=2)
            estimates.append(float(np.median(abs(differences-np.median(differences)))/(.67448975*np.sqrt(6))) if len(differences) else 0.)
        sigma=max(estimates);method='MAD of second differences / (0.67448975*sqrt(6)); approximate, override using measured quadrature noise'
    else:
        sigma=float(noise_sigma_v);method='User supplied quadrature noise standard deviation'
        if not np.isfinite(sigma) or sigma<0:raise ValueError('Шум σ должен быть конечным и неотрицательным.')
    numerical=64*np.finfo(float).eps*max(float(np.max(abs(x2.y))),float(np.max(abs(y2.y))))
    threshold=max(float(phase_sigma)*sigma,numerical,np.finfo(float).tiny)
    valid=np.isfinite(phase)&(magnitude>=threshold)
    info=dict(wrapped=True,display_unit='deg',range_deg=[0,360],noise_sigma_v=sigma,
        noise_method=method,threshold_sigma=float(phase_sigma),threshold_v=threshold,
        valid_points=int(np.count_nonzero(valid&mask)),window_points=int(mask.sum()),
        background_degree=dual.first.settings.background_degree,minimum_branch_points=16,
        maximum_step_deg=90.,maximum_excursion_deg=180.)
    warnings=list(m.warnings)
    if np.any(mask&~valid):warnings.append(f'Фаза: ниже порога/не определено {np.count_nonzero(mask&~valid)} из {mask.sum()} точек; эти точки исключены из FFT/фита.')
    prepared_phase=replace(x2,raw_rad=phase,y=np.where(valid,phase,np.nan),
        background=np.zeros_like(phase),frequencies=np.array([]),spectrum=np.array([]),resolution_hz=float('nan'),
        settings=replace(x2.settings,background_degree=-1),warnings=warnings,phase_info=info)
    return {'x2':x2,'y2':y2,'phase2':prepared_phase}
