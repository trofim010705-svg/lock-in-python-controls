"""Live dual-channel Matplotlib figure; exports the same canvas the user edits."""
from io import BytesIO
import numpy as np
from PIL import Image
from PyQt5.QtCore import Qt, QEvent, QTimer, pyqtSignal
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QScrollArea
from matplotlib.figure import Figure
from matplotlib.font_manager import FontProperties
from matplotlib.mathtext import MathTextParser
from matplotlib.ticker import FuncFormatter
from matplotlib.widgets import SpanSelector
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from .figure_editor import FigureEditor, _Toolbar
from .presentation import model_mathtext, angle_unit
from .core import evaluate
from .export import spectral_peaks


def engineering(value, unit):
    if unit=='deg':return f'{np.rad2deg(value):.6g}°'
    factor, prefix=angle_unit([value])
    return f'{value/factor:.6g} {prefix[:-3]+unit}' if prefix.endswith('rad') else f'{value:.6g} {unit}'


def _parameter_text(prepared, result, unit, channel, time_unit, band, include_peaks=True):
    tf=1e-9 if time_unit=='ns' else 1e-12
    lines=[channel]
    if result is None:
        lines.append('Фит недоступен: нет подходящего достоверного участка фазы.' if unit=='deg' else 'Фит ещё не рассчитан.')
    else:
        def quantity(v,e,scale,u):
            error=f'{e/scale:.3g}' if np.isfinite(e) else '—'
            return f'{v/scale:.6g} ± {error} {u}'
        lines.append(f't_ref = {result.reference_s/tf:.6g} {time_unit}')
        for i in range((len(result.parameters)-1)//4):
            a,f,ph,tau=result.parameters[4*i:4*i+4]
            ea,ef,ep,et=result.errors[4*i:4*i+4]
            scale,prefix=angle_unit([a]); aunit=prefix[:-3]+unit
            if unit=='deg':scale,aunit=np.pi/180.,'°'
            frequency=f'{f/1e9:.6g} GHz (фикс.)' if i in getattr(result,'fixed_frequencies',{}) else quantity(f,ef,1e9,'GHz')
            lines.extend([f'A{i+1} = {quantity(a,ea,scale,aunit)}; f{i+1} = {frequency}',
                          f'τ{i+1} = {quantity(tau,et,tf,time_unit)}; φ{i+1} = {quantity(np.mod(ph,2*np.pi),ep,np.pi/180.,"°")}'])
        scale,prefix=angle_unit([result.parameters[-1]])
        cunit=prefix[:-3]+unit
        if unit=='deg':scale,cunit=np.pi/180.,'°'
        offset=np.mod(result.parameters[-1],2*np.pi) if unit=='deg' else result.parameters[-1]
        lines.append(f'C = {quantity(offset,result.errors[-1],scale,cunit)}; R² = {result.r_squared:.6g}')
        lines.append(f'RMSE = {engineering(result.rmse_rad,unit)}')
    if not include_peaks:return '\n'.join(lines)
    lines.append('FFT: f, амплитуда, FWHM по A/2')
    peaks=spectral_peaks(prepared,band)
    for peak in peaks:
        width=peak.get('fwhm_hz')
        width_text=f'{width/1e9:.6g} GHz' if width is not None else '—'
        lines.append(f'{peak["rank"]}: {peak["frequency_hz"]/1e9:.6g} GHz; A = {engineering(peak["amplitude_rad"],unit)}')
        lines.append(f'    FWHM = {width_text}')
    if not peaks:lines.append('Пики недоступны в выбранной полосе.')
    return '\n'.join(lines)


class _DualSelector(SpanSelector):
    def __init__(self,owner,**kwargs):
        self.owner=owner;self._background=None
        super().__init__(**kwargs)
    def ignore(self,event):
        return bool(self.owner.toolbar.mode) or super().ignore(event)
    def update_background(self,event):
        # All four selectors live on separate axes and are animated. A normal
        # draw already excludes them: no recursive full-canvas redraw needed.
        if not self.useblit or self.canvas.is_saving():return
        self._background=self.canvas.copy_from_bbox(self.ax.bbox)
        for artist in self.artists:
            if artist.get_visible():self.ax.draw_artist(artist)
    def update(self):
        if not self.ax.get_visible():return
        if not self.useblit or self._background is None:
            self.canvas.draw_idle();return
        self.canvas.restore_region(self._background)
        for artist in self.artists:
            if artist.get_visible():self.ax.draw_artist(artist)
        self.canvas.blit(self.ax.bbox)


class _CachedLayoutCanvas(FigureCanvasQTAgg):
    """Reflow the large report only when its geometry changes, not while panning."""
    def draw(self):
        self._draw_pending=False  # an explicit render also consumes queued draws
        owner=self._report_owner
        if owner._geometry_dirty:
            self.figure.set_layout_engine(owner._layout_engine)
        try:
            super().draw()
            owner._geometry_dirty=False
        finally:
            self.figure.set_layout_engine(None)


class DualFigure(QWidget):
    band_changed=pyqtSignal(int,tuple)
    diagnostic_band_changed=pyqtSignal(str,tuple)
    title_validation_error=pyqtSignal(str)
    save_requested=pyqtSignal()
    title_edit_requested=pyqtSignal()
    labels_validation_error=pyqtSignal(str)
    labels_edit_requested=pyqtSignal(str)

    def __init__(self,parent=None):
        super().__init__(parent)
        self.title_size,self.body_size=14.,8.
        self._math_parser=MathTextParser('path')
        self._summary='';self._columns=('','');self._formulas=('','')
        self._layout_running=False;self._layout_queued=False
        self._geometry_dirty=True;self._footer_layout_key=None
        self._normalized_visible=True;self._ready_normalized=False;self._footer_visible=True
        self._alphas=(.55,.55);self._prepared=None;self._results=(None,None)
        self._time_unit='ns'
        self._labels=self.default_labels();self._fit_visible=(True,True)
        self._diagnostics={};self._series_context={}
        self._overlay_signals=('x1','r2')
        self._signal_fit_visible={key:True for key in ('x1','x2','y2','r2','phase2')}
        self._signal_alphas={key:.55 for key in self._signal_fit_visible}
        self._peak_annotations={key:True for key in self._signal_fit_visible}
        self._diagnostic_results={};self._diagnostic_fit_prepared={};self._diagnostic_bands={}
        self._fit_enabled={}
        self.figure=Figure(figsize=(12,12),dpi=100,facecolor='white',layout='constrained')
        self._layout_engine=self.figure.get_layout_engine()
        self.canvas=_CachedLayoutCanvas(self.figure);self.canvas._report_owner=self
        self.canvas.setMinimumWidth(620)
        self.scroll=QScrollArea();self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.NoFrame);self.scroll.setWidget(self.canvas)
        self.scroll.viewport().installEventFilter(self)
        self.toolbar=_Toolbar(self.canvas,self)
        layout=QVBoxLayout(self);layout.setContentsMargins(0,0,0,0)
        layout.addWidget(self.toolbar);layout.addWidget(self.scroll,1)
        self.grid=self.figure.add_gridspec(7,2,height_ratios=[250]*5+[240,180])
        self.time_axes=[self.figure.add_subplot(self.grid[i,0]) for i in (0,3)]
        self.fft_axes=[self.figure.add_subplot(self.grid[i,1]) for i in (0,3)]
        self.diagnostic_time_axes={key:self.figure.add_subplot(self.grid[row,0]) for key,row in (('x2',1),('y2',2),('phase2',4))}
        self.diagnostic_fft_axes={key:self.figure.add_subplot(self.grid[row,1]) for key,row in (('x2',1),('y2',2))}
        self.quadrature_axes=self.figure.add_subplot(self.grid[4,1])
        self.quadrature_points=self.quadrature_axes.plot([],[],ls='none',marker='o',ms=3,color='#6850a1',alpha=.55,mew=0)[0]
        self.quadrature_axes.axhline(0,color='#91a1b0',lw=.6,alpha=.5)
        self.quadrature_axes.axvline(0,color='#91a1b0',lw=.6,alpha=.5)
        self.quadrature_axes.set_aspect('equal',adjustable='datalim')
        self.normalized_axes=self.figure.add_subplot(self.grid[5,:])
        self.footer_axes=self.figure.add_subplot(self.grid[6,:]);self.footer_axes.set_axis_off()
        self.title_artist=self.figure.suptitle('Pump–probe · X1 / R2',fontsize=self.title_size,color='#25435d')
        self.formula_artists=[self.footer_axes.text(x,.99,'',transform=self.footer_axes.transAxes,va='top',ha='left',parse_math=True,color='#25435d') for x in (.01,.52)]
        self.column_artists=[self.footer_axes.text(x,.8,'',transform=self.footer_axes.transAxes,va='top',ha='left',parse_math=False,linespacing=1.35,color='#243b50') for x in (.01,.52)]
        self.summary_artist=self.footer_axes.text(.01,.2,'',transform=self.footer_axes.transAxes,va='top',ha='left',parse_math=False,linespacing=1.35,color='#243b50')
        self.point_artists=[];self.fit_artists=[];self.spectrum_artists=[];self.peak_artists=[]
        self.normalized_points=[];self.normalized_fits=[];self.selectors=[]
        for i,color in enumerate(('#147c9c','#d66b30')):
            axis=self.time_axes[i]
            self.point_artists.append(axis.plot([],[],ls='none',marker='o',ms=3,color=color,alpha=self._alphas[i],mew=0)[0])
            self.fit_artists.append(axis.plot([],[],lw=1.8,color=color,alpha=1)[0])
            self.spectrum_artists.append(self.fft_axes[i].plot([],[],lw=1.3,color=color)[0])
            self.peak_artists.append(self.fft_axes[i].plot([],[],ls='none',marker='o',ms=4,color='#a23153')[0])
            self.normalized_points.append(self.normalized_axes.plot([],[],ls='none',marker='o',ms=3,color=color,alpha=self._alphas[i],mew=0,label=('X1','R2')[i])[0])
            self.normalized_fits.append(self.normalized_axes.plot([],[],color=color,lw=1.8,alpha=1)[0])
            self.selectors.append(_DualSelector(self,ax=self.fft_axes[i],onselect=lambda lo,hi,j=i:self._band_selected(j,lo,hi),
                direction='horizontal',interactive=True,drag_from_anywhere=True,useblit=True,button=1,
                props=dict(facecolor='#1aa5a2',alpha=.12),handle_props=dict(color='#37a7a5',linewidth=.9)))
        self.diagnostic_points={};self.diagnostic_spectra={};self.diagnostic_peaks={}
        self.diagnostic_fit_artists={};self.normalized_diagnostic_points={};self.normalized_diagnostic_fits={};self.diagnostic_selectors={}
        for key,color in (('x2','#c4475a'),('y2','#7a55a3'),('phase2','#3b8d69')):
            self.diagnostic_points[key]=self.diagnostic_time_axes[key].plot([],[],ls='none',marker='o',ms=3,color=color,mew=0)[0]
            self.diagnostic_fit_artists[key]=self.diagnostic_time_axes[key].plot([],[],color=color,lw=1.8,alpha=1)[0]
            self.normalized_diagnostic_points[key]=self.normalized_axes.plot([],[],ls='none',marker='o',ms=3,color=color,alpha=.55,mew=0)[0]
            self.normalized_diagnostic_fits[key]=self.normalized_axes.plot([],[],color=color,lw=1.8,alpha=1)[0]
            if key=='phase2':continue  # phase FFT is only an internal fit seed
            self.diagnostic_spectra[key]=self.diagnostic_fft_axes[key].plot([],[],color=color,lw=1.3)[0]
            self.diagnostic_peaks[key]=self.diagnostic_fft_axes[key].plot([],[],ls='none',marker='o',ms=4,color='#a23153')[0]
            self.diagnostic_selectors[key]=_DualSelector(self,ax=self.diagnostic_fft_axes[key],
                onselect=lambda lo,hi,k=key:self._diagnostic_band_selected(k,lo,hi),direction='horizontal',
                interactive=True,drag_from_anywhere=True,useblit=True,button=1,
                props=dict(facecolor='#1aa5a2',alpha=.12),handle_props=dict(color='#37a7a5',linewidth=.9))
            self.diagnostic_selectors[key].set_visible(False)
        self.phase_unreliable_points=self.diagnostic_time_axes['phase2'].plot([],[],ls='none',marker='o',ms=2.5,color='#999999',alpha=.35,mew=0)[0]
        self.axes_by_id={'x1':self.time_axes[0],'x1_fft':self.fft_axes[0],
            'r2':self.time_axes[1],'r2_fft':self.fft_axes[1],'normalized':self.normalized_axes,
            'quadrature':self.quadrature_axes}
        for key in self.diagnostic_time_axes:
            self.axes_by_id[key]=self.diagnostic_time_axes[key]
            if key in self.diagnostic_fft_axes:self.axes_by_id[key+'_fft']=self.diagnostic_fft_axes[key]
        for key,axis in self.axes_by_id.items():axis._graph_id=key
        for axis in self.axes_by_id.values():
            axis.grid(True,alpha=.17);axis.tick_params(labelsize=9,colors='#354b60')
            for spine in axis.spines.values():spine.set_color('#afbdc9')
        self._units=['rad','V']
        for i in range(2):
            for axis,caption in ((self.time_axes[i],('X1','R2')[i]),(self.fft_axes[i],'FFT '+('X1','R2')[i])):
                axis._dual_caption=caption;axis._dual_unit=self._units[i]
                axis.yaxis.set_major_formatter(FuncFormatter(lambda value,pos,a=axis:self._yformat(a,value)))
                axis.callbacks.connect('ylim_changed',self._ylabel)
                axis.set_title(caption,fontsize=11,color='#25435d')
        for key in self.diagnostic_time_axes:
            axes=[self.diagnostic_time_axes[key]]
            if key in self.diagnostic_fft_axes:axes.append(self.diagnostic_fft_axes[key])
            for axis in axes:
                axis._dual_unit='deg' if key=='phase2' else 'V'
                axis.yaxis.set_major_formatter(FuncFormatter(lambda value,pos,a=axis:self._yformat(a,value)))
                axis.callbacks.connect('ylim_changed',self._ylabel)
        self.quadrature_axes._dual_unit='V'
        for xyaxis in (self.quadrature_axes.xaxis,self.quadrature_axes.yaxis):
            xyaxis.set_major_formatter(FuncFormatter(lambda value,pos:self._xyformat(value)))
        self.quadrature_axes.callbacks.connect('xlim_changed',self._ylabel)
        self.quadrature_axes.callbacks.connect('ylim_changed',self._ylabel)
        self._apply_labels()
        self.canvas.mpl_connect('button_press_event',self._pressed)
        self.set_normalized_visible(True)
        self._layout_footer()

    @staticmethod
    def default_labels():
        labels={}
        names={'x1':'X1','x2':'X2','y2':'Y2','r2':'R2',
               'phase2':r'$\varphi_2(t)$'}
        for key,name in names.items():
            labels.update({key+'.title':name,key+'.xlabel':'Задержка ({time_unit})',
                           key+'.ylabel':name+' ({unit})'})
            if key!='phase2':
                labels.update({key+'_fft.title':'FFT '+name,key+'_fft.xlabel':'Частота (GHz)',
                               key+'_fft.ylabel':'FFT '+name+' ({unit})'})
        labels.update({'quadrature.title':'Плоскость X₂–Y₂',
                       'quadrature.xlabel':'X₂ ({unit})','quadrature.ylabel':'Y₂ ({unit})'})
        labels.update({'normalized.title':'Сравнение нормированных сигналов',
            'normalized.xlabel':'Задержка ({time_unit})','normalized.ylabel':'a.u.',
            'legend.x1_points':'X1 experiment','legend.r2_points':'R2 experiment',
            'legend.x1_fit':'X1 fit','legend.r2_fit':'R2 fit',
            'channel.x1':'X1','channel.r2':'R2 = √(X2² + Y2²)'})
        for key,name in (('x2','X2'),('y2','Y2'),('phase2','φ₂')):
            labels.update({'legend.'+key+'_points':name+' experiment','legend.'+key+'_fit':name+' fit','channel.'+key:name})
        labels.update({'legend.phase2_valid':'R ≥ порога','legend.phase2_unreliable':'R < порога'})
        return labels

    def _expanded_label(self,text,unit=''):
        return FigureEditor.normalize_mathtext(str(text).replace('{unit}',unit).replace('{time_unit}',self._time_unit))

    def set_labels(self,mapping):
        candidate=dict(self._labels)
        try:
            unknown=set(mapping)-set(candidate)
            if unknown:raise ValueError('Неизвестная подпись: '+', '.join(sorted(unknown)))
            candidate.update({key:str(value) for key,value in mapping.items()})
            if candidate==self._labels:
                self.labels_validation_error.emit('');return True
            for key,value in candidate.items():
                if key.startswith('channel.'):continue  # plain text in numeric footer
                expanded=self._expanded_label(value,'µV')
                for line in expanded.splitlines() or ['']:
                    self._math_parser.parse(line,dpi=self.figure.dpi,prop=FontProperties(size=self.title_size))
        except (ValueError,TypeError) as exc:
            self.labels_validation_error.emit('Ошибка подписи: '+str(exc));return False
        self._labels=candidate
        self._update_footer()
        self._apply_labels();self._layout_footer();self.canvas.draw_idle()
        self.labels_validation_error.emit('');return True

    def _apply_axis_labels(self,axis,unit=None):
        key=axis._graph_id
        if unit is None:
            if key=='normalized':unit='a.u.'
            elif key=='phase2':unit='°'
            elif key=='quadrature':unit=self._xyunit()[1]
            else:
                _,prefix=angle_unit(axis.get_ylim())
                unit=prefix[:-3]+axis._dual_unit
        title=self._labels[key+'.title']
        if key=='normalized' and not self._ready_normalized and title==self.default_labels()[key+'.title']:
            title='Сравнение сигналов появится после загрузки'
        changed=False
        text=self._expanded_label(title,unit)
        if axis.get_title()!=text:
            axis.set_title(text,fontsize=11,color='#25435d',parse_math=True);changed=True
        xunit='GHz' if key.endswith('_fft') else self._time_unit
        if key=='quadrature':xunit=unit
        for current,setter,text in ((axis.get_xlabel(),axis.set_xlabel,self._expanded_label(self._labels[key+'.xlabel'],xunit)),
                                    (axis.get_ylabel(),axis.set_ylabel,self._expanded_label(self._labels[key+'.ylabel'],unit))):
            if current!=text:setter(text,fontsize=10,color='#354b60',parse_math=True);changed=True
        if changed:self._geometry_dirty=True

    def _apply_labels(self):
        for axis in self.axes_by_id.values():self._apply_axis_labels(axis)
        self._refresh_legend()
        self._refresh_phase_legend()

    def _refresh_phase_legend(self):
        handles=[];texts=[]
        for artist,key in ((self.diagnostic_points['phase2'],'legend.phase2_valid'),(self.phase_unreliable_points,'legend.phase2_unreliable')):
            if len(artist.get_ydata()) and self._labels.get(key):handles.append(artist);texts.append(self._labels[key])
        old=self.diagnostic_time_axes['phase2'].get_legend()
        if old is not None:old.remove()
        if handles:self.diagnostic_time_axes['phase2'].legend(handles,texts,fontsize=7,loc='upper right')

    def _normal_artists(self,key):
        if key in ('x1','r2'):
            i=('x1','r2').index(key)
            return self.normalized_points[i],self.normalized_fits[i]
        return self.normalized_diagnostic_points[key],self.normalized_diagnostic_fits[key]

    def _main_fit(self,key):
        return self.fit_artists[('x1','r2').index(key)] if key in ('x1','r2') else self.diagnostic_fit_artists[key]

    def _refresh_legend(self):
        handles=[];labels=[];keys=[]
        for name in self._overlay_signals:
            points,fitted=self._normal_artists(name)
            for kind,artist in (('points',points),('fit',fitted)):
                key='legend.'+name+'_'+kind
                if artist.get_visible() and len(artist.get_ydata()) and self._labels.get(key):
                    handles.append(artist);labels.append(self._expanded_label(self._labels[key]));keys.append(key)
        self._legend_keys=keys
        previous=self.normalized_axes.get_legend()
        if previous is not None:previous.remove()
        if handles:self.normalized_axes.legend(handles,labels,loc='upper right',fontsize=8,framealpha=.8)

    def _apply_visibility(self):
        for key,visible in self._signal_fit_visible.items():
            self._main_fit(key).set_visible(visible)
            points,fitted=self._normal_artists(key)
            points.set_visible(key in self._overlay_signals)
            fitted.set_visible(key in self._overlay_signals and visible)
        self._refresh_legend()

    def set_overlay_signals(self,keys):
        selected=tuple(dict.fromkeys(keys))
        if not set(selected)<=set(self._signal_fit_visible):raise ValueError('Неизвестный сигнал для сравнения')
        self._overlay_signals=selected;self._apply_visibility();self.canvas.draw_idle()

    def set_fit_visibility(self,mapping):
        if not set(mapping)<=set(self._signal_fit_visible):raise ValueError('Неизвестный сигнал фита')
        self._signal_fit_visible.update({key:bool(value) for key,value in mapping.items()})
        self._fit_visible=tuple(self._signal_fit_visible[key] for key in ('x1','r2'))
        self._apply_visibility();self.canvas.draw_idle()

    def set_fit_visible(self,first=True,second=True):
        self.set_fit_visibility({'x1':first,'r2':second})

    def set_signal_alphas(self,mapping):
        if not set(mapping)<=set(self._signal_alphas):raise ValueError('Неизвестный сигнал прозрачности')
        self._signal_alphas.update({key:float(np.clip(value,0,1)) for key,value in mapping.items()})
        self._alphas=tuple(self._signal_alphas[key] for key in ('x1','r2'))
        for key,alpha in self._signal_alphas.items():
            point=self.point_artists[('x1','r2').index(key)] if key in ('x1','r2') else self.diagnostic_points[key]
            point.set_alpha(alpha)
            points,fitted=self._normal_artists(key);points.set_alpha(alpha);fitted.set_alpha(1.)
            self._main_fit(key).set_alpha(1.)
        self.quadrature_points.set_alpha((self._signal_alphas['x2']+self._signal_alphas['y2'])/2)
        self.canvas.draw_idle()

    def set_peak_annotations(self,mapping):
        if not set(mapping)<=set(self._peak_annotations):raise ValueError('Неизвестный сигнал FFT')
        self._peak_annotations.update({key:bool(value) for key,value in mapping.items()})
        self._update_footer();self._layout_footer();self.canvas.draw_idle()

    def _update_footer(self):
        blocks={}
        for key,(p,result,unit,band,count,fit_p) in self._series_context.items():
            spectrum_source=fit_p if len(fit_p.spectrum) else p
            text=_parameter_text(spectrum_source,result,'deg' if key=='phase2' else unit,self._labels['channel.'+key],self._time_unit,band,self._peak_annotations[key] and key!='phase2')
            if not self._fit_enabled.get(key,True):
                text=text.replace('Фит ещё не рассчитан.','Расчёт фита отключён.').replace(
                    'Фит недоступен: нет подходящего достоверного участка фазы.','Расчёт фита отключён.')
            if result is not None and np.any(fit_p.fit_mask):
                bounds=fit_p.time[fit_p.fit_mask]
                text+='\nОкно фита: '+f'{bounds[0]/(1e-9 if self._time_unit=="ns" else 1e-12):.6g}…{bounds[-1]/(1e-9 if self._time_unit=="ns" else 1e-12):.6g} {self._time_unit}'
            blocks[key]=text
        self._columns=['\n\n'.join(blocks[k] for k in group if k in blocks)
                       for group in (('x1','x2','y2'),('r2','phase2'))]

    def set_footer_visible(self,visible):
        self._footer_visible=bool(visible)
        self.footer_axes.set_visible(self._footer_visible);self.footer_axes.set_in_layout(self._footer_visible)
        self._layout_footer();self.canvas.draw_idle()

    def _draw_diagnostics(self,time_factor):
        for key in self.diagnostic_time_axes:
            p=self._diagnostics.get(key)
            points=self.diagnostic_points[key]
            fitted=self.diagnostic_fit_artists[key];fitted.set_data([],[])
            if p is None:
                points.set_data([],[])
                if key=='phase2':self.phase_unreliable_points.set_data([],[])
                else:
                    self.diagnostic_spectra[key].set_data([],[]);self.diagnostic_peaks[key].set_data([],[])
                    self.diagnostic_selectors[key].set_visible(False)
                continue
            fit_p=self._diagnostic_fit_prepared.get(key,p)
            result=self._diagnostic_results.get(key)
            fft_p=fit_p if len(fit_p.spectrum) else p
            visible=p.fit_mask if p.fit_mask.sum()>=8 else np.ones(len(p.time),dtype=bool)
            points.set_data(p.time[visible]/time_factor,np.mod(np.rad2deg(p.y[visible]),360.) if key=='phase2' else p.y[visible])
            if key=='phase2':
                invalid=visible&~np.isfinite(p.y)&np.isfinite(p.raw_rad)
                self.phase_unreliable_points.set_data(p.time[invalid]/time_factor,np.mod(np.rad2deg(p.raw_rad[invalid]),360.))
            if result is not None and np.any(fit_p.fit_mask):
                selected_time=fit_p.time[fit_p.fit_mask]
                dense=np.linspace(selected_time[0],selected_time[-1],1500)
                predicted=evaluate(dense,result.parameters,result.reference_s)
                if key=='phase2':
                    predicted=np.mod(np.rad2deg(predicted),360.)
                    predicted[np.flatnonzero(abs(np.diff(predicted))>180.)+1]=np.nan
                fitted.set_data(dense/time_factor,predicted)
            self.diagnostic_time_axes[key].relim();self.diagnostic_time_axes[key].autoscale(enable=True)
            self._ylabel(self.diagnostic_time_axes[key])
            if key=='phase2':
                self.diagnostic_time_axes[key].set_yticks(np.arange(0,361,60))
                self.diagnostic_time_axes[key].set_ylim(0,360)
                continue
            spectrum=self.diagnostic_spectra[key];peaks=self.diagnostic_peaks[key]
            selector=self.diagnostic_selectors[key]
            amplitude=fft_p.spectrum
            spectrum.set_data(fft_p.frequencies/1e9,amplitude)
            selected=np.flatnonzero((fft_p.frequencies>0)&np.isfinite(fft_p.spectrum))
            band=self._diagnostic_bands.get(key)
            if band is not None:
                selected=selected[(fft_p.frequencies[selected]>=band[0])&(fft_p.frequencies[selected]<=band[1])]
                selector.extents=(band[0]/1e9,band[1]/1e9);selector.set_visible(True)
            else:selector.set_visible(False)
            if not len(fft_p.spectrum):selector.set_visible(False)
            if len(selected) and np.max(fft_p.spectrum[selected])>np.finfo(float).tiny:
                maximum=selected[np.argmax(fft_p.spectrum[selected])]
                peaks.set_data([fft_p.frequencies[maximum]/1e9],[amplitude[maximum]])
            else:peaks.set_data([],[])
            axis=self.diagnostic_fft_axes[key]
            axis.relim();axis.autoscale(enable=True);self._ylabel(axis)
            if band is not None and band[0]<band[1]:
                width=.25*(band[1]-band[0])
                self.diagnostic_fft_axes[key].set_xlim(max(0.,band[0]-width)/1e9,min(max(fft_p.nyquist_hz,band[1]),band[1]+width)/1e9)
            elif len(selected) and np.max(fft_p.spectrum[selected])>np.finfo(float).tiny:
                frequency=float(fft_p.frequencies[maximum]);width=max(2*fft_p.resolution_hz,.35*frequency)
                self.diagnostic_fft_axes[key].set_xlim(max(0.,frequency-width)/1e9,min(fft_p.nyquist_hz,frequency+width)/1e9)
        self._draw_quadrature()

    def _draw_quadrature(self):
        """Pair the same experimental samples; never fit/smooth or decimate them."""
        x=self._diagnostics.get('x2');y=self._diagnostics.get('y2')
        self.quadrature_points.set_data([],[])
        if x is None or y is None:return
        mask=x.fit_mask&y.fit_mask&np.isfinite(x.y)&np.isfinite(y.y)
        self.quadrature_points.set_data(x.y[mask],y.y[mask])
        # Reference lines must not force an offset cloud to include the origin.
        self.quadrature_axes.dataLim.set_points(np.array([[np.inf,np.inf],[-np.inf,-np.inf]]))
        if np.any(mask):self.quadrature_axes.update_datalim(np.column_stack((x.y[mask],y.y[mask])))
        self.quadrature_axes.autoscale(enable=True)
        self._ylabel(self.quadrature_axes)

    def _xyunit(self):
        scale,prefix=angle_unit((*self.quadrature_axes.get_xlim(),*self.quadrature_axes.get_ylim()))
        return scale,prefix.replace('rad','V')

    def _xyformat(self,value):
        return f'{value/self._xyunit()[0]:.6g}'

    def _diagnostic_band_selected(self,key,low,high):
        p=self._diagnostic_fit_prepared.get(key,self._diagnostics.get(key))
        if p is None:return
        low=max(0.,float(low));high=min(float(high),p.nyquist_hz/1e9)
        if low<high:self.diagnostic_band_changed.emit(key,(low*1e9,high*1e9))

    def _update_normalized(self,time_factor):
        from .dual_fit_support import overlay_values
        self._ready_normalized=False
        for key in self._signal_fit_visible:
            point,line=self._normal_artists(key);point.set_data([],[]);line.set_data([],[])
            context=self._series_context.get(key)
            if context is None:continue
            p,result,unit,band,count,fit_p=context
            source=fit_p if result is not None else p
            try:
                values=overlay_values(source,result)
                mask=values['mask']
                point.set_data(source.time[mask]/time_factor,values['points'][mask])
                if result is not None and values['method']=='fit' and np.any(mask):
                    time=source.time[mask];dense=np.linspace(time[0],time[-1],1500)
                    line.set_data(dense/time_factor,(evaluate(dense,result.parameters,result.reference_s)-values['offset'])/values['scale'])
                self._ready_normalized=self._ready_normalized or bool(np.any(mask))
            except ValueError:continue
        self._apply_visibility()
        self.normalized_axes.relim(visible_only=True);self.normalized_axes.autoscale(enable=True)

    def _pressed(self,event):
        if not event.dblclick:return
        if self.title_artist.contains(event)[0]:self.title_edit_requested.emit();return
        for key,axis in self.axes_by_id.items():
            for suffix,artist in (('title',axis.title),('xlabel',axis.xaxis.label),('ylabel',axis.yaxis.label)):
                if artist.get_text() and artist.contains(event)[0]:
                    self.labels_edit_requested.emit(key+'.'+suffix);return
        legend=self.normalized_axes.get_legend()
        if legend is not None:
            for text,key in zip(legend.get_texts(),getattr(self,'_legend_keys',[])):
                if text.contains(event)[0]:self.labels_edit_requested.emit(key);return

    def _band_selected(self,index,low,high):
        if self._prepared is None:return
        high=min(float(high),[self._prepared.first,self._prepared.second][index].nyquist_hz/1e9)
        low=max(0.,float(low))
        if low<high:self.band_changed.emit(index,(low*1e9,high*1e9))

    def _yformat(self,axis,value):
        if axis._graph_id=='phase2':return f'{value:.6g}'
        scale,_=angle_unit(axis.get_ylim())
        return f'{value/scale:.6g}'

    def _ylabel(self,axis):
        if axis._graph_id=='phase2':
            self._apply_axis_labels(axis,unit='°');return
        if axis._graph_id=='quadrature':
            self._apply_axis_labels(axis,unit=self._xyunit()[1]);return
        _,prefix=angle_unit(axis.get_ylim())
        self._apply_axis_labels(axis,unit=prefix[:-3]+axis._dual_unit)

    def set_title(self,text):
        try:
            normalized=FigureEditor.normalize_mathtext(text)
            for line in normalized.splitlines() or ['']:
                self._math_parser.parse(line,dpi=self.figure.dpi,prop=FontProperties(size=self.title_size))
        except (ValueError,TypeError) as exc:
            self.title_validation_error.emit('Title: '+str(exc));return False
        if self.title_artist.get_text()!=normalized:
            self.title_artist.set_text(normalized);self._geometry_dirty=True;self.canvas.draw_idle()
        self.title_validation_error.emit('');return True

    def set_fonts(self,title_size,body_size):
        self.title_size,self.body_size=float(title_size),float(body_size)
        self._geometry_dirty=True
        self.title_artist.set_fontsize(self.title_size)
        self._layout_footer();self.canvas.draw_idle()

    def set_alphas(self,first,second):
        self.set_signal_alphas({'x1':first,'r2':second})

    def set_normalized_visible(self,visible):
        self._normalized_visible=bool(visible)
        self.normalized_axes.set_visible(self._normalized_visible)
        self.normalized_axes.set_in_layout(self._normalized_visible)
        self._apply_axis_labels(self.normalized_axes)
        self._refresh_legend()
        self._layout_footer();self.canvas.draw_idle()

    def set_summary_text(self,text):
        self._summary=str(text);self._layout_footer();self.canvas.draw_idle()

    def set_data(self,prepared,results,bands,comparison=None,components=(1,1),time_unit='ns',annotation='',normalized=True,pair=(0,0),diagnostics=None,diagnostic_results=None,diagnostic_fit_prepared=None,diagnostic_bands=None,diagnostic_components=None,fit_enabled=None):
        self._prepared=prepared;self._results=tuple(results);self._time_unit=time_unit
        self._fit_enabled=dict(fit_enabled or {})
        self._diagnostics=diagnostics or {}
        self._diagnostic_results=diagnostic_results or {}
        self._diagnostic_fit_prepared=diagnostic_fit_prepared or {}
        self._diagnostic_bands=diagnostic_bands or {}
        self._diagnostic_components=diagnostic_components or {}
        self._series_context={}
        tf=1e-9 if time_unit=='ns' else 1e-12
        self._units=[prepared.first_unit,prepared.second_unit]
        self._columns=[];self._formulas=[]
        for i,(p,result,unit,band,count) in enumerate(zip((prepared.first,prepared.second),results,self._units,bands,components)):
            mask=p.fit_mask if np.count_nonzero(p.fit_mask)>=8 else np.ones(len(p.time),bool)
            self.point_artists[i].set_data(p.time[mask]/tf,p.y[mask])
            self.fit_artists[i].set_data([],[])
            if result is not None and np.any(p.fit_mask):
                dense=np.linspace(p.time[p.fit_mask][0],p.time[p.fit_mask][-1],1500)
                self.fit_artists[i].set_data(dense/tf,evaluate(dense,result.parameters,result.reference_s))
            self.spectrum_artists[i].set_data(p.frequencies/1e9,p.spectrum)
            peaks=spectral_peaks(p,band)
            self.peak_artists[i].set_data([x['frequency_hz']/1e9 for x in peaks],[x['amplitude_rad'] for x in peaks])
            for axis in (self.time_axes[i],self.fft_axes[i]):
                axis._dual_unit=unit;axis.relim();axis.autoscale(enable=True);self._ylabel(axis)
            self.time_axes[i].set_xlabel(f'Задержка ({time_unit})',fontsize=10)
            self.fft_axes[i].set_xlabel('Частота (GHz)',fontsize=10)
            self.selectors[i].extents=(band[0]/1e9,band[1]/1e9)
            self.selectors[i].set_visible(True)
            lo=max(0,band[0]-.25*(band[1]-band[0]));hi=min(max(p.nyquist_hz,band[1]),band[1]+.25*(band[1]-band[0]))
            if lo<hi:self.fft_axes[i].set_xlim(lo/1e9,hi/1e9)
            self._series_context[('x1','r2')[i]]=(p,result,unit,band,count,p)
            n=(len(result.parameters)-1)//4 if result is not None else count
            symbol=r'\theta_1' if i==0 else (r'R_2' if unit=='V' else r'\theta_2')
            self._formulas.append(model_mathtext(n).replace(r'\theta',symbol,1))
        for key,p in self._diagnostics.items():
            fit_p=self._diagnostic_fit_prepared.get(key,p)
            band=self._diagnostic_bands.get(key,(0.,fit_p.nyquist_hz))
            self._series_context[key]=(p,self._diagnostic_results.get(key),'rad' if key=='phase2' else 'V',band,self._diagnostic_components.get(key,1),fit_p)
        self._update_normalized(tf)
        if annotation:self._summary=annotation
        self._draw_diagnostics(tf)
        self.set_normalized_visible(normalized)
        self._apply_visibility()
        self._update_footer()
        self._apply_labels()
        self._geometry_dirty=True;self._layout_footer();self.canvas.draw_idle()

    def clear_data(self):
        """Remove a previous measurement while retaining the editable Title and style."""
        self._prepared=None;self._results=(None,None);self._ready_normalized=False;self._diagnostics={};self._series_context={};self._diagnostic_results={};self._diagnostic_fit_prepared={}
        self._columns=('','');self._formulas=('','');self._summary=''
        for artist in (*self.point_artists,*self.fit_artists,*self.spectrum_artists,
                       *self.peak_artists,*self.normalized_points,*self.normalized_fits):
            artist.set_data([],[])
        for artist in (*self.diagnostic_points.values(),*self.diagnostic_spectra.values(),*self.diagnostic_peaks.values()):artist.set_data([],[])
        for artist in (*self.diagnostic_fit_artists.values(),*self.normalized_diagnostic_points.values(),*self.normalized_diagnostic_fits.values()):artist.set_data([],[])
        self.phase_unreliable_points.set_data([],[]);self._refresh_phase_legend()
        self.quadrature_points.set_data([],[])
        for selector in (*self.selectors,*self.diagnostic_selectors.values()):selector.set_visible(False)
        self.set_normalized_visible(self._normalized_visible)
        self._layout_footer();self.canvas.draw_idle()

    def eventFilter(self,watched,event):
        if hasattr(self,'scroll') and watched is self.scroll.viewport() and event.type()==QEvent.Resize and not self._layout_queued:
            self._layout_queued=True;QTimer.singleShot(0,self._queued_layout)
        return super().eventFilter(watched,event)

    def _queued_layout(self):
        self._layout_queued=False;self._geometry_dirty=True;self._layout_footer();self.canvas.draw_idle()

    def _layout_footer(self):
        if self._layout_running:return
        key=(tuple(self._columns),tuple(self._formulas),self._summary,self.body_size,
             self.canvas.devicePixelRatioF(),self.figure.dpi,self.scroll.viewport().width(),
             self._normalized_visible,self._footer_visible)
        if key==self._footer_layout_key:return
        self._footer_layout_key=key;self._geometry_dirty=True
        self._layout_running=True
        try:
            renderer=self.canvas.get_renderer();ratio=max(1.,self.canvas.devicePixelRatioF())
            width=max(self.canvas.minimumWidth(),self.scroll.viewport().width())-110
            font=FontProperties(size=self.body_size)
            def measure(text,prop=font,math=False):return renderer.get_text_width_height_descent(text,prop,ismath=math)[0]/ratio if text else 0.
            colwidth=max(30,width*.46)
            def wrap(text,limit):
                lines=[]
                for original in text.split('\n'):
                    rest=original
                    if not rest:lines.append('');continue
                    while rest:
                        if measure(rest)<=limit:lines.append(rest);break
                        low,high=1,len(rest)
                        while low<high:
                            middle=(low+high+1)//2
                            if measure(rest[:middle])<=limit:low=middle
                            else:high=middle-1
                        length=low;space=rest.rfind(' ',0,length+1)
                        if space>0:length=space
                        lines.append(rest[:length].rstrip());rest=rest[length:].lstrip()
                return '\n'.join(lines)
            cols=[wrap(text,colwidth) for text in self._columns]
            while len(cols)<2:cols.append('')
            summary=wrap(self._summary,width*.97)
            formula_height=0
            for i in range(2):
                formula=self._formulas[i] if len(self._formulas)>i else ''
                size=self.body_size+2;prop=FontProperties(size=size)
                fw=measure(formula,prop,True)
                if fw>colwidth:size=max(1.,size*colwidth/fw)
                prop=FontProperties(size=size)
                fh=renderer.get_text_width_height_descent(formula,prop,ismath=True)[1]/ratio if formula else 0
                formula_height=max(formula_height,fh*1.3)
                self.formula_artists[i].set_text(formula);self.formula_artists[i].set_fontsize(size)
            lineheight=self.body_size*self.figure.dpi/(72*ratio)*1.45
            column_lines=max([len(c.splitlines()) for c in cols]+[1])
            summary_lines=len(summary.splitlines()) if summary else 0
            footer_height=35+formula_height+(column_lines+summary_lines+2)*lineheight
            rowheight=250 if self._normalized_visible else 1
            self.grid.set_height_ratios([250]*5+[rowheight,footer_height if self._footer_visible else .001])
            self.canvas.setMinimumHeight(int(1700+(250 if self._normalized_visible else 0)+(footer_height if self._footer_visible else 0)+210))
            for artist,text in zip(self.column_artists,cols):
                artist.set_text(text);artist.set_fontsize(self.body_size)
                artist.set_y(1-(formula_height+12)/footer_height)
            self.summary_artist.set_text(summary);self.summary_artist.set_fontsize(self.body_size)
            self.summary_artist.set_y(1-(formula_height+18+(column_lines+1)*lineheight)/footer_height)
        finally:self._layout_running=False

    def render(self):
        self._layout_footer();self.canvas.draw()

    def capture_images(self,formats=('png',)):
        self.render();result={}
        if 'png' in formats:
            buffer=BytesIO();Image.fromarray(np.asarray(self.canvas.buffer_rgba()).copy()).save(buffer,format='PNG');result['png']=buffer.getvalue()
        engine=self.figure.get_layout_engine();self.figure.set_layout_engine(None)
        try:
            for fmt in formats:
                if fmt=='png':continue
                if fmt not in ('pdf','svg'):raise ValueError('Доступны PNG/PDF/SVG')
                buffer=BytesIO();self.figure.savefig(buffer,format=fmt,dpi=self.figure.dpi,facecolor='white');result[fmt]=buffer.getvalue()
        finally:self.figure.set_layout_engine(engine)
        return result
