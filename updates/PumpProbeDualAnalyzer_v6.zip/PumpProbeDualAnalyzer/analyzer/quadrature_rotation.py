"""Offline rotation of the second demodulator's quadratures.

One orthogonal angle maximizes centered X2 variance and minimizes centered Y2
variance. It cannot remove a genuine second independent quadrature component.
Source files, X1 and the precomputed magnitude R2 are never modified.
"""
from dataclasses import replace
import numpy as np
from .dual_signals import prepare_diagnostics


FORMULA = "X2_rot = X2*cos(theta) + Y2*sin(theta); Y2_rot = -X2*sin(theta) + Y2*cos(theta)"
METHOD = 'Principal axis of centered, background-processed X2/Y2 on the shared analysis window'


def _angle(angle_deg):
    value=float(angle_deg)
    if not np.isfinite(value):
        raise ValueError('Угол поворота квадратур должен быть конечным числом в градусах.')
    return float((value+180.)%360.-180.)


def rotate_quadratures(x, y, angle_deg):
    """Return new arrays after z_rot=z*exp(-i theta); never alter inputs."""
    x,y=np.asarray(x,dtype=float),np.asarray(y,dtype=float)
    if x.shape!=y.shape or not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError('X2 и Y2 должны иметь одинаковую форму и конечные значения.')
    angle=_angle(angle_deg)
    if angle==0.:
        return x.copy(),y.copy()
    theta=np.deg2rad(angle);c,s=np.cos(theta),np.sin(theta)
    with np.errstate(over='ignore',invalid='ignore'):
        xr,yr=x*c+y*s,-x*s+y*c
    if not np.isfinite(xr).all() or not np.isfinite(yr).all():
        raise ValueError('Переполнение при повороте квадратур.')
    return xr,yr


def prepare_rotated_diagnostics(dual, angle_deg=0., phase_sigma=3., noise_sigma_v=None):
    """Rotate only source quadratures; preserve original magnitude and phase gaps.

    The unwrapped phase keeps its original branch and is shifted by -theta.
    This avoids inventing phase at duplicate-position complex cancellations
    whose floating-point residual could otherwise become slightly nonzero.
    A constant phase shift leaves the mean-removed phase FFT amplitude intact.
    """
    angle=_angle(angle_deg)
    original=prepare_diagnostics(dual,phase_sigma,noise_sigma_v)
    if angle==0.:
        return original
    xr,yr=rotate_quadratures(dual.measurement.x2,dual.measurement.y2,angle)
    rotated_measurement=replace(dual.measurement,x2=xr,y2=yr)
    rotated=prepare_diagnostics(replace(dual,measurement=rotated_measurement),phase_sigma,noise_sigma_v)
    original_phase=original['phase2']
    shifted=np.mod(original_phase.raw_rad-np.deg2rad(angle),2*np.pi)
    rotated['phase2']=replace(original_phase,raw_rad=shifted.copy(),
        y=np.where(np.isfinite(original_phase.y),shifted,np.nan),
        phase_info=dict(original_phase.phase_info,rotation_deg=angle))
    return rotated


def _centered_statistics(dual, band=None):
    diagnostics=prepare_diagnostics(dual)
    x,y=diagnostics['x2'].y,diagnostics['y2'].y
    mask=np.asarray(dual.first.fit_mask,dtype=bool)&np.isfinite(x)&np.isfinite(y)
    indices=np.flatnonzero(mask)
    if len(indices)<3:
        return dict(status='insufficient_points',point_count=len(indices),covariance=None,
            amplitude_scale=0.,window_s=None if not len(indices) else [float(dual.first.time[indices[0]]),float(dual.first.time[indices[-1]])])
    xv,yv=x[mask],y[mask]
    # Subtract a local origin before taking the mean: large DC offsets must
    # not dominate the fit or cause an overflowing sum of otherwise finite V.
    with np.errstate(over='ignore',invalid='ignore'):
        xc=xv-xv[0];yc=yv-yv[0]
        xc=xc-np.mean(xc);yc=yc-np.mean(yc)
    if not np.isfinite(xc).all() or not np.isfinite(yc).all():
        raise ValueError('Переполнение при оценке переменной части квадратур.')
    scale=float(max(np.max(abs(xc)),np.max(abs(yc))))
    raw_scale=float(max(np.max(abs(diagnostics['x2'].raw_rad[mask])),
                        np.max(abs(diagnostics['y2'].raw_rad[mask]))))
    floor=64*np.finfo(float).eps*raw_scale
    window=[float(dual.first.time[indices[0]]),float(dual.first.time[indices[-1]])]
    if scale<=max(floor,np.finfo(float).tiny):
        return dict(status='no_ac',point_count=len(indices),covariance=None,
                    amplitude_scale=0.,window_s=window)
    centered=np.column_stack((xc/scale,yc/scale))
    if band is None:
        covariance=centered.T@centered/len(centered)
    else:
        lo,hi=map(float,band)
        if not 0<=lo<hi<=dual.first.nyquist_hz:raise ValueError('Полоса автофазы должна быть в пределах частоты Найквиста.')
        times=dual.first.time[mask];grid=np.linspace(times[0],times[-1],len(times))
        from scipy.signal import detrend
        values=np.column_stack([np.interp(grid,times,centered[:,i]) for i in range(2)])
        values=detrend(values,axis=0,type='linear')
        weights=np.hanning(len(values))
        transform=np.fft.rfft(values*weights[:,None],axis=0)
        frequencies=np.fft.rfftfreq(len(values),grid[1]-grid[0])
        selected=(frequencies>=lo)&(frequencies<=hi)&(frequencies>0)
        if not np.any(selected):raise ValueError('В полосе автофазы нет разрешённых частот. Расширьте полосу.')
        f=transform[selected]
        covariance=np.real(f.conj().T@f)*2/(len(values)*np.sum(weights**2))
        if np.trace(covariance)<=np.finfo(float).tiny:raise ValueError('В выбранной полосе нет переменной составляющей для автофазы.')
    return dict(status='ok',point_count=len(indices),covariance=covariance,
                amplitude_scale=scale,window_s=window)


def _metadata(stats, angle_deg):
    angle=_angle(angle_deg)
    answer=dict(angle_deg=angle,ac_power_x=0.,ac_power_y=0.,retained_fraction=None,
        residual_fraction=None,point_count=stats['point_count'],status=stats['status'],
        method=METHOD,formula=FORMULA,window_s=stats['window_s'],
        source='Original unrotated measurement, not the previous displayed rotation',
        background_degree=None,phase_definition='Circular argument of the same background-processed quadratures, minus theta modulo 360 degrees; original below-threshold mask preserved.',
        ambiguity='Automatic angle is absolute and chosen in [-90,90) degrees; a 180-degree reversal is physically equivalent for variance maximization.',
        messages=[])
    if stats['status']!='ok':
        answer['messages']=[('Для автоматического поворота нужно минимум три точки в окне анализа.'
            if stats['status']=='insufficient_points' else
            'Переменная часть квадратур отсутствует в пределах машинной точности; автоматический угол не определён.')]
        return answer
    c,s=np.cos(np.deg2rad(angle)),np.sin(np.deg2rad(angle))
    cov=stats['covariance'];total=float(np.trace(cov))
    vx=max(0.,float(c*c*cov[0,0]+s*s*cov[1,1]+2*c*s*cov[0,1]))
    vy=max(0.,float(s*s*cov[0,0]+c*c*cov[1,1]-2*c*s*cov[0,1]))
    # Ratios use the scaled covariance even for subnormal native V² powers.
    answer['retained_fraction']=float(np.clip(vx/total,0.,1.))
    answer['residual_fraction']=float(np.clip(vy/total,0.,1.))
    scale=np.longdouble(stats['amplitude_scale'])
    px,py=np.longdouble(vx)*scale*scale,np.longdouble(vy)*scale*scale
    answer['ac_power_x']=float(px) if px<=np.finfo(float).max else None
    answer['ac_power_y']=float(py) if py<=np.finfo(float).max else None
    if answer['residual_fraction']>1e-6:
        answer['messages'].append('В Y2 остаётся независимая переменная компонента: одним постоянным углом убрать её полностью нельзя.')
    return answer


def rotation_metadata(dual, angle_deg, band=None):
    """AC powers/fractions for a manual angle; absent AC does not block analysis."""
    answer=_metadata(_centered_statistics(dual,band),angle_deg)
    answer['background_degree']=dual.first.settings.background_degree
    answer['band_hz']=None if band is None else list(map(float,band))
    if band is not None:answer['method']='AC principal axis in selected FFT band after linear detrending; Hann weighted cross-spectrum'
    return answer


def auto_rotation(dual, band=None):
    """Absolute PCA angle: maximize X2 AC power, minimize Y2 AC power."""
    stats=_centered_statistics(dual,band)
    if stats['status']!='ok':
        raise ValueError(_metadata(stats,0.)['messages'][0])
    cov=stats['covariance'];trace=float(np.trace(cov))
    contrast=float(np.hypot(cov[0,0]-cov[1,1],2*cov[0,1])/trace)
    if contrast<=1e-6:
        raise ValueError('Квадратуры почти изотропны: выделенного направления колебаний нет, автоматический угол не определён. Задайте угол вручную.')
    angle=.5*np.rad2deg(np.arctan2(2*cov[0,1],cov[0,0]-cov[1,1]))
    angle=float((angle+90.)%180.-90.)
    answer=_metadata(stats,angle)
    answer['background_degree']=dual.first.settings.background_degree
    answer['anisotropy']=contrast
    answer['automatic']=True
    answer['band_hz']=None if band is None else list(map(float,band))
    if band is not None:answer['method']='AC principal axis in selected FFT band after linear detrending; Hann weighted cross-spectrum'
    return answer
