"""Fit-safe phase intervals and unitless display normalization for any signal."""
from dataclasses import replace
import numpy as np
from scipy import fft
from .dual_core import normalize_signals


def diagnostic_fit_input(prepared, key):
    """Fit phase within one finite segment; never connect independent 2π offsets.

    X2 and Y2 already have suitable prepared data. For phase, the longest
    contiguous finite run inside the analysis window is selected (earliest on
    ties). The full measured arrays remain available for displaying/exporting.
    """
    if key in ('x2', 'y2'):
        return prepared
    if key != 'phase2':
        raise ValueError('Диагностический сигнал: x2, y2 или phase2')
    valid=np.asarray(prepared.fit_mask,dtype=bool)&np.isfinite(prepared.time)&np.isfinite(prepared.y)
    indices=np.flatnonzero(valid)
    runs=np.split(indices,np.flatnonzero(np.diff(indices)>1)+1) if len(indices) else []
    if prepared.phase_info.get('wrapped'):
        branches=[]
        for run in runs:
            jumps=np.abs(np.angle(np.exp(1j*np.diff(prepared.y[run]))))
            for branch in np.split(run,np.flatnonzero(jumps>np.pi/2)+1):
                if len(branch):branches.append(branch)
        runs=branches
    chosen=max(runs,key=len) if runs else np.array([],dtype=int)
    mask=np.zeros(len(prepared.time),dtype=bool);mask[chosen]=True
    cfg=replace(prepared.settings,background_degree=-1,fit_window_mode='manual')
    messages=list(prepared.warnings)
    if len(chosen):
        cfg=replace(cfg,fit_min_s=float(prepared.time[chosen[0]]),fit_max_s=float(prepared.time[chosen[-1]]))
    if len(chosen)!=np.count_nonzero(prepared.fit_mask):
        if len(chosen):
            messages.append('Для фита фазы выбран самый длинный непрерывный участок: '
                f'{prepared.time[chosen[0]]/1e-9:.6g}…{prepared.time[chosen[-1]]/1e-9:.6g} ns, '
                f'{len(chosen)} точек. Разрывы фазы не интерполируются.')
        else:messages.append('В выбранном окне нет определённых точек фазы для фита.')
    values_y=prepared.y
    branch_rejected=False
    if prepared.phase_info.get('wrapped') and len(chosen):
        branch=np.unwrap(prepared.y[chosen])
        branch_rejected=np.ptp(branch)>np.pi
        values_y=np.full_like(prepared.y,np.nan);values_y[chosen]=branch
        if branch_rejected:messages.append('Фаза меняется более чем на 180°: обычные FFT/затухающий синус не применяются. Сузьте окно анализа.')
    minimum=prepared.phase_info.get('minimum_branch_points',8)
    info=dict(prepared.phase_info)
    if info:info['fit_allowed']=len(chosen)>=minimum and not branch_rejected
    output=replace(prepared,y=values_y,fit_mask=mask,frequencies=np.array([]),spectrum=np.array([]),
                   resolution_hz=float('nan'),settings=cfg,warnings=messages,phase_info=info)
    if len(chosen)<minimum or branch_rejected:
        return replace(output,warnings=messages+[
            f'На непрерывном участке фазы {len(chosen)} точек; нужно минимум {minimum}.'])
    time=prepared.time[chosen];values=values_y[chosen]
    if np.any(np.diff(time)<=0):
        raise ValueError('Время на участке фита фазы должно строго возрастать.')
    floor=64*np.finfo(float).eps*float(np.max(np.abs(values)))
    if np.ptp(values)<=floor:
        return replace(output,warnings=messages+[
            'Фаза на выбранном непрерывном участке постоянна в пределах машинной точности; осцилляционный фит не определён.'])
    # The same finite-window FFT convention as core.prepare, applied only to
    # this contiguous phase interval. No dummy samples or calibration enter it.
    dt=float(np.median(np.diff(time)))
    if (time[-1]-time[0])/dt>1000000:
        raise ValueError('Слишком неоднородная сетка времени для FFT фита фазы.')
    grid=np.linspace(time[0],time[-1],max(8,int(round((time[-1]-time[0])/dt))+1))
    dt=float(grid[1]-grid[0])
    if len(grid)!=len(time) or not np.allclose(np.diff(time),dt,rtol=1e-3,atol=abs(dt)*1e-6):
        messages=messages+['FFT старта фита фазы использует интерполяцию внутри непрерывного участка; фит — исходные точки.']
    samples=np.interp(grid,time,values);samples-=np.mean(samples)
    if cfg.window not in ('hann','boxcar'):
        raise ValueError('Неизвестное окно FFT фазы.')
    weights=np.hanning(len(grid)) if cfg.window=='hann' else np.ones(len(grid))
    nfft=fft.next_fast_len(len(grid)*cfg.padding)
    if nfft>4194304:
        raise ValueError('FFT фита фазы слишком велико: уменьшите zero-padding.')
    spectrum=np.abs(fft.rfft(samples*weights,n=nfft))*2/weights.sum()
    spectrum[0]/=2
    if nfft%2==0:spectrum[-1]/=2
    return replace(output,frequencies=fft.rfftfreq(nfft,dt),spectrum=spectrum,
        resolution_hz=float(1/(len(grid)*dt)),nyquist_hz=float(.5/dt),warnings=messages)


def overlay_values(prepared, result=None):
    """Normalize display points and optional fit without changing source values.

    A usable fit supplies C and max|fit-C| as before. Without it, subtract the
    finite analysis-window mean and scale by max absolute centered data. A
    constant interval is displayed as zero with scale=1, avoiding division by
    zero. All invalid source points remain NaN and fits never extrapolate.
    """
    time=np.asarray(prepared.time,dtype=float)
    values=np.asarray(prepared.y,dtype=float)
    mask=np.asarray(prepared.fit_mask,dtype=bool)&np.isfinite(time)&np.isfinite(values)
    if mask.shape!=time.shape or values.shape!=time.shape:
        raise ValueError('Некорректные массивы для нормировки общего графика.')
    if result is not None and np.any(mask):
        safe=replace(prepared,fit_mask=mask)
        try:
            points,fitted,scale=normalize_signals(safe,result)
            if not np.isfinite(points[mask]).all() or not np.isfinite(fitted[mask]).all():
                raise ValueError('Нечисловой результат нормировки фита.')
            points=np.where(np.isfinite(time)&np.isfinite(values),points,np.nan)
            return dict(points=points,fitted=fitted,scale=float(scale),offset=float(result.parameters[-1]),
                        mask=mask,method='fit')
        except ValueError:
            pass
    # Empty analysis windows still allow a raw data comparison; its actual
    # normalization/visible mask is returned explicitly for reproducibility.
    if not np.any(mask):mask=np.isfinite(time)&np.isfinite(values)
    fitted=np.full_like(values,np.nan)
    points=np.full_like(values,np.nan)
    if not np.any(mask):
        return dict(points=points,fitted=fitted,scale=1.,offset=0.,mask=mask,method='empty')
    offset=float(np.mean(values[mask]));centered=values-offset
    scale=float(np.max(np.abs(centered[mask])))
    floor=64*np.finfo(float).eps*float(np.max(np.abs(values[mask])))
    if not np.isfinite(scale):
        raise ValueError('Переполнение при нормировке общего графика.')
    finite=np.isfinite(time)&np.isfinite(values)
    if scale<=max(floor,np.finfo(float).tiny):
        # Scale=1 keeps the returned offset/scale definition true even if data
        # outside the visible constant interval take other values.
        points[finite]=centered[finite]
        return dict(points=points,fitted=fitted,scale=1.,offset=offset,mask=mask,method='constant')
    points[finite]=centered[finite]/scale
    return dict(points=points,fitted=fitted,scale=scale,offset=offset,mask=mask,method='data')
