"""Reproducible rotation and exact fit-frequency constraints in exported data."""
from pathlib import Path
import json
import tempfile
import unittest
import numpy as np
from analyzer import core
from analyzer.dual_core import load_dual_pair,prepare_dual,compare_fits
from analyzer.dual_fit_support import diagnostic_fit_input
from analyzer.dual_fit_support import overlay_values
from analyzer.quadrature_rotation import prepare_rotated_diagnostics,rotation_metadata,rotate_quadratures
from analyzer.dual_export import build_dual_report,dual_report_text,export_dual
from analyzer.dual_figure import _parameter_text


class DualV4ExportTests(unittest.TestCase):
    def test_pinned_frequency_does_not_invent_phase_or_normalized_oscillation_on_constant_data(self):
        from dataclasses import replace
        base=Path(__file__).resolve().parents[1]/'examples'
        m=load_dual_pair(base/'dual_demo.dat',base/'dual_demo.comments.txt')
        p=prepare_dual(m,core.Settings(bal_mv=-100,sig_mv=100))
        constant=replace(p.second,y=np.full_like(p.second.y,1e-6))
        tiny=core.FitResult(np.array([1e-24,1.28e9,.5,2e-9,1e-6]),np.full(5,np.nan),
            np.zeros((5,5)),0.,0.,float('nan'),[],1,float('inf'),{0:1.28e9})
        norm=overlay_values(constant,tiny)
        self.assertEqual(norm['method'],'constant')
        self.assertTrue(np.isnan(norm['fitted']).all())
        np.testing.assert_allclose(norm['points'],0.,rtol=0,atol=1e-20)
        comparison=compare_fits(tiny,tiny,1.,1.)
        self.assertIsNone(comparison['delta_phase_rad']);self.assertIsNone(comparison['amplitude_ratio'])

    def test_rotation_constraints_and_original_source_survive_export(self):
        base=Path(__file__).resolve().parents[1]/'examples'
        m=load_dual_pair(base/'dual_demo.dat',base/'dual_demo.comments.txt')
        p=prepare_dual(m,core.Settings(bal_mv=-100,sig_mv=100))
        original_x=m.x2.copy();original_r=p.second.raw_rad.copy()
        diagnostics=prepare_rotated_diagnostics(p,25.)
        inputs={k:diagnostic_fit_input(q,k) for k,q in diagnostics.items()}
        frequency=1.280123457e9
        first_band=core.automatic_band(p.first);second_band=core.automatic_band(p.second)
        initial=core.initial_parameters(p.first,1,first_band);initial[1]=frequency
        first=core.fit(p.first,initial,first_band,fixed_frequencies={0:frequency})
        q=inputs['x2'];seed=core.initial_parameters(q,1,core.automatic_band(q));seed[1]=frequency
        x2_band=(.1e9,.5e9)  # Fixed frequency intentionally outside the FFT seed band.
        x2=core.fit(q,seed,x2_band,fixed_frequencies={0:frequency})
        s=dict(measurement=m,prepared=p,results=(first,None),initials=(initial,None),
            bands=(first_band,second_band),components=(1,1),pair=(0,0),comparison=None,
            diagnostics=diagnostics,diagnostic_fit_prepared=inputs,diagnostic_results={'x2':x2},
            diagnostic_initials={'x2':seed},diagnostic_bands={'x2':x2_band},diagnostic_components={'x2':1},
            rotation_deg=25.,rotation_info=rotation_metadata(p,25.),overlay_signals=('x1','x2'),
            fft_peak_enabled={k:False for k in ('x1','x2','y2','r2','phase2')})
        report=build_dual_report(s);text=dual_report_text(report)
        self.assertEqual(report['quadrature_rotation']['angle_deg'],25.)
        self.assertEqual(report['fixed_frequencies']['x1'],{0:frequency})
        self.assertEqual(report['fixed_frequencies']['x2'],{0:frequency})
        self.assertTrue(report['channels'][0]['fit']['parameters'][1]['fixed'])
        second=next(item for item in report['diagnostics'] if item['name']=='x2')
        self.assertTrue(second['fit']['parameters'][1]['fixed'])
        self.assertIn('[fixed]',text);self.assertIn('QUADRATURE ROTATION',text)
        footer=_parameter_text(q,x2,'V','X2','ns',x2_band,False)
        self.assertIn('(фикс.)',footer)
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(export_dual(Path(tmp)/'rotated',s,{}))
            original=np.loadtxt(folder/'input_channels.tsv',skiprows=1)
            rotated=np.loadtxt(folder/'rotated_channels.tsv',skiprows=1)
            xr,yr=rotate_quadratures(m.x2,m.y2,25.)
            np.testing.assert_allclose(original[:,2],m.x2)
            np.testing.assert_allclose(rotated[:,1],xr)
            np.testing.assert_allclose(rotated[:,2],yr)
            np.testing.assert_allclose(rotated[:,3],np.hypot(m.x2,m.y2))
            loaded=json.loads((folder/'analysis.json').read_text())
            self.assertEqual(loaded['fixed_frequencies']['x2'],{'0':frequency})
            self.assertTrue(loaded['channels'][0]['fit']['parameters'][1]['fixed'])
        np.testing.assert_array_equal(m.x2,original_x)
        np.testing.assert_array_equal(p.second.raw_rad,original_r)


if __name__=='__main__':unittest.main()
