"""Fixed frequencies are exact constraints, not narrow numerical bounds."""
from dataclasses import replace
from threading import Event
import unittest
import numpy as np
from analyzer import core
from analyzer.io import Measurement


class FixedFrequencyTests(unittest.TestCase):
    def prepared(self,parameters,n=601,duration=3e-9,noise=1e-9):
        t=np.linspace(0,duration,n)
        y=core.evaluate(t,np.asarray(parameters),0)
        y+=np.random.default_rng(7230).normal(0,noise,n)
        cfg=core.Settings(bal_mv=-100,sig_mv=100,zero_mode='manual',zero_mm=0,
            fit_window_mode='manual',fit_min_s=0,fit_max_s=duration)
        m=Measurement(t*cfg.c/2*1e3,y/cfg.rad_per_unit,'synthetic.dat','synthetic.txt','','V',[])
        return core.prepare(m,cfg)

    def test_single_fixed_outside_fft_band_recovers_remaining_parameters(self):
        truth=np.array([2.3e-6,1.37e9,.63,1.8e-9,4e-7])
        p=self.prepared(truth)
        seed=np.array([1e-6,.7e9,-1.,3e-9,0.])
        result=core.fit(p,seed,(.4e9,.9e9),fixed_frequencies={0:truth[1]})
        self.assertEqual(result.parameters[1],truth[1])
        self.assertAlmostEqual(result.parameters[0]/truth[0],1,delta=.002)
        self.assertAlmostEqual(result.parameters[3]/truth[3],1,delta=.003)
        self.assertAlmostEqual(result.parameters[2],truth[2],delta=.002)
        self.assertGreater(result.r_squared,.99999)
        self.assertEqual(result.fixed_frequencies,{0:truth[1]})
        self.assertEqual(result.errors[1],0.)
        np.testing.assert_array_equal(result.covariance[1],np.zeros(5))
        np.testing.assert_array_equal(result.covariance[:,1],np.zeros(5))
        self.assertTrue(np.isfinite(result.errors[[0,2,3,4]]).all())

    def test_two_modes_mixed_fixed_and_free_preserve_component_identity(self):
        truth=np.array([2.4e-6,1.23e9,.45,2.2e-9,1.5e-6,2.17e9,-.7,1.3e-9,3e-7])
        p=self.prepared(truth,n=801,duration=4e-9)
        p0=np.array([2e-6,1.1e9,.1,3e-9,1.2e-6,2e9,1.,2e-9,0.])
        r=core.fit(p,p0,(1.7e9,2.6e9),fixed_frequencies={0:truth[1]})
        self.assertEqual(r.parameters[1],truth[1])
        self.assertAlmostEqual(r.parameters[5]/truth[5],1,delta=.001)
        self.assertAlmostEqual(r.parameters[0]/truth[0],1,delta=.003)
        self.assertAlmostEqual(r.parameters[4]/truth[4],1,delta=.003)
        self.assertGreater(r.r_squared,.99999)
        self.assertEqual(r.fixed_frequencies,{0:truth[1]})
        self.assertGreater(r.errors[5],0)

    def test_all_fixed_modes_and_empty_fft_still_optimize_lifetimes_phase_amplitude(self):
        truth=np.array([2e-6,1.15e9,.2,1.7e-9,1.4e-6,2.31e9,-.6,2.8e-9,3e-7])
        p=self.prepared(truth,n=801,duration=4e-9)
        p=replace(p,frequencies=np.array([]),spectrum=np.array([]),resolution_hz=float('nan'))
        p0=np.array([1e-6,.9e9,-2.,3e-9,1e-6,3e9,2.,1e-9,0.])
        r=core.fit(p,p0,(.2e9,.8e9),fixed_frequencies={0:truth[1],1:truth[5]})
        np.testing.assert_array_equal(r.parameters[[1,5]],truth[[1,5]])
        self.assertGreater(r.r_squared,.99999)
        for i in (0,4):self.assertAlmostEqual(r.parameters[i]/truth[i],1,delta=.003)
        for i in (3,7):self.assertAlmostEqual(r.parameters[i]/truth[i],1,delta=.005)

    def test_fixed_frequency_inside_band_does_not_duplicate_free_seed(self):
        truth=[4e-6,1.2e9,.4,2e-9,1e-6,1.8e9,-.7,3e-9,1e-7]
        p=self.prepared(truth,n=801,duration=4e-9)
        p0=[1e-6,1.2e9,0.,2e-9,1e-6,1.3e9,0.,2e-9,0.]
        r=core.fit(p,p0,(.5e9,2.5e9),fixed_frequencies={0:1.2e9})
        self.assertEqual(r.parameters[1],1.2e9)
        self.assertAlmostEqual(r.parameters[5]/1.8e9,1,delta=.002)
        self.assertGreater(r.r_squared,.99999)

    def test_six_fixed_components_keep_all_frequency_labels(self):
        truth=np.array([v for i in range(6) for v in
            (.3e-6*(i+1),(.7+.65*i)*1e9,.2*i,(1.5+.2*i)*1e-9)]+[.2e-6])
        p=self.prepared(truth,n=1201,duration=5e-9,noise=1e-10)
        initial=truth.copy();initial[0:-1:4]*=.5;initial[2:-1:4]=0.;initial[3:-1:4]=3e-9
        fixed={i:truth[4*i+1] for i in range(6)}
        r=core.fit(p,initial,(.1e9,.3e9),fixed_frequencies=fixed)
        np.testing.assert_array_equal(r.parameters[1:-1:4],truth[1:-1:4])
        self.assertGreater(r.r_squared,.99999)
        self.assertEqual(r.fixed_frequencies,fixed)
        np.testing.assert_array_equal(r.errors[1:-1:4],np.zeros(6))

    def test_missing_fft_and_free_band_below_spectral_resolution_keeps_seeds_in_bounds(self):
        time=np.linspace(0,3e-9,101)
        truth=np.array([1e-6,100.,.1,3e-9,2e-6,.5e6,.3,2e-9,1e-7])
        values=core.evaluate(time,truth,0)
        cfg=core.Settings(bal_mv=-100,sig_mv=100)
        p=core.Prepared(time,values,values,np.ones(len(time),bool),np.array([]),np.array([]),
            1/3e-9,.5/(time[1]-time[0]),[],cfg,np.zeros(len(time)))
        seed=truth.copy();seed[5]=.5e6
        r=core.fit(p,seed,(0.,1e6),fixed_frequencies={0:100.})
        self.assertEqual(r.parameters[1],100.)
        self.assertGreaterEqual(r.parameters[5],0.)
        self.assertLessEqual(r.parameters[5],1e6)
        self.assertTrue(np.isfinite(r.parameters).all())

    def test_empty_fixed_mapping_is_identical_to_original_free_fit(self):
        p=self.prepared([2e-6,1.4e9,.4,2e-9,1e-7])
        band=core.automatic_band(p);p0=core.initial_parameters(p,1,band)
        free=core.fit(p,p0,band);empty=core.fit(p,p0,band,fixed_frequencies={})
        np.testing.assert_array_equal(free.parameters,empty.parameters)
        np.testing.assert_array_equal(free.errors,empty.errors)
        self.assertEqual(free.fixed_frequencies,{})

    def test_fixed_validation_and_cooperative_cancel(self):
        p=self.prepared([2e-6,1.4e9,.4,2e-9,1e-7]);p0=[2e-6,1.4e9,.4,2e-9,1e-7]
        for fixed in ({-1:1e9},{1:1e9},{.5:1e9},{True:1e9},{0:0},{0:-1},{0:float('nan')},
                      {0:float('inf')},{0:p.nyquist_hz*2},{0:'invalid'},[1e9]):
            with self.subTest(fixed=fixed),self.assertRaises(ValueError):
                core.fit(p,p0,(1e9,2e9),fixed_frequencies=fixed)
        cancel=Event();cancel.set()
        with self.assertRaises(core.Cancelled):core.fit(p,p0,(1e9,2e9),cancel,{0:1.4e9})

    def test_constant_signal_does_not_invent_r_squared_or_parameter_precision(self):
        p=self.prepared([0.,1.5e9,0.,2e-9,1e-6],noise=0)
        p=replace(p,frequencies=np.array([]),spectrum=np.array([]))
        r=core.fit(p,[1e-7,1.5e9,0.,2e-9,0.],(.1e9,1e9),fixed_frequencies={0:1.5e9})
        self.assertTrue(np.isnan(r.r_squared))
        self.assertEqual(r.parameters[1],1.5e9)
        self.assertEqual(r.errors[1],0.)
        self.assertTrue(np.isnan(r.errors[[0,2,3,4]]).all())
        self.assertLess(r.parameters[0],1e-18)


if __name__=='__main__':unittest.main()
