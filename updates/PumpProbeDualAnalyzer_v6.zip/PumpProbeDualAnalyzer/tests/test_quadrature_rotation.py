from dataclasses import replace
import unittest
import numpy as np
from analyzer import core
from analyzer.dual_core import DualMeasurement,prepare_dual
from analyzer.dual_signals import prepare_diagnostics
from analyzer.quadrature_rotation import (rotate_quadratures,prepare_rotated_diagnostics,
    auto_rotation,rotation_metadata)


class QuadratureRotationTests(unittest.TestCase):
    def dual(self,x,y,background=-1):
        n=len(x);position=np.arange(n,dtype=float)*.5
        cfg=core.Settings(bal_mv=-100,sig_mv=100,zero_mode='manual',zero_mm=0,
            fit_window_mode='manual',fit_min_s=0,fit_max_s=(position[-1]*2e-3/3e8 if n>1 else 1e-9),
            bg_min_s=0,bg_max_s=position[-1]*2e-3/3e8 if n>1 else 1e-9,
            background_degree=background)
        m=DualMeasurement(position,np.sin(np.arange(n))*.1,np.asarray(x),np.asarray(y),
            'synthetic.dat','synthetic.comments.txt','','V',[])
        return prepare_dual(m,cfg)

    def test_rotation_preserves_energy_source_and_zero_angle_exactly(self):
        rng=np.random.default_rng(9);x=rng.normal(size=100)*1e-6;y=rng.normal(size=100)*1e-6
        ox,oy=x.copy(),y.copy()
        for angle in (0,17,-83,90,180,360,1e9):
            xr,yr=rotate_quadratures(x,y,angle)
            np.testing.assert_allclose(np.hypot(xr,yr),np.hypot(x,y),rtol=3e-16,atol=1e-21)
        xr,yr=rotate_quadratures(x,y,0)
        np.testing.assert_array_equal(xr,x);np.testing.assert_array_equal(yr,y)
        self.assertIsNot(xr,x)
        np.testing.assert_array_equal(x,ox);np.testing.assert_array_equal(y,oy)
        for angle in (np.nan,np.inf):
            with self.assertRaises(ValueError):rotate_quadratures(x,y,angle)

    def test_auto_removes_ac_from_y_with_dc_offsets_and_is_idempotent(self):
        t=np.arange(1000);s=np.sin(2*np.pi*t/40)*1e-6;angle=37.
        p=self.dual(100e-6+s*np.cos(np.deg2rad(angle)),-30e-6+s*np.sin(np.deg2rad(angle)))
        original=prepare_diagnostics(p);r2_before=p.second.raw_rad.copy();result=auto_rotation(p)
        self.assertAlmostEqual(result['angle_deg'],angle,places=10)
        self.assertLess(result['residual_fraction'],1e-14)
        rotated=prepare_rotated_diagnostics(p,result['angle_deg'])
        self.assertLess(np.std(rotated['y2'].y),np.std(rotated['x2'].y)*1e-12)
        np.testing.assert_array_equal(p.measurement.x2,100e-6+s*np.cos(np.deg2rad(angle)))
        self.assertAlmostEqual(auto_rotation(p)['angle_deg'],result['angle_deg'])
        np.testing.assert_array_equal(p.second.raw_rad,r2_before)
        np.testing.assert_allclose(rotated['phase2'].raw_rad,
            original['phase2'].raw_rad-np.deg2rad(angle),atol=1e-14)
        np.testing.assert_array_equal(rotated['phase2'].spectrum,original['phase2'].spectrum)

    def test_true_ellipse_has_nonzero_residual_and_near_isotropy_rejected(self):
        a=np.arange(1200)*2*np.pi/60
        p=self.dual(2e-6*np.cos(a),1e-6*np.sin(a))
        result=auto_rotation(p)
        self.assertAlmostEqual(result['angle_deg'],0,places=12)
        self.assertAlmostEqual(result['residual_fraction'],.2,places=12)
        self.assertTrue(result['messages'])
        p=self.dual(np.cos(a),np.sin(a))
        with self.assertRaisesRegex(ValueError,'изотроп'):auto_rotation(p)
        self.assertEqual(rotation_metadata(p,12)['status'],'ok')

    def test_configured_background_is_removed_before_auto_angle(self):
        t=np.linspace(0,1,1200);osc=1e-6*np.sin(2*np.pi*20*t)
        x=5e-3*t+osc*np.cos(.6);y=-3e-3*t+osc*np.sin(.6)
        removed=auto_rotation(self.dual(x,y,background=1))
        self.assertAlmostEqual(removed['angle_deg'],np.rad2deg(.6),places=8)
        raw=auto_rotation(self.dual(x,y))
        self.assertGreater(abs(raw['angle_deg']-removed['angle_deg']),50)
        self.assertEqual(removed['background_degree'],1)

    def test_constant_and_short_manual_states_do_not_invent_an_auto_angle(self):
        for x,y,status in ((np.ones(20),np.ones(20)*3,'no_ac'),
                           (np.arange(2.),np.arange(2.),'insufficient_points')):
            p=self.dual(x,y);metadata=rotation_metadata(p,12.)
            self.assertEqual(metadata['status'],status)
            self.assertIsNone(metadata['retained_fraction'])
            with self.assertRaises(ValueError):auto_rotation(p)
            self.assertEqual(set(prepare_rotated_diagnostics(p,12)),{'x2','y2','phase2'})

    def test_tiny_signals_are_scaled_before_covariance(self):
        a=np.arange(600)*2*np.pi/30;s=np.sin(a)*1e-150
        result=auto_rotation(self.dual(s*.8,s*.6))
        self.assertAlmostEqual(result['angle_deg'],np.rad2deg(np.arctan2(.6,.8)),places=10)
        self.assertAlmostEqual(result['retained_fraction'],1.,places=12)
        self.assertGreater(result['ac_power_x'],0)

    def test_manual_power_fractions_match_rotated_centered_data(self):
        rng=np.random.default_rng(35);x=rng.normal(size=2000)*3e-7+1e-5;y=.5*x+rng.normal(size=2000)*1e-7
        p=self.dual(x,y);metadata=rotation_metadata(p,-28)
        xr,yr=rotate_quadratures(x,y,-28)
        self.assertAlmostEqual(metadata['ac_power_x'],np.var(xr),delta=np.var(xr)*1e-12)
        self.assertAlmostEqual(metadata['ac_power_y'],np.var(yr),delta=np.var(yr)*1e-12)
        self.assertAlmostEqual(metadata['retained_fraction'],np.var(xr)/(np.var(xr)+np.var(yr)),places=12)

    def test_duplicate_complex_cancellation_keeps_undefined_phase_after_rotation(self):
        position=np.repeat(np.arange(20,dtype=float),2)
        x=np.ones(40)*3e-7;y=np.ones(40)*2e-7
        x[10:12]=[3e-7,-3e-7];y[10:12]=[2e-7,-2e-7]
        m=DualMeasurement(position,np.sin(position),x,y,'s.dat','s.txt','','V',[])
        cfg=core.Settings(bal_mv=-100,sig_mv=100,zero_mode='manual',zero_mm=0,
            fit_window_mode='manual',fit_min_s=0,fit_max_s=2e-10)
        p=prepare_dual(m,cfg);original=prepare_diagnostics(p)
        self.assertTrue(np.isnan(original['phase2'].y[5]))
        for angle in (13.123,47,90,-155):
            rotated=prepare_rotated_diagnostics(p,angle)
            np.testing.assert_array_equal(np.isnan(rotated['phase2'].y),np.isnan(original['phase2'].y))
            self.assertEqual(len(rotated['phase2'].spectrum),0)
            np.testing.assert_array_equal(p.measurement.x2,x)


if __name__=='__main__':unittest.main()
