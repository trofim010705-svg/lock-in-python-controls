"""New diagnostics, editable labels and presentation-only fit visibility."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
from dataclasses import replace
from io import BytesIO
from types import SimpleNamespace
import unittest
import numpy as np
from PIL import Image
from PyQt5.QtWidgets import QApplication
from analyzer.core import Prepared,Settings,FitResult,evaluate
from analyzer.dual_figure import DualFigure


class DualV2FigureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])

    def build(self):
        e=DualFigure();e.resize(1100,800);e.show();self.addCleanup(e.close)
        self.app.processEvents()
        t=np.linspace(0,3e-9,240);f=np.linspace(0,4e9,300)
        cfg=Settings(bal_mv=-100,sig_mv=100,fit_window_mode='manual',fit_min_s=0,fit_max_s=3e-9)
        prepared=[];results=[]
        for i in range(2):
            params=np.array([2e-6,1.2e9,.3+i*.4,2e-9,5e-6])
            y=evaluate(t,params,0);a=1e-6*np.exp(-((f-1.2e9)/.2e9)**2)
            prepared.append(Prepared(t,y,y,np.ones(len(t),bool),f,a,1/3e-9,40e9,[],cfg,np.zeros_like(t)))
            results.append(FitResult(params,abs(params)*.01,np.eye(5),0,1e-9,.999,[],10,2))
        diagnostics={'x2':replace(prepared[1],y=prepared[1].y*.8),
                     'y2':replace(prepared[1],y=-prepared[1].y*.4),
                     'phase2':replace(prepared[1],y=.3+np.sin(2*np.pi*1.2e9*t),spectrum=prepared[1].spectrum*1e6)}
        dual=SimpleNamespace(first=prepared[0],second=prepared[1],first_unit='rad',second_unit='V')
        bands=((.5e9,2e9),)*2
        e.set_data(dual,tuple(results),bands,diagnostics=diagnostics)
        return e,dual,tuple(results),bands,diagnostics

    def test_all_graphs_correct_units_and_exact_full_canvas_export(self):
        e,dual,results,bands,diagnostics=self.build()
        self.assertEqual(len(e.axes_by_id),11)
        self.assertEqual(e.normalized_axes.get_ylabel(),'a.u.')
        for key,p in diagnostics.items():
            expected=np.mod(np.rad2deg(p.y),360.) if key=='phase2' else p.y
            np.testing.assert_allclose(e.diagnostic_points[key].get_ydata(),expected,atol=1e-12)
            if key=='phase2':continue  # replaced by the paired quadrature scatter
            np.testing.assert_array_equal(e.diagnostic_spectra[key].get_xdata(),p.frequencies/1e9)
            self.assertEqual(len(e.diagnostic_peaks[key].get_xdata()),1)
            low,high=e.diagnostic_fft_axes[key].get_xlim()
            maximum=e.diagnostic_peaks[key].get_xdata()[0]
            self.assertLessEqual(low,maximum);self.assertGreaterEqual(high,maximum)
            self.assertLess(high,p.nyquist_hz/1e9)
        e.render();self.app.processEvents()
        self.assertIn('V',e.diagnostic_time_axes['x2'].get_ylabel())
        self.assertIn('°',e.diagnostic_time_axes['phase2'].get_ylabel())
        self.assertEqual(e.diagnostic_time_axes['phase2'].get_ylim(),(0.,360.))
        before=np.asarray(e.canvas.buffer_rgba()).copy()
        payload=e.capture_images(('png',))['png']
        np.testing.assert_array_equal(before,np.asarray(Image.open(BytesIO(payload))))
        self.assertGreater(Image.open(BytesIO(payload)).height,2000)
        e.clear_data()
        for artist in (*e.diagnostic_points.values(),*e.diagnostic_spectra.values(),*e.diagnostic_peaks.values()):
            self.assertEqual(len(artist.get_ydata()),0)

    def test_labels_and_visibility_preserve_fits_data_and_zoom(self):
        e,dual,results,bands,diagnostics=self.build()
        e.time_axes[0].set_xlim(.5,1.2);e.normalized_axes.set_ylim(-.8,.8)
        original=np.asarray(e.normalized_fits[0].get_ydata()).copy()
        labels={'x2.title':r'$$X_2(t)$$','phase2.ylabel':r'$\varphi$ ({unit})',
                'normalized.ylabel':'a.u.', 'legend.x1_points':'First experiment',
                'legend.r2_fit':'Second fit','channel.r2':'Amplitude channel'}
        self.assertTrue(e.set_labels(labels))
        self.assertEqual(e.diagnostic_time_axes['x2'].get_title(),r'$X_2(t)$')
        self.assertIn('Amplitude channel',e.column_artists[1].get_text())
        e.set_fit_visible(False,True);e.set_alphas(.1,.8)
        self.assertFalse(e.fit_artists[0].get_visible());self.assertFalse(e.normalized_fits[0].get_visible())
        self.assertTrue(e.fit_artists[1].get_visible());self.assertEqual(e.fit_artists[1].get_alpha(),1)
        self.assertEqual(e.time_axes[0].get_xlim(),(.5,1.2))
        self.assertEqual(e.normalized_axes.get_ylim(),(-.8,.8))
        np.testing.assert_array_equal(e.normalized_fits[0].get_ydata(),original)
        texts=[x.get_text() for x in e.normalized_axes.get_legend().get_texts()]
        self.assertIn('Second fit',texts);self.assertNotIn('X1 fit',texts)
        previous=e.diagnostic_time_axes['x2'].get_title()
        self.assertFalse(e.set_labels({'x2.title':r'$$\unknowncommand{x}$$'}))
        self.assertEqual(e.diagnostic_time_axes['x2'].get_title(),previous)
        self.assertTrue(e.set_labels({'x2.title':''}))
        self.assertEqual(e.diagnostic_time_axes['x2'].get_title(),'')
        e.set_data(dual,results,bands,time_unit='ps',diagnostics=diagnostics)
        self.assertFalse(e.fit_artists[0].get_visible())
        self.assertEqual(e.diagnostic_time_axes['x2'].get_xlabel(),'Задержка (ps)')
        e.set_normalized_visible(False);e.set_normalized_visible(True)
        self.assertEqual(e.normalized_axes.get_xlabel(),'Задержка (ps)')
        old=e.canvas.minimumHeight();e.set_footer_visible(False)
        self.assertFalse(e.footer_axes.get_visible());self.assertLess(e.canvas.minimumHeight(),old)
        e.set_footer_visible(True);self.assertTrue(e.footer_axes.get_visible())


if __name__=='__main__':unittest.main()
