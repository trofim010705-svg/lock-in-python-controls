"""Circular phase in degrees must never turn independent noise into a smooth fit."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
from dataclasses import replace
from pathlib import Path
import tempfile,time,json
import unittest
import numpy as np
from PyQt5.QtWidgets import QApplication
from analyzer import core
from analyzer.dual_core import DualMeasurement,prepare_dual
from analyzer.dual_signals import prepare_diagnostics
from analyzer.dual_fit_support import diagnostic_fit_input
from analyzer.quadrature_rotation import prepare_rotated_diagnostics,auto_rotation
from analyzer.dual_ui import DualAnalysisWindow
from analyzer.dual_export import export_dual
from analyzer.dual_figure import DualFigure


def dual(x,y,background=-1):
    t=np.linspace(0,3e-9,len(x));position=t*3e8/2*1e3
    cfg=core.Settings(bal_mv=-100,sig_mv=100,zero_mode='manual',zero_mm=0,
        fit_window_mode='manual',fit_min_s=0,fit_max_s=3e-9,
        background_degree=background,bg_min_s=0,bg_max_s=3e-9)
    m=DualMeasurement(position,1e-6*np.sin(2*np.pi*1.2e9*t),x,y,'s.dat','s.txt','','V',[])
    return prepare_dual(m,cfg)


class PhaseV5NumericTests(unittest.TestCase):
    def test_independent_noise_is_wrapped_and_not_fitted_or_globally_unwrapped(self):
        rng=np.random.default_rng(23);p=dual(rng.normal(0,1e-6,1000),rng.normal(0,1e-6,1000))
        q=prepare_diagnostics(p)['phase2'];f=diagnostic_fit_input(q,'phase2')
        self.assertGreater(np.isfinite(q.raw_rad).sum(),990)
        self.assertTrue(np.all((q.raw_rad>=0)&(q.raw_rad<2*np.pi)))
        self.assertLess(q.phase_info['valid_points'],50)
        self.assertFalse(f.phase_info['fit_allowed']);self.assertEqual(len(f.spectrum),0)

    def test_phase_uses_exact_same_background_processed_quadratures(self):
        t=np.linspace(0,3e-9,800)
        x=100e-6+3e-6*np.cos(2*np.pi*1e9*t);y=-30e-6+3e-6*np.sin(2*np.pi*1e9*t)
        q=prepare_diagnostics(dual(x,y,0))
        expected=np.mod(np.arctan2(q['y2'].y,q['x2'].y),2*np.pi)
        np.testing.assert_allclose(q['phase2'].raw_rad,expected)
        self.assertGreater(np.ptp(expected),6.)

    def test_crossing_zero_uses_local_branch_and_recovers_real_phase_modulation(self):
        t=np.linspace(0,3e-9,901);theta=np.deg2rad(350+15*np.sin(2*np.pi*1.2e9*t+.2))
        p=dual(2e-6*np.cos(theta),2e-6*np.sin(theta));q=prepare_diagnostics(p)['phase2']
        self.assertLess(np.nanmin(np.rad2deg(q.y)),10.);self.assertGreater(np.nanmax(np.rad2deg(q.y)),350.)
        f=diagnostic_fit_input(q,'phase2');self.assertTrue(f.phase_info['fit_allowed'])
        self.assertLess(np.ptp(f.y[f.fit_mask]),np.pi)
        band=core.automatic_band(f);seed=core.initial_parameters(f,1,band)
        r=core.fit(f,seed,band)
        self.assertAlmostEqual(r.parameters[1]/1e9,1.2,delta=.01)
        self.assertGreater(r.r_squared,.9999)

    def test_real_phase_winding_is_shown_but_not_fitted_as_a_damped_sine(self):
        t=np.linspace(0,3e-9,800);theta=2*np.pi*1e9*t
        q=prepare_diagnostics(dual(np.cos(theta)*1e-6,np.sin(theta)*1e-6))['phase2']
        f=diagnostic_fit_input(q,'phase2')
        self.assertFalse(f.phase_info['fit_allowed']);self.assertEqual(len(f.spectrum),0)

    def test_rotation_preserves_circular_phase_quality_and_modulus(self):
        t=np.linspace(0,3e-9,800);theta=.3+.1*np.sin(2*np.pi*1e9*t)
        p=dual(np.cos(theta)*1e-6,np.sin(theta)*1e-6)
        a=prepare_rotated_diagnostics(p,0)['phase2'];b=prepare_rotated_diagnostics(p,70)['phase2']
        np.testing.assert_allclose(np.angle(np.exp(1j*(b.raw_rad-a.raw_rad+np.deg2rad(70)))),0,atol=1e-14)
        np.testing.assert_array_equal(np.isfinite(a.y),np.isfinite(b.y))

    def test_measured_noise_override_masks_weak_data_and_threshold_zero_allows_inspection(self):
        t=np.linspace(0,3e-9,800);p=dual(np.cos(t/1e-9)*1e-9,np.sin(t/1e-9)*1e-9)
        q=prepare_diagnostics(p,3,noise_sigma_v=1e-8)['phase2']
        self.assertFalse(np.isfinite(q.y).any())
        q=prepare_diagnostics(p,0,noise_sigma_v=1e-8)['phase2']
        self.assertTrue(np.isfinite(q.y).all())

    def test_band_auto_rotation_rejects_drift_and_finds_oscillation_orientation(self):
        t=np.linspace(0,3e-9,1001);s=1e-6*np.sin(2*np.pi*2e9*t)
        x=.003*t/t[-1]+s*np.cos(.6);y=-.002*t/t[-1]+s*np.sin(.6)
        p=dual(x,y)
        broad=auto_rotation(p);selected=auto_rotation(p,(1.5e9,2.5e9))
        self.assertGreater(abs(broad['angle_deg']-np.rad2deg(.6)),40.)
        self.assertAlmostEqual(selected['angle_deg'],np.rad2deg(.6),delta=1e-6)
        self.assertEqual(selected['band_hz'],[1.5e9,2.5e9])


class PhaseV5UITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])
    def settle(self,w):
        end=time.monotonic()+90;idle=0
        while time.monotonic()<end:
            self.app.processEvents();time.sleep(.005)
            if w.job is None and not w.pending and not w.timer.isActive() and w.pending_load is None:
                idle+=1
                if idle>10:return
            else:idle=0
        self.fail(w.messages.toPlainText())
    def test_fitted_phase_line_breaks_at_360_and_band_change_cancels_stale_auto(self):
        t=np.linspace(0,3e-9,601)
        theta=core.evaluate(t,np.array([np.deg2rad(18),1.2e9,.2,3e-9,np.deg2rad(350)]),0)
        p=dual(2e-6*np.cos(theta),2e-6*np.sin(theta));d=prepare_diagnostics(p)
        q=diagnostic_fit_input(d['phase2'],'phase2');band=core.automatic_band(q)
        r=core.fit(q,core.initial_parameters(q,1,band),band)
        editor=DualFigure();editor.show()
        try:
            editor.set_data(p,(None,None),((.1e9,2e9),)*2,diagnostics=d,
                diagnostic_results={'phase2':r},diagnostic_fit_prepared={'phase2':q},diagnostic_bands={'phase2':band})
            values=editor.diagnostic_fit_artists['phase2'].get_ydata()
            self.assertTrue(np.isnan(values).any())
            self.assertTrue(np.all((values[np.isfinite(values)]>=0)&(values[np.isfinite(values)]<360)))
            jumps=np.diff(values);self.assertLess(np.nanmax(abs(jumps)),180)
            self.assertEqual(editor.diagnostic_time_axes['phase2'].get_ylim(),(0.,360.))
        finally:editor.close();self.app.processEvents()
        w=DualAnalysisWindow()
        try:
            w.auto_rotation_requested=True;revision=w.revision
            w.auto_phase_band.setCurrentIndex(1)
            self.assertGreater(w.revision,revision)
        finally:w.close();self.app.processEvents()
    def test_degree_axis_gray_noise_no_phase_fit_and_degree_export(self):
        rng=np.random.default_rng(44);n=601;t=np.linspace(0,3e-9,n)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'noise.dat';notes=Path(tmp)/'noise.comments.txt'
            x1=2e-6*np.sin(2*np.pi*1.2e9*t);x1[0]=1e-3
            np.savetxt(path,np.c_[t*3e8/2*1e3,x1,np.zeros(n),rng.normal(0,1e-6,n),rng.normal(0,1e-6,n)],delimiter='\t')
            notes.write_text('Signal unit: V\nRESULT: complete\n')
            w=DualAnalysisWindow();w.show();w.bal.setText('-100');w.sig.setText('100')
            try:
                w.load_paths(path,notes);self.settle(w)
                self.assertIsNone(w.diagnostic_results.get('phase2'))
                self.assertEqual(w.figure.diagnostic_time_axes['phase2'].get_ylim(),(0.,360.))
                self.assertIn('°',w.figure.diagnostic_time_axes['phase2'].get_ylabel())
                self.assertGreater(len(w.figure.phase_unreliable_points.get_ydata()),500)
                self.assertEqual(len(w.figure.diagnostic_fit_artists['phase2'].get_ydata()),0)
                folder=Path(export_dual(Path(tmp)/'export',w.snapshot(),{}))
                table=np.loadtxt(folder/'phase2_time.tsv',skiprows=1)
                self.assertTrue(np.all((table[:,1]>=0)&(table[:,1]<360)))
                self.assertIn('Phase_deg_0_360',(folder/'phase2_time.tsv').read_text().splitlines()[0])
                self.assertTrue((folder/'phase2_time_rad.tsv').exists())
                report=json.loads((folder/'analysis.json').read_text())
                phase=next(d for d in report['diagnostics'] if d['name']=='phase2')
                self.assertIsNone(phase['fit']);self.assertEqual(phase['phase_quality']['range_deg'],[0,360])
            finally:
                w.close()
                while w.pool.activeThreadCount():self.app.processEvents();time.sleep(.005)
                self.app.processEvents()


if __name__=='__main__':unittest.main()
