#!/usr/bin/env python3
"""Run the five-signal Pump-Probe analyzer: python app.py [--demo]."""
import argparse
import os
import sys
from pathlib import Path
# Small independent fits run in one worker. Avoid each BLAS call spawning a
# full CPU-sized pool; explicit user overrides remain respected.
for _name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ.setdefault(_name,'1')
from PyQt5.QtCore import Qt,QTimer
from PyQt5.QtWidgets import QApplication
from analyzer.dual_ui import DualAnalysisWindow


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group();group.add_argument('--demo',action='store_true');group.add_argument('--noise-demo',action='store_true')
    args=parser.parse_args()
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling,True);QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps,True)
    app=QApplication(sys.argv[:1]);app.setStyle('Fusion');window=DualAnalysisWindow();window.show()
    if args.demo or args.noise_demo:
        window.bal.setText('-100');window.sig.setText('100');base=Path(__file__).resolve().parent/'examples'
        name='phase_noise_demo' if args.noise_demo else 'dual_demo'
        if args.noise_demo:
            window.footer_visible.setChecked(False);window.normalized.setChecked(False)
            for control in window.all_channel_controls()[1:]:control.fit_enabled.setChecked(False)
            for key in ('x2','y2','r2','phase2'):
                window.fit_checks[key].setChecked(False);window.peak_checks[key].setChecked(False)
        QTimer.singleShot(0,lambda:window.load_paths(base/(name+'.dat'),base/(name+'.comments.txt')))
    return app.exec_()


if __name__=='__main__':sys.exit(main())
