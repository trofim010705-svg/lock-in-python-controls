"""Запуск: python app.py; без оборудования: python app.py --demo."""
import argparse
import sys

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication

from gui import MainWindow


def main():
    parser = argparse.ArgumentParser(description='GEN60-40 / relay command tester')
    parser.add_argument('--demo', action='store_true', help='Только симулятор; COM не открывается')
    args = parser.parse_args()
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication(sys.argv[:1])
    app.setApplicationName('MagnetCommandTester')
    app.setOrganizationName('LabTools')
    app.setStyle('Fusion')
    window = MainWindow(args.demo)
    window.show()
    return app.exec_()


if __name__ == '__main__':
    sys.exit(main())
