@echo off
setlocal
cd /d "%~dp0"
if exist "venv\Scripts\python.exe" goto dependencies
py -3.11 --version >nul 2>&1
if errorlevel 1 goto default_python
py -3.11 -m venv venv
goto check_venv
:default_python
python -m venv venv
:check_venv
if not exist "venv\Scripts\python.exe" goto failed
:dependencies
"venv\Scripts\python.exe" -c "import PyQt5.QtWidgets, serial" >nul 2>&1
if not errorlevel 1 goto run
echo Installing PyQt5 and pyserial into the project venv...
"venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed
"venv\Scripts\python.exe" -m pip install --only-binary=:all: -r requirements.txt
if errorlevel 1 goto failed
:run
"venv\Scripts\python.exe" app.py %*
if errorlevel 1 goto failed
exit /b 0
:failed
echo.
echo Could not start. Install Python 3.11 x64 and see README_RU.md.
pause
exit /b 1
