"""Synchronized parametric fits, a local blitted player, atomic GIF export."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
from dataclasses import replace
from io import BytesIO
from pathlib import Path
from threading import Event
from types import SimpleNamespace
from unittest.mock import patch
import tempfile
import time
import unittest
import numpy as np
from PIL import Image
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QTimer
from analyzer import core
from analyzer.dual_figure import DualFigure
from analyzer.quadrature_trace import quadrature_trace,trace_counts
from analyzer.xy_animation import XYAnimationDialog
from analyzer.xy_gif import write_xy_gif
from analyzer.dual_export import export_dual


def fixture():
    t=np.linspace(0,3e-9,301);mask=np.ones(len(t),dtype=bool)
    cfg=core.Settings(bal_mv=-100,sig_mv=100,fit_window_mode='manual',fit_min_s=0,fit_max_s=t[-1])
    diagnostic={};results={};inputs={}
    for key,parameters,reference in (
        ('x2',[3e-6,1.2e9,.4,3e-9,5e-6],0.),
        ('y2',[2e-6,1.2e9,1.1,2e-9,-2e-6],.5e-9)):
        parameters=np.array(parameters);y=core.evaluate(t,parameters,reference)
        p=core.Prepared(t,y.copy(),y.copy(),mask.copy(),np.array([]),np.array([]),1/3e-9,50e9,[],cfg,np.zeros_like(t))
        diagnostic[key]=p
        results[key]=core.FitResult(parameters,abs(parameters)*.01,np.eye(5),reference,1e-9,.99,[],1,2.)
        fitted=(t>=.2e-9)&(t<=2.8e-9) if key=='x2' else (t>=.6e-9)&(t<=2.2e-9)
        inputs[key]=replace(p,fit_mask=fitted)
    return diagnostic,results,inputs


def style(trace):
    return dict(title=r'$H=26\,\mathrm{mT}$',plane_title='Плоскость X₂–Y₂',xlabel='X₂ (µV)',ylabel='Y₂ (µV)',
        xlim=(0,10e-6),ylim=(-5e-6,5e-6),scale=1e-6,alpha=.4,time_unit='ns',fit_visible=True,
        points_label='Эксперимент',fit_label='Фит X₂(t), Y₂(t)')


class ParametricTraceTests(unittest.TestCase):
    def test_shared_times_separate_references_and_intersection_without_mutation(self):
        d,r,p=fixture();original={k:q.y.copy() for k,q in d.items()}
        trace=quadrature_trace(d,r,p)
        self.assertTrue(trace.has_fit)
        self.assertGreaterEqual(trace.fit_time_s[0],.6e-9)
        self.assertLessEqual(trace.fit_time_s[-1],2.2e-9)
        for key,values in (('x2',trace.fit_x_v),('y2',trace.fit_y_v)):
            np.testing.assert_allclose(values,core.evaluate(trace.fit_time_s,r[key].parameters,r[key].reference_s))
            np.testing.assert_array_equal(d[key].y,original[key])
        np.testing.assert_array_equal(trace.time_s,d['x2'].time)
        n,m,t=trace_counts(trace,1.)
        self.assertEqual((n,m),(301,1500));self.assertEqual(t,trace.time_s[-1])
        n,m,t=trace_counts(trace,.5)
        self.assertLessEqual(trace.time_s[n-1],t);self.assertGreater(trace.time_s[n],t)
        self.assertLessEqual(trace.fit_time_s[m-1],t);self.assertGreater(trace.fit_time_s[m],t)

    def test_missing_fit_and_nonoverlap_never_invent_xy_model(self):
        d,r,p=fixture()
        self.assertFalse(quadrature_trace(d,{'x2':r['x2']},p).has_fit)
        p['x2']=replace(p['x2'],fit_mask=p['x2'].time<.3e-9)
        self.assertFalse(quadrature_trace(d,r,p).has_fit)
        changed=dict(d);changed['y2']=replace(d['y2'],time=d['y2'].time+1e-12)
        with self.assertRaisesRegex(ValueError,'одинаковыми временами'):quadrature_trace(changed,r,p)


class XYV7GUITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])

    def player(self):
        d,r,p=fixture();trace=quadrature_trace(d,r,p)
        dialog=XYAnimationDialog(trace,style(trace),Path('xy.gif'))
        dialog.show();self.app.processEvents()
        self.addCleanup(self.close_dialog,dialog)
        return dialog

    def close_dialog(self,dialog):
        # Tests may already have closed/deleted a player with WA_DeleteOnClose.
        try:
            dialog.close();end=time.monotonic()+15
            while dialog.pool.activeThreadCount() and time.monotonic()<end:
                self.app.processEvents();time.sleep(.005)
            dialog.close();self.app.processEvents()
        except RuntimeError:pass

    def test_static_xy_curve_opaque_visibility_and_exact_saved_picture(self):
        d,r,p=fixture();editor=DualFigure();editor.resize(1000,800);editor.show()
        self.addCleanup(editor.close);self.app.processEvents()
        first=d['x2'];dual=SimpleNamespace(first=first,second=first,first_unit='rad',second_unit='V')
        editor.set_data(dual,(None,None),((.3e9,2e9),)*2,diagnostics=d,
            diagnostic_results=r,diagnostic_fit_prepared=p)
        trace=quadrature_trace(d,r,p)
        np.testing.assert_allclose(editor.quadrature_fit.get_xdata(),trace.fit_x_v)
        np.testing.assert_allclose(editor.quadrature_fit.get_ydata(),trace.fit_y_v)
        self.assertTrue(editor.quadrature_fit.get_visible());self.assertEqual(editor.quadrature_fit.get_alpha(),1.)
        editor.set_fit_visibility({'x2':False});self.assertFalse(editor.quadrature_fit.get_visible())
        editor.set_fit_visibility({'x2':True,'y2':True})
        editor.set_labels({'legend.quadrature_fit':r'$X_2(t),Y_2(t)$'})
        self.assertIn(r'$X_2(t),Y_2(t)$',[v.get_text() for v in editor.quadrature_axes.get_legend().get_texts()])
        editor.render();self.app.processEvents()
        pixels=np.asarray(editor.canvas.buffer_rgba()).copy()
        exported=editor.capture_images(('png',))['png']
        np.testing.assert_array_equal(pixels,np.asarray(Image.open(BytesIO(exported))))
        editor.clear_data();self.assertEqual(len(editor.quadrature_fit.get_xdata()),0)
        self.assertFalse(editor.animation_button.isEnabled())

    def test_player_updates_only_its_artists_and_uses_physical_delay(self):
        dialog=self.player();trace=dialog.trace
        with patch.object(core,'fit',side_effect=AssertionError('No fit during playback')):
            with patch.object(dialog.canvas,'draw',wraps=dialog.canvas.draw) as draw:
                dialog._show_fraction(.5)
                n,m,t=trace_counts(trace,.5)
                self.assertEqual(len(dialog.points.get_xdata()),n)
                self.assertEqual(len(dialog.fitted.get_xdata()),m)
                self.assertEqual(draw.call_count,0)
                dialog._show_fraction(1.)
                self.assertEqual(len(dialog.points.get_xdata()),len(trace.time_s))
                self.assertEqual(len(dialog.fitted.get_xdata()),len(trace.fit_time_s))
                dialog.fit_check.setChecked(False);self.assertFalse(dialog.fitted.get_visible())
                self.assertEqual(draw.call_count,0)
            dialog.toggle_play();self.assertTrue(dialog.timer.isActive())
            dialog._started-=dialog.duration.value();dialog._tick()
            self.assertFalse(dialog.timer.isActive());self.assertEqual(dialog._fraction,1.)

    def test_gif_frames_unicode_path_cancellation_and_no_matplotlib_in_encoder(self):
        dialog=self.player();scene=dialog.gif_scene()
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)/'измерения'/'траектория.gif'
            with patch.object(dialog.canvas,'draw',side_effect=AssertionError('Worker must not draw Matplotlib')):
                write_xy_gif(target,dialog.trace,scene,1.,5)
            image=Image.open(target);self.assertEqual(image.n_frames,5)
            self.assertEqual(image.info['loop'],0);self.assertLessEqual(image.width,800)
            first=np.array(image.convert('RGB'));image.seek(image.n_frames-1)
            last=np.array(image.convert('RGB'));self.assertGreater(np.count_nonzero(first!=last),100)
            colors=last.astype(int)
            purple=(colors[:,:,0]>colors[:,:,1]+5)&(colors[:,:,2]>colors[:,:,0]+5)
            self.assertGreater(np.count_nonzero(purple),200)
            image.close();original=target.read_bytes()
            event=Event();event.set()
            with self.assertRaises(core.Cancelled):write_xy_gif(target,dialog.trace,scene,1.,5,event)
            self.assertEqual(target.read_bytes(),original)
            class MidCancel:
                def __init__(self):self.calls=0
                def is_set(self):
                    self.calls+=1;return self.calls>3
            with self.assertRaises(core.Cancelled):write_xy_gif(target,dialog.trace,scene,1.,5,MidCancel())
            self.assertEqual(target.read_bytes(),original)
            self.assertFalse(list(target.parent.glob('.xy_gif_*')))

    def test_gif_worker_leaves_event_loop_responsive(self):
        dialog=self.player();dialog.duration.setValue(1.);dialog.fps.setCurrentText('5')
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)/'xy.gif';ticks=[];timer=QTimer();timer.setInterval(2)
            timer.timeout.connect(lambda:ticks.append(1));timer.start()
            with patch('analyzer.xy_animation.QFileDialog.getSaveFileName',return_value=(str(target),'GIF (*.gif)')):
                dialog.save_gif()
            end=time.monotonic()+30
            while dialog.job is not None and time.monotonic()<end:
                self.app.processEvents();time.sleep(.002)
            timer.stop();self.assertIsNone(dialog.job,dialog.status.text())
            self.assertTrue(target.exists(),dialog.status.text());self.assertGreater(len(ticks),0)
            self.assertTrue(dialog.save_button.isEnabled())


if __name__=='__main__':unittest.main()
