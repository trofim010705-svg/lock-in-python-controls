"""Selectable overlay and peak output do not change numerical fits or spectra."""
from dataclasses import replace
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
from analyzer import core
from analyzer.dual_core import load_dual_pair,prepare_dual
from analyzer.dual_signals import prepare_diagnostics
from analyzer.dual_fit_support import diagnostic_fit_input
from analyzer.dual_export import build_dual_report,dual_report_text,export_dual


class DualV3ExportTests(unittest.TestCase):
    def snapshot(self):
        base=Path(__file__).resolve().parents[1]/'examples'
        m=load_dual_pair(base/'dual_demo.dat',base/'dual_demo.comments.txt')
        p=prepare_dual(m,core.Settings(bal_mv=-100,sig_mv=100));diagnostics=prepare_diagnostics(p)
        t=diagnostics['phase2'].time
        phase=core.evaluate(t,np.array([.4,1.5e9,.3,3e-9,2.]),0)
        diagnostics['phase2']=replace(diagnostics['phase2'],y=phase,raw_rad=phase)
        inputs={k:diagnostic_fit_input(v,k) for k,v in diagnostics.items()}
        results={};initials={};bands={}
        for key,q in inputs.items():
            bands[key]=core.automatic_band(q);initials[key]=core.initial_parameters(q,1,bands[key])
            results[key]=core.fit(q,initials[key],bands[key])
        band1=core.automatic_band(p.first);band2=core.automatic_band(p.second)
        return dict(measurement=m,prepared=p,results=(None,None),initials=(None,None),
            bands=(band1,band2),components=(1,1),pair=(0,0),comparison=None,
            diagnostics=diagnostics,diagnostic_fit_prepared=inputs,diagnostic_results=results,
            diagnostic_initials=initials,diagnostic_bands=bands,diagnostic_components={k:1 for k in inputs},
            overlay_signals=('x2','phase2'),fft_peak_enabled={k:False for k in ('x1','x2','y2','r2','phase2')})

    def test_five_peak_flags_exclude_noise_lists_but_preserve_fits_and_full_spectra(self):
        s=self.snapshot();r=build_dual_report(s);text=dual_report_text(r)
        self.assertNotIn('FFT PEAKS:',text)
        self.assertNotIn('FFT: frequency_GHz',text)
        for d in r['diagnostics']:
            self.assertFalse(d['fft_peaks_included']);self.assertEqual(d['fft_peaks'],[])
            self.assertIsNotNone(d['fit']);self.assertEqual(d['initial_parameters'],s['diagnostic_initials'][d['name']].tolist())
        self.assertEqual(r['overlay_signals'],['x2','phase2'])
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(export_dual(Path(tmp)/'selected',s,{}))
            q=np.loadtxt(folder/'comparison.tsv',skiprows=1)
            header=(folder/'comparison.tsv').read_text().splitlines()[0]
            self.assertEqual(header,'Time_s\tx2_data_au\tx2_fit_au\tphase2_data_au\tphase2_fit_au')
            self.assertEqual(q.shape[1],5)
            trajectory=np.loadtxt(folder/'quadrature_fit.tsv',skiprows=1)
            self.assertEqual(trajectory.shape,(1500,3))
            for column,key in ((1,'x2'),(2,'y2')):
                fit=s['diagnostic_results'][key]
                np.testing.assert_allclose(trajectory[:,column],core.evaluate(trajectory[:,0],fit.parameters,fit.reference_s))
            self.assertGreater(np.count_nonzero(np.isfinite(q[:,4])),700)
            for key in ('x2','y2','phase2'):
                spec=np.loadtxt(folder/(key+('_spectrum_rad.tsv' if key=='phase2' else '_spectrum.tsv')),skiprows=1)
                np.testing.assert_allclose(spec[:,1],s['diagnostic_fit_prepared'][key].spectrum)
                table=np.loadtxt(folder/(key+('_time_rad.tsv' if key=='phase2' else '_time.tsv')),skiprows=1)
                self.assertEqual(table.shape[1],7)
            loaded=json.loads((folder/'analysis.json').read_text())
            self.assertTrue(all(not flag for flag in loaded['fft_peak_enabled'].values()))
        s['fft_peak_enabled']['y2']=True;r=build_dual_report(s)
        for d in r['diagnostics']:
            if d['name']=='y2':self.assertGreater(len(d['fft_peaks']),0)
            else:self.assertEqual(d['fft_peaks'],[])

    def test_no_fit_and_no_selection_are_valid_export_states(self):
        s=self.snapshot();s['diagnostic_results']={};s['overlay_signals']=('x1','y2')
        r=build_dual_report(s)
        self.assertTrue(all(item['method']=='data' for item in r['overlay_normalization']))
        s['overlay_signals']=()
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(export_dual(Path(tmp)/'none',s,{}))
            self.assertEqual((folder/'comparison.tsv').read_text().splitlines()[0],'Time_s')


if __name__=='__main__':unittest.main()
