"""Bounded GIF export using Pillow only; no Qt/Matplotlib calls in the worker."""
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from threading import Event
import os
import tempfile
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from .core import Cancelled
from .quadrature_trace import trace_counts


@dataclass(frozen=True)
class GifScene:
    background_png: bytes
    data_pixels: np.ndarray
    fit_pixels: np.ndarray
    clip_box: tuple
    point_alpha: float
    fit_visible: bool
    point_radius: float
    line_width: int
    time_unit: str
    font_path: str


def write_xy_gif(path,trace,scene,duration_s=6.,fps=15,cancel=None):
    """Render <=150 frames over physical delay, keeping all cumulative points.

    The static axes/title are captured once on the GUI thread. Worker frames
    only draw pixels, avoiding both global Matplotlib state and refitting.
    Write atomically so cancellation never replaces an existing good file.
    """
    cancel=cancel or Event()
    duration_s=float(duration_s);fps=int(fps)
    if not np.isfinite(duration_s) or not .5<=duration_s<=30 or not 1<=fps<=30:
        raise ValueError('GIF: длительность 0.5–30 s, частота 1–30 кадров/s.')
    if len(trace.time_s)<2:raise ValueError('Для анимации нужно хотя бы две точки.')
    if cancel.is_set():raise Cancelled('Сохранение GIF отменено')
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    base=Image.open(BytesIO(scene.background_png)).convert('RGB')
    if base.width>800 or base.height>600:raise ValueError('GIF: размер кадра превышает 800×600.')
    box=tuple(int(v) for v in scene.clip_box);left,top,right,bottom=box
    if not 0<=left<right<=base.width or not 0<=top<bottom<=base.height:
        raise ValueError('Некорректная область графика GIF.')
    font=ImageFont.truetype(scene.font_path,12) if scene.font_path else ImageFont.load_default()
    count=min(150,max(2,int(round(duration_s*fps))))
    frame_ms=max(10,int(round(duration_s*1000/count/10))*10)
    # GIF centiseconds cannot represent all requested rates exactly.
    factor=1e-12 if scene.time_unit=='ps' else 1e-9
    point_color=(104,80,161,int(round(255*np.clip(scene.point_alpha,0,1))))
    radius=max(1.,float(scene.point_radius))
    offset=np.array([left,top])
    points=scene.data_pixels-offset;fit=scene.fit_pixels-offset
    def render(fraction):
        if cancel.is_set():raise Cancelled('Сохранение GIF отменено')
        n,m,t=trace_counts(trace,fraction)
        picture=base.copy();layer=picture.crop(box)
        # Sequential RGBA-on-RGB drawing preserves opacity accumulation
        # where experimental markers overlap, just as in the live plot.
        draw=ImageDraw.Draw(layer,'RGBA')
        for x,y in points[:n]:
            if np.isfinite(x) and np.isfinite(y):
                draw.ellipse((x-radius,y-radius,x+radius,y+radius),fill=point_color)
        if scene.fit_visible and m>1:
            valid=np.isfinite(fit[:m]).all(axis=1)
            indices=np.flatnonzero(valid)
            for run in np.split(indices,np.flatnonzero(np.diff(indices)>1)+1):
                if len(run)>1:draw.line([tuple(p) for p in fit[run]],fill=(214,107,48,255),width=scene.line_width)
        if n:
            x,y=points[n-1];r=radius+1.5
            draw.ellipse((x-r,y-r,x+r,y+r),fill=(18,124,156,255))
        label=f't = {t/factor:.5g} {scene.time_unit}   {n}/{len(trace.time_s)}'
        bounds=draw.textbbox((6,5),label,font=font)
        draw.rectangle((2,2,bounds[2]+4,bounds[3]+3),fill=(255,255,255,235))
        draw.text((6,5),label,font=font,fill=(37,67,93,255))
        picture.paste(layer,(left,top))
        return picture
    def frames():
        # Derive one palette from the complete cloud, not the almost empty
        # first frame; this preserves marker colors without frame flicker.
        palette=render(1.).quantize(colors=256)
        for fraction in np.linspace(0.,1.,count):
            # Paletted frames bound storage to <=72 MB at the maximum size.
            yield render(fraction).quantize(palette=palette,dither=Image.Dither.NONE)
    descriptor,temporary=tempfile.mkstemp(prefix='.xy_gif_',suffix='.gif',dir=path.parent)
    os.close(descriptor)
    try:
        stream=frames();first=next(stream)
        first.save(temporary,format='GIF',save_all=True,append_images=stream,
                   duration=frame_ms,loop=0,disposal=2,optimize=False)
        if cancel.is_set():raise Cancelled('Сохранение GIF отменено')
        os.replace(temporary,path)
    finally:
        if os.path.exists(temporary):os.unlink(temporary)
    return str(path)
