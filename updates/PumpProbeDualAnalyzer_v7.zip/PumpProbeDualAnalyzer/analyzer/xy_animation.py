"""Small blitted XY player; the main report never redraws on animation ticks."""
from io import BytesIO
from pathlib import Path
import time
import numpy as np
from PIL import Image
from PyQt5.QtCore import Qt,QTimer,QThreadPool
from PyQt5.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QPushButton,QSlider,
    QLabel,QDoubleSpinBox,QComboBox,QCheckBox,QFileDialog)
from matplotlib.figure import Figure
from matplotlib.font_manager import findfont,FontProperties
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from .quadrature_trace import trace_counts
from .tasks import Job
from .xy_gif import GifScene,write_xy_gif


class XYAnimationDialog(QDialog):
    def __init__(self,trace,style,default_path,parent=None):
        super().__init__(parent);self.setAttribute(Qt.WA_DeleteOnClose)
        self.setWindowTitle('X₂–Y₂ · развитие с задержкой');self.resize(820,700)
        self.trace,self.style,self.default_path=trace,dict(style),Path(default_path)
        self._fraction=0.;self._background=None;self._capturing=False
        self.job=None;self.closing=False
        self.pool=QThreadPool(self);self.pool.setMaxThreadCount(1)
        self.timer=QTimer(self);self.timer.setInterval(67);self.timer.timeout.connect(self._tick)
        layout=QVBoxLayout(self)
        note=QLabel('Пары появляются с увеличением задержки t на линии. Это воспроизведение готовых данных; τ затухания не меняется.')
        note.setWordWrap(True);layout.addWidget(note)
        self.figure=Figure(figsize=(7.5,4.8),dpi=100,facecolor='white')
        self.canvas=FigureCanvasQTAgg(self.figure);layout.addWidget(self.canvas,1)
        self.axes=self.figure.add_subplot(111)
        self.figure.subplots_adjust(left=.14,right=.97,bottom=.14,top=.77)
        self.figure.suptitle(style['title'],fontsize=12,color='#25435d')
        self.axes.set_title(style['plane_title'],fontsize=11,pad=32)
        self.axes.set_xlabel(style['xlabel']);self.axes.set_ylabel(style['ylabel'])
        self.axes.set_xlim(style['xlim']);self.axes.set_ylim(style['ylim'])
        self.axes.set_aspect('equal',adjustable='box')
        self.axes.grid(True,alpha=.17)
        self.axes.axhline(0,color='#91a1b0',lw=.6,alpha=.5)
        self.axes.axvline(0,color='#91a1b0',lw=.6,alpha=.5)
        # Convert once for the small player, keeping both axes in the same unit.
        scale=style['scale']
        from matplotlib.ticker import FuncFormatter
        for axis in (self.axes.xaxis,self.axes.yaxis):axis.set_major_formatter(FuncFormatter(lambda value,pos:f'{value/scale:.6g}'))
        self.points=self.axes.plot([],[],ls='none',marker='o',ms=3,color='#6850a1',alpha=style['alpha'],mew=0,animated=True,label=style['points_label'])[0]
        self.fitted=self.axes.plot([],[],lw=1.8,color='#d66b30',animated=True,label=style['fit_label'])[0]
        self.current=self.axes.plot([],[],ls='none',marker='o',ms=5,color='#147c9c',mew=0,animated=True)[0]
        self.canvas.mpl_connect('draw_event',self._on_draw)
        self.slider=QSlider(Qt.Horizontal);self.slider.setRange(0,1000)
        self.slider.valueChanged.connect(self._seek);layout.addWidget(self.slider)
        row=QHBoxLayout();self.play_button=QPushButton('▶ Воспроизвести');self.reset_button=QPushButton('В начало');self.all_button=QPushButton('Все точки')
        for button in (self.play_button,self.reset_button,self.all_button):row.addWidget(button)
        self.fit_check=QCheckBox('Фит X₂/Y₂');self.fit_check.setEnabled(trace.has_fit)
        self.fit_check.setChecked(trace.has_fit and style['fit_visible']);row.addWidget(self.fit_check)
        layout.addLayout(row)
        row=QHBoxLayout();row.addWidget(QLabel('Длительность, s'))
        self.duration=QDoubleSpinBox();self.duration.setRange(1,20);self.duration.setValue(6);self.duration.setDecimals(1);self.duration.setKeyboardTracking(False)
        row.addWidget(self.duration);row.addWidget(QLabel('GIF, кадров/s'))
        self.fps=QComboBox();self.fps.addItems(['5','10','15','20','25']);self.fps.setCurrentText('15');row.addWidget(self.fps)
        self.save_button=QPushButton('Сохранить GIF…');self.cancel_button=QPushButton('Отмена GIF');self.cancel_button.setEnabled(False)
        row.addWidget(self.save_button);row.addWidget(self.cancel_button);layout.addLayout(row)
        self.counter=QLabel();layout.addWidget(self.counter)
        self.status=QLabel('GIF: отдельная плоскость, до 150 кадров и 800×600 px. Все экспериментальные точки сохраняются.')
        self.status.setWordWrap(True);layout.addWidget(self.status)
        self.play_button.clicked.connect(self.toggle_play)
        self.reset_button.clicked.connect(lambda:self._seek(0))
        self.all_button.clicked.connect(lambda:self._seek(1000))
        self.fit_check.toggled.connect(self._fit_toggled)
        self.duration.valueChanged.connect(self._duration_changed)
        self.save_button.clicked.connect(self.save_gif);self.cancel_button.clicked.connect(self.cancel_export)
        self._legend();self._show_fraction(0.)

    def _legend(self):
        previous=self.axes.get_legend()
        if previous is not None:previous.remove()
        handles=[]
        if self.style['points_label']:handles.append(self.points)
        if self.fit_check.isChecked() and self.style['fit_label']:handles.append(self.fitted)
        if handles:self.axes.legend(handles=handles,fontsize=8,loc='lower center',bbox_to_anchor=(.5,1.01),ncol=2,frameon=False)

    def _fit_toggled(self):
        self._show_fraction(self._fraction);self._legend();self.canvas.draw_idle()

    def _on_draw(self,event):
        self._background=self.canvas.copy_from_bbox(self.axes.bbox)
        if not self._capturing:
            for artist in (self.points,self.fitted,self.current):
                if artist.get_visible():self.axes.draw_artist(artist)

    def _paint(self):
        if self._background is None:self.canvas.draw_idle();return
        self.canvas.restore_region(self._background)
        for artist in (self.points,self.fitted,self.current):
            if artist.get_visible():self.axes.draw_artist(artist)
        self.canvas.blit(self.axes.bbox)

    def _show_fraction(self,fraction):
        self._fraction=float(np.clip(fraction,0,1))
        n,m,t=trace_counts(self.trace,self._fraction)
        self.points.set_data(self.trace.x_v[:n],self.trace.y_v[:n])
        self.fitted.set_data(self.trace.fit_x_v[:m],self.trace.fit_y_v[:m])
        self.fitted.set_visible(self.fit_check.isChecked())
        self.current.set_data(self.trace.x_v[n-1:n],self.trace.y_v[n-1:n])
        self.slider.blockSignals(True);self.slider.setValue(round(self._fraction*1000));self.slider.blockSignals(False)
        factor=1e-12 if self.style['time_unit']=='ps' else 1e-9
        self.counter.setText(f't = {t/factor:.6g} {self.style["time_unit"]} · точек {n}/{len(self.trace.time_s)}')
        self._paint()

    def _pause(self):
        self.timer.stop();self.play_button.setText('▶ Воспроизвести')

    def _seek(self,value):
        self._pause();self._show_fraction(value/1000.)

    def toggle_play(self):
        if self.timer.isActive():self._pause();return
        if self._fraction>=1:self._show_fraction(0.)
        self._started=time.perf_counter()-self._fraction*self.duration.value()
        self.timer.start();self.play_button.setText('Ⅱ Пауза')

    def _duration_changed(self):
        if self.timer.isActive():self._started=time.perf_counter()-self._fraction*self.duration.value()

    def _tick(self):
        fraction=(time.perf_counter()-self._started)/self.duration.value()
        self._show_fraction(fraction)
        if fraction>=1:self._pause()

    def gif_scene(self):
        """Capture static pixels and transforms once; encoding runs in a worker."""
        self._pause();self._capturing=True
        try:
            self.canvas._draw_pending=False
            self.canvas.draw()
            picture=Image.fromarray(np.asarray(self.canvas.buffer_rgba()).copy())
            original=picture.size;picture.thumbnail((800,600),Image.Resampling.LANCZOS)
            sx,sy=picture.width/original[0],picture.height/original[1]
            def pixels(x,y):
                values=self.axes.transData.transform(np.column_stack((x,y)))
                return values*np.array([sx,-sy])+np.array([0,picture.height])
            box=self.axes.bbox
            clip=(max(0,int(np.ceil(box.x0*sx))),max(0,int(np.ceil((original[1]-box.y1)*sy))),
                  min(picture.width,int(np.floor(box.x1*sx))),min(picture.height,int(np.floor((original[1]-box.y0)*sy))))
            buffer=BytesIO();picture.save(buffer,format='PNG')
            return GifScene(buffer.getvalue(),pixels(self.trace.x_v,self.trace.y_v),
                pixels(self.trace.fit_x_v,self.trace.fit_y_v),clip,self.style['alpha'],
                self.fit_check.isChecked(),max(1.,self.figure.dpi/72*1.5*sx),
                max(1,round(self.figure.dpi/72*1.8*sx)),self.style['time_unit'],findfont(FontProperties()))
        finally:
            self._capturing=False;self._paint()

    def save_gif(self):
        if self.job is not None:return
        path,_=QFileDialog.getSaveFileName(self,'Сохранить развитие X₂–Y₂',str(self.default_path),'GIF (*.gif)')
        if not path:return
        if Path(path).suffix.lower()!='.gif':path+='.gif'
        try:scene=self.gif_scene()
        except Exception as exc:self.status.setText(str(exc));return
        duration,fps=self.duration.value(),int(self.fps.currentText())
        self.job=Job('GIF',lambda cancel:write_xy_gif(path,self.trace,scene,duration,fps,cancel))
        self.job.signals.completed.connect(self._export_finished)
        self.save_button.setEnabled(False);self.cancel_button.setEnabled(True)
        self.status.setText('Создание GIF в фоне…');self.pool.start(self.job)

    def cancel_export(self):
        if self.job is not None:self.job.cancel.set()

    def _export_finished(self,package):
        _,value,error=package;cancelled=self.job.cancel.is_set();self.job=None
        self.save_button.setEnabled(True);self.cancel_button.setEnabled(False)
        self.status.setText('Сохранение GIF отменено.' if cancelled else ('Ошибка: '+error if error else 'Сохранено: '+str(value)))
        if self.closing:self.close()

    def keyPressEvent(self,event):
        if event.key()==Qt.Key_Escape:
            self.close();event.accept()
        else:super().keyPressEvent(event)

    def hideEvent(self,event):
        self._pause();super().hideEvent(event)

    def closeEvent(self,event):
        self.closing=True;self._pause();self.cancel_export()
        if self.pool.activeThreadCount():
            event.ignore();QTimer.singleShot(100,self.close)
        else:super().closeEvent(event)
