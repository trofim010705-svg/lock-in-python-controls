"""Experimental XY pairs and a parametric curve from two independent fits."""
from dataclasses import dataclass
import numpy as np
from .core import evaluate


@dataclass(frozen=True)
class QuadratureTrace:
    time_s: np.ndarray
    x_v: np.ndarray
    y_v: np.ndarray
    fit_time_s: np.ndarray
    fit_x_v: np.ndarray
    fit_y_v: np.ndarray

    @property
    def has_fit(self):
        return bool(len(self.fit_time_s)>1 and np.any(np.isfinite(self.fit_x_v)&np.isfinite(self.fit_y_v)))


def quadrature_trace(diagnostics,results=None,fit_prepared=None,samples=1500):
    """Evaluate both models at identical times, using each model's own t_ref.

    No extrapolation beyond either fitted interval; all data stay in volts.
    Sorting by increasing delay also defines playback order, not acquisition
    wall-clock time. Detached arrays make animation/export a stable snapshot.
    """
    empty=lambda:np.array([],dtype=float)
    x,y=diagnostics.get('x2'),diagnostics.get('y2')
    if x is None or y is None:
        return QuadratureTrace(*(empty() for _ in range(6)))
    if x.time.shape!=y.time.shape or not np.array_equal(x.time,y.time):
        raise ValueError('Для плоскости X2/Y2 нужны пары с одинаковыми временами.')
    mask=x.fit_mask&y.fit_mask&np.isfinite(x.time)&np.isfinite(x.y)&np.isfinite(y.y)
    indices=np.flatnonzero(mask);indices=indices[np.argsort(x.time[indices],kind='stable')]
    time,xv,yv=(np.array(a[indices],copy=True) for a in (x.time,x.y,y.y))
    ft,fx,fy=empty(),empty(),empty()
    results=results or {};inputs=fit_prepared or {}
    rx,ry=results.get('x2'),results.get('y2')
    if rx is not None and ry is not None and len(time)>1:
        bounds=[]
        for key,source in (('x2',x),('y2',y)):
            p=inputs.get(key,source)
            valid=p.fit_mask&np.isfinite(p.time)&np.isfinite(p.y)
            if np.count_nonzero(valid)<2:break
            t=p.time[valid];bounds.append((float(np.min(t)),float(np.max(t))))
        if len(bounds)==2:
            lo=max(time[0],bounds[0][0],bounds[1][0])
            hi=min(time[-1],bounds[0][1],bounds[1][1])
            if lo<hi:
                ft=np.linspace(lo,hi,max(2,int(samples)))
                fx=evaluate(ft,rx.parameters,rx.reference_s)
                fy=evaluate(ft,ry.parameters,ry.reference_s)
                invalid=~np.isfinite(fx)|~np.isfinite(fy)
                fx[invalid]=np.nan;fy[invalid]=np.nan
    return QuadratureTrace(time,xv,yv,ft,fx,fy)


def trace_counts(trace,fraction):
    """Cumulative sample/model counts at a fraction of the physical time range."""
    if not len(trace.time_s):return 0,0,float('nan')
    fraction=float(np.clip(fraction,0.,1.))
    t=float(trace.time_s[0]+fraction*(trace.time_s[-1]-trace.time_s[0]))
    if fraction==1.:t=float(trace.time_s[-1])
    return (int(np.searchsorted(trace.time_s,t,side='right')),
            int(np.searchsorted(trace.fit_time_s,t,side='right')),t)
