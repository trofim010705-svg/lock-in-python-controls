"""Data and reports for the two-channel app; image bytes come from the live canvas."""
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
import json
import numpy as np
from . import core
from .dual_core import normalize_signals
from .dual_signals import DIAGNOSTIC_UNITS, diagnostics_metadata
from .dual_fit_support import overlay_values
from .export import spectral_peaks, write_picture, _clean_json


def comparison_text(comparison, unit1='rad', unit2='V'):
    if comparison is None:
        return 'Сравнение доступно после успешных фитов обоих сигналов.'
    c=comparison
    def number(value): return '—' if value is None else f'{value:.6g}'
    return '\n'.join([
        f'Сравнение: X1, мода {c["first_component"]+1}; R2, мода {c["second_component"]+1}',
        f't_ref = {c["reference_s"]/1e-9:.6g} ns; f_X1 = {c["frequency_x1_hz"]/1e9:.6g} GHz; f_R2 = {c["frequency_r2_hz"]/1e9:.6g} GHz',
        f'Δφ = φ_R2 − φ_X1 = {number(None if c["delta_phase_deg"] is None else c["delta_phase_deg"]%360)}° [0,360) при t_ref',
        f'A_R2 / A_X1 = {number(c["amplitude_ratio"])} (по вольтам, до нормировки)',
        f'Δf = {c["delta_frequency_hz"]/1e9:.6g} GHz; Δφ(t) = [Δφ(t_ref) + 360° Δf (t − t_ref)] mod 360°; Δf в Hz',
    ])


def build_dual_report(snapshot):
    p=snapshot['prepared']; m=snapshot['measurement']
    peak_enabled={key:bool(snapshot.get('fft_peak_enabled',{}).get(key,True))
                  for key in ('x1','x2','y2','r2','phase2')}
    peak_enabled['phase2']=False  # its panel now contains the experimental XY cloud
    channels=[]
    for index,(name,prepared,result,unit,factor) in enumerate(zip(
            ('X1','R2'),(p.first,p.second),snapshot['results'],
            (p.first_unit,p.second_unit),(p.first_factor,p.second_factor))):
        original=snapshot['initials'][index]
        p0=np.asarray([] if original is None else original,dtype=float)
        count=snapshot['components'][index]
        if result is not None and (len(p0)!=len(result.parameters) or not np.isfinite(p0).all()):
            raise ValueError('Для отчёта нужен точный набор стартовых параметров завершённого фита '+name)
        parameters=[]
        if result is not None:
            for (label,original_unit),value,error in zip(core.names(count),result.parameters,result.errors):
                pinned=label.startswith('f') and not label.startswith('phi') and int(label[1:])-1 in getattr(result,'fixed_frequencies',{})
                cyclic=label.startswith('phi')
                parameters.append(dict(name=label,unit='deg' if cyclic else (unit if label.startswith('A') or label=='C' else original_unit),
                    value=float(np.rad2deg(value)%360) if cyclic else float(value),
                    stderr=float(np.rad2deg(error)) if cyclic else float(error),value_si=float(value),stderr_si=float(error),fixed=pinned))
        norm=None
        if result is not None:
            try:
                _,_,scale=normalize_signals(prepared,result)
                norm=dict(offset=float(result.parameters[-1]),scale=scale,unit=unit)
            except ValueError: pass
        channels.append(dict(name=name,unit=unit,units_per_volt=factor,
            settings=asdict(prepared.settings),common_time_count=len(prepared.time),
            fit_point_count=int(prepared.fit_mask.sum()),
            fft_band_hz=list(snapshot['bands'][index]),fft_resolution_hz=prepared.resolution_hz,
            fft_peaks=spectral_peaks(prepared,snapshot['bands'][index]) if peak_enabled[name.lower()] else [],
            fft_peaks_included=peak_enabled[name.lower()],
            initial_parameters=p0.tolist(),initial_parameters_note='Exact p0 passed to the completed fit; multistart also tests spectral alternatives.',
            model_components=count,normalization=norm,preparation_messages=list(prepared.warnings),
            fixed_frequencies_hz=getattr(result,'fixed_frequencies',{}) if result is not None else snapshot.get('fixed_frequencies',{}).get(name.lower(),{}),
            fit=None if result is None else dict(parameters=parameters,reference_s=result.reference_s,
                rmse=result.rmse_rad,r_squared=result.r_squared,warnings=list(result.warnings),
                evaluations=result.evaluations,jacobian_condition=result.condition)))
    diagnostics=[]
    for key,prepared in snapshot.get('diagnostics',{}).items():
        fit_input=snapshot.get('diagnostic_fit_prepared',{}).get(key,prepared)
        result=snapshot.get('diagnostic_results',{}).get(key)
        initial=snapshot.get('diagnostic_initials',{}).get(key)
        p0=np.asarray([] if initial is None else initial,dtype=float)
        if result is not None and (len(p0)!=len(result.parameters) or not np.isfinite(p0).all()):
            raise ValueError('Для отчёта нужен точный p0 завершённого фита '+key)
        count=(len(result.parameters)-1)//4 if result is not None else snapshot.get('diagnostic_components',{}).get(key,1)
        band=snapshot.get('diagnostic_bands',{}).get(key,(0.,fit_input.nyquist_hz))
        peaks=spectral_peaks(fit_input,band) if peak_enabled[key] else []
        parameters=[]
        if result is not None:
            for (label,original_unit),value,error in zip(core.names(count),result.parameters,result.errors):
                pinned=label.startswith('f') and not label.startswith('phi') and int(label[1:])-1 in getattr(result,'fixed_frequencies',{})
                cyclic=label.startswith('phi') or (key=='phase2' and label=='C')
                conversion=180/np.pi if label.startswith('phi') or (key=='phase2' and (label.startswith('A') or label=='C')) else 1.
                display_unit='deg' if conversion!=1. else (DIAGNOSTIC_UNITS[key] if label.startswith('A') or label=='C' else original_unit)
                parameters.append(dict(name=label,unit=display_unit,
                    value=(float(value)*conversion)%360 if cyclic else float(value)*conversion,
                    stderr=float(error)*conversion,value_si=float(value),stderr_si=float(error),fixed=pinned))
        if key=='phase2':
            for peak in peaks:peak.update(amplitude=float(np.rad2deg(peak['amplitude_rad'])),amplitude_unit='deg')
        diagnostics.append(dict(name=key,unit=DIAGNOSTIC_UNITS[key],
            common_time_count=len(prepared.time),fit_point_count=int(fit_input.fit_mask.sum()),
            undefined_point_count=int(np.count_nonzero(~np.isfinite(prepared.raw_rad))),
            fft_band_hz=list(band),fft_resolution_hz=fit_input.resolution_hz,
            fft_peaks=peaks,fft_maximum=peaks[0] if peaks else None,fft_peaks_included=peak_enabled[key],
            messages=list(fit_input.warnings),model_components=count,initial_parameters=p0.tolist(),phase_quality=dict(prepared.phase_info),
            display_unit='deg' if key=='phase2' else DIAGNOSTIC_UNITS[key],
            fixed_frequencies_hz=getattr(result,'fixed_frequencies',{}) if result is not None else snapshot.get('fixed_frequencies',{}).get(key,{}),
            fit_time_window_s=[float(fit_input.time[fit_input.fit_mask][0]),float(fit_input.time[fit_input.fit_mask][-1])] if fit_input.fit_mask.any() else None,
            fit=None if result is None else dict(parameters=parameters,reference_s=result.reference_s,
                rmse=result.rmse_rad,r_squared=result.r_squared,warnings=list(result.warnings),
                evaluations=result.evaluations,jacobian_condition=result.condition)))
    sources={'x1':p.first,'r2':p.second,**snapshot.get('diagnostics',{})}
    fit_sources={'x1':p.first,'r2':p.second,**snapshot.get('diagnostic_fit_prepared',{})}
    fit_results={'x1':snapshot['results'][0],'r2':snapshot['results'][1],**snapshot.get('diagnostic_results',{})}
    overlay=[]
    for key in snapshot.get('overlay_signals',('x1','r2')):
        if key not in sources:continue
        series=fit_sources.get(key,sources[key]) if fit_results.get(key) is not None else sources[key]
        norm=overlay_values(series,fit_results.get(key))
        overlay.append(dict(signal=key,method=norm['method'],scale=norm['scale'],offset=norm['offset'],
            window_s=[float(series.time[norm['mask']][0]),float(series.time[norm['mask']][-1])] if norm['mask'].any() else None))
    definitions=diagnostics_metadata()
    if 'phase2' in snapshot.get('diagnostic_fit_prepared',{}):
        definitions['phase_full_window_fft']=definitions['phase_fft']
        definitions['phase_fft']='Internal seed for the phase fit only; no phase FFT plot or peak list. Tables retained for reproducibility. One continuous above-threshold local branch: minimum 16 points, circular adjacent steps <=90deg, total excursion <=180deg. No global noise unwrap.'
    definitions['quadrature_plane']='X-axis=X2_processed_V, Y-axis=Y2_processed_V, paired at the same experimental time inside the common analysis window; current rotation and background subtraction applied. Equal axis scales, no smoothing or phase-threshold exclusion.'
    angle=float(snapshot.get('rotation_deg',0.))
    fixed_configuration={channel['name'].lower():dict(channel['fixed_frequencies_hz']) for channel in channels}
    fixed_configuration.update({channel['name']:dict(channel['fixed_frequencies_hz']) for channel in diagnostics})
    definitions['quadrature_rotation']='X2r=X2*cos(angle)+Y2*sin(angle); Y2r=-X2*sin(angle)+Y2*cos(angle). Original inputs and R2 are unchanged. Phase uses the SAME background-processed quadratures, shifted by -angle modulo360deg. Auto can use the selected frequency band after linear detrending.'
    definitions['quadrature_fit']='Parametric curve (X2_fit(t),Y2_fit(t)) from the already completed independent fits, evaluated at identical delays using each fit own t_ref; only the intersection of their fitting intervals, no extrapolation or new fit. Hidden if either X2/Y2 fit visibility is off.'
    report=dict(application='Pump–Probe Dual Analyzer v7',created_utc=datetime.now(timezone.utc).isoformat(),
        title=snapshot.get('title',''),data_file=m.data_path,notes_file=m.notes_path,
        raw_point_count=len(m.position),source_unit=m.signal_unit,
        second_signal='R2 = hypot(X2, Y2), computed per original row before duplicate positions are averaged.',
        calibration=dict(first_units_per_volt=p.first_factor,second_units_per_volt=p.second_factor,
            first_unit=p.first_unit,second_unit=p.second_unit,
            note='For R2 in volts no Bal/Sig conversion is applied. Amplitude ratios use voltage-equivalent amplitudes.'),
        model='S(u) = sum_i A_i exp(-u/tau_i) sin(2*pi*f_i*u + phi_i) + C; u=t-t_ref',
        channels=channels,comparison=snapshot.get('comparison'),selected_pair=list(snapshot['pair']),
        normalization_definition='With a fit: (processed data - fitted C) / max(abs(fit - C)), same scale for data and fit. Without a usable fit: subtract finite-window mean and divide by max absolute centered data. Constant signals give zero. Experimental noise may exceed 1.',
        normalized_plot_enabled=bool(snapshot.get('normalization',True)),point_alphas=list(snapshot.get('alphas',(.45,.45))),
        time_unit=snapshot.get('time_unit','ns'),annotation=snapshot.get('annotation',''),
        diagnostics=diagnostics,diagnostics_definitions=definitions,
        plot_labels=dict(snapshot.get('labels',{})),fit_lines_visible=list(snapshot.get('fit_visible',(True,True))),
        footer_visible=bool(snapshot.get('footer_visible',True)),
        normalized_unit='a.u.',
        overlay_signals=list(snapshot.get('overlay_signals',('x1','r2'))),overlay_normalization=overlay,
        signal_alphas=dict(snapshot.get('signal_alphas',{})),fit_visibility=dict(snapshot.get('fit_visibility',{})),
        fit_enabled=dict(snapshot.get('fit_enabled',{})),
        fft_peak_enabled=peak_enabled,
        quadrature_rotation=dict(angle_deg=angle,information=dict(snapshot.get('rotation_info',{}))),
        fixed_frequencies=fixed_configuration,
        frequency_constraint_definition='Zero-based component indices. Fixed frequencies are external constraints excluded from optimization. Their zero standard error is not an uncertainty measurement. Fixed frequencies may lie outside the FFT seed band, through Nyquist; free frequencies stay inside the selected band.',
        phase_fit_definition='Phase shown in degrees [0,360). FFT/fit only on a locally continuous above-threshold branch: >=16 points, adjacent circular steps <=90deg, total excursion <=180deg. No artificial global unwrap. Gray/low-amplitude points excluded. Internal fitting values remain radians; phase-time/spectrum tables include explicit degree and SI versions.',
        interpretation='The phase of the fitted R2 oscillation is not atan2(Y2,X2) or the channel-2 carrier phase. Magnitude loses quadrature phase and can produce DC or harmonics. For unequal fitted frequencies, phase difference is only specified at the stated reference and evolves with delta f. No cross-channel uncertainty propagation is claimed.',
        fwhm_definition='Amplitude |FFT| half height A_peak/2, linear interpolation over full spectrum. Finite record and FFT window broaden measured width. Missing/merged crossings have null width.')
    return _clean_json(report)


def dual_report_text(report):
    def n(value): return 'не определено' if value is None else f'{value:.12g}'
    lines=['PUMP–PROBE DUAL ANALYSIS',f'Title: {report["title"]}',
        f'Data: {report["data_file"]}',f'Parameters: {report["notes_file"]}',
        f'Created UTC: {report["created_utc"]}',report['second_signal'],'',
        'MODEL',report['model'],'','CROSS-CHANNEL COMPARISON',comparison_text(report['comparison']),
        '','INTERPRETATION',report['interpretation'],'',
        'NORMALIZATION',report['normalization_definition'],'',
        f'Experimental point alpha X1/R2: {report["point_alphas"]}; fits alpha=1.',
        '','QUADRATURE ROTATION',json.dumps(report.get('quadrature_rotation',{}),ensure_ascii=False,indent=2),
        report.get('diagnostics_definitions',{}).get('quadrature_rotation',''),
        '','FIXED FREQUENCIES',report.get('frequency_constraint_definition',''),
        json.dumps(report.get('fixed_frequencies',{}),ensure_ascii=False,indent=2),
        'FWHM',report['fwhm_definition']]
    for channel in report['channels']:
        unit=channel['unit']; cfg=channel['settings']
        lines+=['','='*64,channel['name'],f'Signal unit: {unit}; units per V: {n(channel["units_per_volt"])}',
            f'Common points: {channel["common_time_count"]}; fit points: {channel["fit_point_count"]}',
            f'x0_mm: {n(cfg["zero_mm"])}; time = 2*(position_mm-x0_mm)*1e-3/c',
            f'Fit window ns: {n(cfg["fit_min_s"]/1e-9)} .. {n(cfg["fit_max_s"]/1e-9)}',
            'Settings SI: '+json.dumps(cfg,ensure_ascii=False),
            'Initial p0 SI/native: '+json.dumps(channel['initial_parameters']),channel['initial_parameters_note']]
        if channel.get('fft_peaks_included',True):
            lines.append('FFT PEAKS: frequency_GHz | amplitude_'+unit+' | FWHM_GHz | width_status')
            for peak in channel['fft_peaks']:
                lines.append(f'{n(peak["frequency_ghz"])} | {n(peak["amplitude_rad"])} | {n(peak["fwhm_ghz"])} | {peak["fwhm_status"]}')
        fit=channel['fit']
        if fit is None: lines.append('FIT: not available')
        else:
            lines+=['FIT',f't_ref_s={n(fit["reference_s"])}; R2={n(fit["r_squared"])}; RMSE_{unit}={n(fit["rmse"])}']
            for param in fit['parameters']:
                label=param['name']; val=param['value']; error=param['stderr']; u=param['unit']
                lines.append(f'{label} = {n(val)} {u} [fixed]' if param.get('fixed') else f'{label} = {n(val)} +/- {n(error)} {u}')
                if label.startswith('f') and not label.startswith('phi'):
                    lines.append(f'    {n(val/1e9)} GHz')
                if label.startswith('tau'):lines.append(f'    {n(val/1e-9)} ns')
            if fit['warnings']:lines+=['FIT MESSAGES']+fit['warnings']
        if channel['preparation_messages']:lines+=['PREPARATION MESSAGES']+channel['preparation_messages']
    if report['comparison'] is not None:
        lines+=['','COMPARISON DETAILS SI',json.dumps(report['comparison'],ensure_ascii=False,indent=2)]
    lines+=['','DIAGNOSTIC DEFINITIONS',json.dumps(report.get('diagnostics_definitions',{}),ensure_ascii=False,indent=2)]
    for diagnostic in report.get('diagnostics',[]):
        lines+=['','DIAGNOSTIC '+diagnostic['name'],f'Internal unit: {diagnostic["unit"]}; display unit: {diagnostic.get("display_unit",diagnostic["unit"])}; undefined points: {diagnostic["undefined_point_count"]}',
            'Initial p0 SI/native: '+json.dumps(diagnostic.get('initial_parameters',[])),
            'Fit interval s: '+json.dumps(diagnostic.get('fit_time_window_s'))]
        if diagnostic.get('fft_peaks_included',True):
            lines.append('FFT: frequency_GHz | amplitude_'+diagnostic.get('display_unit',diagnostic['unit'])+' | FWHM_GHz | width_status')
            for peak in diagnostic['fft_peaks']:
                lines.append(f'{n(peak["frequency_ghz"])} | {n(peak.get("amplitude",peak["amplitude_rad"]))} | {n(peak["fwhm_ghz"])} | {peak["fwhm_status"]}')
            if not diagnostic['fft_peaks']:lines.append('FFT unavailable or no nonzero spectrum.')
        fit=diagnostic.get('fit')
        if fit is None:lines.append('FIT: not available')
        else:
            rmse=np.rad2deg(fit['rmse']) if diagnostic['name']=='phase2' and fit['rmse'] is not None else fit['rmse']
            lines+=['FIT',f't_ref_s={n(fit["reference_s"])}; R2={n(fit["r_squared"])}; RMSE={n(rmse)} {diagnostic.get("display_unit",diagnostic["unit"])}']
            for param in fit['parameters']:
                lines.append(f'{param["name"]} = {n(param["value"])} {param["unit"]} [fixed]' if param.get('fixed') else f'{param["name"]} = {n(param["value"])} +/- {n(param["stderr"])} {param["unit"]}')
            if fit['warnings']:lines+=['FIT MESSAGES']+fit['warnings']
        if diagnostic['messages']:lines+=diagnostic['messages']
        if diagnostic.get('phase_quality'):lines+=['PHASE QUALITY',json.dumps(diagnostic['phase_quality'],ensure_ascii=False,indent=2)]
    lines+=['','PRESENTATION',f'Normalized unit: {report.get("normalized_unit","a.u.")}',
        f'Fit lines X1/R2 visible: {report.get("fit_lines_visible",[True,True])}',
        f'Parameter footer visible: {report.get("footer_visible",True)}',
        'Plot labels: '+json.dumps(report.get('plot_labels',{}),ensure_ascii=False,indent=2)]
    lines+=['Overlay signals: '+json.dumps(report.get('overlay_signals',[])),
        'Overlay normalization: '+json.dumps(report.get('overlay_normalization',[]),ensure_ascii=False),
        'Fit visibility: '+json.dumps(report.get('fit_visibility',{})),
        'Fit calculation enabled: '+json.dumps(report.get('fit_enabled',{})),
        'FFT peak text enabled: '+json.dumps(report.get('fft_peak_enabled',{})),
        'Phase fit: '+report.get('phase_fit_definition','')]
    if report['annotation']:lines+=['','ANNOTATION',report['annotation']]
    return '\n'.join(lines)+'\n'


def export_dual(base, snapshot, image_payloads):
    """Create a fresh export folder; never overwrite a previous result."""
    base=Path(base); base.parent.mkdir(parents=True,exist_ok=True)
    report=build_dual_report(snapshot)
    for i in range(10000):
        folder=base if i==0 else base.with_name(base.name+f'_{i:03d}')
        try:folder.mkdir();break
        except FileExistsError:continue
    else:raise OSError('Не удалось выбрать папку экспорта')
    m=snapshot['measurement']; p=snapshot['prepared']; text=dual_report_text(report)
    np.savetxt(folder/'input_channels.tsv',np.c_[m.position,m.x1,m.x2,m.y2,np.hypot(m.x2,m.y2)],
        delimiter='\t',header='Position_file_units\tX1_V\tX2_V\tY2_V\tR2_V',comments='')
    from .quadrature_rotation import rotate_quadratures
    rotated_x,rotated_y=rotate_quadratures(m.x2,m.y2,snapshot.get('rotation_deg',0.))
    np.savetxt(folder/'rotated_channels.tsv',np.c_[m.position,rotated_x,rotated_y,np.hypot(m.x2,m.y2)],
        delimiter='\t',header='Position_file_units\tX2_rotated_V\tY2_rotated_V\tR2_V',comments='')
    normalized=[p.first.time]
    for name,prepared,result,unit,band in zip(('X1','R2'),(p.first,p.second),snapshot['results'],
            (p.first_unit,p.second_unit),snapshot['bands']):
        prediction=np.full(len(prepared.time),np.nan)
        if result is not None:
            prediction[prepared.fit_mask]=core.evaluate(prepared.time[prepared.fit_mask],result.parameters,result.reference_s)
        np.savetxt(folder/(name+'_time.tsv'),np.c_[prepared.time,prepared.raw_rad,prepared.background,prepared.y,prediction,prepared.y-prediction,prepared.fit_mask],
            delimiter='\t',header=f'Time_s\tRaw_{unit}\tBackground_{unit}\tProcessed_{unit}\tFit_{unit}\tResidual_{unit}\tFit_mask',comments='')
        np.savetxt(folder/(name+'_spectrum.tsv'),np.c_[prepared.frequencies,prepared.spectrum],
            delimiter='\t',header=f'Frequency_Hz\tAmplitude_{unit}',comments='')
        try:
            if result is None:raise ValueError('No fit')
            points,fitted,_=normalize_signals(prepared,result)
        except ValueError:points=fitted=np.full(len(prepared.time),np.nan)
        normalized.extend((points,fitted))
    np.savetxt(folder/'normalized.tsv',np.column_stack(normalized),delimiter='\t',
        header='Time_s\tX1_normalized\tX1_fit_normalized\tR2_normalized\tR2_fit_normalized',comments='')
    for key,prepared in snapshot.get('diagnostics',{}).items():
        unit=DIAGNOSTIC_UNITS[key]
        fit_input=snapshot.get('diagnostic_fit_prepared',{}).get(key,prepared)
        result=snapshot.get('diagnostic_results',{}).get(key)
        prediction=np.full(len(prepared.time),np.nan)
        if result is not None:
            prediction[fit_input.fit_mask]=core.evaluate(prepared.time[fit_input.fit_mask],result.parameters,result.reference_s)
        residual_si=np.angle(np.exp(1j*(prepared.y-prediction))) if key=='phase2' else prepared.y-prediction
        np.savetxt(folder/(key+'_time.tsv'),np.c_[prepared.time,prepared.raw_rad,prepared.background,prepared.y,fit_input.fit_mask,prediction,residual_si],
            delimiter='\t',header=f'Time_s\tRaw_{unit}\tBackground_{unit}\tProcessed_{unit}\tFit_mask\tFit_{unit}\tResidual_{unit}',comments='')
        np.savetxt(folder/(key+'_spectrum.tsv'),np.c_[fit_input.frequencies,fit_input.spectrum],
            delimiter='\t',header=f'Frequency_Hz\tAmplitude_{unit}',comments='')
        if key=='phase2':
            (folder/'phase2_time.tsv').rename(folder/'phase2_time_rad.tsv')
            (folder/'phase2_spectrum.tsv').rename(folder/'phase2_spectrum_rad.tsv')
            angle=np.mod(np.rad2deg(prepared.raw_rad),360.)
            valid=np.isfinite(prepared.y)
            fit_angle=np.mod(np.rad2deg(prediction),360.)
            residual=np.rad2deg(np.angle(np.exp(1j*(prepared.y-prediction))))
            np.savetxt(folder/'phase2_time.tsv',np.c_[prepared.time,angle,valid,fit_input.fit_mask,fit_angle,residual],
                delimiter='\t',header='Time_s\tPhase_deg_0_360\tAbove_threshold\tFit_mask\tFit_deg_0_360\tCircular_residual_deg',comments='')
            np.savetxt(folder/'phase2_spectrum.tsv',np.c_[fit_input.frequencies,np.rad2deg(fit_input.spectrum)],
                delimiter='\t',header='Frequency_Hz\tAmplitude_deg',comments='')
    sources={'x1':p.first,'r2':p.second,**snapshot.get('diagnostics',{})}
    if 'x2' in sources and 'y2' in sources:
        x,y=sources['x2'],sources['y2']
        mask=x.fit_mask&y.fit_mask&np.isfinite(x.y)&np.isfinite(y.y)
        np.savetxt(folder/'quadrature_xy.tsv',np.c_[x.time,x.y,y.y,mask],delimiter='\t',
            header='Time_s\tX2_processed_V\tY2_processed_V\tShown_in_XY_plot',comments='')
        from .quadrature_trace import quadrature_trace
        trace=quadrature_trace(snapshot['diagnostics'],snapshot.get('diagnostic_results'),snapshot.get('diagnostic_fit_prepared'))
        np.savetxt(folder/'quadrature_fit.tsv',np.c_[trace.fit_time_s,trace.fit_x_v,trace.fit_y_v],delimiter='\t',
            header='Time_s\tX2_fit_V\tY2_fit_V',comments='')
    fit_sources={'x1':p.first,'r2':p.second,**snapshot.get('diagnostic_fit_prepared',{})}
    results={'x1':snapshot['results'][0],'r2':snapshot['results'][1],**snapshot.get('diagnostic_results',{})}
    overlay=[p.first.time];columns=['Time_s']
    for key in snapshot.get('overlay_signals',('x1','r2')):
        if key not in sources:continue
        series=fit_sources.get(key,sources[key]) if results.get(key) is not None else sources[key]
        norm=overlay_values(series,results.get(key))
        points=np.where(norm['mask'],norm['points'],np.nan)
        overlay.extend((points,norm['fitted']));columns.extend((key+'_data_au',key+'_fit_au'))
    np.savetxt(folder/'comparison.tsv',np.column_stack(overlay),delimiter='\t',header='\t'.join(columns),comments='')
    (folder/'analysis.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    (folder/'analysis.txt').write_text(text,encoding='utf-8')
    (folder/'measurement_parameters.txt').write_text(m.notes.rstrip()+'\n\n'+'='*72+'\n'+text,encoding='utf-8')
    for ext,payload in image_payloads.items():write_picture(folder/('analysis.'+ext),payload)
    return str(folder)
