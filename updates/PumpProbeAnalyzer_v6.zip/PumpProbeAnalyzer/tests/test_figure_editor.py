"""The saved picture is the actual edited Qt canvas, not another renderer's remake."""
import os
os.environ['QT_QPA_PLATFORM']='offscreen'
os.environ.setdefault('MPLCONFIGDIR','/tmp/analyzer-editor-tests')
from io import BytesIO
import unittest
import numpy as np
from PIL import Image
from PyQt5.QtWidgets import QApplication
from matplotlib.backend_bases import MouseEvent
from analyzer.figure_editor import FigureEditor


class FigureEditorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.app=QApplication.instance() or QApplication([])

    def editor(self):
        e=FigureEditor(); e.resize(950,720); e.show(); self.app.processEvents()
        self.addCleanup(e.close)
        e.time_plot.setTitle('Editable title')
        e.points.setData([0,.5,1,1.5,2],[0,2e-6,-1e-6,1e-6,0])
        e.fit_curve.setData([0,.5,1,1.5,2],[0,1.9e-6,-.9e-6,.9e-6,0])
        e.spectrum.setData([0,2,4,6,8,10],[0,1e-6,3e-6,1e-6,.1e-6,0])
        e.time_plot.setXRange(0,2);e.fft_plot.setXRange(0,10)
        e.time_plot.enableAutoRange();e.fft_plot.enableAutoRange()
        e.legend.addItem(e.points,'Data')
        e.legend.addItem(e.fit_curve,'y = A exp(−u/τ) sin(2πfu + φ) + C\nA=2 µrad')
        e.render()
        return e

    def test_png_equals_canvas_and_vector_capture_preserves_view_and_legend(self):
        e=self.editor()
        e.time_plot.axes.set_xlim(.2,1.7)
        e.time_plot.axes.set_ylim(-2e-6,4e-6)
        e.legend.artist.set_loc((.04,.6))
        e.set_fonts(17,11)
        e.render()
        limits=e.time_plot.viewRange()
        positions=[ax.get_position().bounds for ax in e.figure.axes]
        payload=e.capture_images(('png','pdf','svg'))
        saved=np.asarray(Image.open(BytesIO(payload['png'])).convert('RGBA'))
        visible=np.asarray(e.canvas.buffer_rgba())
        np.testing.assert_array_equal(saved,visible)
        self.assertEqual(e.time_plot.viewRange(),limits)
        for before,ax in zip(positions,e.figure.axes): np.testing.assert_allclose(before,ax.get_position().bounds)
        self.assertTrue(payload['pdf'].startswith(b'%PDF'))
        self.assertIn(b'<svg',payload['svg'])
        self.assertEqual(e.time_plot.axes.title.get_fontsize(),17)
        self.assertEqual(e.legend.artist.get_texts()[0].get_fontsize(),11)
        self.assertIn('µrad',e.time_plot.axes.get_ylabel())

    def test_title_is_plain_editable_text_and_legend_position_survives_refresh(self):
        e=self.editor();requests=[]
        e.title_edit_requested.connect(lambda:requests.append(True))
        e.time_plot.setTitle('Title $\\invalid{ literal &lt;br&gt;')
        e.legend.clear();e.legend.addItem(e.points,'Data $\\invalid{')
        e.legend.artist.set_loc((.1,.4))
        e.legend.clear();e.legend.addItem(e.points,'Changed')
        e.render()
        self.assertEqual(e.time_plot.axes.get_title(),'Title $\\invalid{ literal <br>')
        self.assertFalse(e.time_plot.axes.title.get_parse_math())
        self.assertEqual(e.legend.artist._loc,(.1,.4))
        bbox=e.time_plot.axes.title.get_window_extent(e.canvas.get_renderer())
        event=MouseEvent('button_press_event',e.canvas,(bbox.x0+bbox.x1)/2,(bbox.y0+bbox.y1)/2,button=1,dblclick=True)
        e.canvas.callbacks.process('button_press_event',event)
        self.assertEqual(requests,[True])

    def test_region_drag_without_modifier_notifies_and_respects_bounds(self):
        e=self.editor();changes=[]
        e.region.setBounds((0,10));e.region.setRegion((2,4));e.render()
        e.region.sigRegionChanged.connect(lambda:changes.append(e.region.getRegion()))
        y=sum(e.fft_plot.axes.get_ylim())/2
        x0,y0=e.fft_plot.axes.transData.transform((3,y))
        x1,y1=e.fft_plot.axes.transData.transform((6,y))
        for name,xpos,ypos in [('button_press_event',x0,y0),('motion_notify_event',x1,y1),('button_release_event',x1,y1)]:
            e.canvas.callbacks.process(name,MouseEvent(name,e.canvas,xpos,ypos,button=1))
        self.assertTrue(changes)
        np.testing.assert_allclose(e.region.getRegion(),[5,7],atol=.05)
        e.region.setRegion((-5,15));self.assertEqual(e.region.getRegion(),(0.,10.))
        e.region.blockSignals(True);n=len(changes);e.region.setRegion((1,2));e.region.blockSignals(False)
        self.assertEqual(len(changes),n)
        e.region.setMovable(False);self.assertFalse(e.region.selector.active)


if __name__=='__main__':unittest.main()
