"""One editable Matplotlib figure for both on-screen display and exact export.

Adapters keep the analysis UI's numeric API: x is ns/ps or GHz, y is radians.
All Matplotlib/Qt access, including capture_images(), belongs to the GUI thread.
"""
from html import unescape
from io import BytesIO
import re
import numpy as np
from PIL import Image
from PyQt5.QtCore import QObject, pyqtSignal
from PyQt5.QtWidgets import QWidget, QVBoxLayout
from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter
from matplotlib.widgets import SpanSelector
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT
from .presentation import angle_unit


def _plain(text):
    return unescape(re.sub(r'<br\s*/?>', '\n', str(text), flags=re.IGNORECASE))


class _Toolbar(NavigationToolbar2QT):
    toolitems = tuple(item for item in NavigationToolbar2QT.toolitems
                     if item[0] in ('Home','Back','Forward','Pan','Zoom','Save',None))

    def __init__(self, canvas, editor):
        self.editor = editor
        super().__init__(canvas, editor, coordinates=True)

    def save_figure(self, *args):
        self.editor.save_requested.emit()


class Curve:
    def __init__(self, plot, **kwargs):
        self.plot = plot
        self.artist, = plot.axes.plot([], [], **kwargs)
        self.x = np.array([]); self.y = np.array([])
        plot.curves.append(self)

    def setData(self, x, y):
        self.x = np.asarray(x, dtype=float).copy()
        self.y = np.asarray(y, dtype=float).copy()
        if self.x.shape != self.y.shape:
            raise ValueError('Число координат и значений должно совпадать')
        self.artist.set_data(self.x, self.y)
        self.plot._data_changed()

    def getData(self):
        return self.x, self.y


class _AxisCompatibility:
    def enableAutoSIPrefix(self, enabled):
        # X is already explicitly converted by the analysis UI; never double-scale.
        pass


class Plot:
    def __init__(self, editor, axes):
        self.editor, self.axes = editor, axes
        self.curves = []
        self.auto_y = True
        self._programmatic = 0
        self._y_text, self._y_unit, self._y_factor = '', 'rad', 1.
        axes.set_autoscale_on(False)  # adapters own scaling; drawing never resets a user's view
        axes.grid(True, alpha=.18)
        axes.tick_params(labelsize=9, colors='#354b60')
        for spine in axes.spines.values(): spine.set_color('#a8b5c0')
        axes.callbacks.connect('ylim_changed', self._on_y_changed)
        axes.callbacks.connect('xlim_changed', self._on_x_changed)
        axes.yaxis.set_major_formatter(FuncFormatter(self._format_y))

    def _format_y(self, value, position=None):
        scaled = value/self._y_factor
        if scaled == 0: return '0'
        return f'{scaled:.6g}'

    def _update_y_unit(self):
        if self._y_unit == 'rad':
            factor, unit = angle_unit(self.axes.get_ylim())
        else:
            factor, unit = 1., self._y_unit
        self._y_factor = factor
        text = self._y_text+(' ('+unit+')' if unit else '')
        self.axes.set_ylabel(text, fontsize=10, color='#354b60', parse_math=False)

    def _on_y_changed(self, axes):
        if not self._programmatic:
            self.auto_y = False
        self._update_y_unit()

    def _on_x_changed(self, axes):
        if not self._programmatic:
            self.auto_y = False

    def setLabel(self, axis, text, units=None):
        if axis in ('bottom','top'):
            self.axes.set_xlabel(str(text)+(' ('+str(units)+')' if units else ''),
                                 fontsize=10, color='#354b60', parse_math=False)
        else:
            self._y_text, self._y_unit = str(text), units or ''
            self._update_y_unit()
        self.editor.schedule_draw()

    def setTitle(self, text, color=None, **kwargs):
        self.axes.set_title(unescape(str(text)), fontsize=self.editor.title_size,
                            color=color or '#29465d', parse_math=False)
        self.editor.schedule_draw()

    def setXRange(self, low, high, padding=0):
        if not np.isfinite([low,high]).all(): return
        if low == high: low, high = low-.01, high+.01
        extra = (high-low)*padding
        self._programmatic += 1
        try: self.axes.set_xlim(low-extra, high+extra)
        finally: self._programmatic -= 1
        if self.auto_y: self._apply_auto_y()
        self.editor.schedule_draw()

    def setYRange(self, low, high, padding=0):
        if not np.isfinite([low,high]).all() or low >= high:
            raise ValueError('Минимум Y должен быть меньше максимума')
        self.auto_y = False
        extra = (high-low)*padding
        self._programmatic += 1
        try: self.axes.set_ylim(low-extra, high+extra)
        finally: self._programmatic -= 1
        self._update_y_unit(); self.editor.schedule_draw()

    def enableAutoRange(self, axis='y', enable=True):
        self.auto_y = bool(enable)
        if self.auto_y: self._apply_auto_y()
        self.editor.schedule_draw()

    def _apply_auto_y(self):
        low,high = sorted(self.axes.get_xlim())
        values = []
        for curve in self.curves:
            finite = np.isfinite(curve.x)&np.isfinite(curve.y)
            selected = finite&(curve.x>=low)&(curve.x<=high)
            if np.any(selected): values.append(curve.y[selected])
        if not values:
            for curve in self.curves:
                finite = np.isfinite(curve.y)
                if np.any(finite): values.append(curve.y[finite])
        if not values: return
        combined = np.concatenate(values)
        bottom,top = float(np.min(combined)),float(np.max(combined))
        width = top-bottom
        margin = width*.07 if width>0 else max(abs(bottom)*.07,1e-12)
        self._programmatic += 1
        try: self.axes.set_ylim(bottom-margin,top+margin)
        finally: self._programmatic -= 1
        self._update_y_unit()

    def _data_changed(self):
        if self.auto_y: self._apply_auto_y()
        self.editor.schedule_draw()

    def viewRange(self):
        return [list(self.axes.get_xlim()),list(self.axes.get_ylim())]

    def getAxis(self, name): return _AxisCompatibility()
    def addLegend(self, **kwargs): return self.editor.legend
    def addItem(self, item): pass
    def showGrid(self, x=True, y=True, alpha=.18): self.axes.grid(x or y, alpha=alpha)


class Legend:
    def __init__(self, editor):
        self.editor = editor
        self.entries = []
        self.artist = None
        self.visible = True
        self.location = 'upper right'

    def _remember(self):
        if self.artist is not None:
            self.location = self.artist.get_loc() if hasattr(self.artist,'get_loc') else self.artist._loc

    def _remove(self):
        self._remember()
        if self.artist is not None:
            self.artist.remove(); self.artist = None

    def _rebuild(self):
        self._remove()
        if self.entries:
            self.artist = self.editor.time_plot.axes.legend(
                [curve.artist for curve,text in self.entries], [text for curve,text in self.entries],
                loc=self.location, fontsize=self.editor.legend_size,
                facecolor='white', edgecolor='#ccd7df', framealpha=.9)
            for text in self.artist.get_texts(): text.set_parse_math(False)
            self.artist.set_visible(self.visible)
            self.artist.set_draggable(True, use_blit=False, update='loc')
        self.editor.schedule_draw()

    def clear(self):
        self.entries.clear(); self._remove(); self.editor.schedule_draw()

    def setVisible(self, visible):
        self.visible = bool(visible)
        if self.artist is not None: self.artist.set_visible(self.visible)
        self.editor.schedule_draw()

    def addItem(self, curve, text):
        self.entries = [(c,t) for c,t in self.entries if c is not curve]
        self.entries.append((curve,_plain(text))); self._rebuild()

    def removeItem(self, curve):
        self.entries = [(c,t) for c,t in self.entries if c is not curve]
        self._rebuild()


class _Selector(SpanSelector):
    def __init__(self, region, **kwargs):
        self.region = region
        super().__init__(**kwargs)

    def ignore(self, event):
        if self.region.editor.toolbar.mode: return True
        return super().ignore(event)


class Region(QObject):
    sigRegionChanged = pyqtSignal()

    def __init__(self, editor, bounds=(.3,2.)):
        super().__init__(editor)
        self.editor = editor
        self.values = tuple(map(float,bounds))
        self.bounds = (0.,1e6)
        self.selector = _Selector(self, ax=editor.fft_plot.axes,
            onselect=self._selected, onmove_callback=self._selected,
            direction='horizontal', useblit=False, interactive=True,
            drag_from_anywhere=True, button=1, grab_range=8,
            props=dict(facecolor='#1aa5a2', alpha=.12),
            handle_props=dict(color='#37a7a5', linewidth=.9))
        self.selector.extents = self.values

    def getRegion(self): return self.values

    def _selected(self, low, high): self.setRegion((low,high))

    def setRegion(self, values):
        low,high = sorted(map(float,values))
        low,high = max(self.bounds[0],low), min(self.bounds[1],high)
        if not np.isfinite([low,high]).all() or low>high: return
        changed = (low,high) != self.values
        self.values = low,high
        self.selector.extents = self.values
        self.selector.set_visible(True)
        self.editor.schedule_draw()
        if changed: self.sigRegionChanged.emit()

    def setBounds(self, bounds):
        self.bounds = tuple(map(float,bounds))

    def setMovable(self, movable): self.selector.set_active(bool(movable))
    def setZValue(self, value): pass


class FigureEditor(QWidget):
    title_edit_requested = pyqtSignal()
    save_requested = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.title_size, self.legend_size = 13., 8.
        self.figure = Figure(figsize=(11,9), dpi=100, facecolor='white', layout='constrained')
        self.canvas = FigureCanvasQTAgg(self.figure)
        self.toolbar = _Toolbar(self.canvas,self)
        layout = QVBoxLayout(self); layout.setContentsMargins(0,0,0,0); layout.setSpacing(0)
        layout.addWidget(self.toolbar); layout.addWidget(self.canvas,1)
        axes = self.figure.subplots(2,1)
        self.time_plot, self.fft_plot = Plot(self,axes[0]), Plot(self,axes[1])
        self.legend = Legend(self)
        self.points = Curve(self.time_plot, linestyle='none', marker='o', markersize=3,
                            color='#147c9c', markeredgewidth=0)
        self.fit_curve = Curve(self.time_plot, linewidth=1.8, color='#d56e36')
        self.spectrum = Curve(self.fft_plot, linewidth=1.4, color='#6553a7')
        self.markers = Curve(self.fft_plot, linestyle='none', marker='o', markersize=5,
                             color='#d56e36', markeredgecolor='white', markeredgewidth=.5)
        axes[0].axvline(0, color='#7a8e9b', linewidth=.7, linestyle='--')
        self.region = Region(self)
        self.canvas.setToolTip('Двойной щелчок по Title — редактирование. Легенду можно перетаскивать.')
        self.canvas.mpl_connect('button_press_event',self._pressed)
        self.time_plot.setLabel('bottom','Задержка','ns'); self.time_plot.setLabel('left','Rotation','rad')
        self.fft_plot.setLabel('bottom','Частота','GHz'); self.fft_plot.setLabel('left','FFT amplitude','rad')
        self.fft_plot.setTitle('FFT / selected search band')

    def _pressed(self, event):
        if event.dblclick and self.time_plot.axes.title.contains(event)[0]:
            self.title_edit_requested.emit()

    def schedule_draw(self):
        if hasattr(self,'canvas'): self.canvas.draw_idle()

    def render(self):
        self.time_plot._update_y_unit(); self.fft_plot._update_y_unit()
        self.canvas.draw()

    def set_fonts(self, title_size, legend_size):
        self.title_size, self.legend_size = float(title_size),float(legend_size)
        self.time_plot.axes.title.set_fontsize(self.title_size)
        self.fft_plot.axes.title.set_fontsize(self.title_size)
        self.legend._rebuild()
        self.schedule_draw()

    def capture_images(self, formats=('png',)):
        """Capture current pixel image; vector formats retain this exact layout/view.

        No reconstruction from data occurs. Call only on the Qt GUI thread.
        """
        self.render()
        output = {}
        if 'png' in formats:
            buffer=BytesIO()
            Image.fromarray(np.asarray(self.canvas.buffer_rgba()).copy()).save(buffer,format='PNG')
            output['png']=buffer.getvalue()
        layout_engine=self.figure.get_layout_engine()
        self.figure.set_layout_engine(None)  # freeze the geometry the user just saw
        try:
            for format_name in formats:
                if format_name == 'png': continue
                if format_name not in ('pdf','svg'):
                    raise ValueError('Доступны PNG, PDF и SVG')
                buffer=BytesIO()
                self.figure.savefig(buffer,format=format_name,dpi=self.figure.dpi,
                                    facecolor=self.figure.get_facecolor())
                output[format_name]=buffer.getvalue()
        finally:
            self.figure.set_layout_engine(layout_engine)
        return output
