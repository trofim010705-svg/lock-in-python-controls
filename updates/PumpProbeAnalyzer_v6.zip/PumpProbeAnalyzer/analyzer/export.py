"""Standalone data/report and publication image export; no Qt in this module."""
from dataclasses import asdict
import json
import os
import tempfile
from pathlib import Path
import numpy as np
from .core import evaluate, names
from .presentation import PlotStyle, parameter_label, angle_unit


def _clean_json(value):
    """Represent unavailable statistics with JSON null, never non-standard NaN."""
    if isinstance(value, dict): return {key:_clean_json(item) for key,item in value.items()}
    if isinstance(value, (list,tuple)): return [_clean_json(item) for item in value]
    if isinstance(value,np.generic): return _clean_json(value.item())
    if isinstance(value, (float,np.floating)) and not np.isfinite(value): return None
    return value


def spectral_peaks(prepared, band):
    """All local peaks in the selected band plus its maximum, in amplitude order."""
    from scipy.signal import find_peaks
    from .core import peak_indices
    frequencies, amplitudes = prepared.frequencies, prepared.spectrum
    if len(frequencies) == 0:
        return []
    try:
        indices = peak_indices(prepared,*band)
    except ValueError:
        return []
    local = set(find_peaks(amplitudes)[0].tolist())
    selected = np.flatnonzero((frequencies>=band[0]) & (frequencies<=band[1]) & (frequencies>0))
    return [dict(rank=rank+1, frequency_hz=float(frequencies[index]),
                 frequency_ghz=float(frequencies[index]/1e9), amplitude_rad=float(amplitudes[index]),
                 strongest=(rank==0), is_local_maximum=(int(index) in local),
                 is_band_edge=(index==selected[0] or index==selected[-1]),
                 kind='local_maximum' if int(index) in local else 'band_maximum_not_local_peak')
            for rank,index in enumerate(indices)]


def _model_formula(count):
    if count==1:
        return 'y(t) = A1 * exp(-u/tau1) * sin(2*pi*f1*u + phi1) + C; u = t - t_ref'
    if count>1:
        return f'y(t) = sum(i=1..{count}) A_i * exp(-u/tau_i) * sin(2*pi*f_i*u + phi_i) + C; u = t - t_ref'
    return 'Модель не рассчитана: нет доступного набора стартовых параметров.'


def build_report(measurement, prepared, result, title, band, initial, style):
    """Build a reproducible numerical report independent of editable legend labels."""
    from datetime import datetime,timezone
    p=prepared
    initial=np.asarray(initial,dtype=float)
    count=(len(result.parameters)-1)//4 if result is not None else max(0,(len(initial)-1)//4)
    if len(initial) and (len(initial)!=4*count+1 or not np.isfinite(initial).all()):
        raise ValueError('Некорректный снимок начальных параметров фита для отчёта')
    if result is not None and len(initial)!=len(result.parameters):
        raise ValueError('Для отчёта нужен полный набор p0, использованный в этом фите')
    duration=float(np.ptp(p.time[p.fit_mask])) if p.fit_mask.sum()>1 else None
    named_initial=[dict(name=name,unit=unit,value=float(value))
                   for (name,unit),value in zip(names(count),initial)]
    report=dict(created_utc=datetime.now(timezone.utc).isoformat(),
        title=title,data_file=measurement.data_path,notes_file=measurement.notes_path,
        input_signal_unit=measurement.signal_unit,raw_point_count=len(measurement.position),
        unique_point_count=len(p.time),fit_point_count=int(p.fit_mask.sum()),
        settings=dict(asdict(p.settings),path_factor=2.0),fft_band_hz=list(map(float,band)),
        fft_resolution_hz=float(p.resolution_hz),fft_peaks=spectral_peaks(p,band),warnings=list(p.warnings),
        calibration=dict(bal_mv=p.settings.bal_mv,sig_mv=p.settings.sig_mv,
            coefficient_rad_per_V=p.settings.rad_per_unit,
            formula='theta_rad = sqrt(2)*X1_V/(4*sqrt(Sig_V)*sqrt(Sig_V-Bal_V))',
            bal_V=p.settings.bal_mv*1e-3,sig_V=p.settings.sig_mv*1e-3),
        model=_model_formula(count),component_count=count,
        fit_method='Bounded least squares; linear amplitude/phase solve, variable projection and multistart; full-model refinement',
        fit_bounds_si=dict(amplitude_min_rad=0,frequency_min_hz=max(0,float(band[0])),
            frequency_max_hz=min(float(band[1]),float(p.nyquist_hz)),
            tau_min_s=duration*1e-6 if duration is not None else None,
            tau_max_s=duration*1e6 if duration is not None else None,phase='unbounded',offset='unbounded'),
        initial_parameters_si=list(map(float,initial)),initial_parameters=named_initial,
        initialization_note='The listed p0 is the user-visible SI input passed to fit. Multistart also tests spectral alternatives.',
        presentation=asdict(style))
    if result is not None:
        report['fit']=dict(reference_s=float(result.reference_s),rmse_rad=float(result.rmse_rad),
            r_squared=float(result.r_squared),warnings=list(result.warnings),
            evaluations=int(result.evaluations),jacobian_condition=float(result.condition),
            parameters=[dict(name=name,unit=unit,value=float(value),stderr=float(error))
                        for (name,unit),value,error in zip(names(count),result.parameters,result.errors)])
    return _clean_json(report)


def report_text(report):
    """Readable text includes SI values and friendly GHz/ns/angle equivalents."""
    from .presentation import angle_text
    def number(value): return 'не определено' if value is None else f'{value:.12g}'
    unit=report['presentation']['time_unit']; tf=1e-9 if unit=='ns' else 1e-12
    def friendly(name,value):
        if value is None: return 'не определено'
        if name.startswith('f') and not name.startswith('phi'): return f'{value/1e9:.8g} GHz'
        if name.startswith('tau'): return f'{value/tf:.8g} {unit}'
        if name.startswith('A') or name=='C': return angle_text(value)
        return f'{value:.8g} rad'
    settings=report['settings']; calibration=report['calibration']
    lines=['PUMP–PROBE ANALYSIS',f"Created UTC: {report['created_utc']}",
        f"Title: {report['title']}",f"Data: {report['data_file']}",f"Parameters: {report['notes_file']}",
        f"Points: raw={report['raw_point_count']}; unique={report['unique_point_count']}; fit={report['fit_point_count']}",
        '', 'CALIBRATION',calibration['formula'],
        f"Bal={number(calibration['bal_mv'])} mV; Sig={number(calibration['sig_mv'])} mV; coefficient={number(calibration['coefficient_rad_per_V'])} rad/V",
        '', 'TIME WINDOW',f"x0={number(settings['zero_mm'])} mm; mode={settings['zero_mode']}; path factor=2",
        f"Fit/window: {number(settings['fit_min_s']/tf)} .. {number(settings['fit_max_s']/tf)} {unit}",
        f"Fit/window SI: {number(settings['fit_min_s'])} .. {number(settings['fit_max_s'])} s",
        f"Window mode={settings['fit_window_mode']}; steps after peak={settings['skip_steps']}",
        f"Background polynomial degree={settings['background_degree']}; background interval={number(settings['bg_min_s']/tf)} .. {number(settings['bg_max_s']/tf)} {unit}",
        '', 'FFT / SPECTRAL PEAKS',
        f"Window={settings['window']}; zero padding={settings['padding']}; frequency resolution={number(None if report['fft_resolution_hz'] is None else report['fft_resolution_hz']/1e9)} GHz",
        f"Search band={number(report['fft_band_hz'][0]/1e9)} .. {number(report['fft_band_hz'][1]/1e9)} GHz",
        'FFT amplitude is window-normalized spectral amplitude, not the fitted time-domain A.',
        'Rank | Frequency [GHz] | Frequency [Hz] | Amplitude [rad] | Friendly amplitude | Type / flags']
    if not report['fft_peaks']: lines.append('Пики недоступны: недостаточно спектральных данных либо пустая полоса.')
    for peak in report['fft_peaks']:
        flags=[peak['kind']]
        if peak['strongest']: flags.append('strongest in selected band')
        if peak['is_band_edge']: flags.append('band edge; may not be a physical spectral line')
        lines.append(f"{peak['rank']} | {number(peak['frequency_ghz'])} | {number(peak['frequency_hz'])} | {number(peak['amplitude_rad'])} | {angle_text(peak['amplitude_rad'])} | "+'; '.join(flags))
    bounds=report['fit_bounds_si']
    lines += ['', 'FIT MODEL',report['model'],f"Number of sinusoidal components: {report['component_count']}",
              'Method: '+report['fit_method'],
              f"Constraints: A >= 0; f={number(bounds['frequency_min_hz']/1e9)} .. {number(bounds['frequency_max_hz']/1e9)} GHz; phase and C are free.",
              f"Tau bounds SI: {number(bounds['tau_min_s'])} .. {number(bounds['tau_max_s'])} s",
              '', 'INITIAL PARAMETERS PASSED TO FIT (p0)',report['initialization_note'],
              'Parameter | Value [SI] | SI unit | Friendly value']
    for parameter in report['initial_parameters']:
        lines.append(f"{parameter['name']} | {number(parameter['value'])} | {parameter['unit']} | {friendly(parameter['name'],parameter['value'])}")
    if not report['initial_parameters']: lines.append('Начальные параметры отсутствуют; фит не выполнялся.')
    fit=report.get('fit')
    if fit is None:
        lines += ['', 'FIT RESULT','Фит не рассчитан. Параметры результата отсутствуют.']
    else:
        lines += ['', 'FIT RESULT',
            f"t_ref={number(fit['reference_s']/tf)} {unit} ({number(fit['reference_s'])} s); A and phi are referenced to t_ref.",
            f"RMSE={angle_text(fit['rmse_rad'])}; RMSE SI={number(fit['rmse_rad'])} rad; R2={number(fit['r_squared'])}",
            f"Evaluations={fit['evaluations']}; Jacobian condition={number(fit['jacobian_condition'])}",
            'Parameter | Value [SI] | Std. error [SI] | SI unit | Friendly value']
        for parameter in fit['parameters']:
            lines.append(f"{parameter['name']} | {number(parameter['value'])} | {number(parameter['stderr'])} | {parameter['unit']} | {friendly(parameter['name'],parameter['value'])}")
    lines += ['', 'WARNINGS']
    warnings=[*report['warnings'],*(fit['warnings'] if fit else [])]
    lines.extend(warnings or ['No numerical warnings.'])
    lines.append('Statistical fit errors do not include systematic Bal/Sig calibration uncertainty.')
    return '\n'.join(lines)+'\n'


def export_analysis(base, measurement, prepared, result, title, band, initial, style=None, image_payloads=None):
    style = (style or PlotStyle(fit_label=parameter_label(result))).validate()
    if image_payloads is not None:
        if not isinstance(image_payloads,dict) or not {'png','pdf'} <= image_payloads.keys():
            raise ValueError('Для экспорта видимой фигуры нужны снимки PNG и PDF')
        if set(image_payloads)-{'png','pdf','svg'}:
            raise ValueError('Неизвестный формат снимка фигуры')
        if any(not isinstance(data,(bytes,bytearray)) or not data for data in image_payloads.values()):
            raise ValueError('Снимок фигуры должен содержать непустые байты изображения')
    base = Path(base)
    # Keep every export; never overwrite measurement or previous analyses.
    folder = base
    for i in range(10000):
        folder = base if i == 0 else base.with_name(base.name+f'_{i:03d}')
        try:
            folder.mkdir(parents=True, exist_ok=False)
            break
        except FileExistsError:
            continue
    else:
        raise OSError('Не удалось выбрать папку экспорта')
    p = prepared
    prediction = np.full(len(p.time), np.nan)
    if result is not None:
        prediction[p.fit_mask] = evaluate(p.time[p.fit_mask], result.parameters, result.reference_s)
    np.savetxt(folder/'time_domain.tsv', np.c_[p.time, p.raw_rad, p.background, p.y, prediction, p.y-prediction],
               delimiter='\t', header='Time_s\tX1_rad\tBackground_rad\tProcessed_rad\tFit_rad\tResidual_rad', comments='')
    np.savetxt(folder/'spectrum.tsv', np.c_[p.frequencies, p.spectrum], delimiter='\t',
               header='Frequency_Hz\tAmplitude_rad', comments='')
    report=build_report(measurement,p,result,title,band,initial,style)
    text=report_text(report)
    (folder/'analysis.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    (folder/'analysis.txt').write_text(text,encoding='utf-8')
    (folder/'measurement_parameters.txt').write_text(measurement.notes.rstrip()+'\n\n'+'='*72+'\nANALYSIS REPORT\n'+'='*72+'\n'+text,encoding='utf-8')
    if image_payloads is not None:
        for extension,payload in image_payloads.items(): write_picture(folder/('analysis.'+extension),payload)
    else:
        save_picture(folder/'analysis.png',p,result,title,band,style)
        save_picture(folder/'analysis.pdf',p,result,title,band,style)
    return str(folder)


def make_figure(prepared, result, title, band, style=None):
    """Build both plots with identical labels and applied Y limits."""
    style = (style or PlotStyle(fit_label=parameter_label(result))).validate()
    p = prepared
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    fig = Figure(figsize=(11, 9), constrained_layout=True); FigureCanvasAgg(fig)
    top, bottom = fig.subplots(2, 1)
    visible=p.fit_mask if p.fit_mask.sum()>=8 else np.ones(len(p.time),dtype=bool)
    time_factor,time_unit=angle_unit(style.time_ylim if style.time_ylim is not None else p.y[visible])
    fft_factor,fft_unit=angle_unit(style.fft_ylim if style.fft_ylim is not None else p.spectrum)
    top.plot(p.time[visible]/style.time_factor, p.y[visible]/time_factor, '.', ms=3, color='#147c9c', label=style.experiment_label or '_nolegend_')
    if result:
        t = np.linspace(p.time[p.fit_mask][0], p.time[p.fit_mask][-1], 3000)
        top.plot(t/style.time_factor, evaluate(t, result.parameters, result.reference_s)/time_factor, color='#d56e36',
                 label=style.fit_label or '_nolegend_')
    top.axvline(0, color='#7a8e9b', lw=.7, ls='--')
    top.set(title=title, xlabel=f'Delay ({style.time_unit})', ylabel=f'Rotation ({time_unit})')
    top.title.set_fontsize(getattr(style,'title_font_size',14))
    xlo,xhi=p.time[visible][0]/style.time_factor,p.time[visible][-1]/style.time_factor
    if xlo==xhi: xlo,xhi=xlo-.01,xhi+.01
    top.set_xlim(xlo,xhi)
    if style.show_legend and top.get_legend_handles_labels()[0]: top.legend(fontsize=getattr(style,'legend_font_size',8))
    bottom.plot(p.frequencies/1e9, p.spectrum/fft_factor, color='#6553a7')
    bottom.axvspan(band[0]/1e9,band[1]/1e9, color='#1aa5a2', alpha=.15)
    from .core import peak_indices
    try:
        indices = peak_indices(p, *band)[:30]
        bottom.plot(p.frequencies[indices]/1e9, p.spectrum[indices]/fft_factor, 'o', ms=4, color='#dc713c')
    except ValueError:
        pass
    bottom.set(xlabel='Frequency (GHz)', ylabel=f'FFT amplitude ({fft_unit})', title='FFT / selected search band')
    flo=max(0,band[0]-(band[1]-band[0])*.5)
    fhi=band[1]+(band[1]-band[0])*.5
    if p.nyquist_hz>0: fhi=min(p.nyquist_hz,fhi)
    bottom.set_xlim(flo/1e9,fhi/1e9)
    for ax,limits,factor in ((top,style.time_ylim,time_factor),(bottom,style.fft_ylim,fft_factor)):
        ax.grid(alpha=.2)
        if limits is not None: ax.set_ylim(np.asarray(limits)/factor)
    return fig


def save_picture(path, prepared, result, title, band, style=None, image_payload=None):
    """Save exactly the selected filename; failed writes leave an existing file intact."""
    if image_payload is not None: return write_picture(path,image_payload)
    path = Path(path)
    extension = path.suffix.lower().lstrip('.')
    if extension not in ('png','pdf','svg'):
        raise ValueError('Выберите расширение .png, .pdf или .svg')
    fig = make_figure(prepared, result, title, band, style)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, suffix=path.suffix, delete=False) as handle:
            temporary = Path(handle.name)
        fig.savefig(temporary, format=extension, dpi=300)
        os.replace(temporary,path)
    finally:
        fig.clear()
        if temporary is not None: temporary.unlink(missing_ok=True)
    return str(path)



def write_picture(path, payload):
    """Atomically write a captured visible figure, without drawing or accessing Qt."""
    path=Path(path)
    if path.suffix.lower() not in ('.png','.pdf','.svg'):
        raise ValueError('Выберите расширение .png, .pdf или .svg')
    if not isinstance(payload,(bytes,bytearray)) or not payload:
        raise ValueError('Снимок фигуры должен содержать непустые байты изображения')
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,suffix=path.suffix,delete=False) as handle:
            temporary=Path(handle.name)
            handle.write(payload);handle.flush();os.fsync(handle.fileno())
        os.replace(temporary,path)
    finally:
        if temporary is not None: temporary.unlink(missing_ok=True)
    return str(path)
