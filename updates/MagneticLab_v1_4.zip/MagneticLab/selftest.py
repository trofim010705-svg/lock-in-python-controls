"""End-to-end demo: polarity/start, sweeps, hysteresis, files, GUI, shutdown."""
import json
from pathlib import Path
import platform
import sys
import threading
import time
import traceback
from types import SimpleNamespace


def run(report_path):
    from PyQt5.QtCore import QTimer, QSettings, Qt, QPoint, QRect
    from PyQt5.QtGui import QContextMenuEvent
    from PyQt5.QtWidgets import QApplication, QScrollArea
    import numpy as np
    from window import LabWindow
    from ni_input.backend import load_daqmx
    import pyvisa
    import serial
    from magnet_demo import DemoSerial

    _, constants, *_ = load_daqmx()
    assert constants.TerminalConfiguration.DIFF.value == 10106

    report = Path(report_path).resolve()
    report.parent.mkdir(parents=True, exist_ok=True)
    app = QApplication(sys.argv[:1])
    app.setStyle('Fusion')
    app.setOrganizationName('LabTools')
    app.setApplicationName('MagneticLabBuildCheck')
    QSettings.setDefaultFormat(QSettings.IniFormat)
    QSettings.setPath(QSettings.IniFormat, QSettings.UserScope, str(report.parent / 'settings'))
    window = LabWindow(SimpleNamespace(demo=True, serial=None, timeout=2000, max_frequency=120000))
    window.folder.setText(str(report.parent / 'измерения'))
    window.current_start.setValue(-1)
    window.current_stop.setValue(1)
    window.intervals.setValue(2)
    window.duration.setValue(.4)
    window.sample_delay.setValue(50)
    window.settle.setValue(.1)
    window.manual_current.setValue(1)
    window.slope.setValue(1)
    window.offset.setValue(0)
    window.after_measurement.setCurrentIndex(0)
    window.measurement_mode.setCurrentIndex(0)
    window.resize(1280, 720)
    window.show()
    outcome = {'ok': False, 'frozen': bool(getattr(sys, 'frozen', False)),
               'platform': platform.platform(), 'python': platform.python_version(),
               'qt_platform': app.platformName()}
    phase = 'connecting'
    ending = False
    initial_writes = 0
    started_at = time.monotonic()
    drop_link = threading.Event()
    original_write = DemoSerial.write

    def faulty_write(link, data):
        if drop_link.is_set() and data == b'MC?\r':
            drop_link.clear()
            outcome['injected_com_loss'] = True
            raise serial.SerialException('Self-test: USB COM disconnected')
        return original_write(link, data)

    DemoSerial.write = faulty_write

    def finish(ok, detail):
        nonlocal ending
        if ending:
            return
        ending = True
        outcome.update(ok=ok, detail=detail, elapsed_s=time.monotonic() - started_at,
                       journal=window.journal.toPlainText())
        report.write_text(json.dumps(outcome, ensure_ascii=False, indent=2), encoding='utf-8')
        window.close()

    previous_hook = sys.excepthook
    sys.excepthook = lambda kind, value, tb: finish(False, ''.join(traceback.format_exception(kind, value, tb)))

    def first_point(index, total):
        if index == 1 and 'first_point_no_reset' not in outcome:
            writes = window.mag_worker.driver.source.writes[initial_writes:]
            commands = [x.decode().strip() for x in writes]
            outcome['first_point_no_reset'] = not any(x in commands for x in ('PC 0', 'OUT 0', 'H', 'X'))
            QTimer.singleShot(120, drop_link.set)

    def tick():
        nonlocal phase, initial_writes
        if ending:
            return
        try:
            if phase == 'connecting':
                if window.connected and window.mag_state['identified'] and window.field_data.blocks and not window.mag_busy:
                    phase = 'manual_positive'
                    window.manual_magnet('set_current')
            elif phase == 'manual_positive' and not window.mag_busy:
                assert window.mag_state['polarity'] == 1
                assert window.mag_state['values']['OUT?']
                phase = 'flip_start'
                window.manual_magnet('flip_start')
            elif phase == 'flip_start' and not window.mag_busy:
                assert window.mag_state['polarity'] == -1
                assert window.mag_state['values']['OUT?']
                assert abs(window.mag_state['values']['PC?'] - 1) < .001
                outcome['manual_flip_and_start'] = True
                initial_writes = len(window.mag_worker.driver.source.writes)
                phase = 'sweep'
                window.start_experiment()
            elif phase == 'sweep':
                if window.runner and not outcome.get('point_hook'):
                    window.runner.monitor_period = .1
                    window.runner.point_started.connect(first_point)
                    outcome['point_hook'] = True
                if not hasattr(window, 'last_outcome') or window.exclusive != 'idle':
                    return
                result = window.last_outcome
                assert result['reason'] == 'complete', result
                assert len(result['points']) == 3
                assert all(p['field']['valid'] for p in result['points'])
                assert all(p['statistics']['samples'] >= 4 for p in result['points'])
                assert outcome.get('first_point_no_reset')
                assert outcome.get('injected_com_loss')
                assert result['points'][0]['attempt'] == 2
                assert any(e['device'] == 'magnet' and e['state'] == 'restored'
                           for e in result['metadata']['recovery_events'])
                outcome['automatic_reconnect_and_point_retry'] = True
                assert not window.mag_state['values']['OUT?']
                assert window.mag_state['values']['PC?'] == 0
                folder = Path(result['folder'])
                assert (folder / 'field_dependence.png').stat().st_size > 1000
                assert (folder / 'field_dependence.pdf').stat().st_size > 1000
                assert (folder / 'experiment.txt').exists()
                assert len(list(folder.glob('incomplete/point_*/signal.dat'))) == 1
                summary = np.loadtxt(folder / 'summary.dat', delimiter='\t', skiprows=1, ndmin=2)
                assert summary.shape == (3, 11)
                assert np.allclose(summary[:, 3], [-10, 0, 10], atol=.2)
                for file in folder.glob('point_*/signal.dat'):
                    values = np.loadtxt(file, delimiter='\t', skiprows=1, ndmin=2)
                    assert values.shape[1] == 9
                    assert ((values[:, 5] >= 0) & (values[:, 5] < 360)).all()
                    assert np.allclose(values[:, 4], np.hypot(values[:, 2], values[:, 3]))
                window.refresh_dashboard()
                button_rect = QRect(window.run_button.mapTo(window, QPoint()), window.run_button.size())
                for graph in window.plot_widgets:
                    graph_rect = QRect(graph.mapTo(window, QPoint()), graph.size())
                    assert not graph_rect.intersects(button_rect), 'Run button overlaps a graph'
                    assert graph.height() >= 150
                outcome['controls_outside_graphs'] = True
                settings_scroll = window.dashboard.findChild(QScrollArea)
                assert settings_scroll.widget().width() <= settings_scroll.viewport().width(), 'Settings pane clipped horizontally'
                window.grab().save(str(report.parent / 'preview.png'))
                outcome['folder'] = str(folder)
                outcome['field_points_mT'] = summary[:, 3].tolist()
                outcome['normal_finish_zeroed'] = True
                phase = 'preserve_seed_five'
                window.manual_current.setValue(5)
                window.manual_magnet('set_current')
            elif phase == 'preserve_seed_five' and not window.mag_busy:
                assert window.mag_state['values']['PC?'] == 5
                assert window.mag_state['values']['OUT?']
                phase = 'preserve_disconnected'
                window.toggle_magnet()
            elif phase == 'preserve_disconnected' and not window.mag_busy:
                assert not window.mag_state['connected']
                phase = 'preserve_reconnected'
                window.toggle_magnet()
            elif phase == 'preserve_reconnected' and not window.mag_busy:
                assert window.mag_state['values']['PC?'] == 5
                assert window.mag_state['values']['OUT?']
                assert window.mag_state['polarity'] == 1
                window.current_start.setValue(3)
                window.current_stop.setValue(10)
                window.intervals.setValue(7)
                window.duration.setValue(1)
                window.after_measurement.setCurrentIndex(1)
                window.session_name.setText('five_reconnect_three_to_ten')
                phase = 'preserve_sweep'
                window.start_experiment()
            elif phase == 'preserve_sweep' and window.exclusive == 'idle':
                result = getattr(window, 'last_outcome', {})
                if result.get('metadata', {}).get('parameters', {}).get('start_A') != 3:
                    return
                assert result['reason'] == 'complete', result.get('error')
                assert len(result['points']) == 8
                commands = [x.decode().strip() for x in window.mag_worker.driver.source.writes]
                assert not any(x in commands for x in ('PC 0', 'OUT 0', 'H', 'X')), commands
                assert window.mag_state['values']['PC?'] == 10
                assert window.mag_state['values']['OUT?']
                outcome['five_reconnect_three_to_ten_no_zero'] = True
                phase = 'hold_prepare'
                window.manual_current.setValue(1)
                window.manual_magnet('set_current')
            elif phase == 'hold_prepare' and not window.mag_busy:
                assert window.mag_state['values']['OUT?']
                window.measurement_mode.setCurrentIndex(1)
                window.session_name.setText('hold_test')
                phase = 'hold'
                window.start_experiment()
            elif phase == 'hold' and window.exclusive == 'idle':
                result = getattr(window, 'last_outcome', {})
                if result.get('metadata', {}).get('parameters', {}).get('zero_after', True):
                    return
                assert result['reason'] == 'complete', result.get('error')
                assert result['finish_action'] == 'held'
                assert window.mag_state['values']['OUT?']
                assert window.mag_state['values']['PC?'] == 1
                before = len(window.mag_worker.driver.source.writes)
                window.save_defaults_button.click()
                assert 'сохранены' in window.defaults_status.text()
                assert window.settings.value('defaults/zero_after_v13', True, type=bool) is False
                assert len(window.mag_worker.driver.source.writes) == before
                for field in window.default_fields.values():
                    assert field.contextMenuPolicy() == Qt.NoContextMenu
                    event = QContextMenuEvent(QContextMenuEvent.Mouse, QPoint(3, 3), QPoint(3, 3))
                    app.sendEvent(field.lineEdit(), event)
                assert app.activePopupWidget() is None
                outcome['hold_finish_preserved_current'] = True
                outcome['defaults_button_saved'] = True
                outcome['numeric_right_click_no_popup'] = True
                window.refresh_dashboard()
                window.grab().save(str(report.parent / 'preview_hold.png'))
                window.current_start.setValue(3)
                window.current_stop.setValue(5)
                window.intervals.setValue(2)
                window.duration.setValue(.3)
                window.settle.setValue(.05)
                window.session_name.setText('hysteresis_check')
                initial_writes = len(window.mag_worker.driver.source.writes)
                phase = 'hysteresis'
                assert window.hysteresis_button.isEnabled()
                window.hysteresis_button.click()
            elif phase == 'hysteresis' and window.exclusive == 'idle':
                result = getattr(window, 'last_outcome', {})
                if result.get('metadata', {}).get('parameters', {}).get('mode') != 'hysteresis':
                    return
                assert result['reason'] == 'complete', result.get('error')
                points = result['points']
                assert [p['target_current_A'] for p in points] == [3,4,5,4,3]
                assert [p['sweep_branch'] for p in points] == ['forward']*3+['reverse']*2
                assert all(p['field']['valid'] for p in points)
                assert result['finish_action'] == 'held'
                assert window.mag_state['values']['PC?'] == 3
                assert window.mag_state['values']['OUT?']
                commands = [x.decode().strip() for x in window.mag_worker.driver.source.writes[initial_writes:]]
                assert not any(x in commands for x in ('PC 0','OUT 0','H','X')), commands
                folder = Path(result['folder'])
                summary = np.loadtxt(folder/'summary.dat',delimiter='\t',skiprows=1,ndmin=2)
                assert summary.shape == (5,13)
                assert np.allclose(summary[:,1],[3,4,5,4,3])
                assert summary[:,11].tolist() == [1,1,1,2,2]
                assert len(list(folder.glob('point_*/signal.dat'))) == 5
                assert (folder/'field_dependence.png').stat().st_size > 1000
                assert (folder/'field_dependence.pdf').stat().st_size > 1000
                window.refresh_dashboard()
                assert len(window.curves[2].getData()[0]) == 3
                assert len(window.reverse_curves[2].getData()[0]) == 3
                assert all(legend.isVisible() for legend in window.branch_legends)
                for button in (window.run_button,window.hysteresis_button,window.stop_run_button):
                    rect = QRect(button.mapTo(window,QPoint()),button.size())
                    assert all(not QRect(graph.mapTo(window,QPoint()),graph.size()).intersects(rect) for graph in window.plot_widgets)
                window.grab().save(str(report.parent/'preview_hysteresis.png'))
                outcome['hysteresis_folder'] = str(folder)
                outcome['hysteresis_round_trip_verified'] = True
                outcome['hysteresis_no_turnaround_zero'] = True
                outcome['hysteresis_branch_files_and_plots'] = True
                finish(True, 'Verified continuous 3..5..3 A hysteresis, shared turnaround, two plotted/exported branches, current hold; 5 A reconnect -> 3..10 A without resets, fault recovery, preferences and shutdown.')
        except Exception:
            finish(False, traceback.format_exc())

    timer = QTimer()
    timer.setInterval(20)
    timer.timeout.connect(tick)
    timer.start()
    QTimer.singleShot(0, lambda: window.submit('open'))
    QTimer.singleShot(0, window.toggle_magnet)
    QTimer.singleShot(0, window.toggle_ni)
    QTimer.singleShot(60000, lambda: finish(False, 'Demo test timed out.'))
    app.exec_()
    DemoSerial.write = original_write
    sys.excepthook = previous_hook
    outcome['threads_stopped'] = (not window.thread.isRunning() and not window.mag_thread.isRunning()
        and not window.field_reader.isRunning() and (window.runner is None or not window.runner.isRunning()))
    outcome['close_preserved_current'] = window.plant.get_current() == 3 and window.mag_worker.demo_state[2]
    outcome['ok'] = bool(outcome['ok'] and outcome['threads_stopped'] and outcome['close_preserved_current'])
    report.write_text(json.dumps(outcome, ensure_ascii=False, indent=2), encoding='utf-8')
    return 0 if outcome['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(run(sys.argv[1] if len(sys.argv) > 1 else 'selftest.json'))
