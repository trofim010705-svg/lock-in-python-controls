"""Chronological field curves; both hysteresis branches share the turning point."""


BRANCHES = (('forward', 'Старт → стоп', '#14798c', 'o'),
            ('reverse', 'Стоп → старт', '#dd8435', 't'))


def field_branches(points):
    valid = [p for p in points if p['result'] == 'complete' and p['field']['valid']]
    if not any('sweep_branch' in p for p in points):
        return [('forward', valid)]
    forward = [p for p in valid if p.get('sweep_branch') == 'forward']
    reverse = [p for p in valid if p.get('sweep_branch') == 'reverse']
    # Only use the actual stop point, never the last earlier valid point.
    turning = next((p for p in reversed(forward)
                    if p['index'] == p.get('parameters', {}).get('intervals', -1) + 1), None)
    if reverse and turning is not None:
        reverse = [turning, *reverse]
    return [('forward', forward), ('reverse', reverse)]
