"""Experiment values, units and statistics; independent of Qt and instruments."""
from dataclasses import dataclass, asdict
import math
import threading

import numpy as np


@dataclass(frozen=True)
class Calibration:
    slope: float = 1.0  # mT/mV
    offset: float = 0.0  # mT

    def validate(self):
        if not math.isfinite(self.slope) or self.slope == 0 or not math.isfinite(self.offset):
            raise ValueError('Наклон должен быть конечным ненулевым числом; сдвиг — конечным числом.')

    def field(self, voltage_V):
        return self.slope * (np.asarray(voltage_V) * 1000) + self.offset


@dataclass(frozen=True)
class Experiment:
    mode: str = 'sweep'
    start_A: float = -1.0
    stop_A: float = 1.0
    intervals: int = 10
    acquisition_s: float = 10.0
    period_ms: float = 100.0
    settle_s: float = 1.0
    voltage_V: float = 5.0
    sig_mV: float = 200.0
    bal_mV: float = -200.0
    e_field: str = ''
    additional: str = ''
    folder: str = ''
    name: str = 'measurement'
    zero_after: bool = False

    def validate(self):
        if self.mode not in ('single', 'sweep', 'hysteresis'):
            raise ValueError('Неизвестный режим измерения.')
        if not isinstance(self.zero_after, bool):
            raise ValueError('Выберите действие с током после измерения.')
        values = (self.start_A, self.stop_A, self.acquisition_s, self.period_ms,
                  self.settle_s, self.voltage_V, self.sig_mV, self.bal_mV)
        if not all(math.isfinite(x) for x in values):
            raise ValueError('Параметры должны быть конечными числами.')
        if not -10 <= self.start_A <= 10 or not -10 <= self.stop_A <= 10:
            raise ValueError('Ток прохода: −10…+10 A.')
        if not isinstance(self.intervals, int) or not 1 <= self.intervals <= 10000:
            raise ValueError('Количество интервалов: 1…10000.')
        if not 0.1 <= self.acquisition_s <= 86400 or not 10 <= self.period_ms <= 60000:
            raise ValueError('Время измерения: 0.1…86400 s; период отсчётов: 10…60000 ms.')
        if self.acquisition_s * 1000 / self.period_ms > 1_000_000:
            raise ValueError('В одной точке допускается до 1 000 000 отсчётов Lock-in. Увеличьте Delay.')
        if not 0 <= self.settle_s <= 3600:
            raise ValueError('Задержка после установки тока: 0…3600 s.')
        if self.mode != 'single' and not 0 < self.voltage_V <= 60:
            raise ValueError('Для прохода задайте положительный предел напряжения GEN, не более 60 V.')
        if self.mode == 'hysteresis' and self.start_A == self.stop_A:
            raise ValueError('Для гистерезиса начальный и конечный ток должны различаться.')
        if not self.folder.strip():
            raise ValueError('Выберите папку сохранения.')

    def currents(self):
        if self.mode == 'single':
            return [None]
        result = np.linspace(self.start_A, self.stop_A, self.intervals + 1)
        result[np.abs(result) < 1e-10] = 0
        forward = result.tolist()
        # Share the turning point: no repeated measurement, reset or second run.
        return forward + forward[-2::-1] if self.mode == 'hysteresis' else forward

    def point_context(self, index):
        if self.mode != 'hysteresis':
            return {}
        returning = index > self.intervals + 1
        return {'sweep_branch': 'reverse' if returning else 'forward',
                'branch_point': index - self.intervals - 1 if returning else index}

    def point_label(self, index):
        context = self.point_context(index)
        return {'forward': 'Прямой ход', 'reverse': 'Обратный ход'}.get(context.get('sweep_branch'), 'Точка')

    def metadata(self):
        return asdict(self)


def phase_deg(x, y):
    if x == 0 and y == 0:
        return float('nan')
    result = math.degrees(math.atan2(y, x)) % 360
    return 0.0 if result >= 360 - 1e-12 else result


def signal_statistics(rows):
    """R is averaged after hypot; phase uses the circular mean of unit phasors."""
    if not rows:
        return {'samples': 0, 'amplitude_mean': None, 'phase_mean_deg': None}
    a = np.asarray(rows, dtype=float)
    amplitude = a[:, 4]
    phases = a[:, 5]
    phases = phases[np.isfinite(phases)]
    coherence, phase, circular_std = 0.0, None, None
    if len(phases):
        z = np.exp(1j * np.deg2rad(phases)).mean()
        coherence = float(abs(z))
        if coherence > 1e-8:
            phase = float(np.degrees(np.angle(z)) % 360)
            if phase > 360 - 1e-10:
                phase = 0.0
            circular_std = math.degrees(math.sqrt(max(0, -2 * math.log(min(1, coherence)))))
    return {'samples': len(rows), 'amplitude_mean': float(amplitude.mean()),
            'amplitude_std': float(amplitude.std(ddof=1)) if len(rows) > 1 else 0.0,
            'phase_mean_deg': phase, 'phase_circular_std_deg': circular_std,
            'phase_resultant_length': coherence,
            'x1_mean': float(a[:, 2].mean()), 'y1_mean': float(a[:, 3].mean()),
            'overload_samples': int(np.count_nonzero(a[:, 7])),
            'unlock_samples': int(np.count_nonzero(a[:, 6].astype(int) & 8))}


class DemoPlant:
    def __init__(self):
        self.lock = threading.Lock()
        self.current = 0.0

    def set_current(self, value):
        with self.lock:
            self.current = float(value)

    def get_current(self):
        with self.lock:
            return self.current
