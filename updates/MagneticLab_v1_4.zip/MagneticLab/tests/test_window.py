import tempfile
import time
import unittest
from unittest.mock import patch
from types import SimpleNamespace

from PyQt5.QtCore import QSettings, Qt, QPoint
from PyQt5.QtGui import QContextMenuEvent
from PyQt5.QtWidgets import QApplication

from window import LabWindow


class WindowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setOrganizationName('LabToolsTests')
        cls.app.setApplicationName('MagneticLabPreferences')
        cls.temp = tempfile.TemporaryDirectory()
        QSettings.setDefaultFormat(QSettings.IniFormat)
        QSettings.setPath(QSettings.IniFormat, QSettings.UserScope, cls.temp.name)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def setUp(self):
        QSettings().clear()
        self.windows = []
        self.window = self.make_window()

    def make_window(self):
        window = LabWindow(SimpleNamespace(demo=True, serial=None, timeout=2000, max_frequency=120000))
        self.windows.append(window)
        return window

    def tearDown(self):
        for window in self.windows:
            window.close()
        end = time.perf_counter() + 3
        while time.perf_counter() < end:
            self.app.processEvents()
            if all(w.thread_stopped and not w.mag_thread.isRunning() for w in self.windows):
                break
            time.sleep(.005)
        self.assertTrue(all(w.thread_stopped and not w.mag_thread.isRunning() for w in self.windows))

    def test_right_click_does_not_open_a_numeric_context_menu(self):
        for widget in self.window.default_fields.values():
            self.assertEqual(widget.contextMenuPolicy(), Qt.NoContextMenu)
            self.assertEqual(widget.lineEdit().contextMenuPolicy(), Qt.NoContextMenu)
            event = QContextMenuEvent(QContextMenuEvent.Mouse, QPoint(3, 3), QPoint(3, 3))
            self.app.sendEvent(widget.lineEdit(), event)
        self.assertIsNone(self.app.activePopupWidget())

    def test_button_saves_and_reloads_values_and_end_policy(self):
        w = self.window
        w.slope.setValue(2.5)
        w.offset.setValue(-7)
        w.current_start.setValue(-5)
        w.intervals.setValue(20)
        w.after_measurement.setCurrentIndex(1)
        w.save_defaults_button.click()
        self.assertIn('сохранены', w.defaults_status.text())
        other = self.make_window()
        self.assertEqual(other.slope.value(), 2.5)
        self.assertEqual(other.offset.value(), -7)
        self.assertEqual(other.current_start.value(), -5)
        self.assertEqual(other.intervals.value(), 20)
        self.assertFalse(other.after_measurement.currentData())
        self.assertFalse(other.parameters().zero_after)

    def test_invalid_calibration_is_not_saved_as_default(self):
        w = self.window
        w.slope.setValue(0)
        w.save_defaults_button.click()
        self.assertIn('Не удалось', w.defaults_status.text())
        self.assertFalse(w.settings.contains('defaults/calibration_slope'))

    def test_old_default_zero_preference_is_not_silently_reused(self):
        self.window.settings.setValue('defaults/zero_after', True)
        other = self.make_window()
        self.assertFalse(other.parameters().zero_after)
        self.assertIn('ток не менять', other.stop_run_button.text())

    def test_explicit_new_zero_preference_can_be_saved(self):
        self.window.after_measurement.setCurrentIndex(0)
        self.window.save_defaults_button.click()
        other = self.make_window()
        self.assertTrue(other.parameters().zero_after)

    def test_hysteresis_button_selects_round_trip_with_current_settings(self):
        w = self.window
        w.current_start.setValue(3)
        w.current_stop.setValue(10)
        w.intervals.setValue(7)
        w.measurement_mode.setCurrentIndex(1)
        w.hysteresis_button.setEnabled(True)
        with patch.object(w, 'start_experiment') as start:
            w.hysteresis_button.click()
        start.assert_called_once_with()
        self.assertEqual(w.parameters().mode, 'hysteresis')
        self.assertEqual(w.parameters().currents(), list(range(3,11)) + list(range(9,2,-1)))
        self.assertIn('15 точек', w.grid_info.text())
        self.assertFalse(w.parameters().zero_after)

    def test_hysteresis_button_does_not_change_a_running_experiment(self):
        w = self.window
        w.exclusive = 'running'
        w.start_hysteresis()
        self.assertEqual(w.measurement_mode.currentIndex(), 0)
        w.exclusive = 'idle'


if __name__ == '__main__':
    unittest.main()
