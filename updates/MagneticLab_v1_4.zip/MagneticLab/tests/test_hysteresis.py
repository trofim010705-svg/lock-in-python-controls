from dataclasses import replace
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from experiment import ExperimentRunner
from models import Calibration, Experiment
from plot_data import field_branches
from reconnection import ConnectionLost
from services import MagnetWorker, Ticket
from test_experiment import Lockin, Magnet, Field


class HysteresisTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.lockin, self.magnet = Lockin(), Magnet()
        self.field = Field(self.magnet)
        self.p = Experiment(mode='hysteresis', start_A=3, stop_A=5, intervals=2,
                            acquisition_s=.1, period_ms=10, settle_s=0, folder=self.temp.name)
        self.plots = patch('experiment.save_figures')
        self.plots.start()

    def tearDown(self):
        self.plots.stop()
        self.temp.cleanup()

    def run_scan(self, p=None):
        runner = ExperimentRunner(p or self.p, Calibration(), self.lockin, self.magnet,
                                  self.field, True, demo=True)
        runner.retry_delay = .001
        result = []
        runner.outcome.connect(result.append)
        runner.run()
        return result[-1]

    def test_grid_returns_exactly_and_shares_turning_point(self):
        for start, stop, n in ((-5,5,4),(5,-5,4),(3,10,3),(-2,-5,1)):
            with self.subTest(start=start,stop=stop,n=n):
                p=replace(self.p,start_A=start,stop_A=stop,intervals=n)
                p.validate()
                values=p.currents()
                self.assertEqual(len(values),2*n+1)
                self.assertEqual(values,values[::-1])
                self.assertEqual(values[0],start)
                self.assertEqual(values[n],stop)
                self.assertEqual(values.count(stop),1)
                self.assertEqual(p.point_context(n+1)['sweep_branch'],'forward')
                self.assertEqual(p.point_context(n+2),{'sweep_branch':'reverse','branch_point':1})
        self.assertEqual(replace(self.p,start_A=-1,stop_A=1).currents(),[-1,0,1,0,-1])

    def test_same_endpoints_and_invalid_voltage_are_rejected(self):
        for changes in ({'stop_A':3},{'voltage_V':0}):
            with self.assertRaises(ValueError):replace(self.p,**changes).validate()

    def test_one_continuous_loop_saved_in_order_and_hold_returns_to_start(self):
        self.magnet.current=5
        result=self.run_scan()
        self.assertEqual(result['reason'],'complete')
        self.assertEqual([d['current'] for job,d in self.magnet.calls if job=='set_current'],[3,4,5,4,3])
        self.assertNotIn('zero',[job for job,_ in self.magnet.calls])
        self.assertEqual(self.magnet.current,3)
        self.assertEqual(result['finish_action'],'held')
        self.assertEqual([p['sweep_branch'] for p in result['points']],['forward']*3+['reverse']*2)
        folder=Path(result['folder'])
        self.assertEqual(len(list(folder.glob('point_*/signal.dat'))),5)
        table=np.loadtxt(folder/'summary.dat',skiprows=1,ndmin=2)
        self.assertEqual(table.shape,(5,13))
        np.testing.assert_array_equal(table[:,1],[3,4,5,4,3])
        np.testing.assert_array_equal(table[:,11],[1,1,1,2,2])
        info=json.loads((folder/'experiment.txt').read_text(encoding='utf-8'))
        self.assertEqual(info['hysteresis']['turning_point_index'],3)
        self.assertEqual(info['points'][-1]['sweep_branch'],'reverse')
        last=json.loads(next(folder.glob('point_0005_*/parameters.txt')).read_text(encoding='utf-8'))
        self.assertEqual(last['branch_point'],2)

    def test_explicit_zero_policy_runs_once_after_both_branches(self):
        result=self.run_scan(replace(self.p,zero_after=True))
        self.assertEqual(result['reason'],'complete')
        commands=[job for job,_ in self.magnet.calls]
        self.assertEqual(commands.count('zero'),1)
        self.assertEqual(commands[-1],'zero')
        self.assertEqual([p['target_current_A'] for p in result['points']],[3,4,5,4,3])

    def test_stop_on_return_saves_partial_point_and_preserves_current(self):
        runner=ExperimentRunner(replace(self.p,zero_after=True),Calibration(),self.lockin,self.magnet,self.field,True,demo=True)
        result=[];runner.outcome.connect(result.append)
        def stop_on_return():
            if len(runner.points)==3:runner.stop()
        self.lockin.on_sample=stop_on_return
        runner.run()
        self.assertEqual(result[-1]['reason'],'stopped')
        self.assertEqual(self.magnet.current,4)
        self.assertEqual(result[-1]['points'][-1]['sweep_branch'],'reverse')
        self.assertEqual(result[-1]['points'][-1]['result'],'stopped')
        self.assertNotIn('zero',[job for job,_ in self.magnet.calls])

    def test_reconnect_repeats_return_point_without_restarting_loop(self):
        original=self.magnet.call
        lost=False; seen_stop=False
        def call(job,data=None,*args,**kwargs):
            nonlocal lost,seen_stop
            if job=='set_current' and data['current']==5:seen_stop=True
            if job=='health' and seen_stop and self.magnet.current==4 and not lost:
                lost=True
                raise ConnectionLost('magnet','return leg USB loss')
            return original(job,data,*args,**kwargs)
        self.magnet.call=call
        result=self.run_scan()
        self.assertEqual(result['reason'],'complete')
        self.assertEqual([p['attempt'] for p in result['points']],[1,1,1,2,1])
        self.assertEqual([d['current'] for job,d in self.magnet.calls if job=='set_current'],[3,4,5,4,4,3])
        partial=result['metadata']['incomplete_attempts'][0]
        self.assertEqual((partial['index'],partial['sweep_branch']),(4,'reverse'))
        self.assertNotIn('zero',[job for job,_ in self.magnet.calls])

    def test_branches_keep_acquisition_order_and_share_only_actual_stop(self):
        result=self.run_scan()
        points=result['points']
        # Measured B need not be perfectly monotonic; never sort by measured B.
        points[1]['field']['field_mean_mT']=80
        branches=dict(field_branches(points))
        self.assertEqual([p['index'] for p in branches['forward']],[1,2,3])
        self.assertEqual([p['index'] for p in branches['reverse']],[3,4,5])
        points[2]['result']='stopped'
        self.assertEqual([p['index'] for p in dict(field_branches(points))['reverse']],[4,5])

    def test_export_has_two_distinct_branches_and_legends(self):
        from report import save_figures
        result=self.run_scan()
        # Capture the figure object at the save boundary, before any later reuse.
        captured=[]
        def capture(fig,*args,**kwargs):
            if not captured:
                captured.append([(list(ax.lines[0].get_xdata()),list(ax.lines[1].get_xdata()),
                                  [t.get_text() for t in ax.get_legend().get_texts()]) for ax in fig.axes])
        with patch('matplotlib.figure.Figure.savefig',autospec=True,side_effect=capture):
            save_figures(self.temp.name,result['points'],'V')
        for forward,reverse,labels in captured[0]:
            self.assertEqual(forward,[30,40,50])
            self.assertEqual(reverse,[50,40,30])
            self.assertEqual(labels,['Старт → стоп','Стоп → старт'])


class HysteresisProtocolTests(unittest.TestCase):
    def test_positive_round_trip_never_resets_or_switches_relay(self):
        self.exercise(Experiment(mode='hysteresis',start_A=3,stop_A=10,intervals=2).currents(),allow_relay=False)

    def test_sign_is_reversed_twice_through_confirmed_zero(self):
        self.exercise(Experiment(mode='hysteresis',start_A=1,stop_A=-1,intervals=3).currents(),allow_relay=True)

    def exercise(self,values,allow_relay):
        worker=MagnetWorker(demo=True)
        def call(job,data=None):
            ticket=Ticket();worker.execute(job,{'ticket':ticket,'data':data or {}})
            if ticket.error:raise ticket.error
            return ticket.value
        try:
            with patch('magnet.time.sleep'):
                call('open',{'port':'DEMO','baud':9600,'address':6})
                call('set_current',{'current':5,'voltage':5})
                worker.driver.source.writes.clear()
                for current in values:
                    state=call('set_current',{'current':current,'voltage':5})
                    # The GEN ASCII setpoint is rounded to six significant digits.
                    self.assertAlmostEqual(state['values']['PC?'],abs(current),delta=1e-6)
                    self.assertEqual(state['polarity'],1 if current>0 else -1)
                commands=[x.decode().strip() for x in worker.driver.source.writes]
                if allow_relay:
                    self.assertEqual([x for x in commands if x in ('H','X')],['X','H'])
                    for i,c in enumerate(commands):
                        if c in ('H','X'):
                            prefix=commands[:i]
                            self.assertIn('PC 0',prefix)
                            self.assertIn('OUT 0',prefix)
                            self.assertGreaterEqual(prefix.count('MC?'),3)
                else:
                    self.assertFalse(any(c in commands for c in ('PC 0','OUT 0','H','X')))
        finally:
            worker.driver.close()


if __name__=='__main__':unittest.main()
