"""Только аналоговый вход ai3. Никаких AO/DO, сброса устройства или автокалибровки."""
from datetime import datetime
import math
import time
import platform
import struct
from importlib.metadata import version, PackageNotFoundError

import numpy as np

DRIVER_URL = 'https://www.ni.com/en/support/downloads/drivers/download.ni-daq-mx.html'


def runtime_info():
    result = {'python': platform.python_version(), 'python_bits': struct.calcsize('P') * 8,
              'os': platform.platform()}
    for package in ('nidaqmx', 'numpy'):
        try:
            result[package] = version(package)
        except PackageNotFoundError:
            result[package] = 'not installed'
    return result


def native_access_violation(exc):
    return isinstance(exc, OSError) and 'access violation' in str(exc).lower()


def explain_error(exc):
    code = getattr(exc, 'error_code', None)
    if type(exc).__name__ == 'DaqNotFoundError':
        return 'Не найден системный драйвер NI-DAQmx. Установите NI-DAQmx с сайта NI и перезапустите программу.'
    if code == -50103:
        return 'Ресурс NI занят. Закройте Test Panels в NI MAX и другие программы, использующие AI этой платы.'
    if code == -200279:
        return 'Переполнен входной буфер NI-DAQmx. Сбор остановлен: уменьшите частоту оцифровки или нагрузку на USB/компьютер.'
    if code == -200220:
        return 'Устройство с таким именем не найдено. Сверьте Dev1/Dev2 с именем платы в NI MAX.'
    if native_access_violation(exc):
        return ('Сбой нативного вызова NI-DAQmx (access violation). Это ошибка обращения к памяти, '
                'а не величина напряжения на входе. Подробности и этап вызова записаны в журнал. '
                'Закройте NI MAX Test Panels перед повторной проверкой.')
    return f'{type(exc).__name__}: {exc}'


def load_daqmx():
    try:
        import nidaqmx
        from nidaqmx import constants
        from nidaqmx.stream_readers import AnalogSingleChannelReader
        from nidaqmx.system import System, Device
    except ImportError as exc:
        raise RuntimeError('Не установлен Python-пакет nidaqmx. Запустите start.bat или pip install -r requirements.txt. '
                           'Также нужен системный драйвер NI-DAQmx.') from exc
    return nidaqmx, constants, AnalogSingleChannelReader, System, Device


def discover_devices():
    _, _, _, system_type, _ = load_daqmx()
    system = system_type.local()
    version = system.driver_version
    found = []
    for device in system.devices:
        channels = list(device.ai_physical_chans.channel_names)
        if f'{device.name}/ai3' in channels:
            found.append({'name': device.name, 'product': device.product_type,
                          'serial': str(device.dev_serial_num), 'channel': f'{device.name}/ai3',
                          'ni_simulated_device': bool(device.dev_is_simulated)})
    return found, f'NI-DAQmx {version.major_version}.{version.minor_version}.{version.update_version}'


class NIInput:
    def __init__(self, loader=load_daqmx, progress=None):
        self.loader = loader
        self.task = None
        self.progress = progress or (lambda text: None)
        self.stage = 'initialization'
        self.first_read = True
        self.first_poll = True

    def step(self, name):
        self.stage = name
        self.progress('NI → ' + name)

    def open(self, config):
        config.validate()
        self.step('import nidaqmx')
        api, constants, reader_type, system_type, device_type = self.loader()
        metadata = runtime_info()
        if system_type is not None:
            self.step('System.driver_version')
            driver = system_type.local().driver_version
            metadata['ni_driver'] = f'{driver.major_version}.{driver.minor_version}.{driver.update_version}'
            self.progress('Окружение: ' + str(metadata))
        try:
            self.step('Task() / DAQmxCreateTask')
            self.task = api.Task()
            self.step('add_ai_voltage_chan / DAQmxCreateAIVoltageChan')
            channel = self.task.ai_channels.add_ai_voltage_chan(
                config.channel, terminal_config=constants.TerminalConfiguration.DIFF,
                min_val=-config.voltage_range, max_val=config.voltage_range,
                units=constants.VoltageUnits.VOLTS)
            self.step('cfg_samp_clk_timing / DAQmxCfgSampClkTiming')
            self.task.timing.cfg_samp_clk_timing(config.rate,
                sample_mode=constants.AcquisitionType.CONTINUOUS,
                samps_per_chan=max(10_000, math.ceil(config.rate * 2)))
            # Start performs the normal implicit commit. Keep the startup sequence
            # minimal: no optional overwrite setter or explicit Task.control call.
            self.step('AnalogSingleChannelReader')
            self.reader = reader_type(self.task.in_stream)
            self.array = np.empty(config.block_samples, dtype=np.float64)
            self.step('Task.start / DAQmxStartTask')
            clock_before = time.monotonic()
            self.task.start()
            clock_after = time.monotonic()
            self.step('timing.samp_clk_rate / DAQmxGetSampClkRate')
            self.rate = float(self.task.timing.samp_clk_rate)
            if not math.isfinite(self.rate) or self.rate <= 0:
                raise RuntimeError('NI-DAQmx вернул неверную частоту оцифровки.')
            self.step('channel.ai_min / channel.ai_max')
            minimum, maximum = float(channel.ai_min), float(channel.ai_max)
            self.step('Device product / serial / simulated')
            device = device_type(config.device)
            metadata.update({'device': config.device, 'physical_channel': config.channel,
                    'origin_monotonic_s': clock_before,
                    'time_anchor_uncertainty_s': clock_after - clock_before,
                    'time_anchor_description': 'Software monotonic time before DAQmxStartTask; not a shared hardware trigger with Lock-in.',
                    'product': device.product_type, 'serial': str(device.dev_serial_num),
                    'sample_rate_Hz': self.rate, 'requested_sample_rate_Hz': config.rate,
                    'voltage_min_V': minimum, 'voltage_max_V': maximum,
                    'terminal_configuration': 'DIFFERENTIAL', 'demo': False,
                    'ni_simulated_device': bool(getattr(device, 'dev_is_simulated', False)),
                    'started_local': datetime.now().astimezone().isoformat()})
            self.step('ready')
            return metadata
        except Exception as exc:
            # The owner closes the task in finally, after recording this failure.
            # A failed native close must not hide the original call/traceback.
            exc.ni_stage = self.stage
            raise

    def read(self, stop_event):
        if stop_event.is_set():
            return np.empty(0, dtype=np.float64)
        self.stage = 'in_stream.avail_samp_per_chan / DAQmxGetReadAvailSampPerChan'
        if self.first_poll:
            self.step(self.stage)
            self.first_poll = False
        available = int(self.task.in_stream.avail_samp_per_chan)
        if available < len(self.array):
            stop_event.wait(0.005)
            return np.empty(0, dtype=np.float64)
        wanted = len(self.array)
        if self.first_read:
            self.step('read_many_sample / DAQmxReadAnalogF64 (first block)')
        else:
            self.stage = 'read_many_sample / DAQmxReadAnalogF64'
        count = self.reader.read_many_sample(self.array,
                     number_of_samples_per_channel=wanted, timeout=0.25)
        if self.first_read:
            self.progress(f'Первый блок прочитан: {count} отсчётов.')
            self.first_read = False
        return self.array[:count]

    def close(self):
        if self.task is not None:
            task, self.task = self.task, None
            self.step('Task.close / DAQmxClearTask')
            task.close()


class DemoInput:
    def open(self, config):
        config.validate()
        self.config = config
        self.rate = config.rate
        self.index = 0
        self.next_read = time.monotonic()
        self.random = np.random.default_rng(6363)
        return {'device': 'DEMO', 'physical_channel': 'DEMO/ai3', 'product': 'Симулятор USB-6363',
                'sample_rate_Hz': self.rate, 'voltage_min_V': -config.voltage_range,
                'voltage_max_V': config.voltage_range, 'terminal_configuration': 'DIFFERENTIAL',
                'demo': True, 'started_local': datetime.now().astimezone().isoformat()}

    def read(self, stop_event):
        count = self.config.block_samples
        self.next_read += count / self.rate
        if stop_event.wait(max(0, self.next_read - time.monotonic())):
            return np.empty(0, dtype=np.float64)
        t = (self.index + np.arange(count)) / self.rate
        self.index += count
        amplitude = min(0.05, self.config.voltage_range * 0.3)
        offset = min(0.1, self.config.voltage_range * 0.2)
        return offset + amplitude * np.sin(2 * np.pi * min(1, self.rate / 20) * t) + self.random.normal(0, amplitude/30, count)

    def close(self):
        pass
