"""Signed current over the tested GEN60-40/shared relay protocol."""
import math
import time
from dataclasses import asdict

from magnet_driver import Limits, ValidationError


class PolarityUnknown(ValidationError):
    """Leave the physical current untouched until the user supplies its sign."""


class MagnetController:
    def __init__(self, driver, plant=None):
        self.driver = driver
        self.plant = plant
        self.polarity = None  # Last commanded relay state; no relay position query exists.
        self.polarity_confirmed = False

    def state(self):
        values = dict(self.driver.last)
        current = values.get('MC?')
        return {'connected': self.driver.connected, 'identified': self.driver.identified,
                'connection': asdict(self.driver.config) if self.driver.config else None,
                'polarity': self.polarity, 'values': values,
                'polarity_confirmed': self.polarity_confirmed,
                'signed_current_A': (current * self.polarity if current is not None and self.polarity else None)}

    def _plant(self):
        if self.plant:
            value = self.driver.last.get('PC?', 0) if self.driver.last.get('OUT?', False) else 0
            self.plant.set_current(value * (self.polarity or 1))

    def zero(self, timeout=30):
        self.driver.zero_and_off()
        self._plant()
        deadline, stable = time.monotonic() + timeout, 0
        while time.monotonic() < deadline:
            current = self.driver.query('MC?')
            stable = stable + 1 if abs(current) <= 0.01 else 0
            if stable >= 3:
                return self.state()
            time.sleep(0.1)
        raise ValidationError('Ток не спал до 0.01 A за 30 s. Полярность не переключалась.')

    def confirm_polarity(self, sign):
        if sign not in (-1, 1):
            raise ValidationError('Выберите текущую полярность + или −.')
        self.polarity, self.polarity_confirmed = sign, True
        self._plant()
        return self.state()

    def switch(self, target_sign):
        if target_sign not in (-1, 1):
            raise ValidationError('Полярность должна быть +1 или −1.')
        self.zero()
        self.polarity = None
        self.polarity_confirmed = False
        self.driver.switch_polarity('H' if target_sign > 0 else 'X')
        # The old application verified GEN manually after H/X. Do this once here,
        # without replaying H/X or enabling output after a serial failure.
        self.driver.probe()
        if self.driver.last.get('OUT?', True) or abs(self.driver.last.get('PC?', math.inf)) > 1e-9:
            raise ValidationError('После H/X источник не подтвердил OUT OFF и PC 0.')
        self.polarity = target_sign
        self.polarity_confirmed = True
        self._plant()
        return self.state()

    def set_signed(self, target_A, voltage_V, cancel=None):
        if not math.isfinite(target_A) or not -10 <= target_A <= 10:
            raise ValidationError('Допустимый ток: −10…+10 A.')
        if not math.isfinite(voltage_V) or not 0 < voltage_V <= 60:
            raise ValidationError('Задайте предел напряжения: больше 0, не более 60 V.')
        if cancel is not None and cancel.is_set():
            raise InterruptedError('Остановлено до изменения тока.')
        if not self.driver.identified:
            self.driver.probe()
        if abs(target_A) < 1e-10:
            return self.zero()
        sign = 1 if target_A > 0 else -1
        if sign != self.polarity:
            self.driver.readings()
            already_off = (not self.driver.last.get('OUT?', True)
                           and abs(self.driver.last.get('PC?', math.inf)) <= .0005
                           and abs(self.driver.last.get('MC?', math.inf)) <= .01)
            if not self.polarity_confirmed and not already_off:
                raise PolarityUnknown('Укажите текущую полярность кнопкой «Подтвердить знак без переключения». Ток сохранён; реле не переключалось.')
            self.switch(sign)
        if cancel is not None and cancel.is_set():
            raise InterruptedError('Остановлено после переключения полярности; выход выключен.')
        # Same-sign changes never call PC 0 / OUT 0 / H / X.
        self.driver.readings()
        current_voltage = self.driver.last['PV?']
        if abs(self.driver.last['PC?'] - abs(target_A)) > 0.0005:
            self.driver.set_value('PC', abs(target_A), Limits(10, max(voltage_V, current_voltage)))
        if abs(current_voltage - voltage_V) > 0.0005:
            self.driver.set_value('PV', voltage_V, Limits(10, voltage_V))
        if cancel is not None and cancel.is_set():
            raise InterruptedError('Остановлено до включения выхода.')
        if not self.driver.last.get('OUT?', False):
            self.driver.enable_output(Limits(10, voltage_V))
        self._plant()
        return self.state()

    def wait_current(self, target_A, cancel, timeout=30):
        if abs(target_A) < 1e-10:
            return self.state()
        deadline, stable = time.monotonic() + timeout, 0
        while time.monotonic() < deadline:
            if cancel.is_set():
                raise InterruptedError('Остановлено при ожидании тока.')
            measured = self.driver.query('MC?')
            tolerance = max(0.01, abs(target_A) * 0.01)
            stable = stable + 1 if abs(measured - abs(target_A)) <= tolerance else 0
            if stable >= 3:
                self._plant()
                return self.state()
            if cancel.wait(0.1):
                raise InterruptedError('Остановлено при ожидании тока.')
        raise ValidationError('Фактический ток не достиг уставки. Проверьте предел напряжения и состояние источника.')
