import threading
import time
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

import numpy as np

from field_data import FieldData
from models import Calibration
from reconnection import ConnectionLost, lockin_fingerprint
from services import MagnetWorker, Ticket
from magnet_driver import ValidationError
from magnet import PolarityUnknown
from test_experiment import ExperimentTests


class RecoveryTests(ExperimentTests):
    # Reuse the fixture, not its tests.
    def runner(self, parameters=None):
        runner = super().runner(parameters)
        runner.retry_delay = .001
        return runner

    def test_magnet_loss_repeats_point_and_separates_partial_data(self):
        original = self.magnet.call
        lost = False
        def call(job, *args, **kwargs):
            nonlocal lost
            if job == 'health' and not lost:
                lost = True
                raise ConnectionLost('magnet', 'COM disappeared')
            return original(job, *args, **kwargs)
        self.magnet.call = call
        runner = self.runner()
        runner.run()
        result = self.outcome[-1]
        self.assertEqual(result['reason'], 'complete')
        self.assertEqual([p['index'] for p in result['points']], [1, 2, 3])
        self.assertEqual([p['attempt'] for p in result['points']], [2, 1, 1])
        self.assertTrue(all(p['result'] == 'complete' for p in result['points']))
        self.assertEqual(len(result['metadata']['incomplete_attempts']), 1)
        self.assertEqual(len(list(Path(result['folder']).glob('incomplete/point_*/signal.dat'))), 1)
        self.assertIn('reconnect', [job for job, _ in self.magnet.calls])
        self.assertTrue(any(e['state'] == 'restored' for e in result['metadata']['recovery_events']))

    def test_lockin_loss_reopens_then_repeats_complete_point(self):
        original = self.lockin.call
        lost = False
        def call(job, *args, **kwargs):
            nonlocal lost
            if job == 'lab_xy' and not lost:
                lost = True
                raise ConnectionLost('lockin', 'USB lost')
            if job == 'lab_reconnect':
                return original('lab_snapshot')
            return original(job, *args, **kwargs)
        self.lockin.call = call
        runner = self.runner()
        runner.run()
        self.assertEqual(self.outcome[-1]['reason'], 'complete')
        self.assertEqual(self.outcome[-1]['points'][0]['attempt'], 2)
        self.assertEqual(self.outcome[-1]['metadata']['recovery_events'][-1]['device'], 'lockin')
        self.assertNotIn('zero', [job for job, _ in self.magnet.calls])

    def test_ni_loss_waits_for_fresh_data_and_repeats(self):
        original = self.field.finish
        lost = False
        def finish(*args):
            nonlocal lost
            value = original(*args)
            if not lost:
                lost = True
                self.field.ready = False
                value.update(valid=False, error='NI removed')
            return value
        self.field.finish = finish
        def online(cancel):
            self.field.ready = True
            return self.field.metadata
        self.field.wait_online = online
        runner = self.runner()
        runner.run()
        self.assertEqual(self.outcome[-1]['reason'], 'complete')
        self.assertEqual(self.outcome[-1]['points'][0]['attempt'], 2)

    def test_stop_during_reconnect_ends_wait_and_keeps_existing_points(self):
        original = self.magnet.call
        runner = self.runner()
        def call(job, *args, **kwargs):
            if job == 'health':
                raise ConnectionLost('magnet', 'lost')
            if job == 'reconnect':
                runner.stop()
                raise ConnectionLost('magnet', 'still lost')
            return original(job, *args, **kwargs)
        self.magnet.call = call
        start = time.perf_counter()
        runner.run()
        self.assertLess(time.perf_counter() - start, 2)
        self.assertEqual(self.outcome[-1]['reason'], 'stopped')
        self.assertEqual(self.outcome[-1]['points'], [])
        self.assertEqual(self.outcome[-1]['finish_action'], 'held')

    def test_changed_lockin_settings_wait_for_stop(self):
        runner = self.runner()
        original = self.lockin.call
        def call(job, *args, **kwargs):
            if job == 'lab_xy':
                raise ConnectionLost('lockin', 'lost')
            if job == 'lab_reconnect':
                runner.stop()
                return {'signal_unit': 'A'}
            return original(job, *args, **kwargs)
        self.lockin.call = call
        runner.run()
        self.assertEqual(self.outcome[-1]['reason'], 'stopped')
        self.assertFalse(self.outcome[-1]['points'])

    def test_unknown_polarity_waits_without_zero_then_resumes_after_confirmation(self):
        original = self.magnet.call
        unknown = True
        def call(job, *args, **kwargs):
            nonlocal unknown
            if job == 'set_current' and unknown:
                raise PolarityUnknown('Confirm current sign')
            if job == 'polarity_status':
                unknown = False  # Simulate the user confirming the actual relay sign.
                return {'polarity_confirmed': True}
            return original(job, *args, **kwargs)
        self.magnet.call = call
        runner = self.runner(replace(self.parameters, start_A=3, stop_A=10))
        runner.run()
        self.assertEqual(self.outcome[-1]['reason'], 'complete')
        self.assertNotIn('zero', [job for job, _ in self.magnet.calls])
        self.assertEqual(self.magnet.current, 10)

    def test_stop_while_waiting_for_polarity_preserves_existing_current(self):
        original = self.magnet.call
        self.magnet.current = 5
        runner = self.runner()
        def call(job, *args, **kwargs):
            if job == 'set_current':
                raise PolarityUnknown('Confirm current sign')
            if job == 'polarity_status':
                runner.stop()
                return {'polarity_confirmed': False}
            return original(job, *args, **kwargs)
        self.magnet.call = call
        runner.run()
        self.assertEqual(self.outcome[-1]['reason'], 'stopped')
        self.assertEqual(self.magnet.current, 5)
        self.assertNotIn('zero', [job for job, _ in self.magnet.calls])

    def test_valid_connection_with_unexpected_source_state_is_not_retried(self):
        original = self.magnet.call
        def call(job, *args, **kwargs):
            if job == 'health':
                raise ValidationError('Output switched off on front panel')
            return original(job, *args, **kwargs)
        self.magnet.call = call
        runner = self.runner()
        runner.run()
        self.assertEqual(self.outcome[-1]['reason'], 'error')
        self.assertNotIn('reconnect', [job for job, _ in self.magnet.calls])

    def test_final_read_loss_never_restores_or_zeros_current(self):
        original = self.magnet.call
        lost = False
        def call(job, *args, **kwargs):
            nonlocal lost
            if job == 'read' and not lost:
                lost = True
                raise ConnectionLost('magnet', 'lost at final read')
            return original(job, *args, **kwargs)
        self.magnet.call = call
        runner = self.runner(replace(self.parameters, zero_after=False))
        runner.run()
        self.assertEqual(self.outcome[-1]['reason'], 'complete')
        self.assertEqual(self.magnet.current, 1)
        self.assertEqual(self.outcome[-1]['finish_action'], 'unchanged_unverified')
        self.assertNotIn('zero', [job for job, _ in self.magnet.calls])
        self.assertNotIn('reconnect', [job for job, _ in self.magnet.calls])


# Avoid running inherited baseline tests twice.
for name in tuple(ExperimentTests.__dict__):
    if name.startswith('test_'):
        setattr(RecoveryTests, name, None)
del ExperimentTests


class DeviceRecoveryTests(unittest.TestCase):
    def test_ni_generation_never_mixes_samples_across_reconnect(self):
        field = FieldData()
        origin = time.perf_counter() - 2
        field.configure({'sample_rate_Hz': 10, 'session': 1})
        field.append(0, 10, origin, np.ones(5))
        field.begin(origin + .5, origin + 1)
        field.append(5, 10, origin, np.ones(2))
        field.fail('USB lost')
        field.configure({'sample_rate_Hz': 10, 'session': 2})
        field.append(0, 10, origin, np.full(15, 100.0))
        with self.assertRaises(ConnectionLost):
            field.ensure_online()
        old = field.finish(origin + 1, Calibration(), timeout=0)
        self.assertFalse(old['valid'])
        self.assertEqual(old['mean_voltage_V'], 1)
        self.assertEqual(old['ni']['session'], 1)
        field.ensure_online()
        field.begin(origin + 1.5, origin + 2)
        field.append(15, 10, origin, np.full(6, 100.0))
        new = field.finish(origin + 2, Calibration(), timeout=0)
        self.assertTrue(new['valid'])
        self.assertEqual(new['mean_voltage_V'], 100)
        self.assertEqual(new['ni']['session'], 2)

    def test_reopen_magnet_only_reads_then_normal_set_verifies_zero(self):
        worker = MagnetWorker(demo=True)
        with patch('magnet.time.sleep'):
            worker.execute('open', {'port': 'DEMO', 'baud': 9600, 'address': 6})
            worker.execute('set_current', {'current': 2, 'voltage': 5})
            worker.driver.close()
            worker.controller.polarity = None
            worker.reconnect()
            commands = [x.decode().strip() for x in worker.driver.source.writes]
            self.assertFalse(any(c.startswith(('PC ', 'PV ', 'OUT ')) or c in ('H', 'X') for c in commands))
            self.assertIsNone(worker.controller.polarity)
            self.assertTrue(worker.driver.last['OUT?'])
            worker.driver.source.writes.clear()
            worker.execute('confirm_polarity', {'sign': 1})
            worker.execute('set_current', {'current': -2, 'voltage': 5})
            commands = [x.decode().strip() for x in worker.driver.source.writes]
            relay = commands.index('X')
            self.assertLess(commands.index('PC 0'), relay)
            self.assertLess(commands.index('OUT 0'), relay)
            self.assertGreaterEqual(commands[:relay].count('MC?'), 6)
            self.assertLess(relay, commands.index('OUT 1'))
        worker.driver.close()

    def test_wrong_source_serial_is_not_accepted(self):
        worker = MagnetWorker(demo=True)
        worker.execute('open', {'port': 'DEMO', 'baud': 9600, 'address': 6})
        worker.saved_source_serial = 'ANOTHER-SOURCE'
        with self.assertRaises(ValidationError):
            worker.reconnect()
        self.assertFalse(worker.driver.connected)

    def test_fingerprint_ignores_live_frequency_but_checks_time_constant(self):
        base = {'signal_unit': 'V', 'sections': {'Reference / Output 1': {'values': {'frq1': 100, 'tc1': 5}}}}
        live = {'signal_unit': 'V', 'sections': {'Reference / Output 1': {'values': {'frq1': 101, 'tc1': 5}}}}
        changed = {'signal_unit': 'V', 'sections': {'Reference / Output 1': {'values': {'frq1': 101, 'tc1': 6}}}}
        self.assertEqual(lockin_fingerprint(base), lockin_fingerprint(live))
        self.assertNotEqual(lockin_fingerprint(base), lockin_fingerprint(changed))
