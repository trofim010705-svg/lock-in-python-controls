import threading
import unittest
from unittest.mock import patch

from magnet import MagnetController
from magnet_driver import Connection, MagnetDriver, Limits
from magnet_demo import DemoSerial


class FastCancel:
    def is_set(self): return False
    def wait(self, seconds): return False


class MagnetTests(unittest.TestCase):
    def setUp(self):
        self.driver = MagnetDriver(factory=DemoSerial, cancel=FastCancel())
        self.driver.open(Connection(source_port='DEMO', shared_relay=True))
        self.driver.probe()
        self.control = MagnetController(self.driver)
        self.pause = patch('magnet.time.sleep')
        self.pause.start()

    def tearDown(self):
        self.pause.stop()
        self.driver.close()

    def commands(self):
        return [x.decode().strip() for x in self.driver.source.writes]

    def seed_positive(self, current=5):
        self.control.polarity = 1
        self.control.polarity_confirmed = True
        self.driver.set_value('PV', 5, Limits(10, 5))
        self.driver.set_value('PC', current, Limits(10, 5))
        self.driver.enable_output(Limits(10, 5))
        self.driver.source.writes.clear()

    def test_existing_five_to_five_or_ten_never_resets_current(self):
        self.seed_positive()
        self.control.set_signed(5, 5)
        self.control.set_signed(10, 5)
        for forbidden in ('PC 0', 'OUT 0', 'H', 'X'):
            self.assertNotIn(forbidden, self.commands())
        self.assertEqual(self.driver.last['PC?'], 10)

    def test_negative_to_positive_has_verified_zero_before_relay(self):
        self.seed_positive()
        self.control.set_signed(-5, 5)
        commands = self.commands()
        relay = commands.index('X')
        self.assertLess(commands.index('PC 0'), relay)
        self.assertLess(commands.index('OUT 0'), relay)
        self.assertGreaterEqual(commands[:relay].count('MC?'), 6)
        self.assertLess(relay, commands.index('OUT 1'))
        self.assertEqual(self.control.polarity, -1)
        self.driver.source.writes.clear()
        self.control.set_signed(5, 5)
        self.assertEqual(self.commands().count('H'), 1)
        self.assertEqual(self.control.polarity, 1)

    def test_crossing_without_a_zero_measurement_point_still_zeros(self):
        self.seed_positive(1)
        self.control.set_signed(-1, 5)
        self.assertIn('PC 0', self.commands())
        self.assertIn('X', self.commands())

    def test_zero_point_does_not_flip_or_enable_output(self):
        self.seed_positive()
        self.control.set_signed(0, 5)
        self.assertFalse(self.driver.last['OUT?'])
        self.assertEqual(self.control.polarity, 1)
        self.assertNotIn('X', self.commands())
        self.assertNotIn('OUT 1', self.commands())

    def test_cancel_after_zero_prevents_current_application(self):
        self.seed_positive()
        stop = threading.Event()
        stop.set()
        with self.assertRaises(InterruptedError):
            self.control.set_signed(-5, 5, stop)
        self.assertEqual(self.commands(), [])

    def test_serial_failure_after_relay_never_enables_output(self):
        self.seed_positive()
        original = self.driver.source.write
        def fail(data):
            if data == b'X\r':
                self.driver.source.writes.append(data)
                raise OSError('USB disconnected')
            return original(data)
        self.driver.source.write = fail
        with self.assertRaises(OSError):
            self.control.set_signed(-5, 5)
        self.assertIsNone(self.control.polarity)
        self.assertNotIn('OUT 1', self.commands())
        self.assertFalse(self.driver.last['OUT?'])


if __name__ == '__main__':
    unittest.main()
