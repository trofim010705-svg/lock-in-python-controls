import unittest
from unittest.mock import patch

import serial

from magnet import PolarityUnknown
from reconnection import ConnectionLost
from services import MagnetWorker, Ticket


class PreserveCurrentTests(unittest.TestCase):
    def setUp(self):
        self.pause = patch('magnet.time.sleep')
        self.pause.start()
        self.worker = MagnetWorker(demo=True)
        self.links = []
        original = self.worker.driver.factory
        def factory(*args):
            link = original(*args)
            self.links.append(link)
            return link
        self.worker.driver.factory = factory

    def tearDown(self):
        self.worker.driver.close()
        self.pause.stop()

    def call(self, operation, data=None):
        ticket = Ticket()
        self.worker.execute(operation, {'ticket': ticket, 'data': data or {}})
        self.assertTrue(ticket.event.is_set())
        if ticket.error:
            raise ticket.error
        return ticket.value

    def open(self):
        return self.call('open', {'port': 'DEMO', 'baud': 9600, 'address': 6})

    def seed_five(self):
        self.open()
        self.call('set_current', {'current': 5, 'voltage': 5})
        for link in self.links:
            link.writes.clear()

    def commands(self):
        return [b.decode().strip() for link in self.links for b in link.writes]

    def assert_no_zero_or_relay(self):
        commands = self.commands()
        for forbidden in ('PC 0', 'OUT 0', 'H', 'X'):
            self.assertNotIn(forbidden, commands)

    def test_five_manual_disconnect_reconnect_then_three_to_ten_without_zero(self):
        self.seed_five()
        self.call('close')
        self.open()
        self.assertEqual(self.worker.controller.polarity, 1)
        self.assertFalse(self.worker.controller.polarity_confirmed)
        for current in range(3, 11):
            state = self.call('set_current', {'current': current, 'voltage': 5})
            self.assertEqual(state['values']['PC?'], current)
            self.assertTrue(state['values']['OUT?'])
        self.assert_no_zero_or_relay()
        self.assertIn('PC 3', self.commands())
        self.assertIn('PC 10', self.commands())

    def test_five_serial_loss_and_automatic_reconnect_then_three_without_zero(self):
        self.seed_five()
        original = self.worker.driver.source.write
        def fail(data):
            if data == b'MC?\r':
                raise serial.SerialException('USB disappeared')
            return original(data)
        self.worker.driver.source.write = fail
        with self.assertRaises(ConnectionLost):
            self.call('health', {'current': 5})
        self.call('reconnect')
        self.call('set_current', {'current': 3, 'voltage': 5})
        self.assertEqual(self.worker.driver.last['PC?'], 3)
        self.assertTrue(self.worker.driver.last['OUT?'])
        self.assert_no_zero_or_relay()

    def test_unknown_sign_preserves_five_until_explicit_confirmation(self):
        self.worker.demo_state = (5, 5, True)  # Source was already running before this app.
        self.open()
        with self.assertRaises(PolarityUnknown):
            self.call('set_current', {'current': 3, 'voltage': 5})
        self.assertEqual(self.worker.driver.last['PC?'], 5)
        self.assertTrue(self.worker.driver.last['OUT?'])
        before = list(self.commands())
        self.call('confirm_polarity', {'sign': 1})
        self.assertEqual(before, self.commands())
        self.call('set_current', {'current': 3, 'voltage': 5})
        self.assert_no_zero_or_relay()

    def test_unknown_sign_cancel_keeps_current_and_output(self):
        self.worker.demo_state = (5, 5, True)
        self.open()
        with self.assertRaises(PolarityUnknown):
            self.call('set_current', {'current': -3, 'voltage': 5})
        self.worker.shutdown()
        self.assertEqual(self.worker.demo_state, (5, 5, True))
        self.assert_no_zero_or_relay()

    def test_shutdown_keeps_current_without_hardware_writes(self):
        self.seed_five()
        self.worker.shutdown()
        self.assertEqual(self.worker.demo_state, (5, 5, True))
        self.assertEqual(self.commands(), [])

    def test_opposite_sign_after_reconnect_needs_confirmation_before_relay(self):
        self.seed_five()
        self.call('close')
        self.open()
        with self.assertRaises(PolarityUnknown):
            self.call('set_current', {'current': -3, 'voltage': 5})
        self.assertEqual(self.worker.driver.last['PC?'], 5)
        self.assert_no_zero_or_relay()
        self.call('confirm_polarity', {'sign': 1})
        self.call('set_current', {'current': -3, 'voltage': 5})
        commands = self.commands()
        relay = commands.index('X')
        self.assertLess(commands.index('PC 0'), relay)
        self.assertLess(commands.index('OUT 0'), relay)
        self.assertLess(relay, commands.index('OUT 1'))
