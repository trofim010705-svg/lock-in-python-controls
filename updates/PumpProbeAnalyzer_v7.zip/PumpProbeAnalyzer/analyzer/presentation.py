"""Presentation settings shared by the interactive plots and saved figures."""
from dataclasses import dataclass
import math
import numpy as np


def angle_unit(values):
    """Choose an engineering prefix; the stored arrays always remain radians."""
    values=np.asarray(values,dtype=float)
    finite=np.abs(values[np.isfinite(values)])
    magnitude=float(np.max(finite)) if finite.size else 0
    if magnitude == 0: return 1.0,'rad'
    for factor,unit in ((1.,'rad'),(1e-3,'mrad'),(1e-6,'µrad'),(1e-9,'nrad'),
                        (1e-12,'prad'),(1e-15,'frad'),(1e-18,'arad')):
        if magnitude >= factor: return factor,unit
    return 1e-18,'arad'


def angle_text(value):
    factor,unit=angle_unit([value])
    return f'{value/factor:.4g} {unit}'


@dataclass(frozen=True)
class PlotStyle:
    experiment_label: str = 'X1 experiment'
    fit_label: str = ''
    show_legend: bool = True
    time_ylim: tuple = None
    fft_ylim: tuple = None
    time_unit: str = 'ns'
    title_font_size: float = 14
    legend_font_size: float = 8

    @property
    def time_factor(self):
        return {'ns':1e-9,'ps':1e-12}[self.time_unit]

    def validate(self):
        if self.time_unit not in ('ns','ps'):
            raise ValueError('Единицы времени: ns или ps')
        for size in (self.title_font_size,self.legend_font_size):
            if not math.isfinite(size) or not 5 <= size <= 72:
                raise ValueError('Размер шрифта должен быть от 5 до 72 pt')
        for limits in (self.time_ylim, self.fft_ylim):
            if limits is not None and (len(limits) != 2 or
                    not all(math.isfinite(v) for v in limits) or limits[0] >= limits[1]):
                raise ValueError('Границы Y должны быть конечными числами: минимум < максимум')
        return self


def model_formula(count):
    if count == 1:
        equation='θ(u) = A₁ exp(−u/τ₁) sin(2πf₁u + φ₁) + C'
    else:
        equation=f'θ(u) = Σ(i=1…{count}) Aᵢ exp(−u/τᵢ) sin(2πfᵢu + φᵢ) + C'
    return equation+'\nu = t − t_ref'


def model_mathtext(count):
    if count == 1:
        terms=r'A_1 e^{-\frac{u}{\tau_1}}\sin(2\pi f_1u+\varphi_1)'
    else:
        terms=rf'\sum_{{i=1}}^{{{count}}} A_i e^{{-\frac{{u}}{{\tau_i}}}}\sin(2\pi f_i u+\varphi_i)'
    return r'$\theta(u)='+terms+r'+C,\qquad u=t-t_{\mathrm{ref}}$'


def footer_sections(result, peaks, time_unit='ns', annotation='', data_label='X1 experiment', count=None):
    """Untruncated figure footer; numerical arrays remain SI."""
    factor={'ns':1e-9,'ps':1e-12}[time_unit]
    count=(len(result.parameters)-1)//4 if result is not None else (count or 1)
    fit_lines=[data_label] if data_label.strip() else []
    if annotation.strip():fit_lines.extend(annotation.strip().splitlines())
    def pair(value,error,scale,unit):
        uncertainty=f'{error/scale:.3g}' if np.isfinite(error) else '—'
        return f'{value/scale:.6g} ± {uncertainty} {unit}'
    if result is None:
        fit_lines.append('Фит не рассчитан.')
    else:
        fit_lines.append(f't_ref = {result.reference_s/factor:.6g} {time_unit}')
        for i in range(count):
            a,f,phase,tau=result.parameters[4*i:4*i+4]
            ea,ef,ep,et=result.errors[4*i:4*i+4]
            scale,unit=angle_unit([a])
            fit_lines.append(f'A{i+1} = {pair(a,ea,scale,unit)}; f{i+1} = {pair(f,ef,1e9,"GHz")}')
            fit_lines.append(f'τ{i+1} = {pair(tau,et,factor,time_unit)}; φ{i+1} = {pair(phase,ep,1.,"rad")}')
        scale,unit=angle_unit([result.parameters[-1]])
        fit_lines.append('C = '+pair(result.parameters[-1],result.errors[-1],scale,unit))
        fit_lines.append(f'R² = {result.r_squared:.6g}; RMSE = {angle_text(result.rmse_rad)}')
        if result.warnings:fit_lines.append(f'Предупреждений фита: {len(result.warnings)} (подробности в TXT).')
    fft_lines=['FFT-пики: f, амплитуда, FWHM по A/2']
    if not peaks:fft_lines.append('Нет доступных пиков в выбранной полосе.')
    labels={'not_local_peak':'граница полосы', 'merged_half_height_lobe':'пики не разделены',
            'missing_left_crossing':'нет левой полувысоты','missing_right_crossing':'нет правой полувысоты',
            'missing_half_height_crossings':'нет полувысот'}
    for peak in peaks:
        fft_lines.append(f'{peak["rank"]}: f = {peak["frequency_hz"]/1e9:.6g} GHz; A = {angle_text(peak["amplitude_rad"])}')
        width=peak.get('fwhm_hz')
        if width is None:
            reason=labels.get(peak.get('fwhm_status'),'не разрешена')
            fft_lines.append(f'   FWHM = — ({reason})')
        else:fft_lines.append(f'   FWHM = {width/1e9:.6g} GHz')
    fft_lines.append('Ширины включают влияние окна времени и FFT-окна.')
    return model_mathtext(count),'\n'.join(fit_lines),'\n'.join(fft_lines)


def parameter_label(result, time_unit='ns'):
    if result is None:
        return ''
    lines = []
    for i in range((len(result.parameters)-1)//4):
        a, f, phase, tau = result.parameters[4*i:4*i+4]
        factor={'ns':1e-9,'ps':1e-12}[time_unit]
        lines.append(f'A{i+1}={angle_text(a)}; f{i+1}={f/1e9:.5g} GHz; φ{i+1}={phase:.4g}; τ{i+1}={tau/factor:.5g} {time_unit}')
    lines.append(f'C={angle_text(result.parameters[-1])}; R²={result.r_squared:.5g}')
    return '\n'.join(lines)
