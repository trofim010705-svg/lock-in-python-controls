"""Synthetic examples with the exact Magnetic Lab 1.x file schema."""
from pathlib import Path
import json
import numpy as np


def write_examples(parent):
    parent=Path(parent)
    folders=[]
    for i,name in enumerate(('Пример_прямой_проход','Пример_обратный_проход')):
        folder=parent/name
        folder.mkdir(parents=True,exist_ok=True)
        field=np.linspace(-100,100,61)
        if i:
            field=field[::-1]
        amplitude=(16+12*np.exp(-((field-8*i)/32)**2)+2*i)*1e-6
        phase=(180+np.degrees(np.arctan((field+5*i)/25))+15*i)%360
        headers=['Point','Current_set_A','Current_measured_A','Field_mean_mT','Amplitude_mean_V',
                 'Phase_mean_deg','Amplitude_std_V','Phase_circular_std_deg','Lockin_samples','NI_samples','Complete']
        lines=['\t'.join(headers)]
        points=[]
        for j,(b,r,p) in enumerate(zip(field,amplitude,phase),1):
            values=[j,b/10,b/10,b,r,p,.3e-6,1.5,300,30000,1]
            lines.append('\t'.join(f'{v:.12g}' for v in values))
            points.append({'index':j,'result':'complete','field':{'valid':True,'field_mean_mT':b},
                           'statistics':{'amplitude_mean':r,'phase_mean_deg':p}})
        (folder/'summary.dat').write_text('\n'.join(lines)+'\n',encoding='utf-8')
        (folder/'experiment.txt').write_text(json.dumps({'application':'DEMO: synthetic Magnetic Lab 1.3 data',
            'lockin':{'signal_unit':'V'},'parameters':{'additional':'Демонстрационные данные, не физический эксперимент.'},
            'points':points},ensure_ascii=False,indent=2),encoding='utf-8')
        folders.append(folder)
    return folders
