"""Exercise actual folder loading, GUI controls, math text and exports in the EXE."""
import hashlib
import json
from pathlib import Path
import platform
import sys
import time
import traceback


def run(report_path):
    import numpy as np
    from PyQt5.QtCore import QTimer
    from PyQt5.QtWidgets import QApplication
    from demo_data import write_examples
    from analysis_data import shifted_phase
    from window import AnalyzerWindow

    report_path=Path(report_path).resolve()
    report_path.parent.mkdir(parents=True,exist_ok=True)
    folders=write_examples(report_path.parent/'измерения')
    hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for f in folders for p in f.iterdir()}
    app=QApplication(sys.argv[:1])
    app.setStyle('Fusion')
    window=AnalyzerWindow()
    window.resize(1280,840)
    window.show()
    result={'ok':False,'frozen':bool(getattr(sys,'frozen',False)), 'python':platform.python_version(),
            'platform':platform.platform(),'qt_platform':app.platformName()}
    ending=False
    start=time.monotonic()
    def finish(ok,detail):
        nonlocal ending
        if ending:
            return
        ending=True
        result.update(ok=ok,detail=detail,elapsed_s=time.monotonic()-start)
        report_path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        window.close()
        app.quit()
    original_hook=sys.excepthook
    sys.excepthook=lambda typ,val,tb:finish(False,''.join(traceback.format_exception(typ,val,tb)))

    def tick():
        if ending or window.worker is None or window.worker.isRunning():
            return
        try:
            assert len(window.series)==2, window.last_import_errors
            first=next(s for s in window.series if s.data.folder==folders[0])
            second=next(s for s in window.series if s.data.folder==folders[1])
            assert first.color!=second.color and first.marker!=second.marker
            assert first.data.field[0]<first.data.field[-1]
            assert second.data.field[0]>second.data.field[-1]
            window.tree.setCurrentItem(window.tree.topLevelItem(window.series.index(first)))
            window.legend_text.setText('Прямой проход')
            window.legend_edited('Прямой проход')
            window.phase_slider.setValue(375)
            window.tree.setCurrentItem(window.tree.topLevelItem(window.series.index(second)))
            window.legend_text.setText('Обратный проход')
            window.legend_edited('Обратный проход')
            window.phase_slider.setValue(-225)
            assert first.offset==37.5 and second.offset==-22.5
            window.labels['title'].setText('Демонстрация: $$R(H), \\varphi(H)$$')
            window.labels['phase_label'].setText('$\\varphi$ (°)')
            window.fonts['title_size'].setValue(15)
            window.fonts['legend_size'].setValue(11)
            window.connected.setChecked(True)
            assert window.render_now(),window.last_error
            assert window.plot.unit=='µV'
            for s in window.series:
                line=window.plot.phase_artists[s.uid]
                np.testing.assert_allclose(line.get_ydata(),shifted_phase(s.data.phase,s.offset,'wrapped'))
            result['multiple_folders_distinct_styles']=True
            result['independent_phase_sliders']=True
            result['descending_sweep_preserved']=True
            # These represent pan/zoom on the visible canvas. Saving must not reset them.
            window.plot.phase.set_xlim(-75,80)
            window.plot.amplitude.set_ylim(12,34)
            window.plot.phase.set_ylim(70,330)
            window.canvas.draw()
            export=report_path.parent/'экспорт'
            export.mkdir(exist_ok=True)
            for suffix in ('png','pdf','svg'):
                window.save_plot(export/f'рисунок.{suffix}')
                assert (export/f'рисунок.{suffix}').stat().st_size>1000
            assert window.plot.phase.get_xlim()==(-75,80)
            assert window.plot.amplitude.get_ylim()==(12,34)
            assert window.plot.phase.get_ylim()==(70,330)
            metadata=json.loads((export/'рисунок.png.txt').read_text(encoding='utf-8'))
            assert {s['label']:s['phase_shift_deg'] for s in metadata['series']}=={'Прямой проход':37.5,'Обратный проход':-22.5}
            assert metadata['visible_limits']['field_mT']==[-75,80]
            window.export_data(export/'данные.dat')
            assert len((export/'данные.dat').read_text(encoding='utf-8-sig').splitlines())==123
            assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==old for p,old in hashes.items())
            result['same_figure_export_and_zoom']=True
            result['png_pdf_svg_and_shifted_table']=True
            result['source_files_unchanged']=True
            window.grab().save(str(report_path.parent/'preview.png'))
            finish(True,'Folders, independent phase shifts, labels/math text, SI scale, zoom-preserving export and source hashes verified.')
        except Exception:
            finish(False,traceback.format_exc())
    timer=QTimer()
    timer.setInterval(50)
    timer.timeout.connect(tick)
    timer.start()
    QTimer.singleShot(0,lambda:window.load_folders([report_path.parent/'измерения']))
    QTimer.singleShot(45000,lambda:finish(False,'GUI self-test timed out.'))
    app.exec_()
    sys.excepthook=original_hook
    return 0 if result['ok'] else 1


if __name__=='__main__':
    raise SystemExit(run(sys.argv[1] if len(sys.argv)>1 else 'selftest_report.json'))
