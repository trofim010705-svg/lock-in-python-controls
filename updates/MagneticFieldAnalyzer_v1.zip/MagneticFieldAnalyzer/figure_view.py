"""One editable Matplotlib figure, shared by on-screen preview and saved files."""
from dataclasses import dataclass, field
import csv
import json
import math
from pathlib import Path
import re
import uuid

import numpy as np
from matplotlib.figure import Figure
from matplotlib.mathtext import MathTextParser

from analysis_data import Measurement, shifted_phase, phase_curve

COLORS = ['#197a98', '#d15b3b', '#7357a8', '#36814a', '#ba4d87', '#b18a20', '#496aa6', '#7e6856']
MARKERS = [('Круг', 'o'), ('Квадрат', 's'), ('Треугольник ↑', '^'), ('Ромб', 'D'),
           ('Треугольник ↓', 'v'), ('Плюс', 'P'), ('Крест', 'X'), ('Звезда', '*')]
PREFIXES = [('p', 1e-12), ('n', 1e-9), ('µ', 1e-6), ('m', 1e-3), ('', 1.), ('k', 1e3), ('M', 1e6)]


@dataclass(eq=False)
class Series:
    data: Measurement
    label: str
    color: str
    marker: str
    offset: float = 0.
    visible: bool = True
    alpha: float = .85
    uid: str = field(default_factory=lambda: uuid.uuid4().hex)


@dataclass
class Appearance:
    title: str = ''
    amplitude_title: str = 'Амплитуда от магнитного поля'
    phase_title: str = 'Фаза от магнитного поля'
    x_label: str = 'Магнитное поле, mT'
    amplitude_label: str = ''
    phase_label: str = 'Фаза, °'
    phase_mode: str = 'wrapped'
    amplitude_factor: float | None = None
    title_size: int = 14
    legend_size: int = 10
    label_size: int = 11
    tick_size: int = 10
    marker_size: float = 5.
    connected: bool = False
    show_legend: bool = True
    legend_location: str = 'best'
    grid: bool = True
    x_limits: tuple | None = None
    amplitude_limits: tuple | None = None
    phase_limits: tuple | None = None


def display_unit(series, selected=None):
    visible = [s for s in series if s.visible]
    unit = series[0].data.unit if series else 'V'
    if selected is not None:
        factor = selected
    else:
        maximum = max((float(np.max(s.data.amplitude)) for s in visible), default=0.)
        factor = 1.
        if maximum > 0:
            factor = next((f for _, f in reversed(PREFIXES) if maximum >= f * (1 - 1e-12)), 1e-12)
    prefix = next((p for p, f in PREFIXES if f == factor), '')
    return factor, prefix + unit


def label_text(value):
    value = str(value).replace('$$', '$')
    if len(re.findall(r'(?<!\\)\$', value)) % 2:
        raise ValueError('В формулах нужно закрыть каждый знак $.')
    if '$' in value:
        MathTextParser('path').parse(value, dpi=100)
    return value


def protect_source(path, series):
    path = Path(path).expanduser().resolve()
    if path.name in ('summary.dat', 'experiment.txt', 'parameters.txt', 'signal.dat'):
        if any(path.is_relative_to(s.data.folder.resolve()) for s in series):
            raise ValueError('Нельзя перезаписывать исходный файл измерения. Выберите другое имя экспорта.')


class PlotFigure:
    def __init__(self):
        self.figure = Figure(figsize=(9, 8), facecolor='white')
        self.amplitude, self.phase = self.figure.subplots(2, 1, sharex=True)
        self.figure.subplots_adjust(left=.125, right=.97, bottom=.085, top=.9, hspace=.34)
        self.phase_artists = {}
        self.factor, self.unit = 1., 'V'

    def render(self, series, style):
        labels = [style.title, style.amplitude_title, style.phase_title,
                  style.x_label, style.amplitude_label, style.phase_label]
        labels.extend(s.label for s in series if s.visible)
        for text in labels:
            label_text(text)  # Reject invalid math before changing the visible figure.
        self.factor, self.unit = display_unit(series, style.amplitude_factor)
        self.amplitude.clear()
        self.phase.clear()
        self.phase_artists.clear()
        for s in series:
            if not s.visible:
                continue
            common = dict(marker=s.marker, markersize=style.marker_size, color=s.color,
                          alpha=s.alpha, linewidth=1.15, linestyle='-' if style.connected else 'None',
                          label=label_text(s.label))
            self.amplitude.plot(s.data.field, s.data.amplitude / self.factor, **common)
            phase = shifted_phase(s.data.phase, s.offset, style.phase_mode)
            x, y = phase_curve(s.data.field, phase, style.phase_mode, style.connected)
            self.phase_artists[s.uid], = self.phase.plot(x, y, **common)
        self.figure.suptitle(label_text(style.title), fontsize=style.title_size + 1, y=.985)
        self.amplitude.set_title(label_text(style.amplitude_title), fontsize=style.title_size, pad=10)
        self.phase.set_title(label_text(style.phase_title), fontsize=style.title_size, pad=10)
        self.amplitude.set_ylabel(label_text(style.amplitude_label or 'Амплитуда, ' + self.unit), fontsize=style.label_size)
        self.phase.set_ylabel(label_text(style.phase_label), fontsize=style.label_size)
        self.phase.set_xlabel(label_text(style.x_label), fontsize=style.label_size)
        self.amplitude.tick_params(labelbottom=True)
        for ax in (self.amplitude, self.phase):
            ax.tick_params(labelsize=style.tick_size)
            ax.grid(style.grid, alpha=.22)
            ax.margins(x=.04, y=.12)
            if style.show_legend and ax.lines:
                ax.legend(fontsize=style.legend_size, loc=style.legend_location, framealpha=.9)
        if style.x_limits is not None:
            self.phase.set_xlim(*style.x_limits)
        if style.amplitude_limits is not None:
            self.amplitude.set_ylim(*style.amplitude_limits)
        self.phase_limits(style)

    def phase_limits(self, style):
        if style.phase_limits is not None:
            self.phase.set_ylim(*style.phase_limits)
        elif style.phase_mode == 'wrapped':
            self.phase.set_ylim(0, 360)
        elif style.phase_mode == 'signed':
            self.phase.set_ylim(-180, 180)
        else:
            self.phase.relim()
            self.phase.autoscale(enable=True, axis='y')

    def update_phase(self, series, style):
        for s in series:
            artist = self.phase_artists.get(s.uid)
            if artist is not None:
                y = shifted_phase(s.data.phase, s.offset, style.phase_mode)
                artist.set_data(*phase_curve(s.data.field, y, style.phase_mode, style.connected))
        self.phase_limits(style)

    def metadata(self, series, style):
        return {'application': 'Magnetic Field Analyzer 1.0',
            'source_files_unchanged': True, 'amplitude_display_unit': self.unit,
            'amplitude_display_factor_SI': self.factor, 'appearance': vars(style),
            'visible_limits': {'field_mT': list(self.phase.get_xlim()),
                'amplitude_display_units': list(self.amplitude.get_ylim()), 'phase_deg': list(self.phase.get_ylim())},
            'series': [{'source_folder': str(s.data.folder), 'label': s.label,
                'color': s.color, 'marker': s.marker, 'alpha': s.alpha, 'visible': s.visible,
                'phase_shift_deg': s.offset, 'points': len(s.data.field), 'signal_unit_SI': s.data.unit,
                'import_warnings': s.data.warnings} for s in series]}

    def save(self, path, series, style, dpi=200):
        path = Path(path)
        protect_source(path, series)
        if path.suffix.lower() not in ('.png', '.pdf', '.svg'):
            raise ValueError('Поддерживаются PNG, PDF и SVG.')
        # No second figure, re-layout, auto-scaling, or tight cropping on export.
        self.figure.savefig(path, dpi=dpi, facecolor=self.figure.get_facecolor())
        metadata = self.metadata(series, style)
        try:
            path.with_suffix(path.suffix + '.txt').write_text(
                json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
        except OSError as exc:
            return f'Рисунок сохранён, но не удалось записать параметры: {exc}'
        return ''

    def export_data(self, path, series, style):
        path = Path(path)
        protect_source(path, series)
        with path.open('w', encoding='utf-8-sig', newline='') as stream:
            out = csv.writer(stream, delimiter=',' if path.suffix.lower() == '.csv' else '\t')
            out.writerow(['Series', 'Source_folder', 'Point', 'Field_mT', 'Amplitude_SI', 'SI_unit',
                'Amplitude_display', 'Display_unit', 'Phase_raw_deg', 'Phase_shift_deg', 'Phase_display_deg'])
            for s in series:
                if not s.visible:
                    continue
                phase = shifted_phase(s.data.phase, s.offset, style.phase_mode)
                for point, field, amp, raw, adjusted in zip(s.data.point, s.data.field, s.data.amplitude, s.data.phase, phase):
                    out.writerow([s.label, str(s.data.folder), f'{point:g}', f'{field:.12g}', f'{amp:.12g}',
                        s.data.unit, f'{amp/self.factor:.12g}', self.unit, f'{raw:.12g}', f'{s.offset:g}', f'{adjusted:.12g}'])
