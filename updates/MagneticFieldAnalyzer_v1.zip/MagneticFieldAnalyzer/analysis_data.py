"""Read-only import of Magnetic Lab 1.x folders. All amplitudes are SI values."""
from dataclasses import dataclass
from pathlib import Path
import csv
import json
import math
import os
import re

import numpy as np


class DataError(ValueError):
    pass


@dataclass
class Measurement:
    folder: Path
    point: np.ndarray
    field: np.ndarray
    amplitude: np.ndarray
    phase: np.ndarray
    unit: str
    warnings: list
    metadata_text: str = ''


AMPLITUDE_UNITS = {'V': ('V', 1.), 'mV': ('V', 1e-3), 'uV': ('V', 1e-6),
    'µV': ('V', 1e-6), 'μV': ('V', 1e-6), 'nV': ('V', 1e-9), 'pV': ('V', 1e-12),
    'A': ('A', 1.), 'mA': ('A', 1e-3), 'uA': ('A', 1e-6),
    'µA': ('A', 1e-6), 'μA': ('A', 1e-6), 'nA': ('A', 1e-9), 'pA': ('A', 1e-12)}


def number(value):
    try:
        return float(value) if value is not None else math.nan
    except (TypeError, ValueError):
        return math.nan


def preview(folder):
    path = folder / 'experiment.txt'
    if not path.exists():
        return ''
    with path.open('r', encoding='utf-8-sig', errors='replace') as stream:
        text = stream.read(250001)
    return text[:250000] + ('\n… Отображение сокращено до 250000 символов.' if len(text) > 250000 else '')


def assemble(folder, rows, unit, warnings):
    if unit not in AMPLITUDE_UNITS:
        raise DataError('Неизвестная единица амплитуды: ' + str(unit))
    physical_unit, factor = AMPLITUDE_UNITS[unit]
    values = np.asarray(rows, dtype=float).reshape(-1, 4)
    valid = np.isfinite(values[:, 1]) & np.isfinite(values[:, 2]) & (values[:, 2] >= 0)
    skipped = int(np.count_nonzero(~valid))
    if skipped:
        warnings.append(f'Пропущено точек без конечного поля/амплитуды: {skipped}.')
    values = values[valid]
    if not len(values):
        raise DataError('Нет завершённых точек с измеренным полем и амплитудой.')
    missing_phase = int(np.count_nonzero(~np.isfinite(values[:, 3])))
    if missing_phase:
        warnings.append(f'Не определена фаза у {missing_phase} точек; их амплитуда сохранена.')
    values[~np.isfinite(values[:, 3]), 3] = np.nan
    # Keep acquisition order, including descending sweeps and hysteresis loops.
    return Measurement(folder, values[:, 0], values[:, 1], values[:, 2] * factor,
                       values[:, 3], physical_unit, warnings, preview(folder))


def load_summary(folder):
    path = folder / 'summary.dat'
    with path.open('r', encoding='utf-8-sig') as stream:
        first = stream.readline().lstrip('#').strip()
        names = re.split(r'\s+', first)
        required = ('Point', 'Field_mean_mT', 'Phase_mean_deg', 'Complete')
        if any(key not in names for key in required):
            raise DataError('В summary.dat нет ожидаемых колонок Magnetic Lab: ' + ', '.join(required))
        amplitudes = [n for n in names if n.startswith('Amplitude_mean_')]
        if len(amplitudes) != 1:
            raise DataError('Не удалось однозначно определить колонку Amplitude_mean_*.')
        amp = amplitudes[0]
        rows, incomplete = [], 0
        for line_number, line in enumerate(stream, 2):
            if not line.strip() or line.lstrip().startswith('#'):
                continue
            cells = re.split(r'\s+', line.strip())
            if len(cells) != len(names):
                raise DataError(f'summary.dat, строка {line_number}: число столбцов не совпадает с заголовком.')
            row = dict(zip(names, cells))
            if number(row['Complete']) != 1:
                incomplete += 1
                continue
            rows.append([number(row[k]) for k in ('Point', 'Field_mean_mT', amp, 'Phase_mean_deg')])
    warnings = [f'Исключено незавершённых точек: {incomplete}.'] if incomplete else []
    return assemble(folder, rows, amp[len('Amplitude_mean_'):], warnings)


def load_metadata(folder):
    warnings, documents, unit = [], [], None
    experiment = folder / 'experiment.txt'
    if experiment.exists():
        try:
            info = json.loads(experiment.read_text(encoding='utf-8-sig'))
            documents = info.get('points', [])
            unit = info.get('lockin', {}).get('signal_unit')
        except (OSError, ValueError, AttributeError) as exc:
            warnings.append('Не прочитан experiment.txt: ' + str(exc))
    if not documents:
        files = sorted(folder.glob('point_*/parameters.txt'))
        if (folder / 'parameters.txt').exists():
            files = [folder / 'parameters.txt']
        for path in files:
            try:
                document = json.loads(path.read_text(encoding='utf-8-sig'))
                if not isinstance(document, dict):
                    raise DataError('Ожидался объект JSON.')
                documents.append(document)
                candidate = document.get('lockin', {}).get('signal_unit')
                if candidate:
                    if unit and candidate != unit:
                        raise DataError('В одной папке смешаны разные единицы сигнала.')
                    unit = candidate
            except DataError:
                raise
            except (OSError, ValueError, AttributeError) as exc:
                warnings.append(str(path.name) + ': ' + str(exc))
    if not isinstance(documents, list):
        raise DataError('Поле points в experiment.txt должно быть списком.')
    rows, incomplete = [], 0
    for document in sorted(documents, key=lambda p: number(p.get('index', 0)) if isinstance(p, dict) else 0):
        if not isinstance(document, dict):
            continue
        field, stats = document.get('field', {}), document.get('statistics', {})
        if document.get('result') != 'complete' or field.get('valid') is not True:
            incomplete += 1
            continue
        rows.append([number(document.get('index')), number(field.get('field_mean_mT')),
                     number(stats.get('amplitude_mean')), number(stats.get('phase_mean_deg'))])
    if incomplete:
        warnings.append(f'Исключено незавершённых точек: {incomplete}.')
    if unit is None:
        raise DataError('Не найдена единица сигнала в метаданных Lock-in.')
    return assemble(folder, rows, unit, warnings)


def load_measurement(folder):
    folder = Path(folder).expanduser().resolve()
    if not folder.is_dir():
        raise DataError('Папка не найдена: ' + str(folder))
    if (folder / 'summary.dat').exists():
        return load_summary(folder)
    return load_metadata(folder)


def find_measurements(folder, cancelled=lambda: False):
    """Selecting a parent is convenient; never descend into incomplete attempts."""
    folder = Path(folder).expanduser().resolve()
    if folder.name == 'incomplete' or 'incomplete' in folder.parts:
        return
    for current, directories, files in os.walk(folder, followlinks=False):
        if cancelled():
            return
        directories[:] = [d for d in sorted(directories) if d not in
            ('incomplete', 'venv', '.venv', '__pycache__', '_internal', '.git', 'Source')]
        path = Path(current)
        is_run = ('summary.dat' in files or 'experiment.txt' in files
                  or ('parameters.txt' in files and 'signal.dat' in files))
        if is_run:
            yield path
            directories.clear()


def shifted_phase(phase, offset, mode):
    phase = np.asarray(phase, dtype=float)
    if mode == 'unwrap':
        result = np.full_like(phase, np.nan)
        # Undefined phases split a run; do not infer winding across a gap.
        finite = np.isfinite(phase)
        edges = np.flatnonzero(np.diff(np.r_[False, finite, False]))
        for start, stop in zip(edges[::2], edges[1::2]):
            result[start:stop] = np.rad2deg(np.unwrap(np.deg2rad(phase[start:stop]))) + offset
        return result
    result = (phase + offset) % 360
    if mode == 'signed':
        result = (result + 180) % 360 - 180
    elif mode != 'wrapped':
        raise ValueError('Неизвестный режим фазы.')
    return result


def phase_curve(field, phase, mode, connected):
    """Break connecting lines at a modulo boundary; keep all experimental markers."""
    x, y = np.asarray(field), np.asarray(phase)
    if not connected or mode == 'unwrap' or len(y) < 2:
        return x, y
    breaks = np.flatnonzero(np.abs(np.diff(y)) > 180) + 1
    return np.insert(x.astype(float), breaks, np.nan), np.insert(y.astype(float), breaks, np.nan)
