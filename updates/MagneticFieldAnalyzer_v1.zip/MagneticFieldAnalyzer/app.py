"""Run with Python 3.10+; no instrument drivers are required."""
import argparse
from pathlib import Path
import sys


def main():
    if sys.version_info < (3, 10):
        raise RuntimeError('Нужен Python 3.10 или новее; рекомендуется Python 3.11 x64.')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('folders', nargs='*', help='Measurement folders or their parent')
    parser.add_argument('--self-test', type=Path)
    args = parser.parse_args()
    if args.self_test:
        from selftest import run
        return run(args.self_test)
    from PyQt5.QtCore import QTimer
    from PyQt5.QtWidgets import QApplication
    from window import AnalyzerWindow
    app = QApplication(sys.argv[:1])
    app.setStyle('Fusion')
    window = AnalyzerWindow()
    window.show()
    if args.folders:
        QTimer.singleShot(0, lambda: window.load_folders(args.folders))
    return app.exec_()


if __name__ == '__main__':
    raise SystemExit(main())
