from dataclasses import replace
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QFileDialog

from analysis_data import load_measurement
from window import AnalyzerWindow
from test_data import make_folder


class WindowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([])

    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.one=load_measurement(make_folder(Path(self.temp.name)/'одна'))
        self.two=load_measurement(make_folder(Path(self.temp.name)/'другая'))
        self.w=AnalyzerWindow()
        self.w.loaded([self.one,self.two],[])

    def tearDown(self):
        self.w.close()
        self.app.processEvents()
        self.temp.cleanup()

    def test_slider_changes_only_selected_series(self):
        self.w.tree.setCurrentItem(self.w.tree.topLevelItem(0))
        self.w.phase_slider.setValue(225)
        self.w.tree.setCurrentItem(self.w.tree.topLevelItem(1))
        self.w.phase_slider.setValue(-305)
        self.assertEqual([s.offset for s in self.w.series],[22.5,-30.5])
        self.assertTrue(self.w.render_now())
        np.testing.assert_allclose(self.w.plot.phase.lines[0].get_ydata(),[21.5,23.5,42.5])
        np.testing.assert_allclose(self.w.plot.phase.lines[1].get_ydata(),[328.5,330.5,349.5])

    def test_save_does_not_autoscale_away_a_visible_zoom(self):
        self.w.canvas.draw()
        self.w.plot.phase.set_xlim(13,27)
        self.w.plot.phase.set_ylim(50,200)
        self.w.plot.amplitude.set_ylim(12,28)
        self.w.save_plot(Path(self.temp.name)/'view.png')
        self.assertEqual(self.w.plot.phase.get_xlim(),(13,27))
        self.assertEqual(self.w.plot.phase.get_ylim(),(50,200))
        self.assertEqual(self.w.plot.amplitude.get_ylim(),(12,28))

    def test_invalid_title_blocks_export_without_crashing_or_losing_plot(self):
        artist=self.w.plot.amplitude.lines[0]
        self.w.labels['title'].setText('$\\unsupportedcommand$')
        path=Path(self.temp.name)/'bad.png'
        with self.assertRaises(ValueError):
            self.w.save_plot(path)
        self.assertFalse(path.exists())
        self.assertIs(self.w.plot.amplitude.lines[0],artist)
        self.w.labels['title'].setText('$$R(H)$$')
        self.assertTrue(self.w.render_now())
        self.assertEqual(self.w.plot.figure._suptitle.get_text(),'$R(H)$')

    def test_mixed_physical_units_are_not_overlaid_as_if_equivalent(self):
        third=replace(self.two,folder=Path(self.temp.name)/'ток',unit='A')
        self.w.loaded([third],[])
        self.assertEqual(len(self.w.series),2)
        self.assertIn('V и A',self.w.last_import_errors[0])

    def test_hide_and_remove_series_updates_both_graphs(self):
        self.w.tree.topLevelItem(0).setCheckState(0,Qt.Unchecked)
        self.w.render_now()
        self.assertEqual(len(self.w.plot.amplitude.lines),1)
        self.assertEqual(len(self.w.plot.phase.lines),1)
        self.w.tree.setCurrentItem(self.w.tree.topLevelItem(1))
        self.w.remove_series()
        self.assertEqual(len(self.w.series),1)

    def test_folder_dialog_can_be_opened_and_cancelled(self):
        with patch.object(QFileDialog,'exec_',return_value=QFileDialog.Rejected):
            self.w.choose_folders()
        self.assertEqual(len(self.w.series),2)


if __name__=='__main__':
    unittest.main()
