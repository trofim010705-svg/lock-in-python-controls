import csv
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib import image as mplimage

from analysis_data import load_measurement
from figure_view import Appearance, PlotFigure, Series, label_text
from test_data import make_folder


class FigureTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.folder=make_folder(Path(self.temp.name)/'данные')
        self.data=load_measurement(self.folder)
        self.series=[Series(self.data,'$H=10$','#197a98','o')]
        self.plot=PlotFigure()
        FigureCanvasAgg(self.plot.figure)
        self.style=Appearance()

    def tearDown(self):
        self.temp.cleanup()

    def test_independent_shifts_and_automatic_microvolt_scale(self):
        second=Series(self.data,'Другой проход','#d15b3b','s',offset=90)
        self.series.append(second)
        self.plot.render(self.series,self.style)
        self.assertEqual(self.plot.unit,'µV')
        np.testing.assert_allclose(self.plot.amplitude.lines[0].get_ydata(),[10,20,30])
        np.testing.assert_allclose(self.plot.phase.lines[0].get_ydata(),[359,1,20])
        np.testing.assert_allclose(self.plot.phase.lines[1].get_ydata(),[89,91,110])
        np.testing.assert_allclose(self.data.phase,[359,1,20])

    def test_phase_update_keeps_amplitude_artists(self):
        self.plot.render(self.series,self.style)
        artist=self.plot.amplitude.lines[0]
        self.series[0].offset=10
        self.plot.update_phase(self.series,self.style)
        self.assertIs(self.plot.amplitude.lines[0],artist)
        np.testing.assert_array_equal(self.plot.phase.lines[0].get_ydata(),[9,11,30])

    def test_export_png_pixels_are_the_preview_at_same_dpi_and_limits(self):
        self.style.title='$$\\phi(H)$$'
        self.style.x_limits=(12,29)
        self.style.amplitude_limits=(10,25)
        self.plot.render(self.series,self.style)
        self.plot.figure.set_dpi(120)
        self.plot.figure.canvas.draw()
        before=np.asarray(self.plot.figure.canvas.buffer_rgba()).copy()
        path=Path(self.temp.name)/'видимый.png'
        self.plot.save(path,self.series,self.style,dpi=120)
        saved=np.rint(mplimage.imread(path)*255).astype(np.uint8)
        np.testing.assert_array_equal(saved,before)
        self.assertEqual(self.plot.phase.get_xlim(),(12,29))
        metadata=json.loads(path.with_suffix('.png.txt').read_text())
        self.assertEqual(metadata['visible_limits']['amplitude_display_units'],[10,25])

    def test_data_export_records_raw_and_shifted_phase_without_changing_sources(self):
        raw=self.folder/'summary.dat'
        old=hashlib.sha256(raw.read_bytes()).hexdigest()
        self.series[0].offset=10
        self.plot.render(self.series,self.style)
        path=Path(self.temp.name)/'данные.csv'
        self.plot.export_data(path,self.series,self.style)
        with path.open(encoding='utf-8-sig',newline='') as f:
            rows=list(csv.DictReader(f))
        self.assertEqual(float(rows[0]['Phase_raw_deg']),359)
        self.assertEqual(float(rows[0]['Phase_display_deg']),9)
        self.assertEqual(old,hashlib.sha256(raw.read_bytes()).hexdigest())
        with self.assertRaisesRegex(ValueError,'исходный'):
            self.plot.export_data(raw,self.series,self.style)
        self.assertEqual(old,hashlib.sha256(raw.read_bytes()).hexdigest())

    def test_bad_latex_does_not_clear_existing_figure(self):
        self.plot.render(self.series,self.style)
        artist=self.plot.amplitude.lines[0]
        self.style.title='$\\nonexistentcommand$'
        with self.assertRaises(ValueError):
            self.plot.render(self.series,self.style)
        self.assertIs(self.plot.amplitude.lines[0],artist)
        self.assertEqual(label_text('$$\\phi$$'),'$\\phi$')

    def test_pdf_and_svg_save_current_figure(self):
        self.plot.render(self.series,self.style)
        for suffix in ('.pdf','.svg'):
            path=Path(self.temp.name)/('figure'+suffix)
            self.plot.save(path,self.series,self.style)
            self.assertGreater(path.stat().st_size,1000)


if __name__=='__main__':
    unittest.main()
