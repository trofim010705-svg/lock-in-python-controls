"""Independent two-plot Qt analysis window. Numeric values and reports use SI."""
from html import escape
from pathlib import Path
import numpy as np
from PyQt5.QtCore import Qt, QThreadPool, QTimer, pyqtSlot
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QCheckBox, QDialog, QFormLayout, QGroupBox, QLineEdit, QComboBox, QSpinBox, QPushButton, QLabel,
    QPlainTextEdit, QSplitter, QScrollArea, QTableWidget, QTableWidgetItem,
    QAbstractItemView, QHeaderView, QFileDialog, QTabWidget)
import pyqtgraph as pg
from . import core
from .io import load_pair, associated_notes
from .tasks import Job
from .presentation import PlotStyle, parameter_label

STYLE = '''
QMainWindow { background: #edf2f7; }
QGroupBox { background: white; border: 1px solid #d9e3ee; border-radius: 7px; margin-top: 12px; padding: 12px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; color: #25435d; padding: 0 4px; }
QLineEdit, QComboBox, QSpinBox { min-height: 26px; }
QPushButton { padding: 7px 10px; background: #f5f8fc; color: #194764; border: 1px solid #bfcedb; border-radius: 4px; }
QPushButton#primary { background: #126e96; color: white; }
QPushButton:disabled { color: #93a2ae; }
QTableWidget { background: white; gridline-color: #e1e8f0; }
'''


class AnalysisWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Pump–Probe Analyzer · X1 / FFT / damped oscillations')
        self.resize(1500, 1000); self.setStyleSheet(STYLE)
        self.pool = QThreadPool(self); self.pool.setMaxThreadCount(1)
        self.job = None; self.measurement = self.prepared = self.result = None
        self.dirty = True; self.closing = False
        self.revision = self.job_revision = 0
        self.pending_prepare = self.pending_fit = self.reseed = False
        self.applied_time_ylim = self.applied_fft_ylim = None
        pg.setConfigOptions(antialias=True, foreground='#354b60')
        root = QWidget(); self.setCentralWidget(root); layout = QVBoxLayout(root)
        header = QHBoxLayout()
        self.open_button = QPushButton('Открыть .dat + .txt'); self.open_button.setObjectName('primary')
        self.notes_button = QPushButton('Выбрать другой .txt')
        self.info_button = QPushButton('Окно параметров .txt')
        self.export_button = QPushButton('Экспорт PNG / PDF / данных')
        self.picture_button = QPushButton('Сохранить картинку…')
        self.cancel_button = QPushButton('Отмена вычисления'); self.cancel_button.clicked.connect(self.cancel_job)
        for b in (self.open_button, self.notes_button, self.info_button, self.picture_button, self.export_button, self.cancel_button): header.addWidget(b)
        layout.addLayout(header)
        self.file_label = QLabel('Откройте измерение. Используются только первые два столбца: позиция и X1.')
        self.file_label.setWordWrap(True); layout.addWidget(self.file_label)
        splitter = QSplitter(Qt.Horizontal); splitter.setChildrenCollapsible(False); layout.addWidget(splitter,1)
        self.tabs = QTabWidget(); self.tabs.setMinimumWidth(420); splitter.addWidget(self.tabs)
        settings = QWidget(); left = QVBoxLayout(settings)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setWidget(settings)
        self.tabs.addTab(scroll, 'Анализ')
        self.notes = QPlainTextEdit(); self.notes.setReadOnly(True); self.notes.setPlaceholderText('Содержимое файла параметров .txt')
        self.tabs.addTab(self.notes, 'Параметры .txt')
        self.info_dialog = QDialog(self); self.info_dialog.setWindowTitle('Параметры измерения · .txt')
        self.info_dialog.resize(700,600)
        info_layout = QVBoxLayout(self.info_dialog)
        self.info_text = QPlainTextEdit(); self.info_text.setReadOnly(True); info_layout.addWidget(self.info_text)
        self.info_button.clicked.connect(self.info_dialog.show)
        self.controls = []
        group = QGroupBox('Физический пересчёт'); form = QFormLayout(group)
        self.zero_mode = QComboBox(); self.zero_mode.addItems(['Максимум исходного X1', 'Вручную'])
        form.addRow('Определение x₀', self.zero_mode); self.controls.append(self.zero_mode)
        self.zero = self.number(form, 'Ноль задержки, mm', '106.45')
        self.zero.setToolTip('В автоматическом режиме здесь показана координата максимума исходного X1 в mm.')
        self.units = QComboBox(); self.units.addItems(['mm', 'шаги']); form.addRow('Координаты файла', self.units)
        self.controls.append(self.units)
        self.step_size = self.number(form, 'Миллиметров на шаг', '0')
        self.path_factor = self.number(form, 'Оптический множитель', '2')
        self.light_speed = self.number(form, 'Скорость света, m/s', '3e8')
        self.bal = self.number(form, 'Bal, mV  (Bal < 0)', '')
        self.sig = self.number(form, 'Sig, mV  (Sig > 0)', '')
        self.bal.setPlaceholderText('Измеренное отрицательное значение')
        self.sig.setPlaceholderText('Измеренное положительное значение')
        note = QLabel('θ = √2 · X1 / [4√Sig · √(Sig − Bal)]\nX1 — в V; Bal и Sig переводятся из mV в V.\nУгол — в rad, префикс на графике выбирается автоматически.')
        note.setWordWrap(True); form.addRow(note)
        left.addWidget(group)
        group = QGroupBox('Окно времени и фон'); form = QFormLayout(group)
        self.window_mode = QComboBox(); self.window_mode.addItems(['От максимума X1 + шаги до конца', 'Вручную'])
        form.addRow('Временное окно',self.window_mode); self.controls.append(self.window_mode)
        self.skip_steps = QSpinBox(); self.skip_steps.setRange(0,1000000); self.skip_steps.setValue(3)
        form.addRow('Шагов после максимума',self.skip_steps); self.controls.append(self.skip_steps)
        self.fit_start = self.number(form, 'Начало окна / фита, s', '1e-11')
        self.fit_stop = self.number(form, 'Конец окна / фита, s', '3.5e-9')
        self.background = QComboBox(); self.background.addItems(['Без вычитания', 'Константа', 'Линейный', 'Квадратичный'])
        form.addRow('Полиномиальный фон', self.background); self.controls.append(self.background)
        self.bg_start = self.number(form, 'Оценка фона от, s', '1e-11')
        self.bg_stop = self.number(form, 'Оценка фона до, s', '3.5e-9')
        self.window = QComboBox(); self.window.addItems(['Hann', 'Прямоугольное'])
        form.addRow('Окно FFT', self.window); self.controls.append(self.window)
        self.padding = QComboBox()
        for n in (1,2,4,8,16,32,64,128,512): self.padding.addItem('×'+str(n),n)
        self.padding.setCurrentIndex(3); form.addRow('Zero-padding', self.padding); self.controls.append(self.padding)
        auto_note=QLabel('Графики, FFT и фит пересчитываются автоматически после изменения параметров.'); auto_note.setWordWrap(True); form.addRow(auto_note)
        left.addWidget(group)
        group = QGroupBox('Модель и начальные параметры (SI)'); form = QVBoxLayout(group)
        row = QHBoxLayout()
        self.model = QComboBox(); self.model.addItems(['Один затухающий синус + C', 'Сумма затухающих синусов + C'])
        self.count = QSpinBox(); self.count.setRange(2,6); self.count.setValue(2)
        row.addWidget(self.model,1); row.addWidget(self.count); form.addLayout(row)
        self.reference_label = QLabel('Модель: u = t − t_ref; A и φ заданы при начале фита.'); self.reference_label.setWordWrap(True)
        form.addWidget(self.reference_label)
        self.table = QTableWidget(0,3); self.table.setHorizontalHeaderLabels(['Параметр', 'Старт', 'Фит ± σ'])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setMinimumHeight(220); form.addWidget(self.table)
        self.seed_button = QPushButton('Обновить стартовые параметры по FFT')
        form.addWidget(self.seed_button)
        left.addWidget(group)
        group = QGroupBox('Легенда и масштаб Y'); form = QFormLayout(group)
        self.legend_visible = QCheckBox('Показывать легенду'); self.legend_visible.setChecked(True)
        form.addRow(self.legend_visible)
        self.experiment_label = QLineEdit('X1 experiment'); form.addRow('Точки',self.experiment_label)
        self.fit_label = QPlainTextEdit('Fit'); self.fit_label.setMaximumHeight(95)
        form.addRow('Линия фита',self.fit_label)
        self.legend_parameters = QCheckBox('Добавлять численные параметры фита'); self.legend_parameters.setChecked(True)
        form.addRow(self.legend_parameters)
        self.copy_legend = QPushButton('Параметры → в текст легенды')
        form.addRow(self.copy_legend)
        self.time_y_auto = QCheckBox('Автомасштаб Y: временной график'); self.time_y_auto.setChecked(True)
        self.fft_y_auto = QCheckBox('Автомасштаб Y: FFT'); self.fft_y_auto.setChecked(True)
        self.time_y_min, self.time_y_max = QLineEdit('-5e-6'), QLineEdit('5e-6')
        self.fft_y_min, self.fft_y_max = QLineEdit('0'), QLineEdit('5e-6')
        for auto, low, high in ((self.time_y_auto,self.time_y_min,self.time_y_max),
                                (self.fft_y_auto,self.fft_y_min,self.fft_y_max)):
            form.addRow(auto)
            row=QHBoxLayout(); row.addWidget(low); row.addWidget(high); form.addRow('Y min / max, rad',row)
        self.apply_y_button = QPushButton('Применить границы Y'); form.addRow(self.apply_y_button)
        self.display_controls=[self.legend_visible,self.experiment_label,self.fit_label,self.legend_parameters,
            self.copy_legend,self.time_y_auto,self.fft_y_auto,self.time_y_min,self.time_y_max,self.fft_y_min,self.fft_y_max,self.apply_y_button]
        style_page=QWidget(); style_layout=QVBoxLayout(style_page)
        style_layout.addWidget(group); style_layout.addStretch()
        style_scroll=QScrollArea(); style_scroll.setWidgetResizable(True); style_scroll.setWidget(style_page)
        self.tabs.addTab(style_scroll,'Оформление')
        form.setRowWrapPolicy(QFormLayout.WrapLongRows)
        left.addStretch()
        for form in settings.findChildren(QFormLayout): form.setRowWrapPolicy(QFormLayout.WrapLongRows)
        charts = QWidget(); right = QVBoxLayout(charts); splitter.addWidget(charts)
        self.title = QLineEdit('Pump–probe · X1'); self.title.setPlaceholderText('Title графика')
        right.addWidget(self.title)
        self.graphics = pg.GraphicsLayoutWidget(); self.graphics.setBackground('white'); right.addWidget(self.graphics,1)
        self.time_plot = self.graphics.addPlot(row=0,col=0); self.time_plot.setLabel('bottom','Delay',units='s'); self.time_plot.setLabel('left','Rotation',units='rad')
        self.time_plot.getAxis('bottom').enableAutoSIPrefix(False)
        self.legend = self.time_plot.addLegend(offset=(-10,10),labelTextSize='8pt')
        self.points = self.time_plot.plot(pen=None,symbol='o',symbolSize=4,symbolBrush='#147c9c',symbolPen=None,name='X1 experiment')
        self.fit_curve = self.time_plot.plot(pen=pg.mkPen('#d56e36',width=2))
        self.time_plot.addItem(pg.InfiniteLine(pos=0,angle=90,pen=pg.mkPen('#7a8e9b',style=Qt.DashLine)))
        self.fft_plot = self.graphics.addPlot(row=1,col=0); self.fft_plot.setLabel('bottom','Frequency',units='Hz'); self.fft_plot.setLabel('left','FFT amplitude',units='rad')
        self.spectrum = self.fft_plot.plot(pen=pg.mkPen('#6553a7',width=1.6))
        self.markers = self.fft_plot.plot(pen=None,symbol='o',symbolSize=7,symbolBrush='#d56e36',symbolPen='w')
        self.region = pg.LinearRegionItem((.3e9,2e9),brush=(30,165,162,35)); self.region.setZValue(-5); self.fft_plot.addItem(self.region)
        for plot in (self.time_plot,self.fft_plot): plot.showGrid(x=True,y=True,alpha=.15)
        bandrow = QHBoxLayout(); bandrow.addWidget(QLabel('Поиск пиков, Hz:'))
        self.low = QLineEdit('3e8'); self.high = QLineEdit('2e9')
        bandrow.addWidget(self.low); bandrow.addWidget(self.high); right.addLayout(bandrow)
        self.peak_label = QLabel('Перетащите границы области на спектре.'); self.peak_label.setWordWrap(True); right.addWidget(self.peak_label)
        self.messages = QPlainTextEdit(); self.messages.setReadOnly(True); self.messages.setMaximumHeight(110); right.addWidget(self.messages)
        splitter.setSizes([465,1035])
        self.auto_timer = QTimer(self); self.auto_timer.setSingleShot(True); self.auto_timer.setInterval(450)
        self.auto_timer.timeout.connect(self.dispatch_auto)
        self.peak_timer = QTimer(self); self.peak_timer.setSingleShot(True); self.peak_timer.setInterval(100)
        self.peak_timer.timeout.connect(self.update_peaks)
        self.region.sigRegionChanged.connect(lambda:self.peak_timer.start())
        self.low.editingFinished.connect(self.apply_band); self.high.editingFinished.connect(self.apply_band)
        self.open_button.clicked.connect(self.open_files); self.notes_button.clicked.connect(self.change_notes)
        self.seed_button.clicked.connect(self.reset_seeds); self.export_button.clicked.connect(self.export)
        self.picture_button.clicked.connect(self.save_picture)
        self.apply_y_button.clicked.connect(self.apply_y_limits)
        self.time_y_auto.toggled.connect(self.auto_y_changed); self.fft_y_auto.toggled.connect(self.auto_y_changed)
        self.experiment_label.textChanged.connect(self.refresh_legend); self.fit_label.textChanged.connect(self.refresh_legend)
        self.legend_visible.toggled.connect(self.refresh_legend); self.legend_parameters.toggled.connect(self.refresh_legend)
        self.copy_legend.clicked.connect(self.copy_parameters_to_legend)
        self.title.textChanged.connect(lambda s:self.time_plot.setTitle(escape(s),color='#29465d'))
        self.time_plot.setTitle('Pump–probe · X1',color='#29465d')
        self.model.currentIndexChanged.connect(self.change_model); self.count.valueChanged.connect(self.change_model)
        self.table.itemChanged.connect(self.parameters_edited)
        for w in self.controls:
            if isinstance(w,QLineEdit): w.textEdited.connect(self.invalidate)
            elif isinstance(w,QSpinBox): w.valueChanged.connect(self.invalidate)
            else: w.currentIndexChanged.connect(self.invalidate)
        self.change_model(); self.set_enabled()

    def number(self, form, label, default):
        w = QLineEdit(default); form.addRow(label,w); self.controls.append(w); return w

    @staticmethod
    def value(field):
        value = float(field.text().strip().replace(',','.'))
        if not np.isfinite(value): raise ValueError('Все параметры должны быть конечными числами')
        return value

    def settings(self):
        if not self.bal.text().strip() or not self.sig.text().strip():
            raise ValueError('Введите Bal < 0 и Sig > 0 в милливольтах')
        core.calibration_coefficient(self.value(self.bal),self.value(self.sig))
        return core.Settings(zero_mm=self.value(self.zero), mm_per_unit=1 if self.units.currentIndex()==0 else self.value(self.step_size),
            path_factor=self.value(self.path_factor), c=self.value(self.light_speed), bal_mv=self.value(self.bal), sig_mv=self.value(self.sig),
            fit_min_s=self.value(self.fit_start), fit_max_s=self.value(self.fit_stop),
            background_degree=self.background.currentIndex()-1, bg_min_s=self.value(self.bg_start), bg_max_s=self.value(self.bg_stop),
            window='hann' if self.window.currentIndex()==0 else 'boxcar', padding=self.padding.currentData(),
            zero_mode='peak' if self.zero_mode.currentIndex()==0 else 'manual',
            fit_window_mode='peak_plus_steps' if self.window_mode.currentIndex()==0 else 'manual', skip_steps=self.skip_steps.value())

    def band(self): return tuple(map(float,self.region.getRegion()))

    def components(self): return 1 if self.model.currentIndex()==0 else self.count.value()

    def log(self, message): self.messages.appendPlainText(str(message)); self.statusBar().showMessage(str(message),15000)

    def set_enabled(self):
        busy = self.job is not None
        self.open_button.setEnabled(not busy); self.notes_button.setEnabled(not busy and self.measurement is not None)
        self.info_button.setEnabled(self.measurement is not None)
        loading = busy and self.job.kind == 'Загрузка'
        for w in self.controls: w.setEnabled(not loading)
        self.step_size.setEnabled(not loading and self.units.currentIndex()==1)
        self.zero.setEnabled(not loading and self.zero_mode.currentIndex()==1)
        manual_window=self.window_mode.currentIndex()==1
        self.fit_start.setEnabled(not loading and manual_window); self.fit_stop.setEnabled(not loading and manual_window)
        self.skip_steps.setEnabled(not loading and not manual_window)
        pending=self.pending_prepare or self.pending_fit or self.auto_timer.isActive() or self.peak_timer.isActive()
        valid = self.prepared is not None and not self.dirty and not busy and not pending
        for w in (self.seed_button,self.export_button,self.table): w.setEnabled(valid)
        spectrum_valid=self.prepared is not None and len(self.prepared.spectrum)>0 and not self.dirty and not loading
        self.region.setMovable(spectrum_valid)
        self.low.setEnabled(spectrum_valid); self.high.setEnabled(spectrum_valid)
        self.model.setEnabled(not busy); self.count.setEnabled(not busy and self.model.currentIndex()==1)
        self.cancel_button.setEnabled(busy)
        self.picture_button.setEnabled(valid)
        for field in self.display_controls: field.setEnabled(not busy)
        for auto,low,high in ((self.time_y_auto,self.time_y_min,self.time_y_max),
                              (self.fft_y_auto,self.fft_y_min,self.fft_y_max)):
            low.setEnabled(not busy and not auto.isChecked()); high.setEnabled(not busy and not auto.isChecked())
        self.copy_legend.setEnabled(not busy and self.result is not None)

    def clear_fit(self):
        self.result = None; self.fit_curve.setData([],[])
        self.legend.removeItem(self.fit_curve)
        self.table.blockSignals(True)
        for row in range(self.table.rowCount()):
            if self.table.item(row,2): self.table.item(row,2).setText('')
        self.table.blockSignals(False)
        self.refresh_legend()

    def refresh_legend(self, *_):
        self.legend.clear()
        self.legend.setVisible(self.legend_visible.isChecked())
        for curve,text in ((self.points,self.experiment_label.text()),(self.fit_curve,self.fit_legend_text())):
            if curve is self.fit_curve and self.result is None: continue
            if text.strip(): self.legend.addItem(curve,escape(text).replace('\n','<br>'))

    def fit_legend_text(self):
        text=self.fit_label.toPlainText()
        if self.legend_parameters.isChecked() and self.result is not None:
            text+='\n'+parameter_label(self.result)
        return text.strip()

    def copy_parameters_to_legend(self):
        if self.result is None: return
        text=self.fit_legend_text()
        self.legend_parameters.setChecked(False)
        self.fit_label.setPlainText(text)

    def auto_y_changed(self, *_):
        self.apply_y_limits(); self.set_enabled()

    def apply_y_limits(self):
        try:
            time_limits=None if self.time_y_auto.isChecked() else (self.value(self.time_y_min),self.value(self.time_y_max))
            fft_limits=None if self.fft_y_auto.isChecked() else (self.value(self.fft_y_min),self.value(self.fft_y_max))
            PlotStyle(time_ylim=time_limits,fft_ylim=fft_limits).validate()
            self.applied_time_ylim,self.applied_fft_ylim=time_limits,fft_limits
            self.render_y_limits()
        except Exception as e: self.log(e)

    def render_y_limits(self):
        for plot,limits in ((self.time_plot,self.applied_time_ylim),(self.fft_plot,self.applied_fft_ylim)):
            if limits is None: plot.enableAutoRange(axis='y',enable=True)
            else: plot.setYRange(*limits,padding=0)

    def presentation(self):
        return PlotStyle(self.experiment_label.text(),self.fit_legend_text(),self.legend_visible.isChecked(),
                         self.applied_time_ylim,self.applied_fft_ylim).validate()

    def invalidate(self, *_):
        self.revision += 1
        self.dirty = True; self.clear_fit()
        self.pending_prepare = self.measurement is not None
        self.pending_fit = False
        self.cancel_obsolete_job()
        self.auto_timer.start(); self.set_enabled()
        self.statusBar().showMessage('Параметры изменены — автоматический пересчёт…')

    def cancel_obsolete_job(self):
        if self.job and self.job.kind in ('Пересчёт','Фит'): self.job.cancel.set()

    def queue_fit(self, reseed=False):
        if self.prepared is None or self.dirty:
            return
        self.revision += 1; self.clear_fit()
        self.pending_fit = True; self.reseed = self.reseed or reseed
        self.cancel_obsolete_job()
        if self.job and self.job.kind=='Пересчёт': self.pending_prepare=True
        self.auto_timer.start(); self.set_enabled()

    def parameters_edited(self, item):
        if item.column()==1: self.queue_fit()

    def reset_seeds(self):
        self.queue_fit(reseed=True)

    def change_model(self, *_):
        if self.dirty:
            self.invalidate()
        else:
            self.queue_fit(reseed=True)
        self.set_enabled()

    def dispatch_auto(self):
        if self.closing or self.job is not None: return
        if self.pending_prepare:
            self.pending_prepare=False; self.pending_fit=False
            self.prepare_current()
        elif self.pending_fit:
            self.pending_fit=False
            if self.prepared is not None and not self.dirty and len(self.prepared.spectrum):
                if self.reseed or self.table.rowCount()!=4*self.components()+1:
                    self.fill_parameters()
                self.reseed=False
                self.start_fit()
        self.set_enabled()

    def run_job(self, kind, function):
        if self.job is not None: return
        self.peak_timer.stop()
        self.job_revision=self.revision
        self.job = Job(kind,function); self.job.signals.completed.connect(self.completed)
        self.set_enabled(); self.statusBar().showMessage('Вычисление: '+kind+'…')
        self.pool.start(self.job)

    def cancel_job(self):
        self.pending_prepare=self.pending_fit=False
        self.auto_timer.stop(); self.peak_timer.stop()
        if self.job: self.job.cancel.set(); self.statusBar().showMessage('Запрошена отмена. Ожидание завершения операции…')
        self.set_enabled()

    @pyqtSlot(object)
    def completed(self, package):
        kind, value, error = package
        cancelled = self.job.cancel.is_set()
        stale = kind in ('Пересчёт','Фит') and self.job_revision != self.revision
        self.job = None
        if self.closing: return
        if stale or cancelled:
            if not (self.pending_prepare or self.pending_fit): self.log('Отменённый результат отброшен')
        elif error: self.log(error)
        elif kind == 'Загрузка':
            self.measurement=value; self.prepared=None; self.dirty=True
            self.notes.setPlainText(value.notes); self.info_text.setPlainText(value.notes)
            self.file_label.setText(f'{value.data_path}\nПараметры: {value.notes_path} · X1: {value.signal_unit}')
            self.clear_fit()
            for curve in (self.points,self.spectrum,self.markers): curve.setData([],[])
            self.table.setRowCount(0)
            self.pending_prepare=True
        elif kind == 'Пересчёт':
            self.prepared=value; self.dirty=False
            self.zero.setText(f'{value.settings.zero_mm:.12g}')
            self.fit_start.setText(f'{value.settings.fit_min_s:.12g}')
            self.fit_stop.setText(f'{value.settings.fit_max_s:.12g}')
            self.clear_fit(); self.draw_prepared()
            self.fill_parameters()
            self.pending_fit=bool(len(value.spectrum)); self.reseed=False
        elif kind == 'Фит':
            self.result = value; self.draw_fit()
        elif kind in ('Экспорт','Картинка'): self.log('Сохранено: '+value)
        self.set_enabled()
        if (self.pending_prepare or self.pending_fit) and not self.auto_timer.isActive():
            QTimer.singleShot(0,self.dispatch_auto)

    def open_files(self):
        dat,_ = QFileDialog.getOpenFileName(self,'Массив измерения','','Data (*.dat *.txt);;All files (*)')
        if not dat: return
        notes = associated_notes(dat)
        if notes is None:
            notes,_ = QFileDialog.getOpenFileName(self,'Параметры этого измерения','','Text (*.txt);;All files (*)')
        if notes: self.load_paths(dat,notes)

    def change_notes(self):
        notes,_ = QFileDialog.getOpenFileName(self,'Параметры этого измерения',str(Path(self.measurement.notes_path).parent),'Text (*.txt)')
        if notes: self.load_paths(self.measurement.data_path,notes)

    def load_paths(self, dat, notes):
        if self.job: return
        self.revision+=1; self.pending_prepare=self.pending_fit=False
        self.auto_timer.stop(); self.clear_fit()
        self.run_job('Загрузка',lambda cancel:load_pair(dat,notes))

    def prepare_current(self):
        if self.measurement is None: return
        try: cfg = self.settings()
        except Exception as e: self.log(e); return
        measurement = self.measurement
        self.run_job('Пересчёт',lambda cancel:core.prepare(measurement,cfg))

    def draw_prepared(self):
        p = self.prepared
        visible=p.fit_mask if p.fit_mask.sum()>=8 else np.ones(len(p.time),dtype=bool)
        self.points.setData(p.time[visible],p.y[visible]); self.spectrum.setData(p.frequencies,p.spectrum)
        low,high = self.band()
        low,high = max(0,low),min(high,p.nyquist_hz)
        if low >= high:
            low,high = p.nyquist_hz*.05,p.nyquist_hz*.8
        self.region.blockSignals(True); self.region.setBounds((0,p.nyquist_hz)); self.region.setRegion((low,high)); self.region.blockSignals(False)
        self.low.setText(f'{low:.9g}'); self.high.setText(f'{high:.9g}')
        self.time_plot.setXRange(float(p.time[visible][0]),float(p.time[visible][-1]),padding=0)
        self.fft_plot.setXRange(max(0,low-(high-low)*.3), min(p.nyquist_hz,high+(high-low)*.3),padding=0)
        if p.fit_mask.sum()>=8:
            self.reference_label.setText(f'u = t − t_ref; t_ref = {p.time[p.fit_mask][0]:.8g} s. A и φ заданы при t_ref.')
        else: self.reference_label.setText('Недостаточно точек для FFT/фита; показана исходная кривая.')
        self.log(f'Точек: {len(p.time)}; в фите: {p.fit_mask.sum()}; Δf ≈ {p.resolution_hz:.6g} Hz; Найквист {p.nyquist_hz:.6g} Hz.')
        self.log(f'Bal={p.settings.bal_mv:g} mV; Sig={p.settings.sig_mv:g} mV; коэффициент={p.settings.rad_per_unit:.8g} rad/V. X1 читается в V.')
        self.log(f'x₀ = {p.settings.zero_mm:.12g} mm; метод: '+('максимум исходного X1' if p.settings.zero_mode=='peak' else 'вручную'))
        for warning in p.warnings: self.log(warning)
        self.update_peaks(schedule=False)
        self.render_y_limits()

    def apply_band(self):
        if self.prepared is None: return
        try:
            low,high = self.value(self.low),self.value(self.high)
            if not 0 <= low < high <= self.prepared.nyquist_hz: raise ValueError('Диапазон FFT должен лежать между 0 и частотой Найквиста')
            self.region.setRegion((low,high))
        except Exception as e: self.log(e)

    def update_peaks(self, schedule=True):
        if self.prepared is None or self.dirty: return
        if not len(self.prepared.spectrum):
            self.markers.setData([],[]); self.peak_label.setText('FFT недоступно: в окне недостаточно точек.'); return
        try:
            p=self.prepared; band=self.band(); indices=core.peak_indices(p,*band)
            self.low.setText(f'{band[0]:.9g}'); self.high.setText(f'{band[1]:.9g}')
            shown=indices[:50]; self.markers.setData(p.frequencies[shown],p.spectrum[shown])
            self.peak_label.setText(f'Максимум диапазона: {p.frequencies[indices[0]]:.8g} Hz → f₁ старт. Δf ≈ {p.resolution_hz:.4g} Hz.')
            self.clear_fit()
            params=core.initial_parameters(p,self.components(),band)
            self.table.blockSignals(True)
            for i in range(self.components()):
                item=self.table.item(4*i+1,1)
                if item: item.setText(f'{params[4*i+1]:.10g}')
            self.table.blockSignals(False)
            if schedule: self.queue_fit()
        except Exception as e:
            self.markers.setData([],[]); self.peak_label.setText(str(e)); self.clear_fit()

    def fill_parameters(self):
        if self.prepared is None or self.dirty or not len(self.prepared.spectrum):
            self.table.setRowCount(0); return
        try: params=core.initial_parameters(self.prepared,self.components(),self.band())
        except Exception as e: self.log(e); return
        self.clear_fit(); self.table.blockSignals(True); self.table.setRowCount(len(params))
        for i,((name,unit),value) in enumerate(zip(core.names(self.components()),params)):
            for col,text in enumerate((f'{name} [{unit}]',f'{value:.10g}','')):
                item=QTableWidgetItem(text)
                if col != 1: item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.table.setItem(i,col,item)
        self.table.blockSignals(False)

    def read_parameters(self):
        return np.array([float(self.table.item(i,1).text().replace(',','.')) for i in range(self.table.rowCount())])

    def start_fit(self):
        try:
            parameters=self.read_parameters(); band=self.band(); p=self.prepared
            if p is None or self.dirty: return
        except Exception as e: self.log(e); return
        self.clear_fit()
        self.run_job('Фит',lambda cancel:core.fit(p,parameters,band,cancel))

    def draw_fit(self):
        p,r=self.prepared,self.result
        time=np.linspace(p.time[p.fit_mask][0],p.time[p.fit_mask][-1],3000)
        self.fit_curve.setData(time,core.evaluate(time,r.parameters,r.reference_s))
        self.table.blockSignals(True)
        for i,((name,unit),v,e) in enumerate(zip(core.names(self.components()),r.parameters,r.errors)):
            self.table.item(i,2).setText(f'{v:.6g} ± {e:.2g}')
        self.table.blockSignals(False)
        self.refresh_legend()
        self.log(f'Фит завершён: RMSE={r.rmse_rad:.6g} rad; R²={r.r_squared:.6g}; вычислений={r.evaluations}')
        for warning in r.warnings: self.log(warning)

    def export(self):
        folder=QFileDialog.getExistingDirectory(self,'Папка для результатов анализа')
        if not folder: return
        try: initial=self.read_parameters()
        except Exception as e: self.log(e); return
        from .export import export_analysis
        base=Path(folder)/(Path(self.measurement.data_path).stem+'_analysis')
        args=(base,self.measurement,self.prepared,self.result,self.title.text(),self.band(),initial,self.presentation())
        self.run_job('Экспорт',lambda cancel:export_analysis(*args))

    def save_picture(self):
        path,selected=QFileDialog.getSaveFileName(self,'Сохранить картинку',
            str(Path(self.measurement.data_path).with_name(Path(self.measurement.data_path).stem+'_analysis.png')),
            'PNG (*.png);;PDF (*.pdf);;SVG (*.svg)')
        if not path: return
        if not Path(path).suffix:
            path+='.pdf' if selected.startswith('PDF') else '.svg' if selected.startswith('SVG') else '.png'
        from .export import save_picture
        args=(path,self.prepared,self.result,self.title.text(),self.band(),self.presentation())
        self.run_job('Картинка',lambda cancel:save_picture(*args))

    def closeEvent(self,event):
        self.closing=True
        self.pending_prepare=self.pending_fit=False
        self.auto_timer.stop(); self.peak_timer.stop()
        if self.pool.activeThreadCount():
            event.ignore(); self.closing=True; self.cancel_job()
            QTimer.singleShot(100,self.close)
        else:
            self.info_dialog.close()
            event.accept()
