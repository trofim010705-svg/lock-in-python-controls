"""The two printed equations and parameter blocks share one time convention."""
import unittest
import numpy as np
from matplotlib.mathtext import MathTextParser
from analyzer import sum_frequency as sf
from analyzer.dual_figure import _parameter_text
from test_sum_frequency import fixture


class SumFrequencyPresentationTests(unittest.TestCase):
    def test_explicit_two_line_response_and_carrier_use_the_same_symbols(self):
        parser=MathTextParser('path')
        for formula in (sf.CARRIER_MATH_FORMULA,sf.MATH_FORMULA):
            self.assertIn(r'\Gamma_{0i}t',formula)
            self.assertIn(r'\varphi_{0i}',formula)
            self.assertNotIn(r'\psi',formula)
            self.assertNotIn(r'\tau',formula)
            for line in formula.splitlines():parser.parse(line)
        self.assertIn(r'\theta_1(t)',sf.CARRIER_MATH_FORMULA)
        self.assertIn(r'\theta_2(t)',sf.MATH_FORMULA)
        self.assertIn(r'\frac{1}{2}',sf.MATH_FORMULA)
        self.assertIn(r'\sin(2\pi f_{0i}t+\varphi_{0i})',sf.MATH_FORMULA)
        self.assertIn(r'\cos(2\pi f_{0i}t+\varphi_{0i})',sf.MATH_FORMULA)
        self.assertIn('delay-t_ref',sf.FORMULA)

    def test_printed_carrier_gamma_and_sigma_are_inverse_lifetime(self):
        p,ref,_=fixture()
        ref.errors[3]=1e-12
        text=_parameter_text(p,ref,'rad','X1','ns',(0.,1e10),False,carrier=True)
        self.assertIn('Γ₀[1] = 0.5 ± 0.00025 ns⁻¹',text)
        self.assertIn('A₀[1]',text)
        self.assertNotIn('τ',text)
        self.assertIn('t_ref = 0.4 ns',text)

    def test_all_fit_footers_drop_quality_metrics_and_window_caption(self):
        p,ref,_=fixture();mod=sf.fit(p,ref,2.5)
        for result,key,carrier in ((ref,'X1',True),(ref,'R2',False),(mod,'X2',False),(mod,'Y2',False)):
            text=_parameter_text(p,result,'rad' if carrier else 'V',key,'ns',(0.,1e10),False,carrier=carrier)
            for removed in ('R²','R^2','RMSE','Окно фита'):
                self.assertNotIn(removed,text)
            self.assertIn('t_ref',text)
        self.assertIn('0.4 ns',sf.footer_text(mod))
        self.assertIn('400 ps',sf.footer_text(mod,'ps'))


if __name__=='__main__':unittest.main()
