"""SI conversion, explicit preprocessing, FFT seeds and scaled nonlinear fitting."""
from dataclasses import dataclass, replace, field
from collections.abc import Mapping
from threading import Event
import numpy as np
from scipy import signal, optimize, fft


@dataclass(frozen=True)
class Settings:
    zero_mm: float = 106.45
    mm_per_unit: float = 1.0
    c: float = 3e8  # notebook approximation; use 299792458 for exact vacuum c.
    bal_mv: float = None
    sig_mv: float = None
    fit_min_s: float = 1e-11
    fit_max_s: float = 3.5e-9
    background_degree: int = -1  # off, constant, linear, quadratic
    bg_min_s: float = 1e-11
    bg_max_s: float = 3.5e-9
    window: str = 'hann'
    padding: int = 8
    zero_mode: str = 'peak'
    fit_window_mode: str = 'peak_plus_steps'
    skip_steps: int = 3

    @property
    def path_factor(self):
        return 2.0

    @property
    def rad_per_unit(self):
        return calibration_coefficient(self.bal_mv, self.sig_mv)


def calibration_coefficient(bal_mv, sig_mv):
    """rad/V; Bal and Sig are entered in mV while the file's X1 is in V."""
    if bal_mv is None or sig_mv is None:
        raise ValueError('Введите Bal < 0 и Sig > 0 в милливольтах')
    if not np.isfinite([bal_mv, sig_mv]).all() or bal_mv >= 0 or sig_mv <= 0:
        raise ValueError('Требуется Bal < 0 и Sig > 0; оба значения должны быть конечными')
    bal, sig = bal_mv*1e-3, sig_mv*1e-3
    with np.errstate(over='ignore', divide='ignore', invalid='ignore'):
        coefficient = np.sqrt(2)/(4*np.sqrt(sig)*np.sqrt(sig-bal))
    if not np.isfinite(coefficient) or coefficient <= 0:
        raise ValueError('Bal/Sig приводят к некорректному коэффициенту пересчёта')
    return float(coefficient)


@dataclass
class Prepared:
    time: np.ndarray
    raw_rad: np.ndarray
    y: np.ndarray
    fit_mask: np.ndarray
    frequencies: np.ndarray
    spectrum: np.ndarray
    resolution_hz: float
    nyquist_hz: float
    warnings: list
    settings: Settings
    background: np.ndarray
    phase_info: dict = field(default_factory=dict)


class Cancelled(Exception):
    pass


def prepare(measurement, cfg):
    if measurement.signal_unit == 'A':
        raise ValueError('Формула Bal/Sig требует X1 в вольтах. Выбранный файл содержит амперы.')
    nums = [cfg.zero_mm, cfg.mm_per_unit, cfg.path_factor, cfg.c, cfg.rad_per_unit,
            cfg.fit_min_s, cfg.fit_max_s, cfg.bg_min_s, cfg.bg_max_s]
    if not np.isfinite(nums).all() or min(cfg.mm_per_unit, cfg.path_factor, cfg.c) <= 0 or cfg.rad_per_unit == 0:
        raise ValueError('Проверьте конечность чисел, масштаб оси, скорость света и калибровку')
    if cfg.fit_window_mode == 'manual' and cfg.fit_min_s >= cfg.fit_max_s:
        raise ValueError('Начало диапазона фита должно быть меньше конца')
    if cfg.fit_window_mode not in ('manual', 'peak_plus_steps'):
        raise ValueError('Неизвестный способ выбора временного окна')
    if not isinstance(cfg.skip_steps, (int, np.integer)) or cfg.skip_steps < 0:
        raise ValueError('Количество пропускаемых шагов должно быть целым и неотрицательным')
    if cfg.padding not in (1, 2, 4, 8, 16, 32, 64, 128, 512):
        raise ValueError('Неподдерживаемый коэффициент zero-padding')
    warnings = list(measurement.warnings)
    peak_position = float(measurement.position[int(np.argmax(measurement.x1))]*cfg.mm_per_unit)
    if cfg.zero_mode == 'peak':
        # Use the raw, signed X1 maximum before calibration, background or FFT.
        index = int(np.argmax(measurement.x1))
        cfg = replace(cfg, zero_mm=float(measurement.position[index]*cfg.mm_per_unit))
        if cfg.zero_mm in (np.min(measurement.position)*cfg.mm_per_unit,
                           np.max(measurement.position)*cfg.mm_per_unit):
            warnings.append('Максимум X1 находится на краю скана; проверьте выбранный ноль задержки.')
    elif cfg.zero_mode != 'manual':
        raise ValueError('Неизвестный способ определения нуля задержки')
    t = (measurement.position*cfg.mm_per_unit-cfg.zero_mm)*1e-3*cfg.path_factor/cfg.c
    y = measurement.x1*cfg.rad_per_unit
    order = np.argsort(t, kind='stable'); t, y = t[order], y[order]
    unique, starts, counts = np.unique(t, return_index=True, return_counts=True)
    if len(unique) != len(t):
        warnings.append(f'Повторные координаты усреднены: {len(t)-len(unique)}')
        y = np.add.reduceat(y, starts)/counts; t = unique
    if len(t) == 0:
        raise ValueError('Нет конечных точек для отображения')
    auto_start = None
    if cfg.fit_window_mode == 'peak_plus_steps':
        peak_time = (peak_position-cfg.zero_mm)*1e-3*cfg.path_factor/cfg.c
        peak_index = int(np.argmin(abs(t-peak_time)))
        auto_start = peak_index+cfg.skip_steps
        cfg = replace(cfg, fit_min_s=float(t[min(auto_start,len(t)-1)]), fit_max_s=float(t[-1]))
    raw = y.copy(); background = np.zeros_like(y)
    if cfg.background_degree >= 0:
        m = (t >= cfg.bg_min_s) & (t <= cfg.bg_max_s)
        if m.sum() <= cfg.background_degree:
            warnings.append('Недостаточно точек в диапазоне оценки фона: показан сигнал без вычитания фона.')
        else:
            # Polynomial.fit scales its domain, avoiding ill conditioning of SI seconds.
            poly = np.polynomial.Polynomial.fit(t[m], y[m], cfg.background_degree)
            background = poly(t); y = y-background
    mask = (t >= cfg.fit_min_s) & (t <= cfg.fit_max_s)
    if auto_start is not None and auto_start >= len(t):
        mask[:] = False
    if mask.sum() < 8:
        warnings.append(f'В окне анализа {int(mask.sum())} точек; для FFT/фита нужно минимум 8. '
                        'Исходная кривая остаётся доступна. Измените окно или число пропускаемых шагов.')
        return Prepared(t, raw, y, mask, np.array([]), np.array([]), float('nan'),
                        float(.5/np.median(np.diff(t))) if len(t)>1 else 0., warnings, cfg, background)
    tf, yf = t[mask], y[mask]
    # FFT uses only the same selected time interval as the fit. The fit itself uses
    # original measured coordinates; interpolation is exclusively for FFT.
    dt = np.median(np.diff(tf))
    if (tf[-1]-tf[0])/dt > 1000000:
        raise ValueError('Слишком неоднородная сетка времени для БПФ')
    grid = np.linspace(tf[0], tf[-1], max(8, int(round((tf[-1]-tf[0])/dt))+1))
    dt = grid[1]-grid[0]
    if len(grid) != len(tf) or not np.allclose(np.diff(tf), dt, rtol=1e-3, atol=abs(dt)*1e-6):
        warnings.append('Для БПФ использована линейная интерполяция неравномерной сетки. Фит — по исходным точкам.')
    values = np.interp(grid, tf, yf)
    values -= np.mean(values)
    weights = np.hanning(len(grid)) if cfg.window == 'hann' else np.ones(len(grid))
    if cfg.window not in ('hann', 'boxcar'):
        raise ValueError('Неизвестное окно FFT')
    requested = len(grid)*cfg.padding
    nfft = fft.next_fast_len(requested)
    if nfft > 4194304:
        raise ValueError('FFT слишком велико: уменьшите zero-padding (предел 4 194 304 отсчёта)')
    spectrum = abs(fft.rfft(values*weights, n=nfft))*2/weights.sum()
    spectrum[0] /= 2
    if nfft % 2 == 0:
        spectrum[-1] /= 2
    return Prepared(t, raw, y, mask, fft.rfftfreq(nfft, dt), spectrum,
                    1/(len(grid)*dt), .5/dt, warnings, cfg, background)


def peak_indices(prepared, low, high):
    f, a = prepared.frequencies, prepared.spectrum
    selection = np.flatnonzero((f >= low) & (f <= high) & (f > 0))
    if low >= high or len(selection) == 0:
        raise ValueError('В выбранном диапазоне нет положительных частот FFT')
    local, _ = signal.find_peaks(a)
    local = local[np.isin(local, selection)]
    strongest = selection[np.argmax(a[selection])]
    if a[strongest] <= np.finfo(float).tiny:
        raise ValueError('В выбранном диапазоне нет ненулевого спектрального сигнала')
    indices = np.unique(np.r_[local, strongest])
    return indices[np.argsort(a[indices])[::-1]]


def automatic_band(prepared, count=1):
    """Band around strong oscillatory FFT peaks, without the old 2 GHz ceiling."""
    f, a = prepared.frequencies, prepared.spectrum
    if len(f) < 2 or not np.any(a > 0):
        raise ValueError('Недостаточно спектральных данных для выбора полосы')
    floor = max(prepared.resolution_hz*.45, f[1])
    candidates = peak_indices(prepared, floor, prepared.nyquist_hz)
    strongest = candidates[0]
    chosen = [strongest]
    for index in candidates[1:]:
        if len(chosen) >= max(1,count): break
        if a[index] >= .15*a[strongest] and all(abs(f[index]-f[j]) >= .7*prepared.resolution_hz for j in chosen):
            chosen.append(index)
    width = max(2*prepared.resolution_hz, .35*f[strongest])
    lo = max(prepared.resolution_hz*.1, min(f[chosen])-width)
    hi = min(prepared.nyquist_hz, max(f[chosen])+width)
    return float(lo),float(hi)


def _linear_parameters(t, y, frequencies, lifetimes):
    """Solve sine/cosine amplitudes and common C exactly for fixed f and tau."""
    columns = []
    for frequency,lifetime in zip(frequencies,lifetimes):
        envelope = np.exp(-t/lifetime)
        phase = 2*np.pi*frequency*t
        columns.extend((envelope*np.sin(phase),envelope*np.cos(phase)))
    matrix = np.column_stack([*columns,np.ones(len(t))])
    coefficients = np.linalg.lstsq(matrix,y,rcond=None)[0]
    parameters=[]
    for i,(frequency,lifetime) in enumerate(zip(frequencies,lifetimes)):
        sine,cosine=coefficients[2*i:2*i+2]
        parameters.extend((np.hypot(sine,cosine),frequency,np.arctan2(cosine,sine),lifetime))
    return np.asarray([*parameters,coefficients[-1]]),matrix@coefficients


def _seed_frequencies(p,count,band):
    indices=peak_indices(p,*band)
    frequencies=[]
    for index in indices:
        value=p.frequencies[index]
        if all(abs(value-v)>=p.resolution_hz*.7 for v in frequencies): frequencies.append(value)
        if len(frequencies)==count: break
    while len(frequencies)<count:
        # Fill missing modes as hypotheses, never duplicate a supplied frequency.
        grid=np.linspace(max(band[0],p.resolution_hz*.05),band[1],max(20,count*10))
        value=max(grid,key=lambda x:min(abs(x-v) for v in frequencies))
        frequencies.append(value)
    return frequencies


def initial_parameters(p,count,band):
    frequencies=_seed_frequencies(p,count,band)
    t,y=p.time[p.fit_mask],p.y[p.fit_mask]
    lifetime=max(np.ptp(t),np.finfo(float).tiny)
    parameters,_=_linear_parameters(t-t[0],y,frequencies,[lifetime]*count)
    return parameters


def names(count):
    result = []
    for i in range(1, count+1):
        result.extend([(f'A{i}', 'rad'), (f'f{i}', 'Hz'), (f'phi{i}', 'rad'), (f'tau{i}', 's')])
    return result+[('C', 'rad')]


def evaluate(time_s, parameters, t_ref):
    u = np.asarray(time_s)-t_ref
    p = np.asarray(parameters)
    y = np.full_like(u, p[-1], dtype=float)
    for i in range((len(p)-1)//4):
        a, f, phase, tau = p[4*i:4*i+4]
        y += a*np.exp(-u/tau)*np.sin(2*np.pi*f*u+phase)
    return y


def evaluate_fit(time_s, result):
    """Dispatch fitted models without interpreting δ coefficients as sinusoids."""
    if getattr(result, 'model', None) == 'sum_frequency_linear':
        from .sum_frequency import evaluate as evaluate_modulation
        return evaluate_modulation(time_s, result)
    return evaluate(time_s, result.parameters, result.reference_s)


@dataclass
class FitResult:
    parameters: np.ndarray
    errors: np.ndarray
    covariance: np.ndarray
    reference_s: float
    rmse_rad: float
    r_squared: float
    warnings: list
    evaluations: int
    condition: float
    fixed_frequencies: dict = field(default_factory=dict)


def fit(prepared, p0, band, cancel=None, fixed_frequencies=None):
    if fixed_frequencies is not None and not isinstance(fixed_frequencies, Mapping):
        raise ValueError('Фиксированные частоты задаются как {номер компоненты: частота в Hz}')
    if fixed_frequencies:
        return _fit_fixed_frequencies(prepared,p0,band,cancel,fixed_frequencies)
    cancel = cancel or Event()
    t, y = prepared.time[prepared.fit_mask], prepared.y[prepared.fit_mask]
    p0 = np.asarray(p0, dtype=float)
    count = (len(p0)-1)//4
    if count < 1 or count > 6 or len(p0) != 4*count+1 or not np.isfinite(p0).all():
        raise ValueError('Некорректные начальные параметры')
    if len(t) <= len(p0):
        raise ValueError('Точек должно быть больше, чем параметров модели')
    lo_f, hi_f = max(0, band[0]), min(band[1], prepared.nyquist_hz)
    if hi_f <= lo_f:
        raise ValueError('Некорректные границы частоты')
    t_ref = t[0]; ts = np.ptp(t); ys = max(np.std(y), np.ptp(y)*.1, 1e-30)
    scales = np.array(([ys, 1/ts, 1, ts]*count)+[ys])
    lower, upper = [], []
    for i in range(count):
        if p0[4*i] < 0 or p0[4*i+3] <= 0 or not lo_f <= p0[4*i+1] <= hi_f:
            raise ValueError('Начальные A ≥ 0, tau > 0, частоты должны лежать в выделенном диапазоне FFT')
        lower.extend([0, lo_f, -np.inf, ts*1e-6])
        upper.extend([np.inf, hi_f, np.inf, ts*1e6])
    lower.append(-np.inf); upper.append(np.inf)
    if np.any(p0 < lower) or np.any(p0 > upper):
        raise ValueError('Начальная tau выходит за границы [1e-6, 1e6] длительности фита')
    # Dimensionless optimization avoids losing small radian amplitudes or ns lifetimes.
    def residual(q):
        if cancel.is_set():
            raise Cancelled('Фитирование отменено')
        return (evaluate(t, q*scales, t_ref)-y)/ys
    # Optimizing f/tau with sine/cosine/C solved linearly removes most of the
    # amplitude/phase traps. The original manually supplied p0 remains a candidate.
    total_evaluations=0
    candidates=[]
    best_sse=float('inf')
    def retain(candidate):
        nonlocal total_evaluations,best_sse
        total_evaluations+=candidate.nfev
        if np.isfinite(candidate.fun).all():
            score=float(candidate.fun@candidate.fun)
            best_sse=min(best_sse,score)
            candidates.append((score,candidate))
    retain(optimize.least_squares(residual,p0/scales,bounds=(np.array(lower)/scales,np.array(upper)/scales),
              x_scale='jac',max_nfev=500,ftol=1e-9,xtol=1e-9,gtol=1e-9))
    band_actual=(lo_f,hi_f)
    main=np.asarray(_seed_frequencies(prepared,count,band_actual))
    frequency_sets=[p0[:-1].reshape(count,4)[:,1],main]
    indices=peak_indices(prepared,*band_actual)
    if count==1:
        for index in indices[:4]: frequency_sets.append(np.array([prepared.frequencies[index]]))
        frequency_sets.extend((np.clip(main-prepared.resolution_hz*.3,lo_f,hi_f),
                               np.clip(main+prepared.resolution_hz*.3,lo_f,hi_f)))
    else:
        # Slightly shifted spectral starts catch overlapping modes and window bias.
        for shift in (-.3,.3):
            frequency_sets.append(np.clip(main+shift*prepared.resolution_hz,lo_f,hi_f))
    unique=[]
    for frequencies in frequency_sets:
        if not any(np.allclose(frequencies,previous,rtol=0,atol=prepared.resolution_hz*.025) for previous in unique):
            unique.append(frequencies)
    starts=[]
    for frequencies in unique:
        for lifetime in ((.3,1.,4.) if count<=2 else (1.,3.)):
            starts.append((frequencies,np.full(count,lifetime)))
    # Rank coarse candidates cheaply before nonlinear work.
    u=t-t_ref
    coarse=[]
    for frequencies,lifetimes in starts:
        if cancel.is_set(): raise Cancelled('Фитирование отменено')
        parameters,predicted=_linear_parameters(u,y,frequencies,lifetimes*ts)
        coarse.append((float(np.sum(((predicted-y)/ys)**2)),frequencies,lifetimes))
    coarse.sort(key=lambda x:x[0])
    best_projected=None
    for _,frequencies,lifetimes in coarse[:(8 if count<=2 else 4)]:
        def projected(q):
            if cancel.is_set(): raise Cancelled('Фитирование отменено')
            _,prediction=_linear_parameters(u,y,q[:count]/ts,np.exp(q[count:])*ts)
            return (prediction-y)/ys
        q0=np.r_[frequencies*ts,np.log(lifetimes)]
        result_reduced=optimize.least_squares(projected,q0,
            bounds=(np.r_[np.full(count,lo_f*ts),np.full(count,np.log(1e-6))],
                    np.r_[np.full(count,hi_f*ts),np.full(count,np.log(1e6))]),
            x_scale='jac',max_nfev=600,ftol=1e-9,xtol=1e-9,gtol=1e-9)
        total_evaluations+=result_reduced.nfev
        score=float(result_reduced.fun@result_reduced.fun)
        if best_projected is None or score<best_projected[0]:
            projected_params,_=_linear_parameters(u,y,result_reduced.x[:count]/ts,np.exp(result_reduced.x[count:])*ts)
            best_projected=(score,projected_params)
    if best_projected is not None:
        seed=np.clip(best_projected[1]/scales,np.array(lower)/scales,np.array(upper)/scales)
        retain(optimize.least_squares(residual,seed,bounds=(np.array(lower)/scales,np.array(upper)/scales),
                  x_scale='jac',max_nfev=1000,ftol=1e-10,xtol=1e-10,gtol=1e-10))
    if not candidates: raise ValueError('Не удалось получить конечный результат оптимизации')
    successful=[item for item in candidates if item[1].success]
    _,result=min(successful or candidates,key=lambda item:item[0])
    if not result.success:
        raise ValueError('Оптимизация не сошлась: '+result.message)
    parameters = result.x*scales
    # SVD of J itself avoids squaring its condition number via J.T @ J.
    _, singular, vh = np.linalg.svd(result.jac, full_matrices=False)
    threshold = np.finfo(float).eps*max(result.jac.shape)*singular[0]
    valid = singular > threshold
    rank = np.count_nonzero(valid)
    covariance = (vh[valid].T/singular[valid]**2)@vh[valid]
    covariance *= np.sum(result.fun**2)/(len(y)-len(p0))
    covariance *= np.outer(scales, scales)
    errors = np.sqrt(np.maximum(np.diag(covariance), 0))
    warnings = []
    if count>1:
        frequencies=parameters[:-1].reshape(count,4)[:,1]
        if np.min(abs(frequencies[:,None]-frequencies[None,:])+np.eye(count)*prepared.nyquist_hz)<prepared.resolution_hz*.5:
            warnings.append('Частоты мод ближе половины спектрального разрешения; разделение мод может быть неустойчивым.')
    condition = float(np.linalg.cond(result.jac))
    if rank < len(p0) or condition > 1e8:
        errors[:] = np.nan
        warnings.append('Параметры плохо определены: ранг/обусловленность Якобиана. Ошибки не считаются достоверными.')
    if np.any(result.active_mask):
        warnings.append('Оптимум упирается в границу параметров: проверьте диапазон FFT и модель.')
    for i in range(count):
        if parameters[4*i+3] > 100*ts:
            warnings.append(f'tau{i+1} намного больше окна наблюдения; затухание может быть не определено.')
    dominant_band=automatic_band(prepared)
    dominant_indices=peak_indices(prepared,*dominant_band)
    dominant_frequency=prepared.frequencies[dominant_indices[0]]
    if not lo_f <= dominant_frequency <= hi_f:
        warnings.append(f'Сильнейший пик спектра ({dominant_frequency/1e9:.5g} GHz) вне выбранной полосы; проверьте ограничения частоты.')
    if min(parameters[1:-1:4])*ts < 2:
        warnings.append('В окне наблюдения менее двух периодов низшей моды; оценка частоты/затухания может быть неустойчивой.')
    prediction = evaluate(t, parameters, t_ref)
    sse = np.sum((prediction-y)**2); sst = np.sum((y-y.mean())**2)
    if sst>0 and 1-sse/sst<.5:
        warnings.append('Модель описывает менее половины дисперсии сигнала (R² < 0.5); проверьте полосу, окно и число мод.')
    return FitResult(parameters, errors, covariance, t_ref, float(np.sqrt(sse/len(y))),
                     float(1-sse/sst) if sst > 0 else float('nan'), warnings, total_evaluations, condition)


def _fit_fixed_frequencies(prepared,p0,band,cancel,fixed_frequencies):
    """Optimize only free variables, keeping component identity and exact f values.

    The zero rows/columns in covariance for locked f are constraints, not
    experimental frequency uncertainties. Free-variable covariance is conditional
    on these values and uses the corresponding reduced degrees of freedom.
    """
    cancel=cancel or Event()
    if cancel.is_set():raise Cancelled('Фитирование отменено')
    p0=np.asarray(p0,dtype=float).copy();count=(len(p0)-1)//4
    if count<1 or count>6 or len(p0)!=4*count+1 or not np.isfinite(p0).all():
        raise ValueError('Некорректные начальные параметры')
    fixed={}
    for index,value in fixed_frequencies.items():
        if isinstance(index,(bool,np.bool_)) or not isinstance(index,(int,np.integer)) or not 0<=index<count:
            raise ValueError('Номер фиксируемой компоненты должен быть целым от 0 до числа компонент минус один')
        try:value=float(value)
        except (ValueError,TypeError):raise ValueError('Фиксированная частота должна быть конечным числом в Hz')
        if not np.isfinite(value) or not 0<value<=prepared.nyquist_hz:
            raise ValueError('Фиксированная частота должна быть > 0 и не выше частоты Найквиста')
        fixed[int(index)]=value;p0[4*index+1]=value
    free_components=[i for i in range(count) if i not in fixed]
    t,y=prepared.time[prepared.fit_mask],prepared.y[prepared.fit_mask]
    free=np.asarray([i for i in range(len(p0)) if i not in {4*j+1 for j in fixed}],dtype=int)
    if len(t)<=len(free):raise ValueError('Точек должно быть больше, чем свободных параметров модели')
    if not np.isfinite(t).all() or not np.isfinite(y).all() or np.ptp(t)<=0 or np.any(np.diff(t)<=0):
        raise ValueError('Для фита нужны конечные значения и строго возрастающее время')
    lo_f,hi_f=max(0.,float(band[0])),min(float(band[1]),prepared.nyquist_hz)
    if free_components and (not np.isfinite([lo_f,hi_f]).all() or hi_f<=lo_f):
        raise ValueError('Некорректные границы свободной частоты')
    t_ref=float(t[0]);ts=float(np.ptp(t));u=t-t_ref
    ys=max(float(np.std(y)),float(np.ptp(y))*.1,1e-30)
    scales=np.array(([ys,1/ts,1.,ts]*count)+[ys])
    lower=[];upper=[]
    for i in range(count):
        if p0[4*i]<0 or not ts*1e-6<=p0[4*i+3]<=ts*1e6:
            raise ValueError('Начальные A ≥ 0, tau в пределах [1e-6, 1e6] длительности фита')
        if i in free_components and not lo_f<=p0[4*i+1]<=hi_f:
            raise ValueError('Свободные начальные частоты должны лежать в выделенном диапазоне FFT')
        lower.extend([0.,lo_f,-np.inf,ts*1e-6]);upper.extend([np.inf,hi_f,np.inf,ts*1e6])
    lower.append(-np.inf);upper.append(np.inf)
    lo=np.asarray(lower)[free]/scales[free];hi=np.asarray(upper)[free]/scales[free]
    template=p0/scales
    def physical(q):
        full=template.copy();full[free]=q;parameters=full*scales
        for index,value in fixed.items():parameters[4*index+1]=value
        return parameters
    def residual(q):
        if cancel.is_set():raise Cancelled('Фитирование отменено')
        return (evaluate(t,physical(q),t_ref)-y)/ys
    total=0;candidates=[]
    def retain(candidate):
        nonlocal total
        total+=candidate.nfev
        if np.isfinite(candidate.fun).all():candidates.append((float(candidate.fun@candidate.fun),candidate))
    retain(optimize.least_squares(residual,template[free],bounds=(lo,hi),x_scale='jac',
        max_nfev=700,ftol=1e-9,xtol=1e-9,gtol=1e-9))
    manual=p0[:-1].reshape(count,4)[:,1].copy()
    spectral=manual.copy();known=list(fixed.values())
    try:indices=peak_indices(prepared,lo_f,hi_f) if free_components else []
    except ValueError:indices=[]
    resolution=prepared.resolution_hz if np.isfinite(prepared.resolution_hz) else 1/ts
    available=[]
    for index in indices:
        value=float(prepared.frequencies[index])
        if all(abs(value-other)>=resolution*.4 for other in known+available):available.append(value)
    for i in free_components:
        if available:value=available.pop(0)
        else:
            # A user may intentionally choose a band narrower/lower than the
            # FFT resolution. Spectral resolution must never move seeds beyond
            # that explicit free-frequency constraint.
            grid=np.linspace(lo_f,hi_f,max(30,count*12))
            value=max(grid,key=lambda candidate:min([abs(candidate-v) for v in known] or [hi_f-lo_f]))
        spectral[i]=value;known.append(value)
    frequency_sets=[manual,spectral]
    for shift in (-.3,.3):
        alternate=spectral.copy()
        for i in free_components:alternate[i]=np.clip(alternate[i]+shift*resolution,lo_f,hi_f)
        frequency_sets.append(alternate)
    unique=[]
    for frequencies in frequency_sets:
        if not any(np.allclose(frequencies,previous,rtol=0,atol=resolution*.025) for previous in unique):unique.append(frequencies)
    coarse=[]
    for frequencies in unique:
        for lifetime in ((.2,.6,1.,3.,8.) if count<=2 else (.5,1.,3.)):
            if cancel.is_set():raise Cancelled('Фитирование отменено')
            _,prediction=_linear_parameters(u,y,frequencies,np.full(count,lifetime*ts))
            coarse.append((float(np.sum(((prediction-y)/ys)**2)),frequencies,np.full(count,np.log(lifetime))))
    coarse.sort(key=lambda item:item[0]);best_projected=None
    nfree=len(free_components)
    for _,frequencies,log_lifetimes in coarse[:(8 if count<=2 else 4)]:
        def unpack(q):
            f=frequencies.copy()
            for j,index in enumerate(free_components):f[index]=q[j]/ts
            return f,np.exp(q[nfree:])*ts
        def projected(q):
            if cancel.is_set():raise Cancelled('Фитирование отменено')
            f,lifetimes=unpack(q);_,prediction=_linear_parameters(u,y,f,lifetimes)
            return (prediction-y)/ys
        q0=np.r_[frequencies[free_components]*ts,log_lifetimes]
        reduced_lower=np.r_[np.full(nfree,lo_f*ts),np.full(count,np.log(1e-6))]
        reduced_upper=np.r_[np.full(nfree,hi_f*ts),np.full(count,np.log(1e6))]
        q0=np.clip(q0,reduced_lower,reduced_upper)
        reduced=optimize.least_squares(projected,q0,
            bounds=(reduced_lower,reduced_upper),
            x_scale='jac',max_nfev=700,ftol=1e-10,xtol=1e-10,gtol=1e-10)
        total+=reduced.nfev;score=float(reduced.fun@reduced.fun)
        if best_projected is None or score<best_projected[0]:
            f,lifetimes=unpack(reduced.x);parameters,_=_linear_parameters(u,y,f,lifetimes)
            best_projected=score,parameters
    if best_projected is not None:
        seed=np.clip(best_projected[1][free]/scales[free],lo,hi)
        retain(optimize.least_squares(residual,seed,bounds=(lo,hi),x_scale='jac',
            max_nfev=1000,ftol=1e-10,xtol=1e-10,gtol=1e-10))
    if not candidates:raise ValueError('Не удалось получить конечный результат оптимизации')
    successful=[item for item in candidates if item[1].success]
    _,result=min(successful or candidates,key=lambda item:item[0])
    if not result.success:raise ValueError('Оптимизация не сошлась: '+result.message)
    parameters=physical(result.x)
    _,singular,vh=np.linalg.svd(result.jac,full_matrices=False)
    valid=singular>np.finfo(float).eps*max(result.jac.shape)*singular[0]
    rank=int(np.count_nonzero(valid))
    conditional=(vh[valid].T/singular[valid]**2)@vh[valid]
    conditional*=float(np.sum(result.fun**2))/(len(y)-len(free))
    conditional*=np.outer(scales[free],scales[free])
    covariance=np.zeros((len(p0),len(p0)));covariance[np.ix_(free,free)]=conditional
    errors=np.sqrt(np.maximum(np.diag(covariance),0));warnings=[]
    condition=float(np.linalg.cond(result.jac))
    if rank<len(free) or condition>1e8:
        errors[free]=np.nan
        warnings.append('Свободные параметры плохо определены: ранг/обусловленность Якобиана. Ошибки не считаются достоверными.')
    if np.any(result.active_mask):warnings.append('Оптимум упирается в границу свободных параметров: проверьте диапазон FFT и модель.')
    for i in range(count):
        if parameters[4*i+3]>100*ts:warnings.append(f'tau{i+1} намного больше окна наблюдения; затухание может быть не определено.')
    frequencies=parameters[1:-1:4]
    if count>1 and np.min(abs(frequencies[:,None]-frequencies[None,:])+np.eye(count)*prepared.nyquist_hz)<resolution*.5:
        warnings.append('Частоты мод ближе половины спектрального разрешения; разделение мод может быть неустойчивым.')
    if min(frequencies)*ts<2:warnings.append('В окне наблюдения менее двух периодов низшей моды; оценка затухания может быть неустойчивой.')
    for i in fixed:errors[4*i+1]=0.
    prediction=evaluate(t,parameters,t_ref);sse=float(np.sum((prediction-y)**2));sst=float(np.sum((y-y.mean())**2))
    # A constant array's floating-point mean can differ by an ulp. Such roundoff
    # must not produce a seemingly precise R² for an absent oscillation.
    if sst<=len(y)*(64*np.finfo(float).eps*float(np.max(np.abs(y))))**2:sst=0.
    if sst>0 and 1-sse/sst<.5:warnings.append('Модель описывает менее половины дисперсии сигнала (R² < 0.5); проверьте частоты, окно и число мод.')
    return FitResult(parameters,errors,covariance,t_ref,float(np.sqrt(sse/len(y))),
        float(1-sse/sst) if sst>0 else float('nan'),warnings,total,condition,dict(fixed))
