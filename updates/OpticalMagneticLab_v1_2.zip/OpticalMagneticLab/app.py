"""Optical Magnetic Lab: NI AO0 + AI1/AI0/AI3, 7230 internal Dual Harmonic."""
import argparse,multiprocessing,sys


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--demo',action='store_true')
    p.add_argument('--serial');p.add_argument('--timeout',type=int,default=2000)
    p.add_argument('--ni-diagnostics',metavar='REPORT',help='Check empty NI tasks without writing outputs; save UTF-8 report.')
    p.add_argument('--max-frequency',type=int,choices=(120000,250000),default=120000);args=p.parse_args()
    if args.ni_diagnostics:
        from ni_diagnostics import run
        return run(args.ni_diagnostics)
    from PyQt5.QtCore import Qt
    from PyQt5.QtWidgets import QApplication
    from window import LabWindow
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling,True);QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps,True)
    app=QApplication(sys.argv[:1]);app.setOrganizationName('LabTools');app.setApplicationName('OpticalMagneticLab');app.setStyle('Fusion')
    window=LabWindow(args);window.show();return app.exec_()


if __name__=='__main__':
    multiprocessing.freeze_support();sys.exit(main())
