"""Optical magnetic measurements, inheriting the working 7230 control panel."""
from collections import deque
from pathlib import Path
import time
import shutil
import numpy as np
import pyqtgraph as pg
from PyQt5.QtCore import Qt,QSettings,QTimer,QThread,pyqtSignal
from PyQt5.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QGroupBox,QFormLayout,QLabel,QPushButton,
    QLineEdit,QPlainTextEdit,QDoubleSpinBox,QSpinBox,QComboBox,QTabWidget,QSplitter,QScrollArea,QProgressBar,
    QFileDialog,QApplication,QSizePolicy)
from gui_app import LockinWindow,engineering
from gui_widgets import InstrumentTabBar
from models import Calibration,Experiment,DemoPlant,denominator,ARCSEC_PER_RAD
from daq import Config,AIReader
from capture import CaptureData
from services import DualLockinWorker,AOWorker,Port
from experiment import ExperimentRunner
from storage import field_series,create_folder,save_point


class FieldPlot(pg.PlotWidget):
    def __init__(self,title,left_label):
        super().__init__(background='w')
        self.setTitle(title,color='#25435d',size='12pt');self.setLabel('bottom','Магнитное поле, mT')
        self.setLabel('left',left_label,color='#257b9d');self.showGrid(x=True,y=True,alpha=.2)
        self.setMinimumSize(240,185)
        for side in ('left','bottom'):
            self.getAxis(side).setPen('#718397');self.getAxis(side).setTextPen('#3d5369')
        self.main={branch:self.plot(pen=pg.mkPen(color,width=1.2) if left_label.startswith('α') else None,symbol=marker,symbolSize=6,symbolPen=None,symbolBrush=color)
                   for branch,color,marker in (('forward','#257b9d','o'),('reverse','#7954a2','t'),('single','#257b9d','o'))}
        self.right=pg.ViewBox();self.plotItem.showAxis('right');self.scene().addItem(self.right)
        self.plotItem.getAxis('right').linkToView(self.right);self.right.setXLink(self.plotItem.vb)
        self.plotItem.getAxis('right').setLabel('Фарадей, ″',color='#db7d28')
        self.plotItem.getAxis('right').setTextPen('#db7d28')
        self.faraday=pg.PlotDataItem(pen=pg.mkPen('#db7d28',width=1.3),symbol='d',symbolSize=6,
                                    symbolPen=None,symbolBrush='#db7d28');self.right.addItem(self.faraday)
        self.plotItem.vb.sigResized.connect(self.resize_right);self.resize_right()
    def resize_right(self):
        self.right.setGeometry(self.plotItem.vb.sceneBoundingRect());self.right.linkedViewChanged(self.plotItem.vb,self.right.XAxis)


class LabWindow(LockinWindow):
    worker_class=DualLockinWorker
    ao_request=pyqtSignal(str,object)
    ao_shutdown=pyqtSignal()
    def __init__(self,args):
        self.exclusive='idle';self.want_close=False;self.pending_launch=False;self.runner=None
        self.reader=None;self.ao_busy=False;self.ao_state={};self.store=CaptureData();self.plant=DemoPlant()
        self.points=[];self.live_rows=deque(maxlen=50000);self.sample_count=0;self.current_point=None;self.graph_version=0;self.drawn=-1
        self.settings=QSettings();self.shutdown_started=False;self.default_fields={}
        super().__init__(args);self.worker.plant=self.plant
        self.setWindowTitle('Optical Magnetic Lab 1.2 · NI AO0 / Dual Harmonic'+(' · DEMO' if args.demo else ''))
        self.setMinimumSize(1080,650)
        available=self.screen().availableGeometry();self.resize(min(1500,available.width()),min(950,available.height()))
        self.control_page=self.takeCentralWidget();self.pages=QTabWidget();self.pages.setTabBar(InstrumentTabBar())
        self.dashboard=self.build_dashboard();self.pages.addTab(self.dashboard,'Оптика и магнит')
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(self.control_page)
        self.pages.addTab(scroll,'Управление Lock-in')
        self.journal=QPlainTextEdit();self.journal.setReadOnly(True);self.journal.setMaximumBlockCount(2000)
        self.pages.addTab(self.journal,'Журнал');self.setCentralWidget(self.pages)
        self.ao_thread=QThread(self);self.ao_worker=AOWorker();self.ao_worker.moveToThread(self.ao_thread)
        self.ao_request.connect(self.ao_worker.execute,Qt.QueuedConnection);self.ao_shutdown.connect(self.ao_worker.shutdown,Qt.QueuedConnection)
        self.ao_worker.state.connect(self.ao_changed);self.ao_worker.done.connect(self.ao_done)
        self.ao_worker.stopped.connect(self.ao_thread.quit);self.ao_thread.finished.connect(self.ao_worker.deleteLater)
        self.ao_thread.start();self.ao_port=Port(self.ao_worker);self.lockin_port=Port(self.worker)
        self.worker.link_state.connect(self.lockin_link)
        self.timer=QTimer(self);self.timer.setInterval(200);self.timer.timeout.connect(self.refresh_dashboard);self.timer.start()
        self.update_enabled()
    def number(self,key,value,lo,hi,dec=3):
        w=QDoubleSpinBox();w.setRange(lo,hi);w.setDecimals(dec);w.setValue(float(self.settings.value('defaults/'+key,value)))
        w.setKeyboardTracking(False);w.setContextMenuPolicy(Qt.NoContextMenu);w.lineEdit().setContextMenuPolicy(Qt.NoContextMenu)
        self.default_fields[key]=w;return w
    def group(self,layout,title):
        box=QGroupBox(title);form=QFormLayout(box);form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow);layout.addWidget(box)
        return box,form
    def build_dashboard(self):
        root=QWidget();outer=QVBoxLayout(root)
        cards=QHBoxLayout();outer.addLayout(cards)
        self.top_values=[]
        for title,color in (('+ Channel · ×25,2 − темновое','#257b9d'),('− Channel · ×25,2 − темновое','#7954a2'),('Магнитное поле · AI3','#217f62')):
            box=QGroupBox(title);lay=QVBoxLayout(box);value=QLabel('—');value.setStyleSheet(f'font-size:27px;color:{color};font-weight:600')
            value.setTextInteractionFlags(Qt.TextSelectableByMouse);lay.addWidget(value);cards.addWidget(box,1);self.top_values.append(value)
        split=QSplitter(Qt.Horizontal);outer.addWidget(split,1)
        side=QWidget();side_l=QVBoxLayout(side);side_l.setContentsMargins(0,0,0,0)
        _,actions=self.group(side_l,'Измерение')
        self.run_button=QPushButton('▶ Старт');self.hysteresis_button=QPushButton('↔ Гистерезис · туда и обратно')
        self.stop_button=QPushButton('■ Стоп · сохранить, AO0 оставить')
        self.run_button.setStyleSheet('QPushButton:enabled {background:#176f89;color:white;font-weight:600} QPushButton:disabled {background:#d3dce3;color:#7a8996}')
        self.run_button.clicked.connect(self.start_experiment);self.hysteresis_button.clicked.connect(self.start_hysteresis);self.stop_button.clicked.connect(self.stop_experiment)
        actions.addRow(self.run_button);actions.addRow(self.hysteresis_button);actions.addRow(self.stop_button)
        self.progress=QProgressBar();actions.addRow(self.progress)
        self.run_status=QLabel('Подключите Lock-in и NI. Подключение не меняет AO0.');self.run_status.setWordWrap(True);self.run_status.setMaximumHeight(100);actions.addRow(self.run_status)
        self.run_status.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.save_defaults_button=QPushButton('Сохранить параметры и напряжения\nпо умолчанию')
        self.save_defaults_button.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        self.save_defaults_button.setMinimumHeight(42)
        self.save_defaults_button.setToolTip('Сохраняет введённые значения основной вкладки. Команды на AO0 и генератор не отправляет.')
        self.save_defaults_button.clicked.connect(self.save_defaults);actions.addRow(self.save_defaults_button)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setMinimumWidth(440);scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        left=QWidget();controls=QVBoxLayout(left);scroll.setWidget(left);side_l.addWidget(scroll,1)
        _,form=self.group(controls,'Приборы')
        self.usb_button=QPushButton('Подключить Lock-in · Internal 1f/2f');self.usb_button.clicked.connect(lambda:self.submit('open'));form.addRow(self.usb_button)
        self.lockin_label=QLabel('Dual harmonic; первая и вторая гармоники внутреннего референса.');self.lockin_label.setWordWrap(True);form.addRow(self.lockin_label)
        self.device=QLineEdit(str(self.settings.value('ni/device','Dev1')));form.addRow('Имя NI MAX',self.device)
        self.hall_mode=QComboBox();self.hall_mode.addItems(['AI3 Differential (AI3+/AI3−)','AI3 RSE']);self.hall_mode.setCurrentIndex(int(self.settings.value('ni/hall_mode',0)))
        self.hall_mode.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        form.addRow('Датчик Холла',self.hall_mode)
        self.ni_button=QPushButton('Подключить NI · AI1 / AI0 / AI3 / AO0');self.ni_button.clicked.connect(self.toggle_ni);form.addRow(self.ni_button)
        self.osc_box,form=self.group(controls,'Внутренний генератор Lock-in')
        self.osc_amplitude=self.number('oscillator_Vrms',.1,0,5,6)
        self.osc_frequency=self.number('oscillator_Hz',1000.,.001,self.args.max_frequency,3)
        form.addRow('Амплитуда, V rms',self.osc_amplitude);form.addRow('Частота, Hz',self.osc_frequency)
        self.osc_read=QPushButton('Прочитать генератор');self.osc_apply=QPushButton('Применить к Lock-in')
        self.osc_read.clicked.connect(self.read_oscillator);self.osc_apply.clicked.connect(self.apply_oscillator)
        form.addRow(self.osc_read);form.addRow(self.osc_apply)
        self.osc_actual=QLabel('Фактические значения: —\nОдин общий генератор для 1f и 2f.');self.osc_actual.setWordWrap(True);form.addRow(self.osc_actual)
        _,form=self.group(controls,'Магнит · AO0 относительно AO GND')
        self.manual_voltage=self.number('manual_V',0.,-5,5,4);form.addRow('Напряжение AO0, V',self.manual_voltage)
        self.set_button=QPushButton('Подать напряжение');self.set_button.clicked.connect(self.set_voltage);form.addRow(self.set_button)
        self.zero_button=QPushButton('Обнулить AO0 · 0 V');self.zero_button.clicked.connect(self.zero_output);self.zero_button.setStyleSheet('color:#a52e40');form.addRow(self.zero_button)
        self.ao_label=QLabel('AO0: команда этой программой ещё не задана.');self.ao_label.setWordWrap(True);form.addRow(self.ao_label)
        _,form=self.group(controls,'Калибровка поля и индикаторы')
        self.average=self.number('average_s',1.,.1,60,2);self.slope=self.number('slope',1.,-1e6,1e6,6);self.offset=self.number('offset',0.,-1e6,1e6,6)
        form.addRow('Усреднение сверху, s',self.average);form.addRow('k, mT/mV',self.slope);form.addRow('b, mT',self.offset)
        self.dark_ip=self.number('dark_ip_mV',0.,-1e6,1e6,6);self.dark_im=self.number('dark_im_mV',0.,-1e6,1e6,6)
        form.addRow('Темновое +, mV',self.dark_ip);form.addRow('Темновое −, mV',self.dark_im)
        hint=QLabel('B[mT] = k · AI3[mV] + b\nIp = 25,2·AI1 − Uтемн₊; Im = 25,2·AI0 − Uтемн₋.\nТемновые задаются в mV после усиления ×25,2.');hint.setWordWrap(True);form.addRow(hint)
        self.scan_box,form=self.group(controls,'Проход по напряжению')
        self.measurement_mode=QComboBox();self.measurement_mode.addItems(['Старт → стоп','Фиксированное поле · AO0 не менять','Гистерезис · старт → стоп → старт'])
        self.measurement_mode.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        self.measurement_mode.setCurrentIndex(int(self.settings.value('defaults/mode',0)))
        form.addRow(self.measurement_mode)
        self.start_voltage=self.number('start_V',-1.,-5,5,4);self.stop_voltage=self.number('stop_V',1.,-5,5,4)
        self.intervals=QSpinBox();self.intervals.setRange(1,10000);self.intervals.setValue(int(self.settings.value('defaults/steps',10)))
        self.intervals.setContextMenuPolicy(Qt.NoContextMenu);self.intervals.lineEdit().setContextMenuPolicy(Qt.NoContextMenu)
        form.addRow('Старт AO0, V',self.start_voltage);form.addRow('Стоп AO0, V',self.stop_voltage);form.addRow('Шагов на одну ветвь',self.intervals)
        self.grid_label=QLabel();self.grid_label.setWordWrap(True);form.addRow(self.grid_label)
        self.duration=self.number('duration_s',10.,.1,86400,2);self.period=self.number('period_ms',100.,20,60000,1);self.settle=self.number('settle_s',1.,0,3600,2)
        form.addRow('Acquisition time, s',self.duration);form.addRow('Delay отсчётов, ms',self.period);form.addRow('Задержка после AO0, s',self.settle)
        self.after=QComboBox();self.after.addItem('Оставить AO0 после окончания',False);self.after.addItem('Обнулить AO0 после успешного окончания',True)
        self.after.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        self.after.setCurrentIndex(1 if self.settings.value('defaults/zero_after',False,type=bool) else 0);form.addRow(self.after)
        for w in (self.start_voltage,self.stop_voltage,self.intervals):w.valueChanged.connect(self.grid_changed)
        self.measurement_mode.currentIndexChanged.connect(self.grid_changed)
        self.data_box,form=self.group(controls,'Сохранение')
        self.folder=QLineEdit(str(self.settings.value('data/folder',str(Path.home()/'Documents'/'OpticalMagneticLab'/'data'))))
        browse=QPushButton('…');browse.setMaximumWidth(32);browse.clicked.connect(self.choose_folder)
        row=QHBoxLayout();row.addWidget(self.folder);row.addWidget(browse);form.addRow(row)
        self.session_name=QLineEdit(str(self.settings.value('defaults/name','optical_measurement')))
        self.e_field=QLineEdit(str(self.settings.value('defaults/e_field','')))
        self.additional=QPlainTextEdit(str(self.settings.value('defaults/additional','')));self.additional.setMaximumHeight(70)
        form.addRow('Имя опыта',self.session_name);form.addRow('E field',self.e_field);form.addRow('Additional',self.additional)
        self.recover_button=QPushButton('Сохранить несохранённую точку…');self.recover_button.clicked.connect(self.recover_point);self.recover_button.hide();form.addRow(self.recover_button)
        controls.addStretch();split.addWidget(side)
        right=QWidget();view=QVBoxLayout(right);self.plot_tabs=QTabWidget();view.addWidget(self.plot_tabs)
        field_page=QWidget();grid=QGridLayout(field_page);self.field_plots=[]
        titles=['Амплитуда 1f','Амплитуда 2f','Фаза 1f','Фаза 2f']
        for i,title in enumerate(titles):
            graph=FieldPlot(title,'α, ″' if i<2 else 'φ, °');grid.addWidget(graph,i//2,i%2);self.field_plots.append(graph)
            if i>=2:graph.setYRange(0,360,padding=.02);graph.enableAutoRange(axis='y',enable=False)
        self.plot_tabs.addTab(field_page,'От магнитного поля · Фарадей справа')
        time_page=QWidget();lay=QVBoxLayout(time_page);self.time_axis=QComboBox();self.time_axis.addItems(['Номер отсчёта','Время внутри точки, s'])
        self.time_axis.currentIndexChanged.connect(self.request_draw);lay.addWidget(self.time_axis);tg=QGridLayout();lay.addLayout(tg,1)
        self.time_plots=[];self.time_curves=[]
        for i,title in enumerate(titles):
            graph=pg.PlotWidget(background='w');graph.setTitle(title,color='#25435d');graph.setLabel('left','α, ″' if i<2 else 'φ, °')
            graph.showGrid(x=True,y=True,alpha=.2);graph.setMinimumSize(220,180)
            curve=graph.plot(pen=pg.mkPen('#257b9d',width=1) if i<2 else None,symbol='o',symbolSize=3,symbolPen=None)
            if i>=2:graph.setYRange(0,360,padding=.02);graph.enableAutoRange(axis='y',enable=False)
            self.time_plots.append(graph);self.time_curves.append(curve);tg.addWidget(graph,i//2,i%2)
        self.plot_tabs.addTab(time_page,'Внутри текущей точки')
        self.point_label=QLabel('Амплитуды: угловые секунды (″). Фазы: градусы. Оранжевые ромбы и линия справа — Фарадей.');self.point_label.setWordWrap(True);view.addWidget(self.point_label)
        split.addWidget(right);split.setSizes([450,1030]);self.grid_changed();return root
    def calibration(self):
        c=Calibration(self.slope.value(),self.offset.value(),self.dark_ip.value()/1000,self.dark_im.value()/1000);c.validate();return c
    def config(self):return Config(device=self.device.text().strip(),hall_diff=self.hall_mode.currentIndex()==0,demo=self.args.demo,plant=self.plant)
    def parameters(self):
        return Experiment(mode=('sweep','single','hysteresis')[self.measurement_mode.currentIndex()],start_V=self.start_voltage.value(),stop_V=self.stop_voltage.value(),
            intervals=self.intervals.value(),acquisition_s=self.duration.value(),period_ms=self.period.value(),settle_s=self.settle.value(),folder=self.folder.text(),
            name=self.session_name.text(),additional=self.additional.toPlainText(),e_field=self.e_field.text(),zero_after=self.after.currentData())
    def grid_changed(self):
        n=self.intervals.value();mode=self.measurement_mode.currentIndex()
        self.grid_label.setText('При текущем напряжении, без команды AO0.' if mode==1 else f'{2*n+1 if mode==2 else n+1} точек; шаг {(self.stop_voltage.value()-self.start_voltage.value())/n:+.5g} V. Разворот без обнуления.')
        for w in (self.start_voltage,self.stop_voltage,self.intervals):w.setEnabled(mode!=1 and self.exclusive=='idle')
    def choose_folder(self):
        path=QFileDialog.getExistingDirectory(self,'Папка сохранения',self.folder.text())
        if path:self.folder.setText(path)
    def save_defaults(self):
        try:
            self.calibration()
            for key,w in self.default_fields.items():self.settings.setValue('defaults/'+key,w.value())
            self.settings.setValue('defaults/steps',self.intervals.value());self.settings.setValue('defaults/zero_after',self.after.currentData())
            self.settings.setValue('defaults/mode',self.measurement_mode.currentIndex())
            self.settings.setValue('data/folder',self.folder.text());self.settings.setValue('defaults/name',self.session_name.text())
            self.settings.setValue('defaults/e_field',self.e_field.text());self.settings.setValue('defaults/additional',self.additional.toPlainText())
            self.settings.setValue('ni/device',self.device.text());self.settings.setValue('ni/hall_mode',self.hall_mode.currentIndex());self.settings.sync()
            self.run_status.setText('Значения сохранены. Команды приборам не отправлялись.')
        except Exception as exc:self.run_status.setText(str(exc))
    def read_oscillator(self):
        if self.exclusive=='idle':self.submit('read',dict(titles=['Oscillator output'],optical_oscillator=True))
    def apply_oscillator(self):
        if self.exclusive=='idle':self.submit('apply',dict(title='Oscillator output',
            values=dict(oa=self.osc_amplitude.value(),of=self.osc_frequency.value()),changed=['oa','of'],versions={},optical_oscillator=True))
    def show_oscillator(self,amplitude,frequency,editors=False):
        self.osc_actual.setText(f'Фактически: {amplitude:.6g} V rms; {frequency:.9g} Hz\nОбщий генератор для 1f и 2f.')
        if editors:self.osc_amplitude.setValue(amplitude);self.osc_frequency.setValue(frequency)
    def log_line(self,text):
        if hasattr(self,'journal'):self.journal.appendPlainText(str(text))
    def toggle_ni(self):
        if self.exclusive!='idle':return
        if self.reader and self.reader.isRunning():
            self.reader.stop();self.ao_busy=True;self.ao_request.emit('close',{})
        else:
            try:cfg=self.config();cfg.validate()
            except Exception as exc:self.run_status.setText(str(exc));return
            self.reader=AIReader(cfg,self.store,self);self.reader.message.connect(self.log_line);self.reader.finished.connect(self.update_enabled);self.reader.start()
            self.ao_busy=True;self.ao_request.emit('open',dict(config=cfg))
        self.update_enabled()
    def ao_changed(self,state):self.ao_state=state;self.update_enabled()
    def ao_done(self,job,success,text):
        self.ao_busy=False;self.run_status.setText(text);self.log_line(text);self.update_enabled()
    def set_voltage(self):
        if self.exclusive!='idle':return
        self.ao_busy=True;self.ao_request.emit('write',dict(voltage=self.manual_voltage.value()));self.update_enabled()
    def zero_output(self):
        if self.runner and self.runner.isRunning():self.runner.stop()
        self.ao_busy=True;self.ao_request.emit('write',dict(voltage=0.));self.update_enabled()
    def lockin_link(self,connected,text):self.connected=connected;self.lockin_label.setText(text);self.update_enabled()
    def start_hysteresis(self):
        if self.exclusive!='idle':return
        self.measurement_mode.setCurrentIndex(2);self.start_experiment()
    def start_experiment(self):
        if self.exclusive!='idle' or self.want_close:return
        try:
            self.frozen_parameters=self.parameters();self.frozen_parameters.validate();self.frozen_calibration=self.calibration()
            self.store.ensure_online()
            if not self.connected:raise ValueError('Подключите Lock-in.')
            if (self.frozen_parameters.mode!='single' or self.frozen_parameters.zero_after) and not self.ao_state.get('connected'):raise ValueError('Подключите AO0.')
            if self.ao_busy:raise ValueError('Дождитесь команды AO0.')
        except Exception as exc:self.run_status.setText(str(exc));return
        self.exclusive='draining';self.poll_timer.stop();self.update_enabled();self.dispatch_next()
    def dispatch_next(self):
        if self.exclusive=='running':return
        super().dispatch_next()
        if self.exclusive=='draining' and not self.busy and not self.pending_jobs and not self.pending_edits and not self.edit_timer.isActive():
            self.exclusive='running';self.pending_launch=True;QTimer.singleShot(0,self.launch_experiment)
    def launch_experiment(self):
        if not self.pending_launch or self.want_close:return
        self.pending_launch=False;self.points=[];self.live_rows.clear();self.sample_count=0;self.current_point=None;self.progress.setValue(0);self.request_draw()
        self.runner=ExperimentRunner(self.frozen_parameters,self.frozen_calibration,self.lockin_port,self.ao_port,self.store,self.args.demo,self)
        self.runner.message.connect(self.run_status.setText);self.runner.log.connect(self.log_line);self.runner.samples.connect(self.receive_samples)
        self.runner.point_started.connect(self.point_started);self.runner.point_ready.connect(self.receive_point)
        self.runner.outcome.connect(self.experiment_outcome);self.runner.finished.connect(self.experiment_finished);self.runner.start()
        self.settings.setValue('data/folder',self.folder.text());self.update_enabled()
    def stop_experiment(self):
        if self.exclusive=='draining' or self.pending_launch:
            self.pending_launch=False;self.exclusive='idle';self.update_enabled();return
        if self.runner:self.runner.stop();self.run_status.setText('Остановка и сохранение. AO0 не изменяется.')
    def point_started(self,index,total):self.live_rows.clear();self.sample_count=0;self.current_point=None;self.request_draw()
    def receive_samples(self,rows):self.live_rows.extend(rows);self.sample_count+=len(rows);self.request_draw()
    def receive_point(self,point):
        self.points.append(point);self.current_point=point;self.request_draw()
        self.progress.setValue(round(100*point['index']/len(self.frozen_parameters.targets())))
        d=point['daq'];s=point['statistics']
        self.point_label.setText(f"Точка {point['index']}: B={d['field_mean_mT']:.7g} mT; Ip={d['ip_mean_V']:.6g} V; Im={d['im_mean_V']:.6g} V. "+s['angle_error'])
    def experiment_outcome(self,result):
        self.last_outcome=result;self.points=result['points'];self.request_draw()
        self.run_status.setText({'complete':'Готово.','stopped':'Остановлено.','error':'Ошибка измерения.'}[result['reason']]+'\n'+result['error']+'\n'+result['folder'])
        self.recover_button.setVisible(result['unsaved'])
    def experiment_finished(self):
        self.exclusive='idle';self.update_enabled();self.schedule_poll()
        if self.want_close:QTimer.singleShot(0,self.close)
    def recover_point(self):
        if not self.runner or not self.runner.unsaved:return
        target=QFileDialog.getExistingDirectory(self,'Куда сохранить точку?')
        if target:
            try:
                rows,point,old=self.runner.unsaved;folder=create_folder(target,'recovered_point')
                if (Path(old)/'daq.dat').exists():shutil.copy2(Path(old)/'daq.dat',folder/'daq.dat')
                save_point(folder,rows,dict(point,folder=str(folder),recovered_from=str(old)))
                self.runner.unsaved=None;self.recover_button.hide();self.run_status.setText('Восстановлено: '+str(folder))
            except Exception as exc:self.run_status.setText(str(exc))
    def request_draw(self,*_):self.graph_version+=1
    @staticmethod
    def set_curve(curve,x,y):
        a,b=np.asarray(x,dtype=float),np.asarray(y,dtype=float)
        curve.setData(a,b) if len(a) and np.any(np.isfinite(a)&np.isfinite(b)) else curve.setData([],[])
    def refresh_dashboard(self):
        try:
            c=self.calibration();live=self.store.live(self.average.value(),c)
            for widget,key,unit in zip(self.top_values,('ip_V','im_V','field_mT'),('V','V','mT')):
                widget.setText(engineering(live[key],unit) if live else '—')
        except Exception:
            for w in self.top_values:w.setText('—')
        if self.graph_version!=self.drawn:
            self.drawn=self.graph_version
            for i,graph in enumerate(self.field_plots):
                harmonic='1' if i in (0,2) else '2';key='alpha_mean_arcsec' if i<2 else 'phase_mean_deg'
                for branch,points in field_series(self.points):
                    self.set_curve(graph.main[branch],[p['daq']['field_mean_mT'] for p in points],
                        [p['statistics']['harmonics'][harmonic][key] if p['statistics']['harmonics'][harmonic][key] is not None else np.nan for p in points])
                points=[p for p in self.points if p['result']=='complete' and p['daq']['valid']]
                self.set_curve(graph.faraday,[p['daq']['field_mean_mT'] for p in points],
                    [p['statistics']['faraday_centered_arcsec'] if p['statistics']['faraday_centered_arcsec'] is not None else np.nan for p in points])
            rows=np.asarray(self.live_rows,dtype=float)
            means=(self.current_point['daq']['ip_mean_V'],self.current_point['daq']['im_mean_V']) if self.current_point else self.store.running_means()
            try:norm=denominator(*means) if means else None
            except ValueError:norm=None
            if len(rows):
                idx=np.arange(0,len(rows),max(1,len(rows)//5000));r=rows[idx]
                x=self.sample_count-len(rows)+idx+1 if self.time_axis.currentIndex()==0 else r[:,0]
                arrays=[r[:,4]/norm*ARCSEC_PER_RAD if norm else np.full(len(r),np.nan),r[:,8]/norm*ARCSEC_PER_RAD if norm else np.full(len(r),np.nan),r[:,5],r[:,9]]
            else:x=[];arrays=[[],[],[],[]]
            for graph,curve,y in zip(self.time_plots,self.time_curves,arrays):
                graph.setLabel('bottom','Номер отсчёта' if self.time_axis.currentIndex()==0 else 'Время, s');self.set_curve(curve,x,y)
        self.update_enabled()
    def update_enabled(self):
        super().update_enabled()
        if not hasattr(self,'dashboard'):return
        idle=self.exclusive=='idle' and not self.want_close
        self.control_page.setEnabled(idle);self.usb_button.setEnabled(idle and not self.connected and not self.busy)
        for box in self.all_boxes():
            for key in ('mode','ie1','ie2','refn1','refn2'):
                if key in box.widgets:box.widgets[key].setEnabled(False)
        ready=idle and self.connected and self.store.ready and not self.ao_busy and not (self.runner and self.runner.unsaved)
        self.run_button.setEnabled(ready and (self.measurement_mode.currentIndex()==1 or self.ao_state.get('connected',False)))
        self.hysteresis_button.setEnabled(ready and self.ao_state.get('connected',False));self.stop_button.setEnabled(not idle and not self.want_close)
        self.ni_button.setEnabled(idle and not self.ao_busy);self.device.setEnabled(idle and not (self.reader and self.reader.isRunning()))
        self.ni_button.setText('Отключить NI · AO0 оставить' if self.reader and self.reader.isRunning() else 'Подключить NI · AI1 / AI0 / AI3 / AO0')
        for w in (self.manual_voltage,self.set_button):w.setEnabled(idle and self.ao_state.get('connected',False) and not self.ao_busy)
        self.zero_button.setEnabled(self.ao_state.get('connected',False) and not self.ao_busy and not self.want_close)
        for w in (self.scan_box,self.data_box,self.slope,self.offset,self.hall_mode,self.dark_ip,self.dark_im):w.setEnabled(idle)
        self.osc_box.setEnabled(idle)
        self.save_defaults_button.setEnabled(idle)
        for w in (self.osc_read,self.osc_apply):w.setEnabled(idle and self.connected and not self.busy)
        self.hall_mode.setEnabled(idle and not (self.reader and self.reader.isRunning()))
        value=self.ao_state.get('last_command_V')
        self.ao_label.setText(('Последняя команда: '+f'{value:+.5g} V' if value is not None else 'Уставка AO0 неизвестна.')+
            (' · подтверждена отправка' if self.ao_state.get('confirmed_command') else ' · состояние не подтверждено')+'\nАппаратного readback AO0 нет.')
    def schedule_poll(self,*_):
        if self.exclusive!='idle' or self.want_close:self.poll_timer.stop();return
        super().schedule_poll(*_)
    def on_result(self,job,data):
        if hasattr(self,'osc_actual'):
            payload=(self.inflight or {}).get('payload',{})
            if job in ('read','apply') and 'Oscillator output' in data:
                state=data['Oscillator output'];v=state.get('values',{})
                if 'oa' in v and 'of' in v:self.show_oscillator(v['oa'],v['of'],payload.get('optical_oscillator',False) or job=='apply')
                if state.get('error'):self.run_status.setText('Генератор: '+state['error'])
            elif job=='poll' and data.get('oscillator'):
                self.show_oscillator(*data['oscillator'])
        if job=='apply' and self.exclusive=='draining' and any(v.get('error') for v in data.values()):
            self.exclusive='idle';self.run_status.setText('Старт отменён: Lock-in отклонил настройку. Проверьте вкладку управления.')
        super().on_result(job,data)
    def closeEvent(self,event):
        self.want_close=True
        if self.runner and self.runner.isRunning():self.runner.stop();event.ignore();return
        if self.runner and self.runner.unsaved:
            self.want_close=False;self.run_status.setText('Сохраните несохранённую точку перед закрытием.');event.ignore();return
        if not self.shutdown_started:
            self.shutdown_started=True
            if self.reader:self.reader.stop()
            self.ao_shutdown.emit()
        if (self.reader and self.reader.isRunning()) or self.ao_thread.isRunning():
            event.ignore();QTimer.singleShot(100,self.close);return
        super().closeEvent(event)
