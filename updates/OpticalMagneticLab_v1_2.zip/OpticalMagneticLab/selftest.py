"""End-to-end demo including real spawned NI processes and frozen GUI shutdown."""
import json,sys,time,traceback
from pathlib import Path
from types import SimpleNamespace


def run(path):
    import numpy as np
    from PyQt5.QtCore import QTimer,QSettings,QRect,QPoint
    from PyQt5.QtWidgets import QApplication,QScrollArea
    from window import LabWindow
    from models import ARCSEC_PER_RAD,denominator
    from daq import load_ni
    _,constants,_,_,_=load_ni()
    assert constants.TerminalConfiguration.RSE.value==10083
    assert constants.TerminalConfiguration.DIFF.value==10106
    assert constants.AOIdleOutputBehavior.MAINTAIN_EXISTING_VALUE.value==12528
    path=Path(path).resolve();path.parent.mkdir(parents=True,exist_ok=True)
    app=QApplication(sys.argv[:1]);app.setStyle('Fusion');app.setOrganizationName('LabTools');app.setApplicationName('OpticalLabBuildCheck')
    QSettings.setDefaultFormat(QSettings.IniFormat);QSettings.setPath(QSettings.IniFormat,QSettings.UserScope,str(path.parent/'settings'))
    QSettings().clear()
    w=LabWindow(SimpleNamespace(demo=True,serial=None,timeout=2000,max_frequency=120000));w.resize(1280,850);w.show()
    w.folder.setText(str(path.parent/'измерения'));w.start_voltage.setValue(-1);w.stop_voltage.setValue(1);w.intervals.setValue(2)
    w.duration.setValue(.4);w.period.setValue(80);w.settle.setValue(.05);w.after.setCurrentIndex(0)
    w.dark_ip.setValue(20.);w.dark_im.setValue(10.)
    result=dict(ok=False,frozen=bool(getattr(sys,'frozen',False)),qt_platform=app.platformName())
    start=time.monotonic();stage='connecting';ending=False;before_hold=None;oldhook=sys.excepthook
    def finish(ok,detail):
        nonlocal ending
        if ending:return
        ending=True;result.update(ok=ok,detail=detail,elapsed_s=time.monotonic()-start,journal=w.journal.toPlainText())
        path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');w.close()
    sys.excepthook=lambda typ,value,tb:finish(False,''.join(traceback.format_exception(typ,value,tb)))
    def tick():
        nonlocal stage,before_hold
        if ending:return
        try:
            if stage=='connecting':
                if w.connected and w.store.blocks and w.ao_state.get('connected') and not w.ao_busy and w.hysteresis_button.isEnabled() and w.osc_apply.isEnabled():
                    assert not w.ao_state['runtime']['qt_loaded']
                    assert not w.store.metadata['runtime']['qt_loaded']
                    result['ni_children_without_qt']=True
                    assert w.ao_state.get('last_command_V') is None
                    assert w.plant.get()==0
                    live=w.store.live(1,w.calibration());assert .8<live['ip_V']<1.2 and .8<live['im_V']<1.2
                    result['gain_live_verified']=True;result['connect_does_not_write_ao']=True
                    transport=w.worker.instrument.transport
                    before=(transport.data['OA.'],transport.data['OF.'])
                    w.osc_amplitude.setValue(.125);w.osc_frequency.setValue(1234.5);w.save_defaults_button.click()
                    assert (transport.data['OA.'],transport.data['OF.'])==before and w.plant.get()==0
                    result['defaults_saved_without_hardware_write']=True
                    stage='oscillator_apply';w.osc_apply.click()
            elif stage=='oscillator_apply' and not w.busy:
                if '0.125' not in w.osc_actual.text() or '1234.5' not in w.osc_actual.text():return
                stage='oscillator_read';w.read_oscillator()
            elif stage=='oscillator_read' and not w.busy and w.hysteresis_button.isEnabled():
                assert w.osc_amplitude.value()==.125 and w.osc_frequency.value()==1234.5
                stage='hysteresis';w.hysteresis_button.click()
            elif stage=='hysteresis' and w.exclusive=='idle':
                r=getattr(w,'last_outcome',None)
                if not r:return
                assert r['reason']=='complete',r['error']
                points=r['points'];assert [p['target_V'] for p in points]==[-1,0,1,0,-1]
                assert all(p['daq']['valid'] for p in points)
                assert w.plant.get()==-1 and r['finish_action']=='last_command_held_no_readback'
                centered=[p['statistics']['faraday_centered_arcsec'] for p in points]
                assert abs(np.mean(centered))<1e-8
                folder=Path(r['folder']);result['hysteresis_folder']=str(folder)
                assert (folder/'field_dependence.png').stat().st_size>1000
                assert (folder/'field_dependence.pdf').stat().st_size>1000
                summary=np.genfromtxt(folder/'summary.dat',delimiter='\t',names=True,ndmin=1)
                assert len(summary)==5 and abs(np.mean(summary['Faraday_centered_arcsec']))<1e-8
                for point in points:
                    p=Path(point['folder']);d=point['daq']
                    raw=np.genfromtxt(p/'daq.dat',names=True,delimiter='\t',ndmin=1)
                    signal=np.genfromtxt(p/'signal.dat',names=True,delimiter='\t',ndmin=1)
                    np.testing.assert_allclose(raw['Ip_x25p2_V'],raw['AI1_raw_V']*25.2,rtol=1e-12)
                    np.testing.assert_allclose(raw['Ip_corrected_V'],raw['Ip_x25p2_V']-.02,rtol=1e-12)
                    np.testing.assert_allclose(raw['Im_corrected_V'],raw['Im_x25p2_V']-.01,rtol=1e-12)
                    np.testing.assert_allclose(d['ip_mean_V'],raw['Ip_corrected_V'].mean(),rtol=1e-12)
                    np.testing.assert_allclose(d['im_mean_V'],raw['Im_corrected_V'].mean(),rtol=1e-12)
                    assert d['dark_ip_V']==.02 and d['dark_im_V']==.01
                    assert point['oscillator_start']['amplitude_Vrms']==.125 and point['oscillator_end']['frequency_Hz']==1234.5
                    np.testing.assert_allclose(signal['Oscillator_start_Vrms'],.125)
                    np.testing.assert_allclose(signal['Oscillator_end_Hz'],1234.5)
                    for h in (1,2):
                        expected=signal[f'R{h}_V']/denominator(d['ip_mean_V'],d['im_mean_V'])*ARCSEC_PER_RAD
                        np.testing.assert_allclose(signal[f'Alpha{h}_arcsec'],expected,rtol=1e-11)
                        assert np.isfinite(point['statistics']['harmonics'][str(h)]['alpha_mean_arcsec'])
                    assert (p/'harmonics_time.png').stat().st_size>1000
                    assert (p/'harmonics_time.pdf').stat().st_size>1000
                    assert (p/'harmonics_samples.png').stat().st_size>1000
                    assert (p/'harmonics_samples.pdf').stat().st_size>1000
                assert points[0]['lockin']['reference_mode']==1 and points[0]['lockin']['harmonics']==[1,2]
                result.update(dual_internal_harmonics_verified=True,full_point_photo_normalization_verified=True,
                    dark_subtraction_verified=True,oscillator_controls_and_metadata_verified=True,
                    arcseconds_verified=True,faraday_centered_verified=True,raw_daq_stream_verified=True,hysteresis_hold_verified=True)
                w.refresh_dashboard();w.grab().save(str(path.parent/'preview_field.png'))
                for graph in w.field_plots:
                    assert len(graph.faraday.getData()[0])==5
                    for b in (w.run_button,w.hysteresis_button,w.stop_button):
                        assert not QRect(graph.mapTo(w,QPoint()),graph.size()).intersects(QRect(b.mapTo(w,QPoint()),b.size()))
                w.plot_tabs.setCurrentIndex(1);app.processEvents();w.grab().save(str(path.parent/'preview_time.png'))
                result['four_twin_axes_and_time_plots']=True
                before_hold=w.plant.get();w.measurement_mode.setCurrentIndex(1);w.duration.setValue(1.2);w.session_name.setText('stop_hold_check')
                stage='stopping';w.start_experiment();QTimer.singleShot(550,w.stop_experiment)
            elif stage=='stopping' and w.exclusive=='idle':
                r=w.last_outcome
                if r['metadata']['parameters']['name']!='stop_hold_check':return
                assert r['reason']=='stopped',r['error']
                assert w.plant.get()==before_hold
                result['stop_preserves_ao_verified']=True
                w.measurement_mode.setCurrentIndex(0);w.start_voltage.setValue(.4);w.stop_voltage.setValue(.8);w.intervals.setValue(1)
                w.duration.setValue(.3);w.after.setCurrentIndex(1);w.session_name.setText('explicit_zero_check');stage='zero';w.start_experiment()
            elif stage=='zero' and w.exclusive=='idle':
                r=w.last_outcome
                if r['metadata']['parameters']['name']!='explicit_zero_check':return
                assert r['reason']=='complete',r['error']
                assert r['finish_action']=='zero_command_confirmed' and w.plant.get()==0
                result['explicit_finish_zero_verified']=True
                # Leave a nonzero command to test that closing never writes zero.
                w.manual_voltage.setValue(.7);w.set_voltage();stage='close_hold'
            elif stage=='close_hold' and not w.ao_busy:
                assert w.plant.get()==.7
                result['close_voltage_V']=w.plant.get()
                finish(True,'Verified 1f/2f internal acquisition, streaming RSE photodiodes x25.2, Hall calibration, per-point means, angular seconds, centered Faraday twin axes, sweep/hysteresis/fixed modes, Stop/hold and explicit zero.')
        except Exception:finish(False,traceback.format_exc())
    timer=QTimer();timer.setInterval(50);timer.timeout.connect(tick);timer.start()
    QTimer.singleShot(0,lambda:w.submit('open'));QTimer.singleShot(0,w.toggle_ni)
    QTimer.singleShot(90000,lambda:finish(False,'Self-test timed out at '+stage+': '+w.run_status.text()))
    app.exec_();sys.excepthook=oldhook
    result['threads_stopped']=not w.thread.isRunning() and not w.ao_thread.isRunning() and not w.reader.isRunning()
    result['close_preserved_ao']=w.plant.get()==result.get('close_voltage_V')==.7
    result['ok']=bool(result['ok'] and result['threads_stopped'] and result['close_preserved_ao'])
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return 0 if result['ok'] else 1


if __name__=='__main__':
    import multiprocessing
    multiprocessing.freeze_support();raise SystemExit(run(sys.argv[1]))
