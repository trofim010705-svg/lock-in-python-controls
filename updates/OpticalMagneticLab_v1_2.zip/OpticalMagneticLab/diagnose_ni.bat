@echo off
setlocal
cd /d "%~dp0"
set "OPTICAL_NI_REPORT=%LOCALAPPDATA%\LabTools\OpticalMagneticLab\ni_diagnostics.txt"
if exist "OpticalMagneticLab.exe" goto exe
if exist "venv\Scripts\python.exe" goto venv
py -3.11 app.py --ni-diagnostics "%OPTICAL_NI_REPORT%"
goto report
:venv
"venv\Scripts\python.exe" app.py --ni-diagnostics "%OPTICAL_NI_REPORT%"
goto report
:exe
"OpticalMagneticLab.exe" --ni-diagnostics "%OPTICAL_NI_REPORT%"
:report
if not exist "%OPTICAL_NI_REPORT%" goto failed
echo Report: %OPTICAL_NI_REPORT%
start "NI diagnosis" notepad.exe "%OPTICAL_NI_REPORT%"
exit /b 0
:failed
echo NI diagnostic report was not created. See the error above.
pause
exit /b 1
