"""Four field plots with independent Faraday axes, plus every point's time plots."""
from pathlib import Path
import numpy as np
from storage import field_series


def save_figures(folder,points,cancel=None):
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    folder=Path(folder)
    fig=Figure(figsize=(12,8),layout='constrained');FigureCanvasAgg(fig)
    axes=fig.subplots(2,2).ravel()
    specs=[('1','alpha_mean_arcsec','Амплитуда 1f, ″'),('2','alpha_mean_arcsec','Амплитуда 2f, ″'),
           ('1','phase_mean_deg','Фаза 1f, °'),('2','phase_mean_deg','Фаза 2f, °')]
    for i,(ax,(h,key,title)) in enumerate(zip(axes,specs)):
        for branch,values in field_series(points):
            if not values:continue
            b=[p['daq']['field_mean_mT'] for p in values]
            y=[np.nan if p['statistics']['harmonics'][h][key] is None else p['statistics']['harmonics'][h][key] for p in values]
            ax.plot(b,y,('^' if branch=='reverse' else 'o')+('-' if 'phase' not in key else ''),ms=3,color='#257b9d' if branch!='reverse' else '#7954a2',label='Обратный ход' if branch=='reverse' else 'Сигнал')
        right=ax.twinx()
        valid=[p for p in points if p['result']=='complete' and p['daq']['valid']]
        right.plot([p['daq']['field_mean_mT'] for p in valid],
            [np.nan if p['statistics']['faraday_centered_arcsec'] is None else p['statistics']['faraday_centered_arcsec'] for p in valid],
            'd-',color='#db7d28',ms=3,lw=1,label='Фарадей')
        ax.set_xlabel('Магнитное поле, mT');ax.set_ylabel(title,color='#257b9d');ax.set_title(title)
        right.set_ylabel('Угол Фарадея, ″',color='#db7d28');right.tick_params(axis='y',colors='#db7d28')
        ax.grid(alpha=.2)
        if 'phase' in key:ax.set_ylim(0,360)
        lines,labels=ax.get_legend_handles_labels();lr,rr=right.get_legend_handles_labels()
        ax.legend(lines+lr,labels+rr,fontsize=8,loc='best')
    fig.savefig(folder/'field_dependence.png',dpi=170);fig.savefig(folder/'field_dependence.pdf')
    already_stopped=cancel is not None and cancel.is_set()
    for point in (points[-1:] if already_stopped else points):
        if cancel is not None and cancel.is_set() and not already_stopped:break
        p=Path(point['folder']);file=p/'signal.dat'
        if not file.exists():continue
        data=np.genfromtxt(file,names=True,delimiter='\t',ndmin=1)
        if not len(data):continue
        f=Figure(figsize=(11,7),layout='constrained');FigureCanvasAgg(f)
        a=f.subplots(2,2).ravel()
        for axis,column,title in zip(a,('Alpha1_arcsec','Alpha2_arcsec','Phase1_deg','Phase2_deg'),
                                     ('Амплитуда 1f, ″','Амплитуда 2f, ″','Фаза 1f, °','Фаза 2f, °')):
            # Normalization uses full-point mean Ip/Im, never a per-sample denominator.
            axis.plot(data['Time_start_s'],data[column],'.' if column.startswith('Phase') else '.-',ms=2,lw=.6,color='#257b9d')
            axis.set_xlabel('Время внутри точки, s');axis.set_ylabel(title);axis.grid(alpha=.2)
            if column.startswith('Phase'):axis.set_ylim(0,360)
        f.suptitle(f"Точка {point['index']} · B = {point['daq']['field_mean_mT']:.6g} mT")
        f.savefig(p/'harmonics_time.png',dpi=150);f.savefig(p/'harmonics_time.pdf')
        for axis in a:
            for line in axis.lines:line.set_xdata(np.arange(1,len(data)+1))
            axis.set_xlabel('Номер отсчёта');axis.relim();axis.autoscale_view(scalex=True,scaley=False)
        f.savefig(p/'harmonics_samples.png',dpi=150);f.savefig(p/'harmonics_samples.pdf')
        f.clear()
