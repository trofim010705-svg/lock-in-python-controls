"""Compare the two installed NI C APIs in fresh, Qt-free processes.

Only an empty task is created and closed. No channels, writes, device reset,
calibration or self-test are performed.
"""
import json
import os
from pathlib import Path
import traceback
from ni_native import Config,NativeProcess,driver_runtime,load_ni,prepare_driver


def empty_task_check(api):
    task=api.Task()
    try:return True
    finally:task.close()


def diagnostic_child(pipe,config,library):
    os.environ['NIDAQMX_C_LIBRARY']=library
    report=dict(library=library,ok=False,stage='import nidaqmx',runtime=driver_runtime())
    try:
        report['stage']='Prepare system NI-DAQmx library'
        prepare_driver()
        report['stage']='import nidaqmx'
        api,_,_,_,System=load_ni()
        report['stage']='System.driver_version'
        v=System.local().driver_version
        report['driver']=f'{v.major_version}.{v.minor_version}.{v.update_version}'
        report['runtime']=driver_runtime()
        report['stage']='DAQmxCreateTask: empty task, no channels'
        empty_task_check(api)
        report.update(ok=True,stage='empty task closed')
    except Exception as exc:
        report.update(error=f'{type(exc).__name__}: {exc}',traceback=traceback.format_exc(),runtime=driver_runtime())
    try:pipe.send(('ready',report))
    finally:pipe.close()


def run(path):
    path=Path(path).resolve();path.parent.mkdir(parents=True,exist_ok=True)
    report=dict(application='Optical Magnetic Lab 1.2',output_writes=0,device_resets=0,
                check='Empty DAQmx task only; no AI/AO channels configured.',checks=[])
    def save():path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    save()
    for library in ('nicaiu','nicai_utf8'):
        source=NativeProcess(Config(),library,target=diagnostic_child)
        try:detail=source.open()
        except Exception as exc:detail=dict(library=library,ok=False,error=str(exc),stage=source.last_stage)
        finally:source.close()
        report['checks'].append(detail);save()
    report['ok']=any(c.get('ok') for c in report['checks']);save()
    return 0 if report['ok'] else 1


if __name__=='__main__':
    import multiprocessing,sys
    multiprocessing.freeze_support();raise SystemExit(run(sys.argv[1] if len(sys.argv)>1 else 'ni_diagnostics.txt'))
