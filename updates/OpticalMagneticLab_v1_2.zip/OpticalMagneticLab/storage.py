"""Recoverable per-point samples, calibrated optical quantities and run metadata."""
from datetime import datetime
from pathlib import Path
from dataclasses import asdict
import json,math,os,re,tempfile
import numpy as np
from models import denominator,ARCSEC_PER_RAD


def clean(value):
    if isinstance(value,dict):return {str(k):clean(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [clean(v) for v in value]
    if isinstance(value,(float,np.floating)) and not math.isfinite(value):return None
    if isinstance(value,np.generic):return value.item()
    return value
def now():return datetime.now().astimezone().isoformat(timespec='milliseconds')
def atomic(path,text):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.'+p.name,dir=p.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8',newline='\n') as f:f.write(text);f.flush();os.fsync(f.fileno())
        os.replace(tmp,p)
    finally:Path(tmp).unlink(missing_ok=True)
def metadata(path,data):atomic(path,json.dumps(clean(data),ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def create_folder(parent,name):
    name=re.sub(r'[<>:"/\\|?*\x00-\x1f]','_',name).strip(' .')[:80] or 'measurement'
    p=Path(parent).expanduser().resolve()/f'{name}_{datetime.now():%Y%m%d_%H%M%S_%f}'
    p.mkdir(parents=True,exist_ok=False);return p


def save_point(folder,rows,point):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    daq=point['daq'];stats=point['statistics']
    try:norm=denominator(daq.get('ip_mean_V'),daq.get('im_mean_V'))
    except ValueError:norm=None
    header=['Time_start_s','Time_end_s','X1_V','Y1_V','R1_V','Phase1_deg','X2_V','Y2_V','R2_V','Phase2_deg','Status','Overload',
            'Alpha1_rad','Alpha1_arcsec','Alpha2_rad','Alpha2_arcsec','Ip_point_mean_corrected_V','Im_point_mean_corrected_V','Field_point_mean_mT','Faraday_point_raw_arcsec',
            'Ip_point_mean_x25p2_V','Im_point_mean_x25p2_V','DarkIp_scaled_V','DarkIm_scaled_V',
            'Oscillator_start_Vrms','Oscillator_start_Hz','Oscillator_end_Vrms','Oscillator_end_Hz']
    osc=point.get('oscillator_start',{});end=point.get('oscillator_end',{})
    lines=['\t'.join(header)]
    for row in rows:
        a1=row[4]/norm if norm else float('nan');a2=row[8]/norm if norm else float('nan')
        values=[*row,a1,a1*ARCSEC_PER_RAD,a2,a2*ARCSEC_PER_RAD,daq.get('ip_mean_V'),daq.get('im_mean_V'),daq.get('field_mean_mT'),stats['faraday_raw_arcsec'],
                daq.get('ip_amplified_mean_V',daq.get('ip_mean_V')),daq.get('im_amplified_mean_V',daq.get('im_mean_V')),
                daq.get('dark_ip_V',0.),daq.get('dark_im_V',0.),
                osc.get('amplitude_Vrms'),osc.get('frequency_Hz'),end.get('amplitude_Vrms'),end.get('frequency_Hz')]
        lines.append('\t'.join('nan' if v is None else f'{v:.15g}' for v in values))
    atomic(folder/'signal.dat','\n'.join(lines)+'\n');metadata(folder/'parameters.txt',point)


def save_summary(folder,points,info):
    header=['Point','AO0_set_V','Field_mean_mT','Ip_mean_corrected_V','Im_mean_corrected_V','Alpha1_mean_arcsec','Phase1_mean_deg',
            'Alpha2_mean_arcsec','Phase2_mean_deg','R1_mean_V','R2_mean_V','Faraday_raw_arcsec','Faraday_centered_arcsec','Branch','Lockin_samples','NI_samples','Complete',
            'Ip_mean_x25p2_V','Im_mean_x25p2_V','DarkIp_scaled_V','DarkIm_scaled_V',
            'Oscillator_start_Vrms','Oscillator_start_Hz','Oscillator_end_Vrms','Oscillator_end_Hz']
    lines=['\t'.join(header)]
    for p in points:
        s=p['statistics'];d=p['daq'];h1=s['harmonics']['1'];h2=s['harmonics']['2']
        row=[p['index'],p.get('target_V'),d.get('field_mean_mT'),d.get('ip_mean_V'),d.get('im_mean_V'),h1['alpha_mean_arcsec'],h1['phase_mean_deg'],
             h2['alpha_mean_arcsec'],h2['phase_mean_deg'],h1['amplitude_mean_V'],h2['amplitude_mean_V'],s['faraday_raw_arcsec'],s['faraday_centered_arcsec'],
             2 if p.get('branch')=='reverse' else 1,s['samples'],d['samples'],int(p['result']=='complete' and d['valid']),
             d.get('ip_amplified_mean_V',d.get('ip_mean_V')),d.get('im_amplified_mean_V',d.get('im_mean_V')),d.get('dark_ip_V',0.),d.get('dark_im_V',0.),
             p.get('oscillator_start',{}).get('amplitude_Vrms'),p.get('oscillator_start',{}).get('frequency_Hz'),
             p.get('oscillator_end',{}).get('amplitude_Vrms'),p.get('oscillator_end',{}).get('frequency_Hz')]
        lines.append('\t'.join('nan' if v is None else f'{v:.15g}' for v in row))
    atomic(Path(folder)/'summary.dat','\n'.join(lines)+'\n')
    compact=[{k:v for k,v in p.items() if k not in ('lockin','parameters')} for p in points]
    metadata(Path(folder)/'experiment.txt',dict(info,points=compact))


def field_series(points):
    valid=[p for p in points if p['result']=='complete' and p['daq']['valid']]
    groups={branch:[p for p in valid if p.get('branch')==branch] for branch in ('forward','reverse','single')}
    turning=next((p for p in reversed(groups['forward']) if p['index']==p.get('parameters',{}).get('intervals',-1)+1),None)
    if groups['reverse'] and turning is not None:groups['reverse']=[turning,*groups['reverse']]
    return list(groups.items())
