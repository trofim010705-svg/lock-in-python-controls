"""Bipolar voltage plans, calibrated detector intensities and optical angles."""
from dataclasses import dataclass,asdict
import math
import multiprocessing as mp
import numpy as np

GAIN=25.2
ARCSEC_PER_RAD=180/math.pi*3600


@dataclass(frozen=True)
class Calibration:
    slope:float=1.0  # mT/mV
    offset:float=0.0
    dark_ip_V:float=0.0  # dark voltage after x25.2, not raw AI voltage
    dark_im_V:float=0.0
    def validate(self):
        if not np.isfinite([self.slope,self.offset,self.dark_ip_V,self.dark_im_V]).all() or self.slope==0:
            raise ValueError('Нужны конечный ненулевой наклон k и конечный сдвиг b.')
    def field(self,volts):return self.slope*np.asarray(volts)*1000+self.offset
    def photo(self,plus_raw,minus_raw):return np.asarray(plus_raw)*GAIN-self.dark_ip_V,np.asarray(minus_raw)*GAIN-self.dark_im_V


@dataclass(frozen=True)
class Experiment:
    mode:str='sweep'
    start_V:float=-1.
    stop_V:float=1.
    intervals:int=10
    acquisition_s:float=10.
    period_ms:float=100.
    settle_s:float=1.
    folder:str=''
    name:str='optical_measurement'
    additional:str=''
    e_field:str=''
    zero_after:bool=False
    def validate(self):
        if self.mode not in ('single','sweep','hysteresis'):raise ValueError('Неизвестный режим.')
        if not np.isfinite([self.start_V,self.stop_V,self.acquisition_s,self.period_ms,self.settle_s]).all():raise ValueError('Параметры должны быть конечными.')
        if max(abs(self.start_V),abs(self.stop_V))>5:raise ValueError('AO0: допустимо −5…+5 V.')
        if not isinstance(self.intervals,int) or not 1<=self.intervals<=10000:raise ValueError('Число шагов: 1…10000.')
        if not .1<=self.acquisition_s<=86400 or not 20<=self.period_ms<=60000:raise ValueError('Acquisition: 0.1…86400 s; Delay: 20…60000 ms.')
        if self.acquisition_s*1000/self.period_ms>1_000_000:raise ValueError('Слишком много отсчётов Lock-in в одной точке.')
        if not 0<=self.settle_s<=3600:raise ValueError('Задержка после AO0: 0…3600 s.')
        if self.mode=='hysteresis' and self.start_V==self.stop_V:raise ValueError('Для петли нужны разные старт и стоп.')
        if not self.folder.strip():raise ValueError('Выберите папку сохранения.')
    def targets(self):
        if self.mode=='single':return [None]
        a=np.linspace(self.start_V,self.stop_V,self.intervals+1)
        a[np.abs(a)<1e-12]=0
        v=a.tolist()
        return v+v[-2::-1] if self.mode=='hysteresis' else v
    def context(self,index):
        if self.mode!='hysteresis':return dict(branch='single' if self.mode=='single' else 'forward',branch_point=index)
        rev=index>self.intervals+1
        return dict(branch='reverse' if rev else 'forward',branch_point=index-self.intervals-1 if rev else index)


def phase_deg(x,y):
    return math.degrees(math.atan2(y,x))%360 if x or y else float('nan')


def denominator(ip,im):
    if ip is None or im is None or not np.isfinite([ip,im]).all() or ip<=0 or im<=0:
        raise ValueError('Для пересчёта углов нужны Iₚ > 0 и Iₘ > 0. Модуль показаний автоматически не берётся.')
    # Separate roots avoid unnecessary product overflow/underflow.
    value=2*math.sqrt(2)*math.sqrt(ip)*math.sqrt(im)
    if not math.isfinite(value) or value<=0:raise ValueError('Некорректная нормировка фотодетектора.')
    return value


def faraday(ip,im):
    denominator(ip,im)
    scale=max(ip,im)
    ratio=(ip/scale-im/scale)/(ip/scale+im/scale)
    return .5*math.asin(min(1.,max(-1.,ratio)))


def circular_mean(phases):
    p=np.asarray(phases,dtype=float);p=p[np.isfinite(p)]
    if not len(p):return None
    z=np.exp(1j*np.deg2rad(p)).mean()
    if abs(z)<1e-8:return None
    v=float(np.rad2deg(np.angle(z))%360)
    return 0. if v>360-1e-10 else v


def statistics(rows,daq):
    data=np.asarray(rows,dtype=float)
    result=dict(samples=len(rows),harmonics={},faraday_raw_rad=None,faraday_raw_arcsec=None,
                faraday_centered_arcsec=None,angle_error='')
    result['overload_samples']=int(np.count_nonzero(data[:,11])) if len(data) else 0
    result['unlock_samples']=int(np.count_nonzero(data[:,10].astype(int)&8)) if len(data) else 0
    try:
        norm=denominator(daq.get('ip_mean_V'),daq.get('im_mean_V'))
        theta=faraday(daq['ip_mean_V'],daq['im_mean_V'])
        result.update(faraday_raw_rad=theta,faraday_raw_arcsec=theta*ARCSEC_PER_RAD,
                      faraday_centered_arcsec=theta*ARCSEC_PER_RAD)
    except ValueError as exc:norm=None;result['angle_error']=str(exc)
    for harmonic,start in ((1,2),(2,6)):
        amplitude=data[:,start+2] if len(data) else np.array([])
        mean=float(amplitude.mean()) if len(data) else None
        angle=mean/norm if norm and mean is not None else None
        result['harmonics'][str(harmonic)]=dict(amplitude_mean_V=mean,
            phase_mean_deg=circular_mean(data[:,start+3]) if len(data) else None,
            alpha_mean_rad=angle,alpha_mean_arcsec=angle*ARCSEC_PER_RAD if angle is not None else None)
    return result


def center_faraday(points,enabled):
    valid=[p['statistics']['faraday_raw_arcsec'] for p in points
           if p['result']=='complete' and p['daq']['valid'] and p['statistics']['faraday_raw_arcsec'] is not None]
    offset=float(np.mean(valid)) if enabled and valid else 0.
    for p in points:
        raw=p['statistics']['faraday_raw_arcsec']
        p['statistics']['faraday_centered_arcsec']=raw-offset if raw is not None else None
    return offset


class DemoPlant:
    def __init__(self):
        c=mp.get_context('spawn');self.voltage=c.Value('d',0.);self.direction=c.Value('d',1.)
    def set(self,v):
        with self.voltage.get_lock():
            old=self.voltage.value
            if v!=old:self.direction.value=1. if v>old else -1.
            self.voltage.value=float(v)
    def get(self):return self.voltage.value


FORMULAS=dict(photo='Ip = 25.2 * mean(AI1_V) - dark_ip_V; Im = 25.2 * mean(AI0_V) - dark_im_V; dark voltages are already scaled, over the same complete point window',
    hall='B_mT = slope_mT_per_mV * (1000*AI3_V) + offset_mT',
    alpha='alpha_rad = R_V / (2*sqrt(2)*sqrt(Ip_V)*sqrt(Im_V)); alpha_arcsec=alpha_rad*180/pi*3600',
    faraday='thetaF_rad = 0.5*asin((Ip-Im)/(Ip+Im)); thetaF_arcsec=thetaF_rad*180/pi*3600',
    phase='atan2(Yn,Xn) in degrees [0,360); circular mean',
    centering='Hysteresis only: subtract the arithmetic mean of raw Faraday angles of all complete valid points; turning point counted once. Raw angles retained.')
