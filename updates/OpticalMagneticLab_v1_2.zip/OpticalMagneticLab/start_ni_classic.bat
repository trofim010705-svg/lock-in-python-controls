@echo off
setlocal
cd /d "%~dp0"
set "NIDAQMX_C_LIBRARY=nicaiu"
if not exist "OpticalMagneticLab.exe" goto source
"OpticalMagneticLab.exe" %*
exit /b %errorlevel%
:source
call start.bat %*
exit /b %errorlevel%
