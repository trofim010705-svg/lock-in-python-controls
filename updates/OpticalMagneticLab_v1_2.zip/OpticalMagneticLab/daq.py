"""Qt adapter for the independent NI driver processes."""
from PyQt5.QtCore import QThread,pyqtSignal
from ni_native import Config,NIBackend,DemoBackend,NativeProcess,native_child,load_ni


class AIReader(QThread):
    message=pyqtSignal(str)
    configured=pyqtSignal(object)
    def __init__(self,config,store,parent=None):
        super().__init__(parent);import threading
        self.stop_event=threading.Event();self.config=config;self.store=store;self.expected_serial=None
    def stop(self):self.stop_event.set()
    def run(self):
        previous_error=None;last_error_time=0.
        import time
        while not self.stop_event.is_set():
            source=NativeProcess(self.config,'ai')
            try:
                info=source.open()
                if self.expected_serial and info['serial']!=self.expected_serial:raise RuntimeError('Обнаружена другая плата NI; ожидается исходный серийный номер.')
                self.expected_serial=info['serial'];self.store.configure(info);self.configured.emit(info)
                while not self.stop_event.is_set():
                    kind,payload=source.receive(5)
                    if kind!='samples':raise RuntimeError('NI: неверный блок AI.')
                    index,data=payload;self.store.append(index,data)
            except Exception as exc:
                detail=str(exc);now=time.monotonic()
                if not self.stop_event.is_set() and (detail!=previous_error or now-last_error_time>=30):
                    self.message.emit('NI AI: '+detail);previous_error=detail;last_error_time=now
                self.store.fail(str(exc))
            finally:
                source.close()
                if self.store.ready:self.store.fail('AI не подключены.')
            self.stop_event.wait(2)
