"""Qt-free NI driver workers. Never reset the board or write implicit zero."""
from dataclasses import dataclass
import math
import multiprocessing as mp
import time
import traceback
import os
import sys
import ctypes
import struct
import json
from pathlib import Path
from importlib.metadata import version,PackageNotFoundError
import numpy as np

_NI_PRELOAD=None
_DLL_SEARCH='default'


def _system_directory():
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.GetSystemDirectoryW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint]
    kernel.GetSystemDirectoryW.restype=ctypes.c_uint
    buf=ctypes.create_unicode_buffer(32768)
    n=kernel.GetSystemDirectoryW(buf,len(buf))
    if not 0<n<len(buf):raise OSError('GetSystemDirectoryW failed')
    return Path(buf.value)


def prepare_driver():
    """Use the installed NI C API. Called only inside the NI worker process."""
    global _NI_PRELOAD,_DLL_SEARCH
    if sys.platform!='win32':return
    os.environ.setdefault('NIDAQMX_C_LIBRARY','nicaiu')
    name=os.environ['NIDAQMX_C_LIBRARY']
    if name not in ('nicaiu','nicai_utf8'):raise ValueError('NIDAQMX_C_LIBRARY: nicaiu or nicai_utf8 required')
    # PyInstaller gives its bundled DLL directory priority. NI dependencies must
    # use the system installation. The GUI and Lock-in processes are untouched.
    if getattr(sys,'frozen',False):
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.SetDllDirectoryW.argtypes=[ctypes.c_wchar_p]
        kernel.SetDllDirectoryW.restype=ctypes.c_int
        if not kernel.SetDllDirectoryW(None):raise OSError('SetDllDirectoryW failed')
        _DLL_SEARCH='system search restored in NI child'
    path=_system_directory()/(name+'.dll')
    if path.is_file():_NI_PRELOAD=ctypes.WinDLL(str(path))


def driver_runtime():
    info=dict(python=sys.version.split()[0],bits=struct.calcsize('P')*8,frozen=bool(getattr(sys,'frozen',False)),
              executable=sys.executable,
              c_library=os.environ.get('NIDAQMX_C_LIBRARY','automatic'),dll_search=_DLL_SEARCH,
              qt_loaded=any(n in sys.modules for n in ('PyQt5.QtCore','PySide2.QtCore','PySide6.QtCore')))
    try:info['nidaqmx']=version('nidaqmx')
    except PackageNotFoundError:info['nidaqmx']='not installed'
    if sys.platform=='win32':
        try:
            lib=sys.modules.get('nidaqmx._lib')
            importer=getattr(lib,'lib_importer',None)
            wrapped=getattr(importer,'_windll',None)
            dll=getattr(wrapped,'_library',None)
            if dll is not None:
                kernel=ctypes.WinDLL('kernel32',use_last_error=True)
                kernel.GetModuleFileNameW.argtypes=[ctypes.c_void_p,ctypes.c_wchar_p,ctypes.c_uint]
                kernel.GetModuleFileNameW.restype=ctypes.c_uint
                buf=ctypes.create_unicode_buffer(32768)
                if kernel.GetModuleFileNameW(dll._handle,buf,len(buf)):info['loaded_dll']=buf.value
        except Exception as exc:info['dll_path_error']=str(exc)
    return info


def failure_detail(exc,source):
    prefix=''
    if isinstance(exc,OSError) and 'access violation' in str(exc).lower():
        prefix=('Сбой нативного NI-DAQmx при обращении к памяти. '
                'Запустите diagnose_ni.bat для проверки пустой задачи без записи напряжения.\n')
    return (prefix+f'Этап: {getattr(source,"stage","unknown")}\n{type(exc).__name__}: {exc}\n'
            +'NI runtime: '+json.dumps(driver_runtime(),ensure_ascii=False)+'\n'+traceback.format_exc())


@dataclass(frozen=True)
class Config:
    device:str='Dev1'
    rate:int=1000
    block:int=100
    hall_diff:bool=True
    demo:bool=False
    plant:object=None
    def validate(self):
        if not self.device or '/' in self.device or '\\' in self.device:raise ValueError('Укажите имя платы из NI MAX, например Dev1.')
        if not 100<=self.rate<=10000 or not 10<=self.block<=1000:raise ValueError('Некорректная частота/блок NI.')


def load_ni():
    import nidaqmx
    from nidaqmx import constants
    from nidaqmx.stream_readers import AnalogMultiChannelReader
    from nidaqmx.system import Device,System
    return nidaqmx,constants,AnalogMultiChannelReader,Device,System


class NIBackend:
    def __init__(self,config,loader=load_ni,progress=None):
        self.config=config;self.loader=loader;self.ai=self.ao=None;self.last=None;self.idle='not_created';self.progress=progress or (lambda s:None);self.stage='initialization'
    def step(self,name):
        if name!=self.stage:self.stage=name;self.progress(name)
    def info(self):
        self.config.validate()
        self.step('import nidaqmx')
        api,c,reader,Device,System=self.loader();self.api,self.constants,self.Reader=api,c,reader
        self.step('Device / System.driver_version')
        d=Device(self.config.device);v=System.local().driver_version
        return dict(device=self.config.device,serial=str(d.dev_serial_num),product=d.product_type,
                    driver=f'{v.major_version}.{v.minor_version}.{v.update_version}',demo=False,
                    ni_simulated_device=bool(getattr(d,'dev_is_simulated',False)),
                    ao_channel=f'{self.config.device}/ao0',ao_reference='AO GND',software_ao_limits_V=[-5,5],
                    runtime=driver_runtime())
    def open_ai(self):
        info=self.info();c=self.constants;cfg=self.config
        self.step('Task / AI channels AI1-RSE AI0-RSE AI3-Hall')
        self.ai=self.api.Task()
        for number,terminal in ((1,c.TerminalConfiguration.RSE),(0,c.TerminalConfiguration.RSE),
                                (3,c.TerminalConfiguration.DIFF if cfg.hall_diff else c.TerminalConfiguration.RSE)):
            self.ai.ai_channels.add_ai_voltage_chan(f'{cfg.device}/ai{number}',terminal_config=terminal,
                                                    min_val=-10,max_val=10,units=c.VoltageUnits.VOLTS)
        self.step('AI sample clock and AnalogMultiChannelReader')
        self.ai.timing.cfg_samp_clk_timing(cfg.rate,sample_mode=c.AcquisitionType.CONTINUOUS,samps_per_chan=max(10000,cfg.rate*5))
        self.reader=self.Reader(self.ai.in_stream)
        self.array=np.empty((3,cfg.block),dtype=np.float64)
        self.step('AI Task.start')
        before=time.perf_counter();self.ai.start();after=time.perf_counter()
        self.origin=before;self.rate=float(self.ai.timing.samp_clk_rate)
        return dict(info,sample_rate_Hz=self.rate,origin_monotonic_s=self.origin,
                    anchor_uncertainty_s=after-before+1/self.rate,
                    channels=[f'{cfg.device}/ai1',f'{cfg.device}/ai0',f'{cfg.device}/ai3'],
                    terminals=['RSE','RSE','DIFFERENTIAL' if cfg.hall_diff else 'RSE'])
    def read(self):
        self.step('AnalogMultiChannelReader.read_many_sample')
        n=self.reader.read_many_sample(self.array,number_of_samples_per_channel=self.config.block,timeout=2.)
        return self.array[:,:n].copy()
    def write(self,value):
        value=float(value)
        if not math.isfinite(value) or not -5<=value<=5:raise ValueError('AO0: только −5…+5 V.')
        if self.ao is None:
            self.step('Create AO0 task (no write yet)')
            self.ao=self.api.Task()
            channel=self.ao.ao_channels.add_ao_voltage_chan(f'{self.config.device}/ao0',min_val=-5,max_val=5,
                                                          units=self.constants.VoltageUnits.VOLTS)
            # Set before the first write/start. Channel creation never writes 0.
            self.step('AO0 idle behavior MAINTAIN_EXISTING_VALUE')
            try:
                channel.ao_idle_output_behavior=self.constants.AOIdleOutputBehavior.MAINTAIN_EXISTING_VALUE
                self.idle='MAINTAIN_EXISTING_VALUE'
            except Exception as exc:
                if getattr(exc,'error_code',None)!=-200452:
                    task,self.ao=self.ao,None
                    try:task.close()
                    except Exception:pass
                    raise
                # USB X-Series can reject this optional property. An on-demand
                # scalar task still writes directly to its DAC; do not replace
                # the request with a zero or change device/reset settings.
                self.idle='DEVICE_DEFAULT_ON_DEMAND_PROPERTY_UNSUPPORTED'
        self.step('AO0 write requested voltage')
        self.ao.write(value,auto_start=True);self.last=value
        return dict(last_command_V=value,readback=False,confirmed_command=True,idle_behavior=self.idle)
    def health(self):
        if self.ao is not None:
            self.step('AO0 read-only task health');self.ao.is_task_done()
        return dict(last_command_V=self.last,readback=False,confirmed_command=self.last is not None,idle_behavior=self.idle)
    def close(self):
        for name in ('ai','ao'):
            task=getattr(self,name);setattr(self,name,None)
            if task is not None:task.close()  # no zero write, no reset or reinitialization


class DemoBackend:
    def __init__(self,config):self.config=config;self.last=None;self.index=0
    def info(self):return dict(device='DEMO',serial='6363-DEMO',product='Simulated USB-6363',demo=True,
                              ao_channel='DEMO/ao0',ao_reference='AO GND',software_ao_limits_V=[-5,5],runtime=driver_runtime())
    def open_ai(self):
        self.origin=time.perf_counter();self.rate=self.config.rate;self.index=0
        self.rng=np.random.default_rng(6363)
        return dict(self.info(),sample_rate_Hz=self.rate,origin_monotonic_s=self.origin,anchor_uncertainty_s=1/self.rate,
                    channels=['DEMO/ai1','DEMO/ai0','DEMO/ai3'],terminals=['RSE','RSE','DIFFERENTIAL' if self.config.hall_diff else 'RSE'])
    def read(self):
        n=self.config.block
        time.sleep(max(0,self.origin+(self.index+n)/self.rate-time.perf_counter()))
        v=self.config.plant.get();direction=self.config.plant.direction.value
        theta=.002*np.tanh((v-.3*direction)/1.2)
        ip=.04*(1+np.sin(2*theta))+self.rng.normal(0,1e-6,n)
        im=.04*(1-np.sin(2*theta))+self.rng.normal(0,1e-6,n)
        hall=.008*v+self.rng.normal(0,2e-6,n)
        self.index+=n
        return np.vstack((ip,im,hall))
    def write(self,value):
        value=float(value)
        if not np.isfinite(value) or abs(value)>5:raise ValueError('AO0: только −5…+5 V.')
        self.config.plant.set(value);self.last=value
        return self.health()
    def health(self):return dict(last_command_V=self.last,readback=False,confirmed_command=self.last is not None,idle_behavior='MAINTAIN_EXISTING_VALUE')
    def close(self):pass


def native_child(pipe,config,kind):
    source=DemoBackend(config) if config.demo else NIBackend(config,progress=lambda s:pipe.send(('stage',s)))
    try:
        if not config.demo:
            source.step('Prepare system NI-DAQmx library')
            prepare_driver()
        pipe.send(('ready',source.open_ai() if kind=='ai' else source.info()))
        if kind=='ai':
            index=0
            while not pipe.poll():
                block=source.read();pipe.send(('samples',(index,block)));index+=block.shape[1]
            pipe.recv()
        else:
            while True:
                command,value=pipe.recv()
                if command=='close':break
                try:
                    answer=source.write(value) if command=='write' else source.health()
                    pipe.send(('reply',answer))
                except Exception as exc:
                    pipe.send(('failure',failure_detail(exc,source)));break
    except (EOFError,BrokenPipeError):pass
    except Exception as exc:
        try:pipe.send(('failure',failure_detail(exc,source)))
        except (OSError,EOFError):pass
    finally:
        try:source.close()
        except Exception:pass
        pipe.close()


class NativeProcess:
    def __init__(self,config,kind,target=native_child):self.config=config;self.kind=kind;self.target=target;self.process=None;self.last_stage='starting process'
    def open(self):
        if getattr(sys,'frozen',False):
            # A Qt application's PyInstaller run-time hooks preload QtCore even
            # before freeze_support. Use a separately built, Qt-free executable.
            worker=Path(sys.executable).parent/'NIWorker'/'OpticalNIWorker.exe'
            if not worker.is_file():raise RuntimeError('Не найден NIWorker/OpticalNIWorker.exe. Распакуйте весь архив программы.')
            os.environ['PYINSTALLER_RESET_ENVIRONMENT']='1'
            mp.set_executable(str(worker))
        ctx=mp.get_context('spawn');self.pipe,child=ctx.Pipe()
        self.process=ctx.Process(target=self.target,args=(child,self.config,self.kind),daemon=True)
        try:self.process.start()
        finally:child.close()
        kind,meta=self.receive(30)
        if kind!='ready':raise RuntimeError('NI: нет подтверждения запуска.')
        self.metadata=meta;return meta
    def receive(self,timeout=5):
        deadline=time.perf_counter()+timeout
        while time.perf_counter()<deadline:
            try:
                if self.pipe.poll(.05):
                    kind,value=self.pipe.recv()
                    if kind=='stage':self.last_stage=value;continue
                    if kind=='failure':raise RuntimeError(value)
                    return kind,value
            except (EOFError,OSError) as exc:
                self.process.join(.1)
                raise RuntimeError(f'Связь с NI потеряна: {exc}; код {self.process.exitcode}; этап {self.last_stage}.') from exc
            if not self.process.is_alive():raise RuntimeError(f'Процесс NI завершился, код {self.process.exitcode}; этап {self.last_stage}.')
        raise TimeoutError('NI не ответила; этап '+self.last_stage+'. Состояние AO0 не подтверждено.')
    def command(self,name,value=None):
        self.pipe.send((name,value));kind,result=self.receive(10)
        if kind!='reply':raise RuntimeError('NI: неверный ответ команды AO0.')
        return result
    def close(self):
        if self.process is None:return
        p,self.process=self.process,None
        try:
            if p.pid is None:return
            if p.is_alive():
                try:self.pipe.send(('close',None))
                except OSError:pass
                deadline=time.monotonic()+2
                while p.is_alive() and time.monotonic()<deadline:
                    try:
                        if self.pipe.poll(.03):self.pipe.recv()
                    except (EOFError,OSError):break
                    p.join(.01)
                if p.is_alive():p.terminate();p.join(1)
                if p.is_alive():p.kill();p.join(1)
            else:p.join(.1)
        finally:self.pipe.close()

