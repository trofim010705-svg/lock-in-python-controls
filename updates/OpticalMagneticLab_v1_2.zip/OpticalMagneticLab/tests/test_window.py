from collections import deque
import tempfile,time,unittest
from types import SimpleNamespace
from unittest.mock import patch
from PyQt5.QtCore import QSettings,QRect,QPoint,Qt
from PyQt5.QtWidgets import QApplication,QScrollArea
from window import LabWindow


class WindowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([]);cls.tmp=tempfile.TemporaryDirectory()
        cls.app.setOrganizationName('OpticalLabTests');cls.app.setApplicationName('OpticalWindow')
        QSettings.setDefaultFormat(QSettings.IniFormat);QSettings.setPath(QSettings.IniFormat,QSettings.UserScope,cls.tmp.name)
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def setUp(self):
        QSettings().clear();self.w=LabWindow(SimpleNamespace(demo=True,serial=None,timeout=2000,max_frequency=120000))
    def tearDown(self):
        self.w.close();end=time.monotonic()+8
        while time.monotonic()<end:
            self.app.processEvents()
            if self.w.thread_stopped and not self.w.ao_thread.isRunning():break
            time.sleep(.005)
        self.assertTrue(self.w.thread_stopped);self.assertFalse(self.w.ao_thread.isRunning())
    def test_three_indicators_four_twin_axes_and_four_time_plots(self):
        self.assertEqual(len(self.w.top_values),3);self.assertEqual(len(self.w.field_plots),4);self.assertEqual(len(self.w.time_plots),4)
        self.assertFalse(self.w.run_button.isEnabled());self.assertFalse(self.w.hysteresis_button.isEnabled())
        for graph in self.w.field_plots:self.assertIn('Фарадей',graph.getAxis('right').labelText)
        self.assertEqual(self.w.manual_voltage.minimum(),-5);self.assertEqual(self.w.manual_voltage.maximum(),5)
    def test_button_uses_same_voltage_grid_and_hold_policy(self):
        self.w.start_voltage.setValue(-2);self.w.stop_voltage.setValue(2);self.w.intervals.setValue(2)
        self.w.hysteresis_button.setEnabled(True)
        with patch.object(self.w,'start_experiment') as start:self.w.hysteresis_button.click()
        start.assert_called_once_with();p=self.w.parameters()
        self.assertEqual(p.targets(),[-2,0,2,0,-2]);self.assertFalse(p.zero_after)
    def test_buttons_outside_graphs_and_no_horizontal_settings_clipping(self):
        self.w.resize(1280,850);self.w.show();self.app.processEvents()
        for graph in self.w.field_plots:
            r=QRect(graph.mapTo(self.w,QPoint()),graph.size())
            for button in (self.w.run_button,self.w.stop_button,self.w.hysteresis_button):
                self.assertFalse(r.intersects(QRect(button.mapTo(self.w,QPoint()),button.size())))
        scroll=self.w.dashboard.findChild(QScrollArea)
        self.assertLessEqual(scroll.widget().width(),scroll.viewport().width())
        for field in self.w.default_fields.values():self.assertEqual(field.lineEdit().contextMenuPolicy(),Qt.NoContextMenu)
    def test_sample_number_stays_absolute_when_live_buffer_is_bounded(self):
        self.w.live_rows=deque(maxlen=3)
        rows=[(i,i+.01,1,2,3,40,1,2,3,50,1,0) for i in range(5)]
        self.w.receive_samples(rows);self.w.refresh_dashboard()
        x,_=self.w.time_curves[2].getData();self.assertEqual(list(x),[3,4,5])
        self.w.time_axis.setCurrentIndex(1);self.w.refresh_dashboard()
        x,_=self.w.time_curves[2].getData();self.assertEqual(list(x),[2,3,4])
    def test_oscillator_controls_use_normal_queued_read_and_apply_operations(self):
        self.w.osc_amplitude.setValue(.123456);self.w.osc_frequency.setValue(3456.7)
        with patch.object(self.w,'submit') as submit:
            self.w.apply_oscillator();job,data=submit.call_args.args
            self.assertEqual(job,'apply');self.assertEqual(data['values'],dict(oa=.123456,of=3456.7))
            self.assertEqual(data['title'],'Oscillator output')
            self.w.read_oscillator();job,data=submit.call_args.args
            self.assertEqual(job,'read');self.assertEqual(data['titles'],['Oscillator output'])
    def test_defaults_restore_dark_oscillator_and_manual_voltage_without_writing_hardware(self):
        self.w.dark_ip.setValue(20);self.w.dark_im.setValue(10);self.w.manual_voltage.setValue(.7)
        self.w.osc_amplitude.setValue(.234);self.w.osc_frequency.setValue(1234.5)
        self.w.folder.setText(self.tmp.name);self.w.session_name.setText('saved_name');self.w.e_field.setText('2.1 kV')
        calls=[];self.w.ao_request.connect(lambda *args:calls.append(args));self.w.request.connect(lambda *args:calls.append(args))
        self.w.save_defaults_button.click();self.assertEqual(calls,[])
        other=LabWindow(self.w.args)
        try:
            self.assertEqual(other.calibration().dark_ip_V,.02);self.assertEqual(other.calibration().dark_im_V,.01)
            self.assertEqual(other.manual_voltage.value(),.7);self.assertEqual(other.osc_amplitude.value(),.234)
            self.assertEqual(other.osc_frequency.value(),1234.5);self.assertEqual(other.folder.text(),self.tmp.name)
            self.assertEqual(other.session_name.text(),'saved_name');self.assertEqual(other.e_field.text(),'2.1 kV')
            self.assertEqual(other.plant.get(),0.)
        finally:
            other.close();end=time.monotonic()+8
            while time.monotonic()<end and (other.ao_thread.isRunning() or not other.thread_stopped):
                self.app.processEvents();time.sleep(.005)
            self.assertFalse(other.ao_thread.isRunning());self.assertTrue(other.thread_stopped)
