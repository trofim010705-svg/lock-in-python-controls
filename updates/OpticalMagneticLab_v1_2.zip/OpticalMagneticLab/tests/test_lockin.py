import unittest
from gui_app import Instrument,schema
from services import DualDemoTransport,configure_dual,validate_mode,DualLockinWorker,Ticket,snapshot
from models import DemoPlant


class LockinTests(unittest.TestCase):
    def setUp(self):
        self.plant=DemoPlant();self.transport=DualDemoTransport(self.plant);self.transport.open()
        self.inst=Instrument(self.transport,schema(120000),120000)
    def tearDown(self):self.transport.close()
    def test_dual_internal_harmonics_readback_and_unrelated_settings_preserved(self):
        self.transport.data['SEN1']='16';self.transport.data['OF.']='777';configure_dual(self.inst)
        value=validate_mode(self.inst)
        self.assertEqual(value['REFMODE'],1);self.assertEqual(value['IE'],0)
        self.assertEqual(value['REFN1'],1);self.assertEqual(value['REFN2'],2)
        self.assertEqual(self.transport.data['OF.'],'777');self.assertEqual(self.transport.data['SEN1'],'16')
        self.assertFalse(any(c.startswith(('OF. ','OA. ','SEN','TC')) for c in self.transport.writes))
    def test_no_silent_current_units_or_wrong_second_harmonic(self):
        configure_dual(self.inst);self.transport.data['IMODE']='1'
        with self.assertRaises(ValueError):validate_mode(self.inst)
        self.transport.data['IMODE']='0';self.transport.data['REFN2']='3'
        with self.assertRaises(ValueError):validate_mode(self.inst)
    def test_worker_reads_both_xy_pairs_and_phases(self):
        configure_dual(self.inst)
        worker=DualLockinWorker(True,None,2000,schema(120000),120000);worker.instrument=self.inst;worker.plant=self.plant
        ticket=Ticket();worker.execute('dual_read',dict(ticket=ticket,data={}))
        self.assertIsNone(ticket.error);v=ticket.value['values'];self.assertEqual(len(v),8)
        self.assertGreater(v[2],v[6]);self.assertTrue(0<=v[3]<360 and 0<=v[7]<360)
    def test_oscillator_amplitude_and_frequency_are_actual_readback_in_metadata(self):
        configure_dual(self.inst)
        self.inst.apply('Oscillator output',dict(oa=.234567,of=1234.5),{'oa','of'})
        value=snapshot(self.inst)
        self.assertEqual(value['oscillator']['amplitude_Vrms'],.234567)
        self.assertEqual(value['oscillator']['frequency_Hz'],1234.5)
        self.assertEqual(value['frequency2_Hz'],2469.)
        self.assertEqual(value['oscillator']['shared_by_harmonics'],[1,2])
