from dataclasses import replace
import math,tempfile,unittest
import numpy as np
from models import (Calibration,Experiment,GAIN,ARCSEC_PER_RAD,denominator,faraday,statistics,center_faraday,circular_mean)


class PhysicsTests(unittest.TestCase):
    def test_voltage_plan_endpoints_turnaround_and_single(self):
        self.assertEqual(Experiment(mode='hysteresis',start_V=-5,stop_V=5,intervals=2).targets(),[-5,0,5,0,-5])
        self.assertEqual(Experiment(mode='hysteresis',start_V=5,stop_V=-5,intervals=2).targets(),[5,0,-5,0,5])
        self.assertEqual(Experiment(mode='single').targets(),[None])
        self.assertEqual(Experiment(mode='hysteresis',intervals=2).context(4),dict(branch='reverse',branch_point=1))
    def test_invalid_voltages_and_zero_loop_rejected(self):
        for changes in ({'start_V':5.01},{'stop_V':-5.01},{'start_V':float('nan')},{'intervals':0},{'period_ms':1},
                        {'mode':'hysteresis','start_V':1,'stop_V':1}):
            with self.subTest(changes=changes),self.assertRaises(ValueError):replace(Experiment(folder='/tmp'),**changes).validate()
    def test_hall_voltage_to_millitesla(self):
        self.assertEqual(float(Calibration(2.5,-3).field(.004)),7)
    def test_arcsecond_conversion_and_25p2_applied_exactly_once(self):
        ip=im=.04*GAIN
        r=1e-5;angle=r/denominator(ip,im)
        self.assertAlmostEqual(angle*ARCSEC_PER_RAD,r/(2*math.sqrt(2)*1.008)*180/math.pi*3600)
        self.assertAlmostEqual(1/ARCSEC_PER_RAD,math.pi/(180*3600))
    def test_faraday_uses_half_arcsine_and_positive_intensities(self):
        self.assertAlmostEqual(faraday(2,1),.5*math.asin(1/3))
        self.assertAlmostEqual(faraday(2*GAIN,GAIN),faraday(2,1))
        self.assertAlmostEqual(faraday(1,1),0)
        for ip,im in ((-1,1),(0,1),(1,float('nan'))):
            with self.assertRaises(ValueError):faraday(ip,im)
    def test_two_harmonics_use_full_point_detector_means(self):
        rows=[(0,.01,3e-6,4e-6,5e-6,359,0,2e-6,2e-6,10,1,0),
              (.1,.11,3e-6,4e-6,5e-6,1,0,4e-6,4e-6,30,1,0)]
        d=dict(ip_mean_V=2.,im_mean_V=1.)
        s=statistics(rows,d)
        self.assertAlmostEqual(s['harmonics']['1']['alpha_mean_arcsec'],5e-6/denominator(2,1)*ARCSEC_PER_RAD)
        self.assertAlmostEqual(s['harmonics']['2']['alpha_mean_arcsec'],3e-6/denominator(2,1)*ARCSEC_PER_RAD)
        self.assertAlmostEqual(s['harmonics']['1']['phase_mean_deg'],0)
        self.assertAlmostEqual(s['harmonics']['2']['phase_mean_deg'],20)
        self.assertAlmostEqual(s['faraday_raw_rad'],.5*math.asin(1/3))
    def test_invalid_photodiodes_preserve_raw_signal_statistics(self):
        rows=[(0,.01,3.,4.,5.,10.,1.,2.,math.sqrt(5),20.,1,0)]
        s=statistics(rows,dict(ip_mean_V=-1,im_mean_V=1))
        self.assertEqual(s['harmonics']['1']['amplitude_mean_V'],5)
        self.assertIsNone(s['harmonics']['1']['alpha_mean_arcsec'])
        self.assertTrue(s['angle_error']);self.assertIsNone(circular_mean([0,180]))
    def test_centering_changes_only_faraday_and_retains_raw_values(self):
        points=[dict(result='complete',daq=dict(valid=True),statistics=dict(faraday_raw_arcsec=v,faraday_centered_arcsec=v)) for v in (-10,20,30)]
        offset=center_faraday(points,True)
        self.assertAlmostEqual(offset,40/3)
        self.assertAlmostEqual(sum(p['statistics']['faraday_centered_arcsec'] for p in points),0)
        self.assertEqual([p['statistics']['faraday_raw_arcsec'] for p in points],[-10,20,30])
        center_faraday(points,False)
        self.assertEqual([p['statistics']['faraday_centered_arcsec'] for p in points],[-10,20,30])
