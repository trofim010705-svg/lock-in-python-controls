from types import SimpleNamespace as NS
import os,time,unittest
from unittest.mock import patch,PropertyMock
import numpy as np
from daq import Config,NIBackend,NativeProcess
from models import DemoPlant


class FakeAOChannel:
    def __init__(self,events):self.events=events
    @property
    def ao_idle_output_behavior(self):return self.idle
    @ao_idle_output_behavior.setter
    def ao_idle_output_behavior(self,value):self.idle=value;self.events.append(('idle',value))


class FakeTask:
    def __init__(self,events):
        self.events=events;self.channels=[];self.timing=NS(samp_clk_rate=1000,cfg_samp_clk_timing=self.timing_config)
        self.ai_channels=NS(add_ai_voltage_chan=self.add_ai);self.ao_channels=NS(add_ao_voltage_chan=self.add_ao);self.in_stream=object()
    def timing_config(self,*args,**kwargs):self.events.append(('timing',args,kwargs))
    def add_ai(self,name,**kwargs):self.channels.append((name,kwargs));self.events.append(('AI',name,kwargs))
    def add_ao(self,name,**kwargs):self.events.append(('AO',name,kwargs));return FakeAOChannel(self.events)
    def start(self):self.events.append(('start',))
    def write(self,value,**kwargs):self.events.append(('write',value,kwargs))
    def is_task_done(self):return True
    def close(self):self.events.append(('close',))


class Reader:
    def __init__(self,stream):pass
    def read_many_sample(self,array,**kwargs):array[:]=np.array([.04,.05,.006])[:,None];return array.shape[1]


def crash_child(pipe,config,kind):
    pipe.send(('ready',dict(serial='CRASH')));pipe.close();os._exit(7)


def hanging_child(pipe,config,kind):
    pipe.send(('ready',dict(serial='HANG')))
    pipe.recv();time.sleep(30)
    config.plant.set(5.)


class NIBackendTests(unittest.TestCase):
    def setUp(self):
        self.events=[];self.tasks=[]
        def task():
            t=FakeTask(self.events);self.tasks.append(t);return t
        self.constants=NS(TerminalConfiguration=NS(RSE='RSE',DIFF='DIFF'),VoltageUnits=NS(VOLTS='V'),
            AcquisitionType=NS(CONTINUOUS='CONTINUOUS'),AOIdleOutputBehavior=NS(MAINTAIN_EXISTING_VALUE=12528))
        device=lambda name:NS(dev_serial_num=1234,product_type='USB-6363')
        system=NS(local=lambda:NS(driver_version=NS(major_version=26,minor_version=8,update_version=0)))
        loader=lambda:(NS(Task=task),self.constants,Reader,device,system)
        self.source=NIBackend(Config(),loader=loader)
    def tearDown(self):self.source.close()
    def test_connection_only_reads_info_and_never_creates_ao_task(self):
        self.source.info();self.assertEqual(self.tasks,[]);self.assertEqual(self.events,[])
    def test_ai_channel_order_modes_and_voltage_range(self):
        info=self.source.open_ai()
        self.assertEqual([name for name,kw in self.tasks[0].channels],['Dev1/ai1','Dev1/ai0','Dev1/ai3'])
        self.assertEqual([kw['terminal_config'] for name,kw in self.tasks[0].channels],['RSE','RSE','DIFF'])
        self.assertFalse(any(e[0] in ('AO','write') for e in self.events))
        self.assertEqual(info['terminals'],['RSE','RSE','DIFFERENTIAL'])
        data=self.source.read();self.assertEqual(data.shape,(3,100));self.assertAlmostEqual(data[0,0],.04)
    def test_optional_hall_rse_changes_only_ai3(self):
        self.source.config=Config(hall_diff=False);self.source.open_ai()
        self.assertEqual([kw['terminal_config'] for n,kw in self.tasks[0].channels],['RSE']*3)
    def test_first_write_is_target_not_zero_and_idle_holds_on_close(self):
        self.source.info();self.source.write(3.);self.source.write(-2.);self.source.close()
        writes=[e[1] for e in self.events if e[0]=='write']
        self.assertEqual(writes,[3.,-2.])
        self.assertLess(next(i for i,e in enumerate(self.events) if e[0]=='idle'),next(i for i,e in enumerate(self.events) if e[0]=='write'))
        self.assertEqual([e[1] for e in self.events if e[0]=='idle'],[12528])
        self.assertEqual(len(self.tasks),1)
    def test_hard_limit_rejects_before_creating_output(self):
        self.source.info()
        for value in (-5.01,5.01,float('nan'),float('inf')):
            with self.assertRaises(ValueError):self.source.write(value)
        self.assertEqual(self.tasks,[])
    def test_unsupported_idle_property_still_writes_requested_voltage_without_zero(self):
        self.source.info();error=RuntimeError('Property unsupported');error.error_code=-200452
        with patch.object(FakeAOChannel,'ao_idle_output_behavior',new_callable=PropertyMock,side_effect=error):
            result=self.source.write(2.75);self.source.write(-1.25)
        self.source.close()
        self.assertEqual([e[1] for e in self.events if e[0]=='write'],[2.75,-1.25])
        self.assertEqual(result['idle_behavior'],'DEVICE_DEFAULT_ON_DEMAND_PROPERTY_UNSUPPORTED')
        self.assertEqual(len(self.tasks),1)
    def test_other_idle_errors_are_not_silently_ignored_or_followed_by_a_write(self):
        self.source.info();error=RuntimeError('Resource reserved');error.error_code=-50103
        with patch.object(FakeAOChannel,'ao_idle_output_behavior',new_callable=PropertyMock,side_effect=error):
            with self.assertRaises(RuntimeError):self.source.write(2.75)
        self.assertFalse(any(e[0]=='write' for e in self.events));self.assertIsNone(self.source.ao)


class NativeProcessTests(unittest.TestCase):
    def test_crash_is_reported_without_freezing_parent(self):
        s=NativeProcess(Config(),'ao',target=crash_child)
        try:
            s.open()
            with self.assertRaises(RuntimeError):s.receive(1)
        finally:s.close()
    def test_hanging_process_is_bounded_and_no_delayed_write_survives(self):
        plant=DemoPlant();s=NativeProcess(Config(demo=True,plant=plant),'ao',target=hanging_child)
        try:
            s.open();s.pipe.send(('write',5.))
            with self.assertRaises(TimeoutError):s.receive(.1)
            start=time.monotonic();s.close();self.assertLess(time.monotonic()-start,4)
            self.assertEqual(plant.get(),0.)
        finally:s.close()
