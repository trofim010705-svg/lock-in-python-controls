from pathlib import Path
import tempfile,unittest
from unittest.mock import patch
import numpy as np
from report import save_figures


class ReportTests(unittest.TestCase):
    def test_four_independent_right_axes_use_centered_faraday_and_measured_field(self):
        with tempfile.TemporaryDirectory() as folder:
            points=[]
            for i,b in enumerate((-2,3),1):
                points.append(dict(index=i,branch='forward',result='complete',folder=folder,
                    daq=dict(valid=True,field_mean_mT=b),statistics=dict(faraday_centered_arcsec=b*10,
                        harmonics={h:dict(alpha_mean_arcsec=i*.1,phase_mean_deg=i*30) for h in ('1','2')})))
            captured=[]
            def capture(fig,*a,**k):
                if not captured:captured.append(fig)
            with patch('matplotlib.figure.Figure.savefig',autospec=True,side_effect=capture):save_figures(folder,points)
            fig=captured[0];self.assertEqual(len(fig.axes),8)
            right=[a for a in fig.axes if 'Фарадея' in a.get_ylabel()]
            self.assertEqual(len(right),4)
            for axis in right:
                line=axis.lines[0];np.testing.assert_array_equal(line.get_xdata(),[-2,3]);np.testing.assert_array_equal(line.get_ydata(),[-20,30])
                self.assertEqual(line.get_marker(),'d');self.assertEqual(line.get_linestyle(),'-')
