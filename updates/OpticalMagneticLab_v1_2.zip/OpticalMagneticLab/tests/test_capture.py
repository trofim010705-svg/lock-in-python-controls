from pathlib import Path
import tempfile,unittest
from unittest.mock import patch
import numpy as np
from capture import CaptureData,DAQLost
from models import Calibration,GAIN


class CaptureTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name);self.s=CaptureData()
        self.s.configure(dict(sample_rate_Hz=1000,origin_monotonic_s=0,serial='OLD'))
        self.values=np.vstack((np.linspace(.03,.05,10),np.linspace(.04,.06,10),np.arange(10)*.001))
    def tearDown(self):
        if self.s.capture is not None:
            try:self.s.finish(.1,timeout=0)
            except Exception:pass
        self.tmp.cleanup()
    def test_identical_window_means_and_streamed_raw_scaled_values(self):
        self.s.append(0,self.values);self.s.begin(.002,.007,Calibration(2,-1),self.path)
        result=self.s.finish(.007,timeout=0)
        self.assertTrue(result['valid']);self.assertEqual(result['samples'],5)
        self.assertAlmostEqual(result['ip_mean_V'],self.values[0,2:7].mean()*GAIN)
        self.assertAlmostEqual(result['im_mean_V'],self.values[1,2:7].mean()*GAIN)
        self.assertAlmostEqual(result['field_mean_mT'],7.)
        raw=np.genfromtxt(self.path/'daq.dat',names=True,delimiter='\t')
        self.assertEqual(len(raw),5)
        np.testing.assert_allclose(raw['Ip_x25p2_V'],raw['AI1_raw_V']*GAIN)
    def test_early_stop_clips_newest_pending_block(self):
        self.s.append(0,self.values);self.s.begin(.01,.1,Calibration(),self.path)
        self.s.append(10,self.values)
        result=self.s.finish(.015,timeout=0)
        self.assertEqual(result['samples'],5)
        self.assertAlmostEqual(result['ip_mean_V'],self.values[0,:5].mean()*GAIN)
    def test_reconnect_does_not_mix_generations(self):
        self.s.append(0,self.values);self.s.begin(.01,.05,Calibration(),self.path);self.s.append(10,self.values)
        self.s.fail('USB lost');self.s.configure(dict(sample_rate_Hz=1000,origin_monotonic_s=0,serial='NEW'))
        self.s.append(0,np.ones((3,100))*100)
        result=self.s.finish(.02,timeout=0)
        self.assertFalse(result['valid']);self.assertEqual(result['ni']['serial'],'OLD')
        self.assertLess(result['ip_mean_V'],2.)
    def test_stream_error_is_fatal_not_endless_reconnect(self):
        self.s.append(0,self.values);self.s.begin(.01,.1,Calibration(),self.path);self.s.append(10,self.values)
        with patch('capture.np.savetxt',side_effect=OSError('disk full')):
            with self.assertRaises(OSError):self.s.append(20,self.values)
        with self.assertRaises(OSError):self.s.ensure_online()
        result=self.s.finish(.02,timeout=0)
        self.assertTrue(result['fatal_error']);self.assertFalse(result['valid'])
    def test_live_values_are_scaled_once_and_channels_are_separate(self):
        self.s.append(0,self.values);v=self.s.live(1,Calibration())
        self.assertAlmostEqual(v['ip_V'],self.values[0].mean()*GAIN)
        self.assertAlmostEqual(v['im_V'],self.values[1].mean()*GAIN)
        self.assertAlmostEqual(v['field_mT'],4.5)
    def test_dark_voltage_is_subtracted_after_gain_in_live_running_mean_and_saved_data(self):
        c=Calibration(2,-1,.2,-.05)
        self.s.append(0,self.values)
        live=self.s.live(1,c)
        self.assertAlmostEqual(live['ip_V'],self.values[0].mean()*GAIN-.2)
        self.assertAlmostEqual(live['im_V'],self.values[1].mean()*GAIN+.05)
        self.s.begin(.002,.007,c,self.path)
        running=self.s.running_means();d=self.s.finish(.007,timeout=0)
        expected=self.values[:2,2:7].mean(axis=1)*GAIN-np.array([.2,-.05])
        np.testing.assert_allclose(running,expected)
        np.testing.assert_allclose([d['ip_mean_V'],d['im_mean_V']],expected)
        self.assertEqual(d['dark_ip_V'],.2);self.assertEqual(d['dark_im_V'],-.05)
        raw=np.genfromtxt(self.path/'daq.dat',names=True,delimiter='\t')
        np.testing.assert_allclose(raw['Ip_corrected_V'],raw['AI1_raw_V']*GAIN-.2)
        np.testing.assert_allclose(raw['Im_corrected_V'],raw['AI0_raw_V']*GAIN+.05)
        np.testing.assert_allclose(raw['Ip_x25p2_V'],raw['AI1_raw_V']*GAIN)
