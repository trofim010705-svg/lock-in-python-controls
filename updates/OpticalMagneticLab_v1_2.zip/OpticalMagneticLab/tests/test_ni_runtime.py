import ctypes
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace as NS
import unittest
from unittest.mock import Mock,patch

from ni_native import Config,NativeProcess,prepare_driver
from ni_diagnostics import empty_task_check
from models import DemoPlant


class NIRuntimeTests(unittest.TestCase):
    def test_missing_worker_stops_before_creating_driver_process(self):
        with tempfile.TemporaryDirectory() as td:
            with patch.object(sys,'frozen',True,create=True),patch.object(sys,'executable',str(Path(td)/'OpticalMagneticLab.exe')):
                source=NativeProcess(Config(),'ao')
                with self.assertRaisesRegex(RuntimeError,'NIWorker'):source.open()
                self.assertIsNone(source.process)

    def test_spawned_driver_process_does_not_import_qt(self):
        import PyQt5.QtCore  # GUI is loaded in the parent, but not in the child.
        source=NativeProcess(Config(demo=True,plant=DemoPlant()),'ao')
        try:
            info=source.open()
            self.assertFalse(info['runtime']['qt_loaded'])
            self.assertIsNone(source.command('health')['last_command_V'])
        finally:source.close()

    def test_classic_api_is_default_and_loaded_from_system_directory(self):
        with tempfile.TemporaryDirectory() as td:
            (Path(td)/'nicaiu.dll').touch()
            with patch.dict(os.environ,{},clear=True),patch.object(sys,'platform','win32'),\
                 patch('ni_native._system_directory',return_value=Path(td)),\
                 patch.object(ctypes,'WinDLL',create=True) as load:
                prepare_driver()
                self.assertEqual(os.environ['NIDAQMX_C_LIBRARY'],'nicaiu')
                load.assert_called_once_with(str(Path(td)/'nicaiu.dll'))

    def test_explicit_utf8_selection_is_respected_for_diagnosis(self):
        with tempfile.TemporaryDirectory() as td:
            (Path(td)/'nicai_utf8.dll').touch()
            with patch.dict(os.environ,{'NIDAQMX_C_LIBRARY':'nicai_utf8'}),patch.object(sys,'platform','win32'),\
                 patch('ni_native._system_directory',return_value=Path(td)),\
                 patch.object(ctypes,'WinDLL',create=True) as load:
                prepare_driver()
                load.assert_called_once_with(str(Path(td)/'nicai_utf8.dll'))

    def test_frozen_search_policy_changes_only_inside_driver_preparation(self):
        kernel=NS(SetDllDirectoryW=Mock(return_value=1))
        with tempfile.TemporaryDirectory() as td:
            (Path(td)/'nicaiu.dll').touch()
            with patch.dict(os.environ,{'NIDAQMX_C_LIBRARY':'nicaiu'}),patch.object(sys,'platform','win32'),\
                 patch.object(sys,'frozen',True,create=True),patch('ni_native._system_directory',return_value=Path(td)),\
                 patch.object(ctypes,'WinDLL',create=True,side_effect=[kernel,object()]):
                prepare_driver()
                kernel.SetDllDirectoryW.assert_called_once_with(None)

    def test_diagnostic_task_is_empty_and_closed_without_channels_or_writes(self):
        events=[]
        class Task:
            def __init__(self,*args,**kwargs):events.append(('create',args,kwargs))
            def close(self):events.append(('close',))
        self.assertTrue(empty_task_check(NS(Task=Task)))
        self.assertEqual(events,[('create',(),{}),('close',)])

    def test_create_task_failure_does_not_fall_back_to_a_zero_or_write(self):
        events=[]
        def fail():events.append('create');raise OSError('access violation reading 0x0000')
        with self.assertRaises(OSError):empty_task_check(NS(Task=fail))
        self.assertEqual(events,['create'])
