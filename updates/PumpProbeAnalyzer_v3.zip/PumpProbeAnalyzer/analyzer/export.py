"""Standalone data/report and publication image export; no Qt in this module."""
from dataclasses import asdict
import json
import os
import tempfile
from pathlib import Path
import numpy as np
from .core import evaluate, names
from .presentation import PlotStyle, parameter_label, angle_unit


def export_analysis(base, measurement, prepared, result, title, band, initial, style=None):
    style = (style or PlotStyle(fit_label=parameter_label(result))).validate()
    base = Path(base)
    # Keep every export; never overwrite measurement or previous analyses.
    folder = base
    for i in range(10000):
        folder = base if i == 0 else base.with_name(base.name+f'_{i:03d}')
        try:
            folder.mkdir(parents=True, exist_ok=False)
            break
        except FileExistsError:
            continue
    else:
        raise OSError('Не удалось выбрать папку экспорта')
    p = prepared
    prediction = np.full(len(p.time), np.nan)
    if result:
        prediction[p.fit_mask] = evaluate(p.time[p.fit_mask], result.parameters, result.reference_s)
    np.savetxt(folder/'time_domain.tsv', np.c_[p.time, p.raw_rad, p.background, p.y, prediction, p.y-prediction],
               delimiter='\t', header='Time_s\tX1_rad\tBackground_rad\tProcessed_rad\tFit_rad\tResidual_rad', comments='')
    np.savetxt(folder/'spectrum.tsv', np.c_[p.frequencies, p.spectrum], delimiter='\t',
               header='Frequency_Hz\tAmplitude_rad', comments='')
    report = dict(title=title, data_file=measurement.data_path, notes_file=measurement.notes_path,
                  input_signal_unit=measurement.signal_unit, settings=asdict(p.settings),
                  fft_band_hz=band, fft_resolution_hz=p.resolution_hz, warnings=p.warnings,
                  calibration=dict(bal_mv=p.settings.bal_mv, sig_mv=p.settings.sig_mv,
                      coefficient_rad_per_V=p.settings.rad_per_unit,
                      formula='theta_rad = sqrt(2)*X1_V/(4*sqrt(Sig_V)*sqrt(Sig_V-Bal_V))',
                      bal_V=p.settings.bal_mv*1e-3, sig_V=p.settings.sig_mv*1e-3),
                  model='sum A_i exp(-u/tau_i) sin(2 pi f_i u + phi_i) + C; u=t-t_ref',
                  initial_parameters_si=list(map(float, initial)), presentation=asdict(style))
    if result:
        report['fit'] = dict(reference_s=result.reference_s, rmse_rad=result.rmse_rad,
                             r_squared=result.r_squared, warnings=result.warnings,
                             evaluations=result.evaluations, jacobian_condition=result.condition,
                             parameters=[dict(name=n, unit=u, value=float(v), stderr=float(e))
                                         for (n,u), v,e in zip(names((len(result.parameters)-1)//4), result.parameters, result.errors)])
    # JSON null represents unavailable uncertainty; emit standards-compliant JSON.
    def clean(x):
        if isinstance(x, dict): return {k:clean(v) for k,v in x.items()}
        if isinstance(x, (list, tuple)): return [clean(v) for v in x]
        if isinstance(x, (float, np.floating)) and not np.isfinite(x): return None
        return x
    (folder/'analysis.json').write_text(json.dumps(clean(report), ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    (folder/'measurement_parameters.txt').write_text(measurement.notes, encoding='utf-8')
    save_picture(folder/'analysis.png', p, result, title, band, style)
    save_picture(folder/'analysis.pdf', p, result, title, band, style)
    return str(folder)


def make_figure(prepared, result, title, band, style=None):
    """Build both plots with identical labels and applied Y limits."""
    style = (style or PlotStyle(fit_label=parameter_label(result))).validate()
    p = prepared
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    fig = Figure(figsize=(11, 9), constrained_layout=True); FigureCanvasAgg(fig)
    top, bottom = fig.subplots(2, 1)
    time_factor,time_unit=angle_unit(style.time_ylim if style.time_ylim is not None else p.y)
    fft_factor,fft_unit=angle_unit(style.fft_ylim if style.fft_ylim is not None else p.spectrum)
    top.plot(p.time, p.y/time_factor, '.', ms=3, color='#147c9c', label=style.experiment_label or '_nolegend_')
    if result:
        t = np.linspace(p.time[p.fit_mask][0], p.time[p.fit_mask][-1], 3000)
        top.plot(t, evaluate(t, result.parameters, result.reference_s)/time_factor, color='#d56e36',
                 label=style.fit_label or '_nolegend_')
    top.axvline(0, color='#7a8e9b', lw=.7, ls='--')
    top.set(title=title, xlabel='Delay (s)', ylabel=f'Rotation ({time_unit})')
    if style.show_legend and top.get_legend_handles_labels()[0]: top.legend(fontsize=7)
    bottom.plot(p.frequencies, p.spectrum/fft_factor, color='#6553a7')
    bottom.axvspan(*band, color='#1aa5a2', alpha=.15)
    from .core import peak_indices
    try:
        indices = peak_indices(p, *band)[:30]
        bottom.plot(p.frequencies[indices], p.spectrum[indices]/fft_factor, 'o', ms=4, color='#dc713c')
    except ValueError:
        pass
    bottom.set(xlabel='Frequency (Hz)', ylabel=f'FFT amplitude ({fft_unit})', title='FFT / selected search band')
    bottom.set_xlim(max(0, band[0]-(band[1]-band[0])*.5), min(p.nyquist_hz, band[1]+(band[1]-band[0])*.5))
    for ax,limits,factor in ((top,style.time_ylim,time_factor),(bottom,style.fft_ylim,fft_factor)):
        ax.grid(alpha=.2); ax.ticklabel_format(style='sci', axis='x', scilimits=(-3,3))
        if limits is not None: ax.set_ylim(np.asarray(limits)/factor)
    return fig


def save_picture(path, prepared, result, title, band, style=None):
    """Save exactly the selected filename; failed writes leave an existing file intact."""
    path = Path(path)
    extension = path.suffix.lower().lstrip('.')
    if extension not in ('png','pdf','svg'):
        raise ValueError('Выберите расширение .png, .pdf или .svg')
    fig = make_figure(prepared, result, title, band, style)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, suffix=path.suffix, delete=False) as handle:
            temporary = Path(handle.name)
        fig.savefig(temporary, format=extension, dpi=300)
        os.replace(temporary,path)
    finally:
        fig.clear()
        if temporary is not None: temporary.unlink(missing_ok=True)
    return str(path)
