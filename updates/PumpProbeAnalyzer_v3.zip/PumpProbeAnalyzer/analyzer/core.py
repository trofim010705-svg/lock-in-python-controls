"""SI conversion, explicit preprocessing, FFT seeds and scaled nonlinear fitting."""
from dataclasses import dataclass, replace
from threading import Event
import numpy as np
from scipy import signal, optimize, fft


@dataclass(frozen=True)
class Settings:
    zero_mm: float = 106.45
    mm_per_unit: float = 1.0
    path_factor: float = 2.0
    c: float = 3e8  # notebook approximation; use 299792458 for exact vacuum c.
    bal_mv: float = None
    sig_mv: float = None
    fit_min_s: float = 1e-11
    fit_max_s: float = 3.5e-9
    background_degree: int = -1  # off, constant, linear, quadratic
    bg_min_s: float = 1e-11
    bg_max_s: float = 3.5e-9
    window: str = 'hann'
    padding: int = 8
    zero_mode: str = 'peak'

    @property
    def rad_per_unit(self):
        return calibration_coefficient(self.bal_mv, self.sig_mv)


def calibration_coefficient(bal_mv, sig_mv):
    """rad/V; Bal and Sig are entered in mV while the file's X1 is in V."""
    if bal_mv is None or sig_mv is None:
        raise ValueError('Введите Bal < 0 и Sig > 0 в милливольтах')
    if not np.isfinite([bal_mv, sig_mv]).all() or bal_mv >= 0 or sig_mv <= 0:
        raise ValueError('Требуется Bal < 0 и Sig > 0; оба значения должны быть конечными')
    bal, sig = bal_mv*1e-3, sig_mv*1e-3
    with np.errstate(over='ignore', divide='ignore', invalid='ignore'):
        coefficient = np.sqrt(2)/(4*np.sqrt(sig)*np.sqrt(sig-bal))
    if not np.isfinite(coefficient) or coefficient <= 0:
        raise ValueError('Bal/Sig приводят к некорректному коэффициенту пересчёта')
    return float(coefficient)


@dataclass
class Prepared:
    time: np.ndarray
    raw_rad: np.ndarray
    y: np.ndarray
    fit_mask: np.ndarray
    frequencies: np.ndarray
    spectrum: np.ndarray
    resolution_hz: float
    nyquist_hz: float
    warnings: list
    settings: Settings
    background: np.ndarray


class Cancelled(Exception):
    pass


def prepare(measurement, cfg):
    if measurement.signal_unit == 'A':
        raise ValueError('Формула Bal/Sig требует X1 в вольтах. Выбранный файл содержит амперы.')
    nums = [cfg.zero_mm, cfg.mm_per_unit, cfg.path_factor, cfg.c, cfg.rad_per_unit,
            cfg.fit_min_s, cfg.fit_max_s, cfg.bg_min_s, cfg.bg_max_s]
    if not np.isfinite(nums).all() or min(cfg.mm_per_unit, cfg.path_factor, cfg.c) <= 0 or cfg.rad_per_unit == 0:
        raise ValueError('Проверьте конечность чисел, масштаб оси, скорость света и калибровку')
    if cfg.fit_min_s >= cfg.fit_max_s:
        raise ValueError('Начало диапазона фита должно быть меньше конца')
    if cfg.padding not in (1, 2, 4, 8, 16, 32, 64, 128, 512):
        raise ValueError('Неподдерживаемый коэффициент zero-padding')
    warnings = list(measurement.warnings)
    if cfg.zero_mode == 'peak':
        # Use the raw, signed X1 maximum before calibration, background or FFT.
        index = int(np.argmax(measurement.x1))
        cfg = replace(cfg, zero_mm=float(measurement.position[index]*cfg.mm_per_unit))
        if cfg.zero_mm in (np.min(measurement.position)*cfg.mm_per_unit,
                           np.max(measurement.position)*cfg.mm_per_unit):
            warnings.append('Максимум X1 находится на краю скана; проверьте выбранный ноль задержки.')
    elif cfg.zero_mode != 'manual':
        raise ValueError('Неизвестный способ определения нуля задержки')
    t = (measurement.position*cfg.mm_per_unit-cfg.zero_mm)*1e-3*cfg.path_factor/cfg.c
    y = measurement.x1*cfg.rad_per_unit
    order = np.argsort(t, kind='stable'); t, y = t[order], y[order]
    unique, starts, counts = np.unique(t, return_index=True, return_counts=True)
    if len(unique) != len(t):
        warnings.append(f'Повторные координаты усреднены: {len(t)-len(unique)}')
        y = np.add.reduceat(y, starts)/counts; t = unique
    if len(t) < 8 or t[-1] <= t[0]:
        raise ValueError('Нужно не менее 8 различных координат')
    raw = y.copy(); background = np.zeros_like(y)
    if cfg.background_degree >= 0:
        m = (t >= cfg.bg_min_s) & (t <= cfg.bg_max_s)
        if m.sum() <= cfg.background_degree:
            raise ValueError('Недостаточно точек в диапазоне оценки фона')
        # Polynomial.fit scales its domain, avoiding ill conditioning of SI seconds.
        poly = np.polynomial.Polynomial.fit(t[m], y[m], cfg.background_degree)
        background = poly(t); y = y-background
    mask = (t >= cfg.fit_min_s) & (t <= cfg.fit_max_s)
    if mask.sum() < 8:
        raise ValueError('В диапазоне фита менее 8 точек. Проверьте ноль задержки и границы.')
    tf, yf = t[mask], y[mask]
    # FFT uses only the same selected time interval as the fit. The fit itself uses
    # original measured coordinates; interpolation is exclusively for FFT.
    dt = np.median(np.diff(tf))
    if (tf[-1]-tf[0])/dt > 1000000:
        raise ValueError('Слишком неоднородная сетка времени для БПФ')
    grid = np.linspace(tf[0], tf[-1], max(8, int(round((tf[-1]-tf[0])/dt))+1))
    dt = grid[1]-grid[0]
    if len(grid) != len(tf) or not np.allclose(np.diff(tf), dt, rtol=1e-3, atol=abs(dt)*1e-6):
        warnings.append('Для БПФ использована линейная интерполяция неравномерной сетки. Фит — по исходным точкам.')
    values = np.interp(grid, tf, yf)
    values -= np.mean(values)
    weights = np.hanning(len(grid)) if cfg.window == 'hann' else np.ones(len(grid))
    if cfg.window not in ('hann', 'boxcar'):
        raise ValueError('Неизвестное окно FFT')
    requested = len(grid)*cfg.padding
    nfft = fft.next_fast_len(requested)
    if nfft > 4194304:
        raise ValueError('FFT слишком велико: уменьшите zero-padding (предел 4 194 304 отсчёта)')
    spectrum = abs(fft.rfft(values*weights, n=nfft))*2/weights.sum()
    spectrum[0] /= 2
    if nfft % 2 == 0:
        spectrum[-1] /= 2
    return Prepared(t, raw, y, mask, fft.rfftfreq(nfft, dt), spectrum,
                    1/(len(grid)*dt), .5/dt, warnings, cfg, background)


def peak_indices(prepared, low, high):
    f, a = prepared.frequencies, prepared.spectrum
    selection = np.flatnonzero((f >= low) & (f <= high) & (f > 0))
    if low >= high or len(selection) == 0:
        raise ValueError('В выбранном диапазоне нет положительных частот FFT')
    local, _ = signal.find_peaks(a)
    local = local[np.isin(local, selection)]
    strongest = selection[np.argmax(a[selection])]
    if a[strongest] <= np.finfo(float).tiny:
        raise ValueError('В выбранном диапазоне нет ненулевого спектрального сигнала')
    indices = np.unique(np.r_[local, strongest])
    return indices[np.argsort(a[indices])[::-1]]


def initial_parameters(p, count, band):
    indices = peak_indices(p, *band)
    frequencies = []
    for i in indices:
        f = p.frequencies[i]
        if all(abs(f-v) >= p.resolution_hz*.7 for v in frequencies):
            frequencies.append(f)
        if len(frequencies) == count:
            break
    while len(frequencies) < count:
        candidate = np.linspace(band[0], band[1], count+2)[len(frequencies)+1]
        frequencies.append(max(candidate, p.resolution_hz*.05))
    t, y = p.time[p.fit_mask], p.y[p.fit_mask]
    ref = t[0]
    amplitude = max(np.ptp(y)/2, np.finfo(float).tiny)/count
    tau = max(np.ptp(t), np.finfo(float).tiny)
    params = []
    for f in frequencies:
        # Phase estimate relative to t_ref: A is the envelope at fit start.
        basis = np.column_stack((np.sin(2*np.pi*f*(t-ref)), np.cos(2*np.pi*f*(t-ref)), np.ones(len(t))))
        coeff = np.linalg.lstsq(basis, y, rcond=None)[0]
        params.extend([amplitude, f, np.arctan2(coeff[1], coeff[0]), tau])
    return np.asarray([*params, np.median(y)])


def names(count):
    result = []
    for i in range(1, count+1):
        result.extend([(f'A{i}', 'rad'), (f'f{i}', 'Hz'), (f'phi{i}', 'rad'), (f'tau{i}', 's')])
    return result+[('C', 'rad')]


def evaluate(time_s, parameters, t_ref):
    u = np.asarray(time_s)-t_ref
    p = np.asarray(parameters)
    y = np.full_like(u, p[-1], dtype=float)
    for i in range((len(p)-1)//4):
        a, f, phase, tau = p[4*i:4*i+4]
        y += a*np.exp(-u/tau)*np.sin(2*np.pi*f*u+phase)
    return y


@dataclass
class FitResult:
    parameters: np.ndarray
    errors: np.ndarray
    covariance: np.ndarray
    reference_s: float
    rmse_rad: float
    r_squared: float
    warnings: list
    evaluations: int
    condition: float


def fit(prepared, p0, band, cancel=None):
    cancel = cancel or Event()
    t, y = prepared.time[prepared.fit_mask], prepared.y[prepared.fit_mask]
    p0 = np.asarray(p0, dtype=float)
    count = (len(p0)-1)//4
    if count < 1 or count > 6 or len(p0) != 4*count+1 or not np.isfinite(p0).all():
        raise ValueError('Некорректные начальные параметры')
    if len(t) <= len(p0):
        raise ValueError('Точек должно быть больше, чем параметров модели')
    lo_f, hi_f = max(0, band[0]), min(band[1], prepared.nyquist_hz)
    if hi_f <= lo_f:
        raise ValueError('Некорректные границы частоты')
    t_ref = t[0]; ts = np.ptp(t); ys = max(np.std(y), np.ptp(y)*.1, 1e-30)
    scales = np.array(([ys, 1/ts, 1, ts]*count)+[ys])
    lower, upper = [], []
    for i in range(count):
        if p0[4*i] < 0 or p0[4*i+3] <= 0 or not lo_f <= p0[4*i+1] <= hi_f:
            raise ValueError('Начальные A ≥ 0, tau > 0, частоты должны лежать в выделенном диапазоне FFT')
        lower.extend([0, lo_f, -np.inf, ts*1e-6])
        upper.extend([np.inf, hi_f, np.inf, ts*1e6])
    lower.append(-np.inf); upper.append(np.inf)
    if np.any(p0 < lower) or np.any(p0 > upper):
        raise ValueError('Начальная tau выходит за границы [1e-6, 1e6] длительности фита')
    # Dimensionless optimization avoids losing small radian amplitudes or ns lifetimes.
    def residual(q):
        if cancel.is_set():
            raise Cancelled('Фитирование отменено')
        return (evaluate(t, q*scales, t_ref)-y)/ys
    result = optimize.least_squares(residual, p0/scales, bounds=(np.array(lower)/scales, np.array(upper)/scales),
                                    x_scale='jac', max_nfev=12000, ftol=1e-10, xtol=1e-10, gtol=1e-10)
    if not result.success:
        raise ValueError('Оптимизация не сошлась: '+result.message)
    parameters = result.x*scales
    # SVD of J itself avoids squaring its condition number via J.T @ J.
    _, singular, vh = np.linalg.svd(result.jac, full_matrices=False)
    threshold = np.finfo(float).eps*max(result.jac.shape)*singular[0]
    valid = singular > threshold
    rank = np.count_nonzero(valid)
    covariance = (vh[valid].T/singular[valid]**2)@vh[valid]
    covariance *= np.sum(result.fun**2)/(len(y)-len(p0))
    covariance *= np.outer(scales, scales)
    errors = np.sqrt(np.maximum(np.diag(covariance), 0))
    warnings = []
    condition = float(np.linalg.cond(result.jac))
    if rank < len(p0) or condition > 1e8:
        errors[:] = np.nan
        warnings.append('Параметры плохо определены: ранг/обусловленность Якобиана. Ошибки не считаются достоверными.')
    if np.any(result.active_mask):
        warnings.append('Оптимум упирается в границу параметров: проверьте диапазон FFT и модель.')
    for i in range(count):
        if parameters[4*i+3] > 100*ts:
            warnings.append(f'tau{i+1} намного больше окна наблюдения; затухание может быть не определено.')
    prediction = evaluate(t, parameters, t_ref)
    sse = np.sum((prediction-y)**2); sst = np.sum((y-y.mean())**2)
    return FitResult(parameters, errors, covariance, t_ref, float(np.sqrt(sse/len(y))),
                     float(1-sse/sst) if sst > 0 else float('nan'), warnings, result.nfev, condition)
