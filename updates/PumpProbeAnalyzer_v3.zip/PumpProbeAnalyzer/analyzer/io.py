"""Read only position and X1; other demodulator columns are deliberately ignored."""
from dataclasses import dataclass
from pathlib import Path
import re
import numpy as np


@dataclass
class Measurement:
    position: np.ndarray
    x1: np.ndarray
    data_path: str
    notes_path: str
    notes: str
    signal_unit: str
    warnings: list


def read_text(path):
    raw = Path(path).read_bytes()
    for encoding in ('utf-8-sig', 'utf-16', 'cp1251'):
        try:
            return raw.decode(encoding)
        except UnicodeError:
            continue
    raise ValueError('Не удалось определить кодировку: '+str(path))


def associated_notes(path):
    path = Path(path)
    for candidate in (path.with_name(path.stem+'.comments.txt'), path.with_suffix('.txt')):
        if candidate != path and candidate.is_file():
            return candidate
    return None


def load_pair(data_path, notes_path):
    text, notes = read_text(data_path), read_text(notes_path)
    rows, warnings, started = [], [], False
    for line_number, line in enumerate(text.splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue
        # Tabs/semicolon support decimal commas; whitespace supports legacy files.
        parts = re.split(r'\t+|;', stripped) if '\t' in stripped or ';' in stripped else stripped.split()
        try:
            pair = [float(x.strip().replace(',', '.')) for x in parts[:2]]
            if len(pair) != 2:
                raise ValueError()
        except ValueError:
            if started:
                raise ValueError(f'Строка {line_number}: повреждена координата или X1')
            if len(rows) == 0 and line_number > 100:
                raise ValueError('Численные данные не найдены в первых 100 строках')
            continue  # Origin Long Names/Units or other initial text headers.
        started = True
        rows.append(pair)
        if len(rows) > 1000000:
            raise ValueError('Поддерживается не более 1 000 000 точек')
    if len(rows) < 8:
        raise ValueError('Для анализа нужно не менее 8 численных строк')
    data = np.asarray(rows)
    finite = np.isfinite(data).all(axis=1)
    if not finite.all():
        warnings.append(f'Исключено нечисловых/бесконечных строк: {np.count_nonzero(~finite)}. Координаты не угадывались.')
        data = data[finite]
    if len(data) < 8:
        raise ValueError('Осталось менее 8 конечных точек')
    unit = 'неизвестна'
    match = re.search(r'(?:Signal unit:\s*|"unit"\s*:\s*")([VA])', text+'\n'+notes)
    if match:
        unit = match.group(1)
    else:
        lines = text.splitlines()
        for i, line in enumerate(lines[:-1]):
            if 'Position' in line and 'X1' in line:
                units = lines[i+1].split()
                if len(units) >= 2 and units[1] in ('V', 'A'):
                    unit = units[1]
    return Measurement(data[:, 0], data[:, 1], str(data_path), str(notes_path), notes, unit, warnings)
