from dataclasses import replace
from pathlib import Path
import math,tempfile,time,unittest
from unittest.mock import patch
from experiment import ExperimentRunner
from models import Experiment,Calibration
from services import LinkLost


class AO:
    def __init__(self):self.value=2.;self.calls=[]
    def call(self,job,data=None,*args,**kwargs):
        self.calls.append((job,data))
        if job=='write':self.value=data['voltage']
        return dict(last_command_V=self.value,confirmed_command=True,readback=False)


class USB:
    def __init__(self):self.on_read=None
    def call(self,job,*args,**kwargs):
        if job in ('dual_prepare','dual_snapshot','dual_reconnect'):return dict(signal_unit='V',sections={},reference_mode=1,harmonics=[1,2])
        if job=='dual_health':return {}
        if self.on_read:self.on_read()
        t=time.perf_counter()
        return dict(start=t,end=t,values=[3e-6,4e-6,5e-6,53.13,1e-6,0,1e-6,0],status=1,overload=0)


class Store:
    def __init__(self,ao):self.ao=ao
    def ensure_online(self):pass
    def wait_online(self,cancel):return {}
    def begin(self,start,end,calibration,folder):self.start=start;self.end=end;Path(folder).mkdir(parents=True,exist_ok=True)
    def finish(self,end):
        return dict(valid=True,samples=100,ip_mean_V=1.1,im_mean_V=1.,field_mean_mT=self.ao.value*8,
                    start_monotonic_s=self.start,end_monotonic_s=end,error='')


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.ao=AO();self.usb=USB();self.store=Store(self.ao)
        self.p=Experiment(mode='hysteresis',start_V=3,stop_V=5,intervals=2,acquisition_s=.1,period_ms=20,settle_s=0,folder=self.tmp.name)
        self.plots=patch('report.save_figures');self.plots.start()
    def tearDown(self):self.plots.stop();self.tmp.cleanup()
    def run_scan(self,p=None,hook=None):
        runner=ExperimentRunner(p or self.p,Calibration(),self.usb,self.ao,self.store,demo=True)
        runner.retry_delay=.001;out=[];runner.outcome.connect(out.append)
        if hook:hook(runner)
        runner.run();return runner,out[-1]
    def writes(self):return [v['voltage'] for job,v in self.ao.calls if job=='write']
    def test_hysteresis_turnaround_does_not_zero_and_returns_to_start(self):
        runner,out=self.run_scan()
        self.assertEqual(out['reason'],'complete');self.assertEqual(self.writes(),[3,4,5,4,3])
        self.assertEqual(self.ao.value,3);self.assertEqual(len(out['points']),5)
        self.assertAlmostEqual(sum(p['statistics']['faraday_centered_arcsec'] for p in out['points']),0,places=8)
        self.assertEqual(len(list(Path(out['folder']).glob('point_*/signal.dat'))),5)
    def test_negative_to_positive_is_direct_bipolar_voltage_plan(self):
        runner,out=self.run_scan(replace(self.p,start_V=-1,stop_V=1))
        self.assertEqual(self.writes(),[-1,0,1,0,-1]);self.assertEqual(out['reason'],'complete')
    def test_fixed_field_has_no_ao_write(self):
        runner,out=self.run_scan(replace(self.p,mode='single'))
        self.assertEqual(self.writes(),[]);self.assertEqual(self.ao.value,2.)
        self.assertEqual(out['points'][0]['target_V'],None)
        self.assertEqual(out['points'][0]['statistics']['faraday_centered_arcsec'],out['points'][0]['statistics']['faraday_raw_arcsec'])
    def test_explicit_zero_occurs_only_after_complete_loop(self):
        runner,out=self.run_scan(replace(self.p,zero_after=True))
        self.assertEqual(self.writes(),[3,4,5,4,3,0]);self.assertEqual(out['finish_action'],'zero_command_confirmed')
    def test_stop_on_return_ignores_finish_zero(self):
        def hook(runner):
            self.usb.on_read=lambda:runner.stop() if len(runner.points)==3 else None
        runner,out=self.run_scan(replace(self.p,zero_after=True),hook)
        self.assertEqual(out['reason'],'stopped');self.assertEqual(self.writes(),[3,4,5,4])
        self.assertEqual(out['points'][-1]['result'],'stopped')
    def test_disk_error_retains_raw_rows_for_recovery_without_zero(self):
        with patch('experiment.save_point',side_effect=OSError('disk full')):
            runner,out=self.run_scan(replace(self.p,zero_after=True))
        self.assertEqual(out['reason'],'error');self.assertTrue(runner.unsaved[0]);self.assertEqual(self.writes(),[3])
    def test_loss_on_return_repeats_only_that_point(self):
        original=self.usb.call;lost=False
        def call(job,*args,**kwargs):
            nonlocal lost
            if job=='dual_read' and self.ao.value==4 and len([x for x in self.writes() if x==5]) and not lost:
                lost=True;raise LinkLost('lockin','USB lost')
            return original(job,*args,**kwargs)
        self.usb.call=call;runner,out=self.run_scan()
        self.assertEqual(out['reason'],'complete');self.assertEqual(self.writes(),[3,4,5,4,4,3])
        self.assertEqual([p['attempt'] for p in out['points']],[1,1,1,2,1])
        self.assertEqual(len(list(Path(out['folder']).glob('incomplete/point_*/signal.dat'))),1)
    def test_export_error_with_zero_option_still_holds_ao(self):
        with patch('report.save_figures',side_effect=OSError('PNG failed')):
            runner,out=self.run_scan(replace(self.p,zero_after=True))
        self.assertEqual(out['reason'],'error');self.assertEqual(self.writes(),[3,4,5,4,3])
    def test_stop_during_export_prevents_pending_finish_zero(self):
        def hook(runner):
            self.hook=patch('report.save_figures',side_effect=lambda *a,**k:runner.stop());self.hook.start()
        try:runner,out=self.run_scan(replace(self.p,zero_after=True),hook)
        finally:self.hook.stop()
        self.assertEqual(out['reason'],'stopped');self.assertEqual(self.writes(),[3,4,5,4,3])
    def test_ao_link_loss_after_capture_replays_target_without_zero(self):
        original=self.ao.call;count=0
        def call(job,*a,**k):
            nonlocal count
            if job=='health':
                count+=1
                if count==2:raise LinkLost('ao','native output process lost')
            return original(job,*a,**k)
        self.ao.call=call;runner,out=self.run_scan()
        self.assertEqual(out['reason'],'complete');self.assertEqual(self.writes(),[3,3,4,5,4,3])
        self.assertEqual([p['attempt'] for p in out['points']],[2,1,1,1,1])
        self.assertTrue(any(e['device']=='ao' and e['status']=='restored' for e in out['metadata']['recovery_events']))
    def test_ni_gap_excludes_failed_attempt_and_repeats_full_point(self):
        original=self.store.finish;first=True
        def finish(end):
            nonlocal first
            value=original(end)
            if first:first=False;value.update(valid=False,error='NI USB gap')
            return value
        self.store.finish=finish;runner,out=self.run_scan()
        self.assertEqual(out['reason'],'complete');self.assertEqual(self.writes(),[3,3,4,5,4,3])
        self.assertEqual(len(out['points']),5);self.assertEqual(len(out['metadata']['incomplete_attempts']),1)
    def test_changed_lockin_settings_do_not_silently_mix_data(self):
        original=self.usb.call
        def hook(runner):
            def call(job,*a,**k):
                if job=='dual_read':raise LinkLost('lockin','USB lost')
                if job=='dual_reconnect':
                    runner.stop();return dict(sections={'Input':{'values':{'input':3}}},signal_unit='V')
                return original(job,*a,**k)
            self.usb.call=call
        runner,out=self.run_scan(hook=hook)
        self.assertEqual(out['reason'],'stopped');self.assertEqual(out['points'],[]);self.assertNotIn(0,self.writes())
