"""Serial ownership of Lock-in USB and the separate analog-output process."""
import math
import threading
import time
import traceback
import re
from PyQt5.QtCore import QObject,Qt,pyqtSignal,pyqtSlot
from gui_app import Worker,Instrument,USB7230,DemoTransport
from daq import NativeProcess
from models import phase_deg


class LinkLost(RuntimeError):
    def __init__(self,device,detail):self.device=device;self.detail=str(detail);super().__init__(f'{device}: {detail}')


class Ticket:
    def __init__(self,cancel=None):self.cancel=cancel;self.event=threading.Event();self.value=None;self.error=None
    def finish(self,value=None,error=None):self.value=value;self.error=error;self.event.set()


class Port(QObject):
    request=pyqtSignal(str,object)
    def __init__(self,worker):super().__init__();self.request.connect(worker.execute,Qt.QueuedConnection)
    def call(self,job,data=None,cancel=None,timeout=60):
        ticket=Ticket(cancel);self.request.emit(job,{'ticket':ticket,'data':data or {}})
        deadline=time.perf_counter()+timeout
        while not ticket.event.wait(.025):
            if time.perf_counter()>deadline:raise TimeoutError(f'Нет ответа операции {job}; состояние не подтверждено.')
        if ticket.error:raise ticket.error
        return ticket.value


class DualDemoTransport(DemoTransport):
    def __init__(self,plant):super().__init__();self.plant=plant;self.writes=[]
    def exchange(self,command):
        words=command.upper().split();name=words[0]
        if len(words)>1:self.writes.append(command)
        if len(words)==1 and name in ('FRQ1.','FRQ2.'):
            return str(float(self.data['OF.'])*int(self.data['REFN'+name[3]])),1,0
        if len(words)==1 and re.fullmatch(r'(X|Y|MAG|PHA)[12]\.',name):
            n=int(name[-2]);v=self.plant.get();t=time.perf_counter()
            amplitude=(12e-6 if n==1 else 5e-6)*(1+.3*math.sin(v*1.2+n*.3))
            phase=math.radians((155 if n==1 else 230)+(24 if n==1 else 15)*v)
            x=amplitude*math.cos(phase)+.1e-6*math.sin(t*71+n)
            y=amplitude*math.sin(phase)+.1e-6*math.cos(t*47+n)
            value=x if name.startswith('X') else y if name.startswith('Y') else math.hypot(x,y) if name.startswith('MAG') else phase_deg(x,y)
            return str(value),1,0
        return super().exchange(command)


def validate_mode(inst):
    values={name:int(inst.values(name)[0]) for name in ('REFMODE','IE','REFN1','REFN2','IMODE','VMODE')}
    if values['REFMODE']!=1 or values['IE']!=0 or values['REFN1']!=1 or values['REFN2']!=2:
        raise ValueError('Нужны Dual harmonic, Internal, Harmonic 1=1 и Harmonic 2=2. Подключите Lock-in заново.')
    if values['IMODE']!=0 or values['VMODE'] not in (1,2,3):raise ValueError('Для оптического пересчёта нужен вход Lock-in в вольтах (A, −B или A−B).')
    return values


def configure_dual(inst):
    for cmd,value in (('REFMODE',1),('IE',0),('REFN1',1),('REFN2',2),('IMODE',0)):
        if int(inst.values(cmd)[0])!=value:inst.query(f'{cmd} {value}')
    if int(inst.values('VMODE')[0])==0:inst.query('VMODE 1')
    inst.mode=1
    return validate_mode(inst)


def snapshot(inst,cancel=None):
    validate_mode(inst)
    sections={}
    for title in inst.sections:
        if cancel and cancel.is_set():raise InterruptedError('Остановлено при чтении Lock-in.')
        sections[title]=inst.read_section(title)
    oscillator=float(inst.values('OF.')[0])
    return dict(firmware=inst.query('VER'),reference_mode=1,source='Internal',harmonics=[1,2],
                input_mode=0,signal_unit='V',sections=sections,
                frequency1_Hz=oscillator,frequency2_Hz=2*oscillator,
                reported_reference1_Hz=float(inst.values('FRQ1.')[0]),reported_reference2_Hz=float(inst.values('FRQ2.')[0]))


def fingerprint(s):
    sections={}
    for name in ('Input','Demodulator','Output filters / Noise','Reference / Output 1','Reference / Output 2','Oscillator output'):
        v=s.get('sections',{}).get(name,{}).get('values',{})
        sections[name]={k:val for k,val in v.items() if k not in ('frq1','frq2')}
    return sections


class DualLockinWorker(Worker):
    plant=None
    link_state=pyqtSignal(bool,str)
    def open_instrument(self,configure=True):
        demo,serial,timeout,sections,maximum=self.args
        transport=DualDemoTransport(self.plant) if demo else USB7230(serial,timeout)
        transport.open();inst=Instrument(transport,sections,maximum)
        try:
            if configure:configure_dual(inst)
            else:validate_mode(inst)
            self.instrument=inst
        except Exception:transport.close();raise
    @pyqtSlot(str,object)
    def execute(self,job,payload):
        if job=='open':
            try:
                self.open_instrument();self.result.emit(job,{'version':self.instrument.query('VER')+' · Dual harmonic 1f/2f, Internal'})
                self.link_state.emit(True,'Dual harmonic 1f/2f · Internal')
            except Exception as exc:
                self.instrument=None;self.failed.emit(job,str(exc),True);self.link_state.emit(False,str(exc))
            return
        if job not in ('dual_prepare','dual_snapshot','dual_read','dual_reconnect','dual_health'):
            return super().execute(job,payload)
        ticket=payload['ticket']
        try:
            if ticket.cancel and ticket.cancel.is_set():raise InterruptedError('Остановлено пользователем.')
            if job=='dual_reconnect':
                if self.instrument is None:self.open_instrument(configure=False)
                value=snapshot(self.instrument,ticket.cancel);self.link_state.emit(True,'Связь Lock-in восстановлена.')
            else:
                if self.instrument is None:raise LinkLost('lockin','USB не подключён.')
                inst=self.instrument
                if job=='dual_prepare':configure_dual(inst);value=snapshot(inst,ticket.cancel)
                elif job=='dual_snapshot':value=snapshot(inst,ticket.cancel)
                elif job=='dual_health':value=validate_mode(inst)
                else:
                    start=time.perf_counter();rows=[];status=overload=0
                    for ch in (1,2):
                        x=float(inst.values(f'X{ch}.')[0]);status|=inst.status;overload|=inst.overload
                        y=float(inst.values(f'Y{ch}.')[0]);status|=inst.status;overload|=inst.overload
                        if not math.isfinite(x) or not math.isfinite(y):raise ValueError('Lock-in вернул NaN/Inf.')
                        rows.extend((x,y,math.hypot(x,y),phase_deg(x,y)))
                    value=dict(start=start,end=time.perf_counter(),values=rows,status=status,overload=overload)
            ticket.finish(value)
        except Exception as exc:
            transport_failure=(isinstance(exc,(OSError,LinkLost)) or type(exc).__name__ in ('VisaIOError','ProtocolError'))
            if transport_failure:
                if self.instrument is not None:
                    try:self.instrument.transport.close()
                    except Exception:pass
                self.instrument=None;self.link_state.emit(False,str(exc));exc=LinkLost('lockin',str(exc))
            ticket.finish(error=exc)


class AOWorker(QObject):
    state=pyqtSignal(object)
    done=pyqtSignal(str,bool,str)
    stopped=pyqtSignal()
    def __init__(self):
        super().__init__();self.source=None;self.config=None;self.serial=None;self.last=None;self.metadata={}
    @pyqtSlot(str,object)
    def execute(self,job,payload):
        ticket=payload.get('ticket');data=payload.get('data',payload)
        try:
            if ticket and ticket.cancel and ticket.cancel.is_set():raise InterruptedError('Команда AO0 отменена до отправки.')
            if job in ('open','reconnect'):
                if job=='open':self.config=data['config']
                if self.config is None:raise ValueError('Сначала подключите NI.')
                if self.source:self.source.close()
                self.source=NativeProcess(self.config,'ao');info=self.source.open()
                if job=='reconnect' and self.serial and self.serial!=info['serial']:raise RuntimeError('Подключена другая плата NI; AO0 не изменён.')
                if job=='open' and self.serial and self.serial!=info['serial']:self.last=None
                self.serial=info['serial'];self.metadata=info
                result=dict(info,connected=True,last_command_V=self.last,confirmed_command=False,readback=False)
            elif job=='close':
                if self.source:self.source.close()
                self.source=None;result=dict(connected=False,last_command_V=self.last,confirmed_command=False,readback=False)
            else:
                if self.source is None:raise LinkLost('ao','AO0 не подключён.')
                if job=='write':result=self.source.command('write',data['voltage']);self.last=result['last_command_V']
                else:
                    result=self.source.command('health')
                    if result.get('last_command_V') is None:result['last_command_V']=self.last
                result.update(connected=True,**self.metadata)
            self.state.emit(result)
            if ticket:ticket.finish(result)
            else:self.done.emit(job,True,'AO0: команда завершена.' if job=='write' else 'AO0: подключение без изменения напряжения.')
        except Exception as exc:
            if not isinstance(exc,(ValueError,InterruptedError)):
                if self.source:self.source.close()
                self.source=None;self.state.emit(dict(connected=False,last_command_V=self.last,confirmed_command=False,readback=False))
                exc=LinkLost('ao',str(exc))
            if ticket:ticket.finish(error=exc)
            else:self.done.emit(job,False,str(exc))
    @pyqtSlot()
    def shutdown(self):
        if self.source:self.source.close()
        self.source=None;self.stopped.emit()
