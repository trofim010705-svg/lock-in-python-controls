"""One continuous analog-voltage sweep, with point-local optical normalization."""
from dataclasses import asdict
from pathlib import Path
import threading,time,math,traceback
from PyQt5.QtCore import QThread,pyqtSignal
from capture import DAQLost
from services import LinkLost,fingerprint
from models import statistics,center_faraday,FORMULAS
from storage import create_folder,save_point,save_summary,metadata,now


class ExperimentRunner(QThread):
    message=pyqtSignal(str)
    log=pyqtSignal(str)
    samples=pyqtSignal(object)
    point_started=pyqtSignal(int,int)
    point_ready=pyqtSignal(object)
    prepared=pyqtSignal(object)
    outcome=pyqtSignal(object)
    def __init__(self,p,calibration,lockin,ao,store,demo=False,parent=None):
        super().__init__(parent);self.p=p;self.calibration=calibration;self.lockin=lockin;self.ao=ao;self.store=store;self.demo=demo
        self.stop_event=threading.Event();self.points=[];self.folder=None;self.unsaved=None;self.retry_delay=2.;self.info={}
    def stop(self):self.stop_event.set()
    def check(self,daq=True):
        if self.stop_event.is_set():raise InterruptedError('Остановлено пользователем.')
        if daq:self.store.ensure_online()
    def recovery(self,failure):
        device='ni' if isinstance(failure,DAQLost) else failure.device
        self.log.emit(f'Потеря связи {device}: {failure}')
        self.info.setdefault('recovery_events',[]).append(dict(time=now(),device=device,status='lost',detail=str(failure)))
        while True:
            self.check(daq=False)
            self.message.emit(f'Ожидание {device}; AO0 не обнуляется. Stop доступен.')
            try:
                if device=='ni':meta=self.store.wait_online(self.stop_event)
                elif device=='ao':meta=self.ao.call('reconnect',cancel=self.stop_event)
                else:
                    meta=self.lockin.call('dual_reconnect',cancel=self.stop_event)
                    if self.info.get('lockin') and fingerprint(meta)!=fingerprint(self.info['lockin']):raise ValueError('Настройки Lock-in изменились. Восстановите исходные настройки.')
                self.info.setdefault('recovery_events',[]).append(dict(time=now(),device=device,status='restored',metadata=meta))
                self.log.emit(f'{device}: связь восстановлена, прерванная точка измеряется заново.')
                return
            except InterruptedError:raise
            except Exception as exc:
                self.log.emit(str(exc))
                if self.stop_event.wait(self.retry_delay):self.check(daq=False)
    def measure(self,index,target,attempt):
        p=self.p;self.check();state={}
        if target is not None:
            self.message.emit(f'Точка {index}/{len(p.targets())}: AO0 = {target:+.5g} V')
            state=self.ao.call('write',dict(voltage=target),self.stop_event)
            if self.stop_event.wait(p.settle_s):self.check(daq=False)
            self.ao.call('health',cancel=self.stop_event)
        self.lockin.call('dual_health',cancel=self.stop_event)
        self.check()
        folder=self.folder/f'point_{index:04d}'
        # Retried partial data have already been moved to incomplete/.
        folder.mkdir(exist_ok=True)
        self.point_started.emit(index,len(p.targets()))
        self.message.emit(f'Точка {index}/{len(p.targets())}: запись {p.acquisition_s:g} s · попытка {attempt}')
        start=time.perf_counter();deadline=start+p.acquisition_s
        self.store.begin(start,deadline,self.calibration,folder)
        rows=[];batch=[];tick=start;last_emit=start;next_health=start+1.;failure=None
        try:
            while time.perf_counter()<deadline:
                self.check()
                if self.stop_event.wait(max(0,min(tick,deadline)-time.perf_counter())):self.check(daq=False)
                if time.perf_counter()>=deadline:break
                if target is not None and time.perf_counter()>=next_health:
                    self.ao.call('health',cancel=self.stop_event);next_health=time.perf_counter()+1.
                value=self.lockin.call('dual_read',cancel=self.stop_event)
                if value['end']<=deadline:
                    row=(value['start']-start,value['end']-start,*value['values'],value['status'],value['overload'])
                    rows.append(row);batch.append(row)
                if time.perf_counter()-last_emit>=.15:
                    self.samples.emit(tuple(batch));batch=[];last_emit=time.perf_counter()
                tick+=p.period_ms/1000
                if tick<time.perf_counter():tick+=math.ceil((time.perf_counter()-tick)/(p.period_ms/1000))*(p.period_ms/1000)
            self.check();self.lockin.call('dual_health',cancel=self.stop_event)
            if target is not None:self.ao.call('health',cancel=self.stop_event)
        except Exception as exc:failure=exc
        if batch:self.samples.emit(tuple(batch))
        daq=self.store.finish(min(deadline,time.perf_counter()))
        if daq.get('fatal_error') and failure is None:failure=OSError(daq['error'])
        if not daq['valid'] and failure is None:failure=DAQLost(daq['error'])
        if not rows and failure is None:failure=RuntimeError('Нет отсчётов Lock-in: увеличьте Acquisition time / уменьшите Delay.')
        lost=isinstance(failure,(LinkLost,DAQLost))
        reason='connection_lost' if lost else 'stopped' if self.stop_event.is_set() else 'error' if failure else 'complete'
        point=dict(index=index,attempt=attempt,target_V=target,ao=state,result=reason,error=str(failure) if failure else '',
            daq=daq,statistics=statistics(rows,daq),lockin=self.info['lockin'],parameters=asdict(p),**p.context(index))
        if lost:
            dest=self.folder/'incomplete'/f'point_{index:04d}_attempt_{attempt:04d}'
            dest.parent.mkdir(exist_ok=True);folder.rename(dest);folder=dest
        point['folder']=str(folder)
        self.unsaved=(rows,point,folder);save_point(folder,rows,point);self.unsaved=None
        if not lost:self.points.append(point);self.point_ready.emit(point)
        else:self.info.setdefault('incomplete_attempts',[]).append(dict(index=index,attempt=attempt,folder=str(folder)))
        save_summary(self.folder,self.points,dict(self.info,result='running'))
        if failure:raise failure
    def run(self):
        p=self.p;reason='complete';error='';finish='hold_unverified'
        self.info=dict(application='Optical Magnetic Lab 1.0',demo=self.demo,started=now(),parameters=asdict(p),calibration=asdict(self.calibration),
            formulas=FORMULAS,ao_policy='No writes at connect/reconnect/Stop/errors/shutdown. Only explicit manual command, scan target, or selected successful-finish zero.',
            timing='AI1, AI0, AI3 share an NI sample clock; multiplexed inputs. Lock-in X1/Y1/X2/Y2 are sequential USB queries. Software QPC anchor, no common hardware trigger.')
        try:
            p.validate();self.calibration.validate();self.check()
            self.folder=create_folder(p.folder,p.name)
            save_summary(self.folder,[],dict(self.info,result='preparing'))
            while True:
                try:self.info['lockin']=self.lockin.call('dual_prepare',cancel=self.stop_event);break
                except LinkLost as exc:self.recovery(exc)
            self.prepared.emit(self.info['lockin'])
            for index,target in enumerate(p.targets(),1):
                attempt=1
                while True:
                    try:self.measure(index,target,attempt);break
                    except (LinkLost,DAQLost) as exc:self.recovery(exc);attempt+=1
        except InterruptedError as exc:reason='stopped';error=str(exc)
        except Exception as exc:
            reason='error';error=f'{type(exc).__name__}: {exc}';self.log.emit(traceback.format_exc())
        finally:
            if reason=='complete' and self.stop_event.is_set():reason='stopped'
            # Read only until all data and plots have been saved successfully.
            try:self.info['ao_final']=self.ao.call('health',timeout=15);finish='last_command_held_no_readback'
            except Exception as exc:self.info['ao_final_error']=str(exc)
            offset=center_faraday(self.points,p.mode=='hysteresis')
            self.info.update(finished=now(),result=reason,error=error,finish_action=finish,faraday_center_offset_arcsec=offset)
            if self.folder:
                try:
                    for point in self.points:metadata(Path(point['folder'])/'parameters.txt',point)
                    save_summary(self.folder,self.points,self.info)
                    self.message.emit('Сохранение графиков. Пока AO0 сохраняется.')
                    from report import save_figures
                    save_figures(self.folder,self.points,cancel=self.stop_event)
                except Exception as exc:
                    reason='error';error+='\nОшибка экспорта: '+str(exc);self.info.update(result=reason,error=error)
                    try:save_summary(self.folder,self.points,self.info)
                    except Exception:pass
            if reason=='complete' and self.stop_event.is_set():reason='stopped'
            if reason=='complete' and p.zero_after:
                try:
                    self.info['ao_final']=self.ao.call('write',dict(voltage=0.),self.stop_event)
                    finish='zero_command_confirmed'
                except InterruptedError:reason='stopped'
                except Exception as exc:reason='error';error+='\nAO0 не обнулён: '+str(exc)
            self.info.update(finished=now(),result=reason,error=error,finish_action=finish)
            if self.folder:
                try:save_summary(self.folder,self.points,self.info)
                except Exception as exc:reason='error';error+='\nОшибка конечных метаданных: '+str(exc)
            self.outcome.emit(dict(reason=reason,error=error,finish_action=finish,folder=str(self.folder or ''),points=self.points,
                                   metadata=self.info,unsaved=self.unsaved is not None))
