"""Bounded live buffer, streaming NI file and identical photodiode/Hall windows."""
from collections import deque
from pathlib import Path
import math
import threading
import time
import numpy as np
from models import GAIN


class DAQLost(RuntimeError):pass


class CaptureData:
    def __init__(self):
        self.cv=threading.Condition();self.blocks=deque();self.capture=None
        self.ready=False;self.metadata={};self.generation=0;self.watermark=-math.inf;self.last_received=-math.inf;self.error=''
    def configure(self,metadata):
        with self.cv:
            self.generation+=1;self.metadata=dict(metadata);self.blocks.clear();self.ready=True;self.error=''
            self.watermark=self.last_received=-math.inf
            if self.capture is not None:self.capture['error']='NI переподключена внутри точки.'
            self.cv.notify_all()
    def fail(self,error):
        with self.cv:
            self.ready=False;self.error=str(error)
            if self.capture is not None:self.capture['error']=self.capture.get('error') or str(error)
            self.cv.notify_all()
    def ensure_online(self):
        with self.cv:
            if self.capture and self.capture.get('fatal'):raise OSError(self.capture['error'])
            if (self.capture and self.capture.get('error')) or not self.ready or time.perf_counter()-self.last_received>3:
                raise DAQLost(self.error or (self.capture or {}).get('error') or 'Нет свежих данных NI.')
    def wait_online(self,cancel):
        with self.cv:
            while not (self.ready and self.blocks and time.perf_counter()-self.last_received<3):
                if cancel.is_set():raise InterruptedError('Остановлено при ожидании NI.')
                self.cv.wait(.1)
            return dict(self.metadata)
    def _commit(self,cap,times,data,end):
        mask=(times>=cap['start'])&(times<min(end,cap['end']))
        v=data[:,mask];t=times[mask]
        if not len(t):return
        try:
            rows=np.column_stack((t-cap['start'],v.T,v[0]*GAIN,v[1]*GAIN,cap['calibration'].field(v[2])))
            np.savetxt(cap['file'],rows,delimiter='\t',fmt='%.15g')
        except OSError as exc:
            cap['fatal']=True;cap['error']='Ошибка записи daq.dat: '+str(exc);raise
        cap['n']+=len(t);cap['sum']+=v.sum(axis=1);cap['sum2']+=(v*v).sum(axis=1)
    def append(self,index,data):
        data=np.asarray(data,dtype=float)
        if data.ndim!=2 or data.shape[0]!=3 or not np.isfinite(data).all():raise ValueError('NI: нужен конечный массив AI1/AI0/AI3.')
        if not data.shape[1]:return
        with self.cv:
            rate=self.metadata['sample_rate_Hz'];first=self.metadata['origin_monotonic_s']+index/rate
            times=first+np.arange(data.shape[1])/rate
            self.blocks.append((times,data.copy()))
            while len(self.blocks)>1 and (times[-1]-self.blocks[0][0][0]>60 or len(self.blocks)*data.shape[1]>200000):self.blocks.popleft()
            self.watermark=float(times[-1]);self.last_received=time.perf_counter()
            cap=self.capture
            if cap and cap['generation']==self.generation and not cap.get('error'):
                if cap['pending'] is not None:self._commit(cap,*cap['pending'],cap['end'])
                # Keep the newest block until finish so an early Stop can clip it.
                cap['pending']=(times,data.copy())
            self.cv.notify_all()
    def live(self,seconds,calibration):
        with self.cv:
            if not self.ready or not self.blocks or time.perf_counter()-self.last_received>3:return None
            end=self.watermark;total=np.zeros(3);n=0
            for t,v in reversed(self.blocks):
                mask=t>=end-seconds
                total+=v[:,mask].sum(axis=1);n+=int(mask.sum())
                if t[0]<end-seconds:break
            if not n:return None
            means=total/n
            return dict(ip_V=means[0]*GAIN,im_V=means[1]*GAIN,field_mT=float(calibration.field(means[2])))
    def begin(self,start,end,calibration,folder):
        with self.cv:
            self.ensure_online()
            if self.capture is not None:raise RuntimeError('Окно NI уже открыто.')
            path=Path(folder);path.mkdir(parents=True,exist_ok=True)
            stream=(path/'daq.dat').open('w',encoding='utf-8',newline='\n')
            stream.write('Time_s\tAI1_raw_V\tAI0_raw_V\tAI3_raw_V\tIp_x25p2_V\tIm_x25p2_V\tField_mT\n')
            cap=dict(start=start,end=end,generation=self.generation,metadata=dict(self.metadata),file=stream,
                     calibration=calibration,n=0,sum=np.zeros(3),sum2=np.zeros(3),pending=None,error='')
            self.capture=cap
            for times,data in self.blocks:
                if times[-1]>=start:self._commit(cap,times,data,end)
    def running_means(self):
        with self.cv:
            cap=self.capture
            if not cap:return None
            sums=cap['sum'].copy();n=cap['n']
            if cap['pending'] is not None:
                t,v=cap['pending'];mask=(t>=cap['start'])&(t<cap['end'])
                sums+=v[:,mask].sum(axis=1);n+=int(mask.sum())
            return (float(sums[0]/n*GAIN),float(sums[1]/n*GAIN)) if n else None
    def finish(self,end=None,timeout=2):
        with self.cv:
            cap=self.capture
            if cap is None:raise RuntimeError('Окно NI не открыто.')
            end=min(cap['end'],time.perf_counter() if end is None else end)
            deadline=time.perf_counter()+timeout
            while self.ready and not cap.get('error') and self.watermark<end and time.perf_counter()<deadline:self.cv.wait(.05)
            self.capture=None
            try:
                if cap['pending'] is not None and not cap.get('fatal'):self._commit(cap,*cap['pending'],end)
            except OSError as exc:
                cap['fatal']=True;cap['error']='Ошибка записи daq.dat: '+str(exc)
            finally:cap['file'].close()
            means=cap['sum']/cap['n'] if cap['n'] else np.full(3,np.nan)
            valid=self.ready and not cap.get('error') and cap['generation']==self.generation and self.watermark>=end and cap['n']>0
            return dict(valid=bool(valid),samples=cap['n'],ip_raw_mean_V=float(means[0]),im_raw_mean_V=float(means[1]),
                hall_mean_V=float(means[2]),ip_mean_V=float(means[0]*GAIN),im_mean_V=float(means[1]*GAIN),
                field_mean_mT=float(cap['calibration'].field(means[2])),gain=GAIN,
                start_monotonic_s=cap['start'],end_monotonic_s=end,ni_generation=cap['generation'],ni=cap['metadata'],
                fatal_error=bool(cap.get('fatal')),
                error='' if valid else cap.get('error') or self.error or 'Нет полного покрытия окна NI.')
