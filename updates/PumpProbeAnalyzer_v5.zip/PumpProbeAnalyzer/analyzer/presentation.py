"""Presentation settings shared by the interactive plots and saved figures."""
from dataclasses import dataclass
import math
import numpy as np


def angle_unit(values):
    """Choose an engineering prefix; the stored arrays always remain radians."""
    values=np.asarray(values,dtype=float)
    finite=np.abs(values[np.isfinite(values)])
    magnitude=float(np.max(finite)) if finite.size else 0
    if magnitude == 0: return 1.0,'rad'
    for factor,unit in ((1.,'rad'),(1e-3,'mrad'),(1e-6,'µrad'),(1e-9,'nrad'),
                        (1e-12,'prad'),(1e-15,'frad'),(1e-18,'arad')):
        if magnitude >= factor: return factor,unit
    return 1e-18,'arad'


def angle_text(value):
    factor,unit=angle_unit([value])
    return f'{value/factor:.4g} {unit}'


@dataclass(frozen=True)
class PlotStyle:
    experiment_label: str = 'X1 experiment'
    fit_label: str = ''
    show_legend: bool = True
    time_ylim: tuple = None
    fft_ylim: tuple = None
    time_unit: str = 'ns'

    @property
    def time_factor(self):
        return {'ns':1e-9,'ps':1e-12}[self.time_unit]

    def validate(self):
        if self.time_unit not in ('ns','ps'):
            raise ValueError('Единицы времени: ns или ps')
        for limits in (self.time_ylim, self.fft_ylim):
            if limits is not None and (len(limits) != 2 or
                    not all(math.isfinite(v) for v in limits) or limits[0] >= limits[1]):
                raise ValueError('Границы Y должны быть конечными числами: минимум < максимум')
        return self


def parameter_label(result, time_unit='ns'):
    if result is None:
        return ''
    lines = []
    for i in range((len(result.parameters)-1)//4):
        a, f, phase, tau = result.parameters[4*i:4*i+4]
        factor={'ns':1e-9,'ps':1e-12}[time_unit]
        lines.append(f'A{i+1}={angle_text(a)}; f{i+1}={f/1e9:.5g} GHz; φ{i+1}={phase:.4g}; τ{i+1}={tau/factor:.5g} {time_unit}')
    lines.append(f'C={angle_text(result.parameters[-1])}; R²={result.r_squared:.5g}')
    return '\n'.join(lines)
