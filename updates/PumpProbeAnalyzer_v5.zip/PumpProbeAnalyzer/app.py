#!/usr/bin/env python3
"""Run: python app.py [--demo]. No equipment connection is required."""
import argparse
import sys
from pathlib import Path
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtWidgets import QApplication
from analyzer.ui import AnalysisWindow


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--demo', action='store_true')
    args = parser.parse_args()
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication(sys.argv[:1]); app.setStyle('Fusion')
    window = AnalysisWindow(); window.show()
    if args.demo:
        window.bal.setText('-100'); window.sig.setText('100')
        base = Path(__file__).resolve().parent/'examples'
        QTimer.singleShot(0, lambda: window.load_paths(base/'demo.dat', base/'demo.comments.txt'))
    return app.exec_()


if __name__ == '__main__':
    sys.exit(main())
