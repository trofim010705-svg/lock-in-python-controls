"""Live dual-channel Matplotlib figure; exports the same canvas the user edits."""
from io import BytesIO
import numpy as np
from PIL import Image
from PyQt5.QtCore import Qt, QEvent, QTimer, pyqtSignal
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QScrollArea
from matplotlib.figure import Figure
from matplotlib.font_manager import FontProperties
from matplotlib.mathtext import MathTextParser
from matplotlib.ticker import FuncFormatter
from matplotlib.widgets import SpanSelector
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from .figure_editor import FigureEditor, _Toolbar
from .presentation import model_mathtext, angle_unit
from .core import evaluate
from .export import spectral_peaks


def engineering(value, unit):
    factor, prefix=angle_unit([value])
    return f'{value/factor:.6g} {prefix[:-3]+unit}' if prefix.endswith('rad') else f'{value:.6g} {unit}'


def _parameter_text(prepared, result, unit, channel, time_unit, band):
    tf=1e-9 if time_unit=='ns' else 1e-12
    lines=[channel]
    if result is None:
        lines.append('Фит ещё не рассчитан.')
    else:
        def quantity(v,e,scale,u):
            error=f'{e/scale:.3g}' if np.isfinite(e) else '—'
            return f'{v/scale:.6g} ± {error} {u}'
        lines.append(f't_ref = {result.reference_s/tf:.6g} {time_unit}')
        for i in range((len(result.parameters)-1)//4):
            a,f,ph,tau=result.parameters[4*i:4*i+4]
            ea,ef,ep,et=result.errors[4*i:4*i+4]
            scale,prefix=angle_unit([a]); aunit=prefix[:-3]+unit
            lines.extend([f'A{i+1} = {quantity(a,ea,scale,aunit)}; f{i+1} = {quantity(f,ef,1e9,"GHz")}',
                          f'τ{i+1} = {quantity(tau,et,tf,time_unit)}; φ{i+1} = {quantity(ph,ep,1.,"rad")}'])
        scale,prefix=angle_unit([result.parameters[-1]])
        lines.append(f'C = {quantity(result.parameters[-1],result.errors[-1],scale,prefix[:-3]+unit)}; R² = {result.r_squared:.6g}')
        lines.append(f'RMSE = {engineering(result.rmse_rad,unit)}')
    lines.append('FFT: f, амплитуда, FWHM по A/2')
    peaks=spectral_peaks(prepared,band)
    for peak in peaks:
        width=peak.get('fwhm_hz')
        width_text=f'{width/1e9:.6g} GHz' if width is not None else '—'
        lines.append(f'{peak["rank"]}: {peak["frequency_hz"]/1e9:.6g} GHz; A = {engineering(peak["amplitude_rad"],unit)}')
        lines.append(f'    FWHM = {width_text}')
    if not peaks:lines.append('Пики недоступны в выбранной полосе.')
    return '\n'.join(lines)


class _DualSelector(SpanSelector):
    def __init__(self,owner,**kwargs):
        self.owner=owner
        super().__init__(**kwargs)
    def ignore(self,event):
        return bool(self.owner.toolbar.mode) or super().ignore(event)


class DualFigure(QWidget):
    band_changed=pyqtSignal(int,tuple)
    title_validation_error=pyqtSignal(str)
    save_requested=pyqtSignal()
    title_edit_requested=pyqtSignal()
    labels_validation_error=pyqtSignal(str)
    labels_edit_requested=pyqtSignal(str)

    def __init__(self,parent=None):
        super().__init__(parent)
        self.title_size,self.body_size=14.,8.
        self._math_parser=MathTextParser('path')
        self._summary='';self._columns=('','');self._formulas=('','')
        self._layout_running=False;self._layout_queued=False
        self._normalized_visible=True;self._ready_normalized=False;self._footer_visible=True
        self._alphas=(.55,.55);self._prepared=None;self._results=(None,None)
        self._time_unit='ns'
        self._labels=self.default_labels();self._fit_visible=(True,True)
        self._diagnostics={}
        self.figure=Figure(figsize=(12,12),dpi=100,facecolor='white',layout='constrained')
        self.canvas=FigureCanvasQTAgg(self.figure)
        self.canvas.setMinimumWidth(620)
        self.scroll=QScrollArea();self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QScrollArea.NoFrame);self.scroll.setWidget(self.canvas)
        self.scroll.viewport().installEventFilter(self)
        self.toolbar=_Toolbar(self.canvas,self)
        layout=QVBoxLayout(self);layout.setContentsMargins(0,0,0,0)
        layout.addWidget(self.toolbar);layout.addWidget(self.scroll,1)
        self.grid=self.figure.add_gridspec(7,2,height_ratios=[250]*5+[240,180])
        self.time_axes=[self.figure.add_subplot(self.grid[i,0]) for i in (0,3)]
        self.fft_axes=[self.figure.add_subplot(self.grid[i,1]) for i in (0,3)]
        self.diagnostic_time_axes={key:self.figure.add_subplot(self.grid[row,0]) for key,row in (('x2',1),('y2',2),('phase2',4))}
        self.diagnostic_fft_axes={key:self.figure.add_subplot(self.grid[row,1]) for key,row in (('x2',1),('y2',2),('phase2',4))}
        self.normalized_axes=self.figure.add_subplot(self.grid[5,:])
        self.footer_axes=self.figure.add_subplot(self.grid[6,:]);self.footer_axes.set_axis_off()
        self.title_artist=self.figure.suptitle('Pump–probe · X1 / R2',fontsize=self.title_size,color='#25435d')
        self.formula_artists=[self.footer_axes.text(x,.99,'',transform=self.footer_axes.transAxes,va='top',ha='left',parse_math=True,color='#25435d') for x in (.01,.52)]
        self.column_artists=[self.footer_axes.text(x,.8,'',transform=self.footer_axes.transAxes,va='top',ha='left',parse_math=False,linespacing=1.35,color='#243b50') for x in (.01,.52)]
        self.summary_artist=self.footer_axes.text(.01,.2,'',transform=self.footer_axes.transAxes,va='top',ha='left',parse_math=False,linespacing=1.35,color='#243b50')
        self.point_artists=[];self.fit_artists=[];self.spectrum_artists=[];self.peak_artists=[]
        self.normalized_points=[];self.normalized_fits=[];self.selectors=[]
        for i,color in enumerate(('#147c9c','#d66b30')):
            axis=self.time_axes[i]
            self.point_artists.append(axis.plot([],[],ls='none',marker='o',ms=3,color=color,alpha=self._alphas[i],mew=0)[0])
            self.fit_artists.append(axis.plot([],[],lw=1.8,color=color,alpha=1)[0])
            self.spectrum_artists.append(self.fft_axes[i].plot([],[],lw=1.3,color=color)[0])
            self.peak_artists.append(self.fft_axes[i].plot([],[],ls='none',marker='o',ms=4,color='#a23153')[0])
            self.normalized_points.append(self.normalized_axes.plot([],[],ls='none',marker='o',ms=3,color=color,alpha=self._alphas[i],mew=0,label=('X1','R2')[i])[0])
            self.normalized_fits.append(self.normalized_axes.plot([],[],color=color,lw=1.8,alpha=1)[0])
            self.selectors.append(_DualSelector(self,ax=self.fft_axes[i],onselect=lambda lo,hi,j=i:self._band_selected(j,lo,hi),
                direction='horizontal',interactive=True,drag_from_anywhere=True,useblit=False,button=1,
                props=dict(facecolor='#1aa5a2',alpha=.12),handle_props=dict(color='#37a7a5',linewidth=.9)))
        self.diagnostic_points={};self.diagnostic_spectra={};self.diagnostic_peaks={}
        for key,color in (('x2','#287d9c'),('y2','#7a55a3'),('phase2','#3b8d69')):
            self.diagnostic_points[key]=self.diagnostic_time_axes[key].plot([],[],ls='none',marker='o',ms=3,color=color,mew=0)[0]
            self.diagnostic_spectra[key]=self.diagnostic_fft_axes[key].plot([],[],color=color,lw=1.3)[0]
            self.diagnostic_peaks[key]=self.diagnostic_fft_axes[key].plot([],[],ls='none',marker='o',ms=4,color='#a23153')[0]
        self.axes_by_id={'x1':self.time_axes[0],'x1_fft':self.fft_axes[0],
            'r2':self.time_axes[1],'r2_fft':self.fft_axes[1],'normalized':self.normalized_axes}
        for key in self.diagnostic_time_axes:
            self.axes_by_id[key]=self.diagnostic_time_axes[key]
            self.axes_by_id[key+'_fft']=self.diagnostic_fft_axes[key]
        for key,axis in self.axes_by_id.items():axis._graph_id=key
        for axis in self.axes_by_id.values():
            axis.grid(True,alpha=.17);axis.tick_params(labelsize=9,colors='#354b60')
            for spine in axis.spines.values():spine.set_color('#afbdc9')
        self._units=['rad','V']
        for i in range(2):
            for axis,caption in ((self.time_axes[i],('X1','R2')[i]),(self.fft_axes[i],'FFT '+('X1','R2')[i])):
                axis._dual_caption=caption;axis._dual_unit=self._units[i]
                axis.yaxis.set_major_formatter(FuncFormatter(lambda value,pos,a=axis:self._yformat(a,value)))
                axis.callbacks.connect('ylim_changed',self._ylabel)
                axis.set_title(caption,fontsize=11,color='#25435d')
        for key in self.diagnostic_time_axes:
            for axis in (self.diagnostic_time_axes[key],self.diagnostic_fft_axes[key]):
                axis._dual_unit='rad' if key=='phase2' else 'V'
                axis.yaxis.set_major_formatter(FuncFormatter(lambda value,pos,a=axis:self._yformat(a,value)))
                axis.callbacks.connect('ylim_changed',self._ylabel)
        self._apply_labels()
        self.canvas.mpl_connect('button_press_event',self._pressed)
        self.set_normalized_visible(True)
        self._layout_footer()

    @staticmethod
    def default_labels():
        labels={}
        names={'x1':'X1','x2':'X2','y2':'Y2','r2':'R2',
               'phase2':r'$\varphi_2(t)$'}
        for key,name in names.items():
            labels.update({key+'.title':name,key+'.xlabel':'Задержка ({time_unit})',
                           key+'.ylabel':name+' ({unit})'})
            labels.update({key+'_fft.title':'FFT '+name,key+'_fft.xlabel':'Частота (GHz)',
                           key+'_fft.ylabel':'FFT '+name+' ({unit})'})
        labels.update({'normalized.title':'Нормированные осцилляции · C вычтен',
            'normalized.xlabel':'Задержка ({time_unit})','normalized.ylabel':'a.u.',
            'legend.x1_points':'X1 experiment','legend.r2_points':'R2 experiment',
            'legend.x1_fit':'X1 fit','legend.r2_fit':'R2 fit',
            'channel.x1':'X1','channel.r2':'R2 = √(X2² + Y2²)'})
        return labels

    def _expanded_label(self,text,unit=''):
        return FigureEditor.normalize_mathtext(str(text).replace('{unit}',unit).replace('{time_unit}',self._time_unit))

    def set_labels(self,mapping):
        candidate=dict(self._labels)
        try:
            unknown=set(mapping)-set(candidate)
            if unknown:raise ValueError('Неизвестная подпись: '+', '.join(sorted(unknown)))
            candidate.update({key:str(value) for key,value in mapping.items()})
            for key,value in candidate.items():
                if key.startswith('channel.'):continue  # plain text in numeric footer
                expanded=self._expanded_label(value,'µV')
                for line in expanded.splitlines() or ['']:
                    self._math_parser.parse(line,dpi=self.figure.dpi,prop=FontProperties(size=self.title_size))
        except (ValueError,TypeError) as exc:
            self.labels_validation_error.emit('Ошибка подписи: '+str(exc));return False
        self._labels=candidate
        if self._columns and self._columns[0]:
            self._columns=[self._labels['channel.'+key]+'\n'+text.partition('\n')[2]
                           for key,text in zip(('x1','r2'),self._columns)]
        self._apply_labels();self._layout_footer();self.canvas.draw_idle()
        self.labels_validation_error.emit('');return True

    def _apply_axis_labels(self,axis,unit=None):
        key=axis._graph_id
        if unit is None:
            if key=='normalized':unit='a.u.'
            else:
                _,prefix=angle_unit(axis.get_ylim())
                unit=prefix[:-3]+axis._dual_unit
        title=self._labels[key+'.title']
        if key=='normalized' and not self._ready_normalized and title==self.default_labels()[key+'.title']:
            title='Нормирование появится после обоих фитов'
        axis.set_title(self._expanded_label(title,unit),fontsize=11,color='#25435d',parse_math=True)
        xunit='GHz' if key.endswith('_fft') else self._time_unit
        axis.set_xlabel(self._expanded_label(self._labels[key+'.xlabel'],xunit),fontsize=10,parse_math=True)
        axis.set_ylabel(self._expanded_label(self._labels[key+'.ylabel'],unit),fontsize=10,color='#354b60',parse_math=True)

    def _apply_labels(self):
        for axis in self.axes_by_id.values():self._apply_axis_labels(axis)
        self._refresh_legend()

    def _refresh_legend(self):
        handles=[];labels=[];keys=[]
        for i,name in enumerate(('x1','r2')):
            key='legend.'+name+'_points'
            if self._labels[key]:
                handles.append(self.normalized_points[i]);labels.append(self._expanded_label(self._labels[key]));keys.append(key)
            key='legend.'+name+'_fit'
            if self._fit_visible[i] and self._ready_normalized and self._labels[key]:
                handles.append(self.normalized_fits[i]);labels.append(self._expanded_label(self._labels[key]));keys.append(key)
        self._legend_keys=keys
        previous=self.normalized_axes.get_legend()
        if previous is not None:previous.remove()
        if handles:self.normalized_axes.legend(handles,labels,loc='upper right',fontsize=8,framealpha=.8)

    def set_fit_visible(self,first=True,second=True):
        self._fit_visible=(bool(first),bool(second))
        for i,visible in enumerate(self._fit_visible):
            self.fit_artists[i].set_visible(visible);self.normalized_fits[i].set_visible(visible)
        self._refresh_legend();self.canvas.draw_idle()

    def set_footer_visible(self,visible):
        self._footer_visible=bool(visible)
        self.footer_axes.set_visible(self._footer_visible);self.footer_axes.set_in_layout(self._footer_visible)
        self._layout_footer();self.canvas.draw_idle()

    def _draw_diagnostics(self,time_factor):
        for key in self.diagnostic_time_axes:
            p=self._diagnostics.get(key)
            points=self.diagnostic_points[key];spectrum=self.diagnostic_spectra[key];peaks=self.diagnostic_peaks[key]
            if p is None:
                for artist in (points,spectrum,peaks):artist.set_data([],[])
                continue
            visible=p.fit_mask if p.fit_mask.sum()>=8 else np.ones(len(p.time),dtype=bool)
            points.set_data(p.time[visible]/time_factor,p.y[visible])
            spectrum.set_data(p.frequencies/1e9,p.spectrum)
            selected=np.flatnonzero((p.frequencies>0)&np.isfinite(p.spectrum))
            if len(selected) and np.max(p.spectrum[selected])>np.finfo(float).tiny:
                maximum=selected[np.argmax(p.spectrum[selected])]
                peaks.set_data([p.frequencies[maximum]/1e9],[p.spectrum[maximum]])
            else:peaks.set_data([],[])
            for axis in (self.diagnostic_time_axes[key],self.diagnostic_fft_axes[key]):
                axis.relim();axis.autoscale(enable=True);self._ylabel(axis)
            if len(selected) and np.max(p.spectrum[selected])>np.finfo(float).tiny:
                frequency=float(p.frequencies[maximum])
                width=max(2*p.resolution_hz,.35*frequency)
                self.diagnostic_fft_axes[key].set_xlim(max(0.,frequency-width)/1e9,
                    min(p.nyquist_hz,frequency+width)/1e9)

    def _pressed(self,event):
        if not event.dblclick:return
        if self.title_artist.contains(event)[0]:self.title_edit_requested.emit();return
        for key,axis in self.axes_by_id.items():
            for suffix,artist in (('title',axis.title),('xlabel',axis.xaxis.label),('ylabel',axis.yaxis.label)):
                if artist.get_text() and artist.contains(event)[0]:
                    self.labels_edit_requested.emit(key+'.'+suffix);return
        legend=self.normalized_axes.get_legend()
        if legend is not None:
            for text,key in zip(legend.get_texts(),getattr(self,'_legend_keys',[])):
                if text.contains(event)[0]:self.labels_edit_requested.emit(key);return

    def _band_selected(self,index,low,high):
        if self._prepared is None:return
        high=min(float(high),[self._prepared.first,self._prepared.second][index].nyquist_hz/1e9)
        low=max(0.,float(low))
        if low<high:self.band_changed.emit(index,(low*1e9,high*1e9))

    def _yformat(self,axis,value):
        scale,_=angle_unit(axis.get_ylim())
        return f'{value/scale:.6g}'

    def _ylabel(self,axis):
        _,prefix=angle_unit(axis.get_ylim())
        self._apply_axis_labels(axis,unit=prefix[:-3]+axis._dual_unit)

    def set_title(self,text):
        try:
            normalized=FigureEditor.normalize_mathtext(text)
            for line in normalized.splitlines() or ['']:
                self._math_parser.parse(line,dpi=self.figure.dpi,prop=FontProperties(size=self.title_size))
        except (ValueError,TypeError) as exc:
            self.title_validation_error.emit('Title: '+str(exc));return False
        self.title_artist.set_text(normalized);self.title_validation_error.emit('');self.canvas.draw_idle();return True

    def set_fonts(self,title_size,body_size):
        self.title_size,self.body_size=float(title_size),float(body_size)
        self.title_artist.set_fontsize(self.title_size)
        self._layout_footer();self.canvas.draw_idle()

    def set_alphas(self,first,second):
        self._alphas=tuple(float(np.clip(x,0,1)) for x in (first,second))
        for i,a in enumerate(self._alphas):
            self.point_artists[i].set_alpha(a);self.normalized_points[i].set_alpha(a)
            self.fit_artists[i].set_alpha(1.);self.normalized_fits[i].set_alpha(1.)
        self.canvas.draw_idle()

    def set_normalized_visible(self,visible):
        self._normalized_visible=bool(visible)
        self.normalized_axes.set_visible(self._normalized_visible)
        self.normalized_axes.set_in_layout(self._normalized_visible)
        self._apply_axis_labels(self.normalized_axes)
        self._refresh_legend()
        self._layout_footer();self.canvas.draw_idle()

    def set_summary_text(self,text):
        self._summary=str(text);self._layout_footer();self.canvas.draw_idle()

    def set_data(self,prepared,results,bands,comparison=None,components=(1,1),time_unit='ns',annotation='',normalized=True,pair=(0,0),diagnostics=None):
        self._prepared=prepared;self._results=tuple(results);self._time_unit=time_unit
        self._diagnostics=diagnostics or {}
        tf=1e-9 if time_unit=='ns' else 1e-12
        self._units=[prepared.first_unit,prepared.second_unit]
        self._columns=[];self._formulas=[]
        for i,(p,result,unit,band,count) in enumerate(zip((prepared.first,prepared.second),results,self._units,bands,components)):
            mask=p.fit_mask if np.count_nonzero(p.fit_mask)>=8 else np.ones(len(p.time),bool)
            self.point_artists[i].set_data(p.time[mask]/tf,p.y[mask])
            self.fit_artists[i].set_data([],[])
            if result is not None and np.any(p.fit_mask):
                dense=np.linspace(p.time[p.fit_mask][0],p.time[p.fit_mask][-1],1500)
                self.fit_artists[i].set_data(dense/tf,evaluate(dense,result.parameters,result.reference_s))
            self.spectrum_artists[i].set_data(p.frequencies/1e9,p.spectrum)
            peaks=spectral_peaks(p,band)
            self.peak_artists[i].set_data([x['frequency_hz']/1e9 for x in peaks],[x['amplitude_rad'] for x in peaks])
            for axis in (self.time_axes[i],self.fft_axes[i]):
                axis._dual_unit=unit;axis.relim();axis.autoscale(enable=True);self._ylabel(axis)
            self.time_axes[i].set_xlabel(f'Задержка ({time_unit})',fontsize=10)
            self.fft_axes[i].set_xlabel('Частота (GHz)',fontsize=10)
            self.selectors[i].extents=(band[0]/1e9,band[1]/1e9)
            self.selectors[i].set_visible(True)
            lo=max(0,band[0]-.25*(band[1]-band[0]));hi=min(max(p.nyquist_hz,band[1]),band[1]+.25*(band[1]-band[0]))
            if lo<hi:self.fft_axes[i].set_xlim(lo/1e9,hi/1e9)
            self._columns.append(_parameter_text(p,result,unit,(self._labels['channel.x1'],self._labels['channel.r2'])[i],time_unit,band))
            n=(len(result.parameters)-1)//4 if result is not None else count
            symbol=r'\theta_1' if i==0 else (r'R_2' if unit=='V' else r'\theta_2')
            self._formulas.append(model_mathtext(n).replace(r'\theta',symbol,1))
        self._ready_normalized=all(r is not None for r in results)
        for line in (*self.normalized_points,*self.normalized_fits):line.set_data([],[])
        if self._ready_normalized:
            from .dual_core import normalize_signals
            for i,(p,r) in enumerate(zip((prepared.first,prepared.second),results)):
                try:
                    values,_,scale=normalize_signals(p,r)
                    mask=p.fit_mask
                    self.normalized_points[i].set_data(p.time[mask]/tf,np.asarray(values)[mask])
                    dense=np.linspace(p.time[mask][0],p.time[mask][-1],1500)
                    self.normalized_fits[i].set_data(dense/tf,(evaluate(dense,r.parameters,r.reference_s)-r.parameters[-1])/scale)
                except ValueError:pass
        self.normalized_axes.relim();self.normalized_axes.autoscale(enable=True)
        self.normalized_axes.set_xlabel(f'Задержка ({time_unit})',fontsize=10)
        self.normalized_axes.set_title('Нормированные осцилляции · C вычтен' if self._ready_normalized else 'Нормирование появится после обоих фитов',fontsize=11,color='#25435d')
        if annotation:self._summary=annotation
        self._draw_diagnostics(tf)
        self.set_normalized_visible(normalized)
        self.set_fit_visible(*self._fit_visible)
        self._apply_labels()
        self._layout_footer();self.canvas.draw_idle()

    def clear_data(self):
        """Remove a previous measurement while retaining the editable Title and style."""
        self._prepared=None;self._results=(None,None);self._ready_normalized=False;self._diagnostics={}
        self._columns=('','');self._formulas=('','');self._summary=''
        for artist in (*self.point_artists,*self.fit_artists,*self.spectrum_artists,
                       *self.peak_artists,*self.normalized_points,*self.normalized_fits):
            artist.set_data([],[])
        for artist in (*self.diagnostic_points.values(),*self.diagnostic_spectra.values(),*self.diagnostic_peaks.values()):artist.set_data([],[])
        for selector in self.selectors:selector.set_visible(False)
        self.set_normalized_visible(self._normalized_visible)
        self._layout_footer();self.canvas.draw_idle()

    def eventFilter(self,watched,event):
        if hasattr(self,'scroll') and watched is self.scroll.viewport() and event.type()==QEvent.Resize and not self._layout_queued:
            self._layout_queued=True;QTimer.singleShot(0,self._queued_layout)
        return super().eventFilter(watched,event)

    def _queued_layout(self):
        self._layout_queued=False;self._layout_footer();self.canvas.draw_idle()

    def _layout_footer(self):
        if self._layout_running:return
        self._layout_running=True
        try:
            renderer=self.canvas.get_renderer();ratio=max(1.,self.canvas.devicePixelRatioF())
            width=max(self.canvas.minimumWidth(),self.scroll.viewport().width())-110
            font=FontProperties(size=self.body_size)
            def measure(text,prop=font,math=False):return renderer.get_text_width_height_descent(text,prop,ismath=math)[0]/ratio if text else 0.
            colwidth=max(30,width*.46)
            def wrap(text,limit):
                lines=[]
                for original in text.split('\n'):
                    rest=original
                    if not rest:lines.append('');continue
                    while rest:
                        if measure(rest)<=limit:lines.append(rest);break
                        low,high=1,len(rest)
                        while low<high:
                            middle=(low+high+1)//2
                            if measure(rest[:middle])<=limit:low=middle
                            else:high=middle-1
                        length=low;space=rest.rfind(' ',0,length+1)
                        if space>0:length=space
                        lines.append(rest[:length].rstrip());rest=rest[length:].lstrip()
                return '\n'.join(lines)
            cols=[wrap(text,colwidth) for text in self._columns]
            while len(cols)<2:cols.append('')
            summary=wrap(self._summary,width*.97)
            formula_height=0
            for i in range(2):
                formula=self._formulas[i] if len(self._formulas)>i else ''
                size=self.body_size+2;prop=FontProperties(size=size)
                fw=measure(formula,prop,True)
                if fw>colwidth:size=max(1.,size*colwidth/fw)
                prop=FontProperties(size=size)
                fh=renderer.get_text_width_height_descent(formula,prop,ismath=True)[1]/ratio if formula else 0
                formula_height=max(formula_height,fh*1.3)
                self.formula_artists[i].set_text(formula);self.formula_artists[i].set_fontsize(size)
            lineheight=self.body_size*self.figure.dpi/(72*ratio)*1.45
            column_lines=max([len(c.splitlines()) for c in cols]+[1])
            summary_lines=len(summary.splitlines()) if summary else 0
            footer_height=35+formula_height+(column_lines+summary_lines+2)*lineheight
            rowheight=250 if self._normalized_visible else 1
            self.grid.set_height_ratios([250]*5+[rowheight,footer_height if self._footer_visible else .001])
            self.canvas.setMinimumHeight(int(1700+(250 if self._normalized_visible else 0)+(footer_height if self._footer_visible else 0)+210))
            for artist,text in zip(self.column_artists,cols):
                artist.set_text(text);artist.set_fontsize(self.body_size)
                artist.set_y(1-(formula_height+12)/footer_height)
            self.summary_artist.set_text(summary);self.summary_artist.set_fontsize(self.body_size)
            self.summary_artist.set_y(1-(formula_height+18+(column_lines+1)*lineheight)/footer_height)
        finally:self._layout_running=False

    def render(self):
        self._layout_footer();self.canvas.draw()

    def capture_images(self,formats=('png',)):
        self.render();result={}
        if 'png' in formats:
            buffer=BytesIO();Image.fromarray(np.asarray(self.canvas.buffer_rgba()).copy()).save(buffer,format='PNG');result['png']=buffer.getvalue()
        engine=self.figure.get_layout_engine();self.figure.set_layout_engine(None)
        try:
            for fmt in formats:
                if fmt=='png':continue
                if fmt not in ('pdf','svg'):raise ValueError('Доступны PNG/PDF/SVG')
                buffer=BytesIO();self.figure.savefig(buffer,format=fmt,dpi=self.figure.dpi,facecolor='white');result[fmt]=buffer.getvalue()
        finally:self.figure.set_layout_engine(engine)
        return result
